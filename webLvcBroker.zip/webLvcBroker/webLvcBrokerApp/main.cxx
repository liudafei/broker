/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file main.cxx
//! \brief Contains the application entry point for the WebLVC Broker.
//! \ingroup webLvcBrokerApp

#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <webLvcBroker/webLvcBrokerDialog.h>
#include <vlutil/vlExceptions.h>
#include <vlutil/vlMiniDumper.h>
#include <widgets/brokerApp.h>
#include <iostream>

#ifdef _WIN32
#include <windows.h>
#include <fcntl.h>
#include <io.h>
#endif

#ifdef __fedora7__
#include <string.h>
#include <errno.h>
#include <stdio.h>
#endif

// Add a console out if necessary (for windows help)
void allocateConsole()
{
#if _WIN32
   int hConInHandle;
   long lStdInHandle;
   FILE *fp;

   AllocConsole();

   freopen("CON", "w", stdout);
   freopen("CON", "w", stderr);

   lStdInHandle= (long)GetStdHandle(STD_INPUT_HANDLE);
   hConInHandle = _open_osfhandle(lStdInHandle, _O_TEXT);
   fp = _fdopen( hConInHandle, "r" );
   *stdin = *fp;
#endif
}

int main( int argc, char* argv[] )
{
   DtINIT_MINIDUMPER( "WebLVC Broker" );

#ifdef __fedora7__
   // On some Linux distributions (i.e. Fedora), the SESSION_MANAGER variable is set
   // incorrectly when the user is running in certain environments such
   // as GNOME or possibly KDE. This causes strange behavior with Qt
   // if the variable is found at at application startup as Qt attempts
   // to make an SmcOpenConnection call using the information from
   // SESSION_MANAGER, but the SmcOpenConnection call will silently
   // fail for the child brokers started from VRX as the environment
   // of VRX is passed to the children.

   // Session management via XSMP/DBUS is for allowing a session
   // manager application like gnome-session to manage the state of
   // applications, and is unnecessary for VRX operation.

   // An alternative to unsetting this SESSION_MANAGER variable would
   // be to modify the variable so that it correctly points to the
   // local hostname for its ICE socket, as Fedora Core incorrectly
   // sets the hostname in the variable to 'unix'
   if ( unsetenv("SESSION_MANAGER") == 0 )
   {
      DtInfo << "Unset SESSION_MANAGER environment variable\n";
      std::cout << "Unset SESSION_MANAGER environment variable\n";
   }
   else
   {
      DtWarn << "Could not unset the SESSION_MANAGER environment variable: "
         << strerror(errno) << std::endl;
      std::cout << "Could not unset the SESSION_MANAGER environment variable: "
         << strerror(errno) << std::endl;
   }
#endif

   try
   {
      using namespace MAKVrExchange;
      using namespace MAKVrExchange::DtWebLvcBroker;

      int argCount = 1;
      while ( argCount < argc )
      {
         if ( strstr(argv[argCount],"-h") || strstr(argv[argCount],"--help")
            || strstr(argv[argCount],"-v") || strstr(argv[argCount],"--version") )
         {
            allocateConsole();
            break;
         }
         argCount++;
      }

      // Load the configuration options
      DtWebLvcBrokerInitializer* webLvcInit = new DtWebLvcBrokerInitializer( argc, argv );
      webLvcInit->parseCmdLine();

      DtBrokerApp::setBrokerCreator( MAKVrExchange::DtWebLvcBroker::DtWebLvcBroker::create );
      DtBrokerApp::setBrokerDialogCreator( DtWebLvcBrokerDialog::create );
      DtBrokerApp* brokerApp = new DtBrokerApp( webLvcInit );

      // Run the broker.
      webLvcInit->setDarkModeEnabled(webLvcInit->darkModeEnabled());
      brokerApp->run( webLvcInit->showConnectionInfoDialog() );

      DtDELETE( brokerApp );
   }
   catch ( DtException& es )
   {
      std::cerr << "WebLVC Broker exiting with DtException: " << es << std::endl;
      DtFatal << "WebLVC Broker exiting with DtException: " << es << std::endl;
   }
   catch ( const std::exception& ex )
   {
      std::cerr << "WebLVC Broker exiting with std::exception: " << ex.what() << std::endl;
      DtFatal << "WebLVC Broker exiting with std::exception: " << ex.what() << std::endl;
   }
   catch ( ... )
   {
      std::cerr << "WebLVC Broker exiting with unknown exception." << std::endl;
      DtFatal << "WebLVC Broker exiting with unknown exception." << std::endl;
   }

   return 0;
}

