/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcVersion.h
//! \brief Declares manifest constants which define the release number of MAKWebLVCServer.
//! \ingroup webLvcBrokerApp

#pragma once

#define PORTAL_VERSION_STRING "1.7"
#define PORTAL_MAJOR_VERSION 1
#define PORTAL_MINOR_VERSION 7
#define PORTAL_REVISION      0

//! This will be incremented for each WebLVC release
//! Release Num 1 = 1.0
//! Release Num 2 = 1.1
//! Release Num 3 = 1.2
//! Release Num 4 = 1.3
//! Release Num 5 = 1.4
//! Release Num 6 = 1.5
//! Release Num 6 = 1.6
//! Release Num 7 = 1.6.1

#define PORTAL_RELEASE_NUM 8
