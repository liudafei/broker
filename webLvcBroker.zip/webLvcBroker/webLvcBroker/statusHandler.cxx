/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file statusHandler.cxx
//! \brief Contains the DtStatusRequestHandler class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/baseWebLvcInteractionTranslator.h>
#include <webLvcBroker/baseWebLvcObjectTranslator.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <webLvcBroker/webSocketClient.h>
#include <webLvcBroker/statusHandler.h>
#include <webLvcBroker/webLvcBroker.h>
#include <Poco/Net/HTTPServerResponse.h>
#include <Poco/Net/HTTPServerRequest.h>
#include <Poco/Net/HTTPClientSession.h>
#include <Poco/Net/NetException.h>
#include <Poco/StreamCopier.h>
#include <Poco/RWLock.h>
#include <vlutil/vlPrint.h>
#include <json/json.h>
#include <iostream>

using Poco::Net::HTTPRequestHandler;
using Poco::Net::HTTPServerResponse;
using Poco::Net::WebSocketException;
using Poco::Net::HTTPClientSession;
using Poco::Net::HTTPServerRequest;
using Poco::Net::HTTPResponse;
using Poco::Net::HTTPRequest;
using Poco::Net::WebSocket;
using Poco::StreamCopier;
using Poco::Timestamp;
using Poco::RWLock;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtStatusRequestHandler::DtStatusRequestHandler( const std::string& uri )
         : HTTPRequestHandler()
         , myUri( uri )
      {
      }

      DtStatusRequestHandler::~DtStatusRequestHandler()
      {
      }

      void DtStatusRequestHandler::handleRequest(HTTPServerRequest& request, HTTPServerResponse& response)
      {
         bool myHtmlResponse = ( myUri == "/status.html");
         Json::Value data(Json::objectValue);
         data["StartTime"] = DtWebLvcBroker::theWebLvcBroker->startTime();
         data["ClientsTotal"] = DtWebLvcBroker::theWebLvcBroker->clientsSinceStart();
         data["ServerFrameTime"] = DtWebLvcBroker::theWebLvcBroker->avgFrameTime();

         std::list<DtClient*>::iterator i = DtWebLvcBroker::theWebLvcBroker->clientList().begin();
         int count = 1;
         Json::Value clients(Json::arrayValue);
         while( i != DtWebLvcBroker::theWebLvcBroker->clientList().end() )
         {
            Json::Value c(Json::objectValue);
            c["name"] = (*i)->name();
            c["addr"] = (*i)->addrString();
            c["connectTime"] = (*i)->connectTime();
            c["frameTime"] = (*i)->averageFrameTime();
            c["UpdatesPerFrame"] = (*i)->averageUpdateCount();
            clients[count++] = c;
            ++i;
         }
         data["Clients"] = clients;

         /* std::map<std::string,DtTranslator*>::iterator objTrans = DtWebLvcBroker::theWebLvcBroker->objectTranslators().begin();
         while( objTrans != DtWebLvcBroker::theWebLvcBroker->objectTranslators().end() )
         {
         out << objTrans->second->status().c_str() << "<br>";
         ++objTrans;
         }*/



         // change this to build the json, and then cast it into html or just return it
         if( myHtmlResponse )
         {
            try
            {
               response.setStatus(HTTPResponse::HTTP_OK);
               response.setContentType("text/html");
               response.set( "Access-Control-Allow-Origin", "*" );
               std::ostream& out = response.send();
               time_t t = DtWebLvcBroker::theWebLvcBroker->startTime();
               out << "<h1>WebLVC Server Status</h1>"

                  << "<p> Started at: "  << ctime(&t) << "<br>"
                  << "Clients Since Start: "  << DtWebLvcBroker::theWebLvcBroker->clientsSinceStart() << "<br>";
               out << "Server Frame Rate: " << 1/DtWebLvcBroker::theWebLvcBroker->avgFrameTime() << "</p>";



               std::list<DtClient*>::iterator i = DtWebLvcBroker::theWebLvcBroker->clientList().begin();
               int count = 1;
               out << "<h2> Client List (" << DtWebLvcBroker::theWebLvcBroker->clientList().size() << ")</h2> <p>";
               while( i != DtWebLvcBroker::theWebLvcBroker->clientList().end() )
               {
                  out << "Client #"<< count << " " << (*i)->name() << " " << (*i)->addrString() << " ";

                  t = (*i)->connectTime();
                  out << "Connected: " << ctime(&t) << " ";
                  out << "FPS: " << 1/(*i)->averageFrameTime() << " ";
                  out << "UPF: " << (*i)->averageUpdateCount() << "<br>";
                  ++i;
               }


               out << "<p><h2>Object Translators</h2><br>";
               DtWebLvcBroker::NamedObjectTranslatorMap::const_iterator objTrans = DtWebLvcBroker::theWebLvcBroker->objectTranslators().begin();
               while ( objTrans != DtWebLvcBroker::theWebLvcBroker->objectTranslators().end() )
               {
                  out << ((DtBaseWebLvcObjectTranslator*)objTrans->second)->status().c_str() << "<br>";
                  ++objTrans;
               }

               out.flush();

            }
            catch ( Poco::Exception& )
            {
               return;
            }
            catch ( ... )
            {
            }
         }
         else
         {
            // return the json response
            response.setStatus(HTTPResponse::HTTP_OK);
            response.set( "Access-Control-Allow-Origin", "*" );
            Json::StyledWriter writer;
            response.setContentType("text/json");
            std::ostream& out = response.send();
            out << writer.write(data);
            out.flush();
         }
      }

   }
}
