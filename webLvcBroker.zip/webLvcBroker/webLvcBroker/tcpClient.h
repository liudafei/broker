/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file tcpClient.h
//! \brief Contains the DtTcpClient class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/client.h>
#include <Poco/Net/StreamSocket.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtTcpClient is responsible for maintaining the connection
      //! an active tcp client.  Each tcp client has its own message thread in the server
      //! that is associated to instances of this class.
      class DT_DLL_WEBLVCBROKER DtTcpClient : public DtClient
      {
      public:

         //! \brief CTOR.
         DtTcpClient( Poco::Net::StreamSocket& ws );

         //! \brief CTOR.
         //! Takes ownership of the socket, deleting it when the client is deleted.
         DtTcpClient( Poco::Net::StreamSocket* ws );

         //! \brief Virtual DTOR.
         virtual ~DtTcpClient();

         virtual int sendFrame( const void* buffer, int length );
         virtual int receiveFrame( void* buffer, int length, int& flags );

      private:

         //! Copy Constructor not implemented - Copy Not Allowed.
         DtTcpClient( const DtTcpClient& other );

         //! Assignment Operator Not implemented - Assignment Not Allowed.
         DtTcpClient& operator = ( const DtTcpClient& other );

      protected:

         Poco::Net::StreamSocket& mySocket;
         bool mySocketIsOwned;

      };

   }
}
