/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file statusHandler.h
//! \brief Contains the DtStatusRequestHandler class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <Poco/Net/HTTPRequestHandler.h>
#include <Poco/Timestamp.h>
#include <Poco/RWLock.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtStatusRequestHandler is a class that sets up status page
      //! detailing the health of your server.
      class DT_DLL_WEBLVCBROKER DtStatusRequestHandler
         : public Poco::Net::HTTPRequestHandler
      {
      public:

         //! \brief CTOR.
         DtStatusRequestHandler( const std::string& uri );

         //! \brief Virtual DTOR.
         virtual ~DtStatusRequestHandler();

         //! returns information about the system
         void handleRequest( Poco::Net::HTTPServerRequest& request,
            Poco::Net::HTTPServerResponse& response );

      private:

         //! Copy Constructor not implemented - Copy Not Allowed.
         DtStatusRequestHandler( const DtStatusRequestHandler& other );

         //! Assignment Operator Not implemented - Assignment Not Allowed.
         DtStatusRequestHandler& operator = ( const DtStatusRequestHandler& other );

      protected:

         std::string myUri;

      };

   }
}
