/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file vrvMsgTranslator.h
//! \brief Contains the DtVrvMsgTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/baseWebLvcInteractionTranslator.h>
#include <portal/pVrvMimicView.h>
#include <portal/pVrvMimicTrackView.h>
#include <portal/pVrvSensorMode.h>
#include <portal/pVrvObserverMode.h>
#include <portal/pVrvViewMagnification.h>
#include <portal/pVrvUseSavedView.h>
#include <portal/pVrvSetSystemState.h>
#include <portal/pVrvModelSet.h>
#include <portal/pVrvModelScaling.h>
#include <portal/pVrvModelScaleFactor.h>
#include <portal/pVrvKeyPress.h>
#include <portal/pVrvFollowView.h>
#include <portal/pVrvTetherView.h>
#include <portal/pVrvMouseEvent.h>
#include <portal/pVrvTrackHistories.h>
#include <portal/pVrvDynamicOcean.h>
#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtVrvMsgTranslator are responsible for translating DtPortalVRV(...) messages to MAK:VRVMessages.
      class DT_DLL_WEBLVCBROKER DtVrvMsgTranslator : public DtBaseWebLvcInteractionTranslator
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME("MAK:VRVMessage");

         //! \brief CTOR.
         DtVrvMsgTranslator(DtBroker* broker);

         //! \brief Virtual DTOR.
         virtual ~DtVrvMsgTranslator();

         virtual void tick(){};

         virtual DtWebLvcBroker* webLvcBroker();
         virtual const DtWebLvcBroker* webLvcBroker() const;

         virtual void enableReflectTranslator(bool enabled);
         virtual void enablePublishTranslator(bool enabled);

         virtual void initializeWebLvcCallbacks();
         virtual void removeWebLvcCallbacks();

         virtual void initializePortalCallbacks();
         virtual void removePortalCallbacks();

         virtual char convertKey(Json::Value source);



         template <typename T>
         void createInteraction( const T& obj )
         {
            Json::Value root;
            root["MessageKind"] = 2;
            root["InteractionType"] = myMessageNames[obj.theKind];

            translate( obj, &root );

            Json::FastWriter writer;
            std::string buffer = writer.write( root );
            webLvcBroker()->queueToSend( buffer, 0 );

            if ( this->myBroker->isTranslatorDebuggingOn(name()) )
            {
               printIncomingOutgoingStateReps(obj, root);
            }
         }

         template <typename T>
         static void receivePortalInteraction( const T& inter, void* usr )
         {
            ((DtVrvMsgTranslator*)usr)->createInteraction( inter );
         }

         //! @name Translation Methods
         //! @{

         virtual void translate( const Json::Value& source, DtPortalVrvMimicViewInteraction* destination );
         virtual void translate( const DtPortalVrvMimicViewInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvMimicTrackViewInteraction* destination );
         virtual void translate( const DtPortalVrvMimicTrackViewInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvSensorModeInteraction* destination );
         virtual void translate( const DtPortalVrvSensorModeInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvViewMagnificationInteraction* destination );
         virtual void translate( const DtPortalVrvViewMagnificationInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvUseSavedViewInteraction* destination );
         virtual void translate( const DtPortalVrvUseSavedViewInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvObserverModeInteraction* destination );
         virtual void translate( const DtPortalVrvObserverModeInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvSetSystemStateInteraction* destination );
         virtual void translate( const DtPortalVrvSetSystemStateInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvModelSetInteraction* destination );
         virtual void translate( const DtPortalVrvModelSetInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvModelScalingInteraction* destination );
         virtual void translate( const DtPortalVrvModelScalingInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvModelScaleFactorInteraction* destination );
         virtual void translate( const DtPortalVrvModelScaleFactorInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvKeyPressInteraction* destination );
         virtual void translate( const DtPortalVrvKeyPressInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvFollowViewInteraction* destination );
         virtual void translate( const DtPortalVrvFollowViewInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvTetherViewInteraction* destination );
         virtual void translate( const DtPortalVrvTetherViewInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvMouseEventInteraction* destination );
         virtual void translate( const DtPortalVrvMouseEventInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvTrackHistoriesInteraction* destination );
         virtual void translate( const DtPortalVrvTrackHistoriesInteraction& source, Json::Value* destination );

         virtual void translate( const Json::Value& source, DtPortalVrvDynamicOceanInteraction* destination );
         virtual void translate( const DtPortalVrvDynamicOceanInteraction& source, Json::Value* destination );

         //! @}

         virtual void processMsg( Json::Value* msg, DtClient* client );

         virtual void printIncomingOutgoingStateReps( const DtPortalMessage& incoming,
            const Json::Value& outgoing );

         virtual void printIncomingOutgoingStateReps( const Json::Value& incoming,
            const DtPortalMessage& outgoing );

         virtual void createFullStateMsgs( std::list<std::string>& msgs, DtClient* client ) {}

         //! \brief Unregisters callbacks.
         virtual void shutdown();

      protected:

         std::map<std::string,int> myMessageTypes;
         std::map<int,std::string> myMessageNames;

      };


      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvMimicViewInteraction>( const DtPortalVrvMimicViewInteraction& incoming );
//      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvMimicViewInteraction>( const DtPortalVrvMimicViewInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvMimicTrackViewInteraction>( const DtPortalVrvMimicTrackViewInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvSensorModeInteraction>( const DtPortalVrvSensorModeInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvViewMagnificationInteraction>( const DtPortalVrvViewMagnificationInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvObserverModeInteraction>( const DtPortalVrvObserverModeInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvUseSavedViewInteraction>( const DtPortalVrvUseSavedViewInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvSetSystemStateInteraction>( const DtPortalVrvSetSystemStateInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvModelSetInteraction>( const DtPortalVrvModelSetInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvModelScalingInteraction>( const DtPortalVrvModelScalingInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvModelScaleFactorInteraction>( const DtPortalVrvModelScaleFactorInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvKeyPressInteraction>( const DtPortalVrvKeyPressInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvFollowViewInteraction>( const DtPortalVrvFollowViewInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvTetherViewInteraction>( const DtPortalVrvTetherViewInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvMouseEventInteraction>( const DtPortalVrvMouseEventInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvTrackHistoriesInteraction>( const DtPortalVrvTrackHistoriesInteraction& incoming );
      template void DtVrvMsgTranslator::createInteraction<DtPortalVrvDynamicOceanInteraction>( const DtPortalVrvDynamicOceanInteraction& incoming );

      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvMimicViewInteraction>( const DtPortalVrvMimicViewInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvMimicTrackViewInteraction>( const DtPortalVrvMimicTrackViewInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvSensorModeInteraction>( const DtPortalVrvSensorModeInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvViewMagnificationInteraction>( const DtPortalVrvViewMagnificationInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvObserverModeInteraction>( const DtPortalVrvObserverModeInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvUseSavedViewInteraction>( const DtPortalVrvUseSavedViewInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvSetSystemStateInteraction>( const DtPortalVrvSetSystemStateInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvModelSetInteraction>( const DtPortalVrvModelSetInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvModelScalingInteraction>( const DtPortalVrvModelScalingInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvModelScaleFactorInteraction>( const DtPortalVrvModelScaleFactorInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvKeyPressInteraction>( const DtPortalVrvKeyPressInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvFollowViewInteraction>( const DtPortalVrvFollowViewInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvTetherViewInteraction>( const DtPortalVrvTetherViewInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvMouseEventInteraction>( const DtPortalVrvMouseEventInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvTrackHistoriesInteraction>( const DtPortalVrvTrackHistoriesInteraction& inter, void* usr );
      template void DtVrvMsgTranslator::receivePortalInteraction<DtPortalVrvDynamicOceanInteraction>( const DtPortalVrvDynamicOceanInteraction& inter, void* usr );

   }
}
