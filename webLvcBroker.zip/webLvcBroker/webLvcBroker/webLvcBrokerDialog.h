/*****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcBrokerDialog.h
//! \brief Contains the DtWebLvcBrokerDialog class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <widgets/brokerDialog.h>

class QLabel;
class QSpinBox;
class QLineEdit;
class QPushButton;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      class DtWebLvcBroker;
      class DtWebLvcBrokerInitializer;

      //! \brief Responsible for displaying all information about the broker.
      //! \ingroup webLvcBroker
      class DT_DLL_WEBLVCBROKER DtWebLvcBrokerDialog : public DtBrokerDialog
      {  Q_OBJECT;
      public:

         //! \brief Static creation method.
         //! Instantiates a new broker dialog.
         //! Default creator for WebLVC broker dialogs.
         static DtBrokerDialog* create( DtBroker* broker,
            DtBrokerInitializer* init, QWidget* parent = 0 );

      protected:

         //! \brief CTOR.
         DtWebLvcBrokerDialog( DtWebLvcBroker* broker, DtWebLvcBrokerInitializer* init,
            QWidget* parent = 0 );

      public:

         //! \brief DTOR.
         virtual ~DtWebLvcBrokerDialog();

         //! \brief Accessor for casted WebLVC Initializer.
         virtual DtWebLvcBrokerInitializer* webLvcInitializer();

         //! \brief Enable or disable the TCP connection widgets.
         virtual void setTcpConnectEnabled( bool onOff );

         //! \brief Update the list of clients.
         virtual void clientsUpdated();

      protected:

         //! @name Initialization Methods
         //! @{

         //! \brief Initializes the broker dialog.
         //! Overridden to create the clients page.
         virtual void initialize();

         //! \brief Instantiate the Clients Page.
         virtual void initClientsPage();

         //! \brief Instantiate the Connection Settings Widget.
         //! Returns NULL - there is no connection settings widget.
         virtual DtConnectionSettingsWidget* instantiateConnectionSettingsWidget();

         //! \brief Instantiate the General Settings Widget.
         virtual DtGeneralSettingsWidget* instantiateGeneralSettingsWidget();

         //! \brief Initialize the headers for the object list views.
         virtual void initObjectListViewHeaders();

         //! @}

         //! \brief Updates the entry for the object in the reflected/published list.
         //! Does nothing - there is no object list.
         virtual void updateObjectText( const DtBrokerObject* brokerObject,
            QTreeWidgetItem* item, const QString& status );

         //! \brief Event filter method for monitoring widget focus.
         virtual bool eventFilter( QObject* obj, QEvent* event );

      protected slots:

         //! \brief Slot for processing connect when button is pressed.
         virtual void on_clientConnectButton_released();

      private:

         //! Copy CTOR not implemented -- Do Not Copy!
         DtWebLvcBrokerDialog( const DtWebLvcBrokerDialog& other );

         //! Assignment Operator not implemented -- Do Not Copy!
         DtWebLvcBrokerDialog& operator = ( const DtWebLvcBrokerDialog& other );

      protected:

         DtGenericListView* myClientsListWidget;
         DtWebLvcBroker* myWebLvcBroker;

         QLabel* myClientHostnameLabel;
         QLineEdit* myClientConnectHostLineEdit;
         QLabel* myClientPortLabel;
         QSpinBox* myClientConnectPortSpinBox;
         QPushButton* myClientConnectButton;

      };

   }
}
