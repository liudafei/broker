/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file lvcObjectTranslator.inl
//! \brief Contains the DtLvcObjectTranslator class definition.
//! \ingroup webLvcBroker

#ifndef _lvcObjectTranslator_INL_
#error "Inline definitions file must be included from declaring header."
#endif

#include <webLvcBroker/client.h>
#include <portal/requestTransDiagnosticMessage.h>
#include <portal/pObjectPublisherTypes.h>
#include <portal/transDiagnosticMessage.h>
#include <webLvcBroker/baseWebLvcObjectTranslator.h>

typedef std::set<DtString> StringSet;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::DtLvcObjectTranslator(
            DtBroker* broker, const DtString& name, DtPortalMessageKind kind )
         : DtBaseObjectTranslator<T_PortalObject,T_PortalReflectedObject,DtBaseWebLvcObjectTranslator>(
            broker, name, kind )
      {
         webLvcBroker()->addAttributeUpdateCB( std::string(name.c_str()), this );

         // Listen for translation diagnostic message requests.
         DtRequestTranslationDiagnosticMessage::addCallback(
            broker->portalConnection(), requestTransDiagCb, this );
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::~DtLvcObjectTranslator()
      {
         // Stop listening for translation diagnostic message requests.
         DtRequestTranslationDiagnosticMessage::removeCallback(
            webLvcBroker()->portalConnection(), requestTransDiagCb, this );
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::tick()
      {
         // TODO Tick!
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::initializePortalCallbacks()
      {
         myLockingPortalReflectedManager = new DtLockingReflectedObjectManager
            < DtPortalReflectedObjectTemplate<T_PortalObject> >( this->broker()->portalConnection() );
         this->myPortalReflectedManager = (DtPortalReflectedObjectManager<DtPortalReflectedObjectTemplate<T_PortalObject> >*) myLockingPortalReflectedManager;
         this->myPortalReflectedManager->addAdditionCallback( ParentClass::portalObjectAddedCb, this );
         this->myPortalReflectedManager->addRemovalCallback( ParentClass::portalObjectDeletedCb, this );
         this->myPortalReflectedManager->setDiscoveryCondition( ParentClass::portalDiscoveryCriteria, this );
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::removePortalCallbacks()
      {
         if ( this->myPortalReflectedManager )
         {
            // Callbacks will be removed when the list is deleted. Also,
            // removal callbacks will need to be called on list deletion.
            DtDELETE( myLockingPortalReflectedManager );
            this->myPortalReflectedManager = 0;
         }
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtWebLvcBroker* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::webLvcBroker()
      {
         return (DtWebLvcBroker*) this->myBroker;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      const DtWebLvcBroker* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::webLvcBroker() const
      {
         return (const DtWebLvcBroker*) this->myBroker;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::discoverPortalObject(
         const T_PortalReflectedObject& refObj )
      {
         // Create BrokerObjectStateRepository and store publisher in it
         DtBrokerObject* brokerObject = findBrokerObject( &refObj );
         if ( ! brokerObject )
         {
            brokerObject = createBrokerObject(&refObj);
         }

         // We don't really need an LVC publisher at this point
         //createLVCPublisher( brokerObject );

         refObj.addUpdateCallback( this->portalObjectUpdatedCb, this );

         receivePortalUpdate( refObj );
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::receivePortalUpdate(
         const T_PortalReflectedObject& obj )
      {
         DtBrokerObject* brokerObject = findBrokerObject( obj.sr()->identifier() );
         if ( ! brokerObject )
         {
            DtWarn << "Received update call for deleted portal entity! "  << std::endl;
            return;
         }

         // don't necessarily send the update right now, wait until the Broker is ready to do it
         myLock.writeLock();
         std::map<void*,std::set<DtString> >::iterator itr = this->myLvcUpdateSet.begin();
         std::map<void*,std::set<DtString> >::iterator end = this->myLvcUpdateSet.end();
         for ( ; itr != end; ++itr )
         {
            itr->second.insert( obj.sr()->identifier() );
         }

         myLock.unlock();

         this->callObjectUpdateCallbacks(brokerObject);
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::removePortalObject(
         const T_PortalReflectedObject& obj )
      {
         // Bail out if we are not publishing this one.
         DtBrokerObject* brokerObj = releaseBrokerObject( &obj );
         if ( ! brokerObj )
         {
           return;
         }

         brokerObj->setLastUpdate( webLvcBroker()->simTime() );

         sendRemoveObjMessage( obj.sr()->identifier().c_str(), 0 );

         this->callObjectRemoveCallbacks( brokerObj );

         DtDELETE( brokerObj );

         myLock.writeLock();

         {  // Remove as-seen-by state repositories for the removed object.
            std::list<DtClient*>::iterator itr = webLvcBroker()->clientList().begin();
            std::list<DtClient*>::iterator end = webLvcBroker()->clientList().end();
            for ( ; itr != end; ++itr )
            {
               (*itr)->removeAsSeenByRemote( this->name(), obj.sr()->identifier().c_str() );
            }
         }

         {  // Clear any pending updates for the removed object.
            std::map<void*, std::set<DtString> >::iterator itr = this->myLvcUpdateSet.begin();
            std::map<void*, std::set<DtString> >::iterator end = this->myLvcUpdateSet.end();
            for ( ; itr != end; ++itr )
            {
               itr->second.erase( obj.sr()->identifier() );
            }
         }

         myLock.unlock();
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::removeClientObject(
         const std::string& obj )
      {
         // Bail out if we are not publishing this one.
         DtBrokerObject* brokerObj = releaseBrokerObject( obj );
         if ( ! brokerObj )
         {
            return;
         }

         brokerObj->setLastUpdate( webLvcBroker()->simTime() );

         DtPortalObjectPublisher* objPub = (DtPortalObjectPublisher*) brokerObj->publisherPtr();
         DtDELETE( objPub );

         DtClient* client = (DtClient*) brokerObj->brokerDataPtr( ClientPtrData );
         sendRemoveObjMessage( obj.c_str(), client );

         DtDELETE( brokerObj );

         myLock.writeLock();

         {  // Remove as-seen-by state repositories for the removed object.
            std::list<DtClient*>::iterator itr = webLvcBroker()->clientList().begin();
            std::list<DtClient*>::iterator end = webLvcBroker()->clientList().end();
            for ( ; itr != end; ++itr )
            {
               (*itr)->removeAsSeenByRemote( this->name(), obj.c_str() );
            }
         }

         {  // Clear any pending updates for the removed object.
            std::map<void*, std::set<DtString> >::iterator itr = this->myLvcUpdateSet.begin();
            std::map<void*, std::set<DtString> >::iterator end = this->myLvcUpdateSet.end();
            for ( ; itr != end; ++itr )
            {
               itr->second.erase( obj.c_str() );
            }
         }

         myLock.unlock();
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtBrokerObject* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::createBrokerObject(
         const T_PortalReflectedObject* refObj )
      {
         DtBrokerObject* brokerObj = new DtBrokerObject( true, this->name() );
         brokerObj->setObjectName( refObj->baseObject()->identifier() );
         brokerObj->setFirstUpdate( webLvcBroker()->simTime() );
         brokerObj->setLastUpdate( webLvcBroker()->simTime() );
         brokerObj->setReflectedObjPtr(refObj);
         brokerObj->setIsPublishable(true); //All objects are publishable right now.
         myLvcPublisherMap[refObj] = brokerObj;

         this->callObjectDiscoverCallbacks( brokerObj );

         return brokerObj;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtBrokerObject* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::findBrokerObject(
         const std::string& refObj )
      {
         typename LvcToPortalReflectedMap::iterator pos = this->myPortalPublisherMap.find( refObj );
         if ( pos != this->myPortalPublisherMap.end() )
         {
            return pos->second;
         }
         return 0;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtBrokerObject* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::findBrokerObject(
         const T_PortalReflectedObject* refObj )
      {
         typename PortalToLvcReflectedMap::iterator pos = this->myLvcPublisherMap.find( refObj );
         if ( pos != this->myLvcPublisherMap.end() )
         {
            return pos->second;
         }
         return 0;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtBrokerObject* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::findBrokerObject(
         const DtString& objectName )
      {
         // Abort if no name was given.
         if ( objectName.isEmpty() )
         {
            return 0;
         }

         {  // Iterate over the Reflected HLA Objects and check for the right object name.
            typename LvcToPortalReflectedMap::iterator itr = myPortalPublisherMap.begin();
            typename LvcToPortalReflectedMap::iterator end = myPortalPublisherMap.end();
            for ( ; itr != end; ++itr )
            {
               if ( itr->second->objectName() == objectName )
               {
                  return itr->second;
               }
            }
         }

         {  // Iterate over the Reflected HLA Objects and check for the right object name.
            typename PortalToLvcReflectedMap::iterator itr = myLvcPublisherMap.begin();
            typename PortalToLvcReflectedMap::iterator end = myLvcPublisherMap.end();
            for ( ; itr != end; ++itr )
            {
               if ( itr->second->objectName() == objectName )
               {
                  return itr->second;
               }
            }
         }

         // Object wasn't found, return null.
         return 0;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtBrokerObject* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::releaseBrokerObject(
         const std::string& refObj )
      {
         typename LvcToPortalReflectedMap::iterator pos = this->myPortalPublisherMap.find( refObj );
         if ( pos != this->myPortalPublisherMap.end() )
         {
            DtBrokerObject* brokerObj = pos->second;
            myPortalPublisherMap.erase( pos );
            return brokerObj;
         }
         return 0;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtBrokerObject* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::releaseBrokerObject(
         const T_PortalReflectedObject* refObj )
      {
         typename PortalToLvcReflectedMap::iterator pos = this->myLvcPublisherMap.find( refObj );
         if ( pos != this->myLvcPublisherMap.end() )
         {
            DtBrokerObject* brokerObj = pos->second;
            myLvcPublisherMap.erase( pos );
            return brokerObj;
         }
         return 0;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      Poco::RWLock* DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::lock()
      {
         return &myLockingPortalReflectedManager->lock();
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      DtString DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::status()
      {
         DtString stat = this->name();
         stat += " : ";
         stat += DtString( (int)this->myPortalReflectedManager->reflectedObjectMap().size() );
         stat += " objects ";
         return stat;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      int DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::processUpdateSet( void* id )
      {
         if ( ! this->myReflectEnabled )
         {
            return 0;
         }

         this->myLockingPortalReflectedManager->lock().readLock();
         myLock.writeLock(); //This cannot be optimized to a readLock because translators sometimes set temporary variables

         int count = 0;
         std::map<void*,std::set<DtString> >::const_iterator findItr = this->myLvcUpdateSet.find( id );
         if ( findItr != this->myLvcUpdateSet.end() )
         {
            std::set<DtString>::const_iterator itr = findItr->second.begin();
            std::set<DtString>::const_iterator end = findItr->second.end();
            for ( ; itr != end; ++itr, ++count )
            {
               typename DtLockingReflectedObjectManager<T_PortalReflectedObject>::ReflectedObjectMap::const_iterator objItr =
                  this->myPortalReflectedManager->reflectedObjectMap().find( itr->c_str() );
               if ( objItr != this->myPortalReflectedManager->reflectedObjectMap().end() )
               {
                  const T_PortalObject* sr = objItr->second->sr();
                  if ( sr )
                  {
                     Json::Value val;
                     val["MessageKind"] = 1;
                     val["ObjectName"] = sr->identifier().c_str();
                     val["ObjectType"] = sr->name().c_str();

                     translate( *sr, &val );

                     ((DtClient*)id)->checkAsSeenByRemote( this->name(), sr->identifier(), val );
                     if ( val.size() > 3 )
                     {
                        std::string buffer;
                        Json::FastWriter writer;
                        buffer = writer.write( val );
                        ((DtClient*)id)->sendMsg( buffer );
                     }

                     if ( this->myBroker->isTranslatorDebuggingOn(this->name()) )
                     {
                        printIncomingOutgoingStateReps( *sr, val, this->name() );
                     }

                     performPortalDebugging( *sr, val );
                  }
               }
            }
         }
         myLock.unlock();
         this->myLockingPortalReflectedManager->lock().unlock();

         myLock.writeLock();
         this->myLvcUpdateSet[id].clear();
         myLock.unlock();

         return count;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
         void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::createUpdateSet(void* id)
      {
         myLock.writeLock();
         this->myLvcUpdateSet[id] = StringSet();
         myLock.unlock();
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::processClientRemoval( DtClient* client )
      {
         myLock.writeLock();
         this->myLvcUpdateSet.erase(client);
         myLock.unlock();

         LvcToPortalReflectedMap::iterator itr = myPortalPublisherMap.begin();
         LvcToPortalReflectedMap::iterator end = myPortalPublisherMap.end();
         while (itr != end )
         {
            if ( itr->second->brokerDataPtr(ClientPtrData) == client )
            {

               DtBrokerObject* bo = itr->second;
               T_PortalObject* sr = (T_PortalObject*) ((DtPortalObjectPublisher*)bo->publisherPtr())->baseSr();
               ++itr;
               removeClientObject( sr->identifier().c_str() );
            }
            else
            {
               ++itr;
            }
         }
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::sendRemoveObjMessage(
         const char* identifier, DtClient* client )
      {
         // Send obj removal message
         // 0 - Administrative messages (e.g. filtering requests)
         Json::Value root;
         root["MessageKind"] = 4;
         root["ObjectName"] = identifier;

         std::string buffer;
         Json::FastWriter writer;
         buffer = writer.write( root );

         ((DtWebLvcBroker*)this->myBroker)->queueToSend( buffer, client );
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::createFullStateMsgs(
         std::list<std::string>& msgs, DtClient* client )
      {
         // Abort if publishing is disabled.
         if ( ! this->myPublishEnabled )
         {
            return;
         }

         Json::Value root;
         std::string buffer;
         Json::FastWriter writer;

         {  // Create state messages for portal objects.
            this->myLockingPortalReflectedManager->lock().readLock();

            typename DtLockingReflectedObjectManager<T_PortalReflectedObject>::ReflectedObjectMap::const_iterator itr;
            typename DtLockingReflectedObjectManager<T_PortalReflectedObject>::ReflectedObjectMap::const_iterator end;
            itr = this->myPortalReflectedManager->reflectedObjectMap().begin();
            end = this->myPortalReflectedManager->reflectedObjectMap().end();
            for ( ; itr != end; ++itr )
            {
               T_PortalReflectedObject* obj = &( *itr->second );

               // Construct the base message.
               root["MessageKind"] = 1;
               root["ObjectName"] = obj->sr()->identifier().c_str();
               root["ObjectType"] = obj->sr()->name().c_str();

               // Translate the state from the portal object into the message.
               translate( *obj->sr(), &root );

               // Convert the JSON message to a string and add it to the list.
               buffer = writer.write( root );
               msgs.push_back( buffer );

               // Clear the message for the next iteration.
               root.clear();
            }

            this->myLockingPortalReflectedManager->lock().unlock();
         }

         {  // Create state messages for client objects.
            typename LvcToPortalReflectedMap::const_iterator itr = this->myPortalPublisherMap.begin();
            typename LvcToPortalReflectedMap::const_iterator end = this->myPortalPublisherMap.end();
            for ( ; itr != end; ++itr )
            {
               DtClient* client = (DtClient*) itr->second->brokerDataPtr( ClientPtrData );
               if ( client && client != client )
               {
                  DtPortalObjectPublisher* pub = (DtPortalObjectPublisher*) itr->second->publisherPtr();
                  T_PortalObject* pubSr = (T_PortalObject*) pub->baseSr();

                  // Construct the base message.
                  root["MessageKind"] = 1;
                  root["ObjectName"] = pubSr->identifier().c_str();
                  root["ObjectType"] = pubSr->name().c_str();

                  // Translate the state from the portal object into the message.
                  translate( *pubSr, &root );

                  // Convert the JSON message to a string and add it to the list.
                  buffer = writer.write( root );
                  msgs.push_back( buffer );

                  // Clear the message for the next iteration.
                  root.clear();
               }
            }
         }
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::processMsg(
         Json::Value* msg, DtClient* client )
      {
         DtBrokerObject* brokerObj = this->myPortalPublisherMap[(*msg)["ObjectName"].asString()];
         if ( ! brokerObj )
         {
            brokerObj = new DtBrokerObject( false, this->name() );
            brokerObj->setPublisherPtr( new DtPortalObjectPublisherTemplate<T_PortalObject>(this->myBroker->portalConnection()) );
            brokerObj->setBrokerDataPtr( ClientPtrData, client );
            this->myPortalPublisherMap[(*msg)["ObjectName"].asString()] = brokerObj;
         }

         // Call registered object update callbacks.
         this->callObjectUpdateCallbacks( brokerObj );

         DtPortalObjectPublisher* pub = (DtPortalObjectPublisher*) brokerObj->publisherPtr();
         T_PortalObject* destination = (T_PortalObject*) pub->baseSr();

         if ( destination )
         {
            destination->setIdentifier( (*msg)["ObjectName"].asString().c_str() );
            translate( *msg, destination );
         }

         if ( this->myBroker->isTranslatorDebuggingOn(this->name()) )
         {
            printIncomingOutgoingStateReps( *msg, *destination, this->name() );
         }

         performPortalDebugging( *msg, *destination );

         // Publish to Portal.
         ((DtPortalObjectPublisher*)brokerObj->publisherPtr())->tick();

         // Publish to other clients.
         Json::FastWriter writer;
         std::string msgstr = writer.write( *msg );
         ((DtWebLvcBroker*)this->myBroker)->queueToSend( msgstr, client );
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::printIncomingOutgoingStateReps(
         const DtPortalMessage& incoming, const Json::Value& outgoing, const DtString& objectName )
      {
         DtInfo << "========ORIG (Portal) - " << objectName << " ========" << std::endl;
         DtInfo << incoming;
         DtInfo << "========NEW (WebLVC) - " << objectName << " ========" << std::endl;
         DtInfo << outgoing.toStyledString();
         DtInfo << "------------------------------------------------" << std::endl;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::printIncomingOutgoingStateReps(
         const Json::Value& incoming, const DtPortalMessage& outgoing, const DtString& objectName )
      {
         DtInfo << "========ORIG (WebLVC) - " << objectName << " ========" << std::endl;
         DtInfo << incoming.toStyledString();
         DtInfo << "========NEW (Portal) - " << objectName << " ========" << std::endl;
         DtInfo << outgoing;
         DtInfo << "------------------------------------------------" << std::endl;
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::performPortalDebugging(
         const DtString& objectName )
      {
         // Look up the object's DtBrokerObject, and abort if not found.
         DtBrokerObject* brokerObj = findBrokerObject( objectName );
         if ( ! brokerObj )
         {
            return;
         }

         // Get source and destination state repositories.
         // This needs to be done differently depending on whether it's a portal or protocol object.
         if ( brokerObj->isPortalObject() )
         {
            // Unimplemented: Need to look up portal and WebLVC states for
            // object and pass to protocol specific ::performPortalDebugging method.
            DtInfo << "STUB: Send initial translation monitoring update." << std::endl;

            // Example code:
//            // Get reflected (Portal) object and state rep.
//            const T_PortalReflectedObject* refObj =
//               static_cast<const T_PortalReflectedObject*>( brokerObj->reflectedObjPtr() );
//            const T_PortalObject& sr = *(refObj->sr());
//
//            // Get publisher (HLA) and state rep.
//            T_TenaObjectPublisher* publisher =
//               static_cast<T_TenaObjectPublisher*>( brokerObj->publisherPtr() );
//            T_TenaObjectStateRepository& newSr =
//               static_cast<T_TenaObjectStateRepository&>(*publisher->sr());
//
//            // Send translation monitoring message to Portal.
//            performPortalDebugging( sr, newSr );
         }
         else
         {
            // Unimplemented: Need to look up portal and WebLVC states for
            // object and pass to protocol specific ::performPortalDebugging method.
            DtInfo << "STUB: Send initial translation monitoring update." << std::endl;

            // Example code:
//            // Get reflected (HLA) object and state rep.
//            const T_TenaReflectedObject* refObj =
//               static_cast<const T_TenaReflectedObject*>( brokerObj->reflectedObjPtr() );
//            const T_TenaObjectStateRepository& sr =
//               static_cast<const T_TenaObjectStateRepository&>( *refObj->sr() );
//
//            // Get publisher (Portal) and state rep.
//            DtPortalObjectPublisherTemplate<T_PortalObject>* publisher =
//               static_cast<DtPortalObjectPublisherTemplate<T_PortalObject>*>(
//                  brokerObj->publisherPtr() );
//            T_PortalObject& newSr = *(publisher->sr());
//
//            // Send translation monitoring message to Portal.
//            performPortalDebugging( sr, newSr );
         }
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::performPortalDebugging(
         const DtPortalObject& incoming, const Json::Value& outgoing )
      {
         if ( myTransDebugNames.size() )
         {
            typedef std::set<DtString> TransDebugObjectNamesSet;
            TransDebugObjectNamesSet::iterator itr =
               myTransDebugNames.find( incoming.identifier() );
            if ( itr != myTransDebugNames.end() )
            {
               std::ostringstream inStr;
               inStr << incoming;

               std::ostringstream outStr;
               outStr << outgoing;

               DtTranslationDiagnosticMessage msg;
               msg.setObjectName( incoming.identifier() );
               msg.setBrokerName( this->myBroker->brokerName() );
               msg.setIncomingState( inStr.str().c_str() );
               msg.setOutgoingState( outStr.str().c_str() );
               this->myBroker->portalConnection()->send( msg );
            }
         }
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::performPortalDebugging(
         const Json::Value& incoming, const DtPortalObject& outgoing )
      {
         if ( myTransDebugNames.size() )
         {
            typedef std::set<DtString> TransDebugObjectNamesSet;
            TransDebugObjectNamesSet::iterator itr =
               myTransDebugNames.find( outgoing.identifier() );
            if ( itr != myTransDebugNames.end() )
            {
               std::ostringstream inStr;
               inStr << incoming;

               std::ostringstream outStr;
               outStr << outgoing;

               DtTranslationDiagnosticMessage msg;
               msg.setObjectName( outgoing.identifier() );
               msg.setBrokerName( this->myBroker->brokerName() );
               msg.setIncomingState( inStr.str().c_str() );
               msg.setOutgoingState( outStr.str().c_str() );
               this->myBroker->portalConnection()->send( msg );
            }
         }
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      unsigned int DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::numObjects() const
      {
         return myPortalPublisherMap.size() + myLvcPublisherMap.size();
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::requestTransDiagCb(
         const DtRequestTranslationDiagnosticMessage& msg, void* usr )
      {
         ((DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>*)usr)
            ->requestTransDiagCb( msg );
      }

      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      void DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION>::requestTransDiagCb(
         const DtRequestTranslationDiagnosticMessage& msg )
      {
         if ( msg.sendingEnabled() )
         {
            myTransDebugNames.insert( msg.objectName() );
            performPortalDebugging( msg.objectName() );
         }
         else
         {
            myTransDebugNames.erase( msg.objectName() );
         }
      }

   }
}
