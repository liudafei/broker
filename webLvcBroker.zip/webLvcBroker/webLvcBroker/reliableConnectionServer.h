/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file reliableConnectionServer.h
//! \brief Contains the DtReliableConnectionServer class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtReliableConnectionServer is a class that provides an abstract
      //! interface that can represent either a TCPServer or HTTPServer.
      class DT_DLL_WEBLVCBROKER DtReliableConnectionServer
      {
      public:

         //! constructor
         DtReliableConnectionServer();

         //! destructor
         virtual ~DtReliableConnectionServer();

         //! Start listening for and handling connection requests
         virtual void start() = 0;

         //! Stop listening for and handling connection requests
         virtual void stop() = 0;

      private:

         //! Copy Constructor not implemented - Copy Not Allowed.
         DtReliableConnectionServer( const DtReliableConnectionServer& other );

         //! Assignment Operator Not implemented - Assignment Not Allowed.
         DtReliableConnectionServer& operator = ( const DtReliableConnectionServer& other );

      };

   }
}
