/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file vrvMsgTranslator.cxx
//! \brief Contains the DtVrvMsgTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/vrvMsgTranslator.h>
#include <portal/pDataInter.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtVrvMsgTranslator::DtVrvMsgTranslator( DtBroker* broker )
         : DtBaseWebLvcInteractionTranslator( broker, translatorName(), DtPortalVrvMimicViewInteractionKind )
         , myMessageTypes()
      {
         myMessageTypes["MAK:VrvMimicView"] = 1;
         myMessageTypes["MAK:VrvMimicTrackView"] = 2;
         myMessageTypes["MAK:VrvSensorMode"] = 3;
         myMessageTypes["MAK:VrvViewMagnification"] = 4;
         myMessageTypes["MAK:VrvObserverMode"] = 5;
         myMessageTypes["MAK:VrvUseSavedView"] = 6;
         myMessageTypes["MAK:VrvSetSystemState"] = 7;
         myMessageTypes["MAK:VrvModelSet"] = 8;
         myMessageTypes["MAK:VrvModelScaling"] = 9;
         myMessageTypes["MAK:VrvModelScaleFactor"] = 10;
         myMessageTypes["MAK:VrvKeyPress"] = 11;
         myMessageTypes["MAK:VrvFollowView"] = 12;
         myMessageTypes["MAK:VrvTetherView"] = 13;
         myMessageTypes["MAK:VrvMouseEvent"] = 14;
         myMessageTypes["MAK:VrvTrackHistories"] = 15;
         myMessageTypes["MAK:VrvDynamicOcean"] = 16;

         myMessageNames[1] = "MAK:VrvMimicView";
         myMessageNames[2] = "MAK:VrvMimicTrackView";
         myMessageNames[3] = "MAK:VrvSensorMode";
         myMessageNames[4] = "MAK:VrvViewMagnification";
         myMessageNames[5] = "MAK:VrvObserverMode";
         myMessageNames[6] = "MAK:VrvUseSavedView";
         myMessageNames[7] = "MAK:VrvSetSystemState";
         myMessageNames[8] = "MAK:VrvModelSet";
         myMessageNames[9] = "MAK:VrvModelScaling";
         myMessageNames[10] = "MAK:VrvModelScaleFactor";
         myMessageNames[11] = "MAK:VrvKeyPress";
         myMessageNames[12] = "MAK:VrvFollowView";
         myMessageNames[13] = "MAK:VrvTetherView";
         myMessageNames[14] = "MAK:VrvMouseEvent";
         myMessageNames[15] = "MAK:VrvTrackHistories";
         myMessageNames[16] = "MAK:VrvDynamicOcean";
      }

      DtVrvMsgTranslator::~DtVrvMsgTranslator()
      {
         removeWebLvcCallbacks();
         removePortalCallbacks();
      }

      DtWebLvcBroker* DtVrvMsgTranslator::webLvcBroker()
      {
         return (DtWebLvcBroker*) myBroker;
      }

      const DtWebLvcBroker* DtVrvMsgTranslator::webLvcBroker() const
      {
         return (const DtWebLvcBroker*) myBroker;
      }

      void DtVrvMsgTranslator::enableReflectTranslator( bool enabled )
      {
         if ( myReflectEnabled != enabled )
         {
            if ( enabled )
            {
               initializeWebLvcCallbacks();
            }
            else
            {
               removeWebLvcCallbacks();
            }
            myReflectEnabled = enabled;
         }
      }

      void DtVrvMsgTranslator::enablePublishTranslator( bool enabled )
      {
         if ( myPublishEnabled != enabled )
         {
            if ( enabled )
            {
               initializePortalCallbacks();
            }
            else
            {
               removePortalCallbacks();
            }
            myPublishEnabled = enabled;
         }
      }

      void DtVrvMsgTranslator::initializeWebLvcCallbacks()
      {
         std::map<std::string,int>::iterator itr = myMessageTypes.begin();
         std::map<std::string,int>::iterator end = myMessageTypes.end();
         for ( ; itr != end; ++itr )
         {
            webLvcBroker()->addInteractionCB( itr->first, this );
         }
      }

      void DtVrvMsgTranslator::removeWebLvcCallbacks()
      {
         std::map<std::string,int>::iterator itr = myMessageTypes.begin();
         std::map<std::string,int>::iterator end = myMessageTypes.end();
         for ( ; itr != end; ++itr )
         {
            webLvcBroker()->removeInteractionCB( itr->first );
         }
      }

      void DtVrvMsgTranslator::initializePortalCallbacks()
      {
         DtPortalVrvMimicViewInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvMimicTrackViewInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvSensorModeInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvViewMagnificationInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvObserverModeInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvUseSavedViewInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvSetSystemStateInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvModelSetInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvModelScalingInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvModelScaleFactorInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvKeyPressInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvFollowViewInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvTetherViewInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvMouseEventInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvTrackHistoriesInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvDynamicOceanInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
      }

      void DtVrvMsgTranslator::removePortalCallbacks()
      {
         DtPortalVrvMimicViewInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvMimicTrackViewInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvSensorModeInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvViewMagnificationInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvObserverModeInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvUseSavedViewInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvSetSystemStateInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvModelSetInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvModelScalingInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvModelScaleFactorInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvKeyPressInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvFollowViewInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvTetherViewInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvMouseEventInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvTrackHistoriesInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrvDynamicOceanInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
      }

      void DtVrvMsgTranslator::translate( const DtPortalVrvMimicViewInteraction& source,
         Json::Value* destination )
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.offset()[0];
        v[1] = source.offset()[1];
        v[2] = source.offset()[2];
        (*destination)["Offset"] = v;
        v[0u] = source.offsetOri().psi();
        v[1] = source.offsetOri().theta();
        v[2] = source.offsetOri().phi();
        (*destination)["OffsetOri"] = v;
        (*destination)["Observer"] = source.observer().string();
        (*destination)["AttachedEntity"] = source.attachedEntity().string();
      }

      void DtVrvMsgTranslator::translate( const Json::Value& source,
         DtPortalVrvMimicViewInteraction* destination )
      {
         Json::Value v( Json::arrayValue );
         v[0u] = 0.0;
         v[1] = 0.0;
         v[2] = 0.0;
         destination->setOffset( DtVector(source.get("Offset",v)[0u].asDouble(),
            source.get("Offset",v)[1u].asDouble(),
            source.get("Offset",v)[2u].asDouble() ) );
         destination->setOffsetOri( DtTaitBryan(source.get("OffsetOri",v)[0u].asDouble(),
            source.get("OffsetOri",v)[1u].asDouble(),
            source.get("OffsetOri",v)[2u].asDouble() ) );
         destination->setObserver( source.get("Observer","none").asCString() );
         destination->setAttachedEntity( source.get("AttachedEntity","none").asCString() );
      }

      void DtVrvMsgTranslator::translate( const DtPortalVrvMimicTrackViewInteraction& source,
          Json::Value* destination )
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.offset()[0];
        v[1] = source.offset()[1];
        v[2] = source.offset()[2];
        (*destination)["Offset"] = v;
        v[0u] = source.offsetOri().psi();
        v[1] = source.offsetOri().theta();
        v[2] = source.offsetOri().phi();
        (*destination)["OffsetOri"] = v;
        (*destination)["Observer"] = source.observer().string();
        (*destination)["AttachedEntity"] = source.attachedEntity().string();
        (*destination)["TrackedEntity"] = source.attachedEntity().string();
      }

      void DtVrvMsgTranslator::translate( const Json::Value& source,
         DtPortalVrvMimicTrackViewInteraction* destination )
      {
         Json::Value v( Json::arrayValue );
         v[0u] = 0.0;
         v[1] = 0.0;
         v[2] = 0.0;
         destination->setOffset( DtVector(source.get("Offset",v)[0u].asDouble(),
            source.get("Offset",v)[1u].asDouble(),
            source.get("Offset",v)[2u].asDouble() ) );
         destination->setOffsetOri( DtTaitBryan(source.get("OffsetOri",v)[0u].asDouble(),
            source.get("OffsetOri",v)[1u].asDouble(),
            source.get("OffsetOri",v)[2u].asDouble() ) );
         destination->setObserver( source.get("Observer","none").asCString() );
         destination->setAttachedEntity( source.get("AttachedEntity","none").asCString() );
         destination->setTrackedEntity( source.get("TrackedEntity","none").asCString() );
      }

      void DtVrvMsgTranslator::translate( const DtPortalVrvSensorModeInteraction& source,
         Json::Value* destination )
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.vantage().site();
        v[1] = source.vantage().host();
        v[2] = source.vantage().entityNum();
        (*destination)["Vantage"] = v;
        (*destination)["Observer"] = source.observer().string();
        (*destination)["SensorMode"] = source.sensorMode().string();
      }

      void DtVrvMsgTranslator::translate( const Json::Value& source,
         DtPortalVrvSensorModeInteraction* destination )
      {
         Json::Value a( Json::arrayValue );
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("Vantage",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setVantage( eid );
         destination->setObserver( source.get("Observer","none").asCString() );
         destination->setSensorMode( source.get("SensorMode","none").asCString() );
      }

      void DtVrvMsgTranslator::translate( const DtPortalVrvViewMagnificationInteraction& source,
         Json::Value* destination )
      {

        (*destination)["Observer"] = source.observer().string();
        (*destination)["ViewMagnification"] = source.viewMagnification();
      }

      void DtVrvMsgTranslator::translate( const Json::Value& source,
         DtPortalVrvViewMagnificationInteraction* destination )
      {
         destination->setObserver( source.get("Observer","none").asCString() );
         destination->setViewMagnification( source.get("ViewMagnification",1.0).asDouble() );
      }

      void DtVrvMsgTranslator::translate( const DtPortalVrvObserverModeInteraction& source,
         Json::Value* destination )
      {
        (*destination)["Observer"] = source.observer().string();
        (*destination)["ObserverMode"] = source.observerMode().string();
      }

      void DtVrvMsgTranslator::translate( const Json::Value& source,
         DtPortalVrvObserverModeInteraction* destination )
      {
         destination->setObserver( source.get("Observer","none").asCString() );
         destination->setObserverMode( source.get("ObserverMode","none").asCString() );
      }

      void DtVrvMsgTranslator::translate( const DtPortalVrvUseSavedViewInteraction& source,
         Json::Value* destination )
      {
        (*destination)["Observer"] = source.observer().string();
        (*destination)["SavedViewFilename"] = source.savedViewFilename().string();
        (*destination)["SavedViewDisplayName"] = source.savedViewDisplayName().string();
        (*destination)["SmoothTime"] = source.smoothTime();
      }

      void DtVrvMsgTranslator::translate( const Json::Value& source,
         DtPortalVrvUseSavedViewInteraction* destination )
      {
         destination->setObserver( source.get("Observer","none").asCString() );
         destination->setSavedViewFilename( source.get("SavedViewFilename","none").asCString() );
         destination->setSavedViewDisplayName( source.get("SavedViewDisplayName","none").asCString() );
         destination->setSmoothTime( source.get("SmoothTime",0.0).asDouble() );
      }

      void DtVrvMsgTranslator::translate( const DtPortalVrvSetSystemStateInteraction& source,
         Json::Value* destination )
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.vantage().site();
        v[1] = source.vantage().host();
        v[2] = source.vantage().entityNum();
        (*destination)["Vantage"] = v;
        (*destination)["EntityLabels"] = source.entityLabels();
        (*destination)["TacticalGraphicsLabels"] = source.tacticalGraphicsLabels();
        (*destination)["HeightAboveTerrainLines"] = source.heightAboveTerrainLines();
        (*destination)["FireDetonateLines"] = source.fireDetonateLines();
        (*destination)["TacticalGraphics"] = source.tacticalGraphics();
        (*destination)["RadioCommunications"] = source.radioCommunications();
        (*destination)["VaporTrail"] = source.vaporTrail();
        (*destination)["PlanarReflections"] = source.planarReflections();
      }

#define DtTRANSLATEBOOL( T, N, n ) \
   if ( source.isMember(n) ) \
   { \
      destination->set##N( source.get(n,0).asBool() ); \
   }

      void DtVrvMsgTranslator::translate( const Json::Value& source,
         DtPortalVrvSetSystemStateInteraction* destination )
      {
         Json::Value a( Json::arrayValue );
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get( "Vantage", a );
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setVantage( eid );

         DtTRANSLATEBOOL( bool, EntityLabels, "EntityLabels" );
         DtTRANSLATEBOOL( bool, TacticalGraphicsLabels, "TacticalGraphicsLabels" );
         DtTRANSLATEBOOL( bool, HeightAboveTerrainLines, "HeightAboveTerrainLines" );
         DtTRANSLATEBOOL( bool, FireDetonateLines, "FireDetonateLines" );
         DtTRANSLATEBOOL( bool, TacticalGraphics, "TacticalGraphics" );
         DtTRANSLATEBOOL( bool, RadioCommunications, "RadioCommunications" );
         DtTRANSLATEBOOL( bool, VaporTrail, "VaporTrail" );
         DtTRANSLATEBOOL( bool, PlanarReflections, "PlanarReflections" );
      }

      void DtVrvMsgTranslator::translate( const DtPortalVrvModelSetInteraction& source,
         Json::Value* destination )
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.vantage().site();
        v[1] = source.vantage().host();
        v[2] = source.vantage().entityNum();
        (*destination)["Vantage"] = v;
        (*destination)["ObserverMode"] = source.observerMode().string();
        (*destination)["ModelSet"] = source.modelSet();
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvModelSetInteraction* destination)
      {
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("Vantage",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setVantage( eid );
         destination->setObserverMode( source.get("ObserverMode","none").asCString() );
         destination->setModelSet( source.get("ModelSet",0).asInt() );
      }

      void DtVrvMsgTranslator::translate(
         const DtPortalVrvModelScalingInteraction& source, Json::Value* destination)
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.vantage().site();
        v[1] = source.vantage().host();
        v[2] = source.vantage().entityNum();
        (*destination)["Vantage"] = v;
        (*destination)["ObserverMode"] = source.observerMode().string();
        (*destination)["ModelScaling"] = source.modelScaling();
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvModelScalingInteraction* destination)
      {
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("Vantage",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setVantage( eid );
         destination->setObserverMode( source.get("ObserverMode","none").asCString() );
         destination->setModelScaling( source.get("ModelScaling",false).asBool() );
      }
      void DtVrvMsgTranslator::translate(
         const DtPortalVrvModelScaleFactorInteraction& source, Json::Value* destination)
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.vantage().site();
        v[1] = source.vantage().host();
        v[2] = source.vantage().entityNum();
        (*destination)["Vantage"] = v;
        (*destination)["ObserverMode"] = source.observerMode().string();
        (*destination)["ModelScaleFactor"] = source.modelScaleFactor();
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvModelScaleFactorInteraction* destination)
      {
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("Vantage",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setVantage( eid );
         destination->setObserverMode( source.get("ObserverMode","none").asCString() );
         destination->setModelScaleFactor( source.get("ModelScaleFactor",1.0).asDouble() );
      }

      void DtVrvMsgTranslator::translate(
         const DtPortalVrvKeyPressInteraction& source, Json::Value* destination)
      {

        (*destination)["Observer"] = source.observerName().string();
        (*destination)["Key"] = source.key();
        (*destination)["KeyState"] = source.pressed();
        Json::Value a(Json::objectValue);
        a["Shift"] = source.shift();
        a["Alt"] = source.alt();
        a["Ctrl"] = source.ctrl();
        (*destination)["Modifiers"] = a;
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvKeyPressInteraction* destination)
      {
         Json::Value a(Json::objectValue);
         a = source.get("Modifiers",a);
         destination->setObserverName( source.get("Observer","Observer1").asCString() );
         destination->setKey(convertKey(source));
         destination->setPressed( source.get("KeyState",false).asBool() );
         destination->setShift( a.get("Shift",false).asBool() );
         destination->setAlt( a.get("Alt",false).asBool() );
         destination->setCtrl( a.get("Ctrl",false).asBool() );
      }

      void DtVrvMsgTranslator::translate(
         const DtPortalVrvFollowViewInteraction& source, Json::Value* destination)
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.offset()[0];
        v[1] = source.offset()[1];
        v[2] = source.offset()[2];
        (*destination)["Offset"] = v;
        v[0u] = source.offsetOri().psi();
        v[1] = source.offsetOri().theta();
        v[2] = source.offsetOri().phi();
        (*destination)["OffsetOri"] = v;
        (*destination)["Observer"] = source.observer().string();
        (*destination)["AttachedEntity"] = source.attachedEntity().string();
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvFollowViewInteraction* destination)
      {
         Json::Value v(Json::arrayValue);
         v[0u] = 0.0;
         v[1] = 0.0;
         v[2] = 0.0;
         destination->setOffset( DtVector(source.get("Offset",v)[0u].asDouble(),
            source.get("Offset",v)[1u].asDouble(),
            source.get("Offset",v)[2u].asDouble() ) );
         destination->setOffsetOri( DtTaitBryan(source.get("OffsetOri",v)[0u].asDouble(),
            source.get("OffsetOri",v)[1u].asDouble(),
            source.get("OffsetOri",v)[2u].asDouble() ) );
         destination->setObserver( source.get("Observer","none").asCString() );
         destination->setAttachedEntity( source.get("AttachedEntity","none").asCString() );
      }

      void DtVrvMsgTranslator::translate(
         const DtPortalVrvTetherViewInteraction& source, Json::Value* destination)
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.offset()[0];
        v[1] = source.offset()[1];
        v[2] = source.offset()[2];
        (*destination)["Offset"] = v;
        v[0u] = source.offsetOri().psi();
        v[1] = source.offsetOri().theta();
        v[2] = source.offsetOri().phi();
        (*destination)["OffsetOri"] = v;
        (*destination)["Observer"] = source.observer().string();
        (*destination)["AttachedEntity"] = source.attachedEntity().string();
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvTetherViewInteraction* destination)
      {
         Json::Value v(Json::arrayValue);
         v[0u] = 0.0;
         v[1] = 0.0;
         v[2] = 0.0;
         destination->setOffset( DtVector(source.get("Offset",v)[0u].asDouble(),
            source.get("Offset",v)[1u].asDouble(),
            source.get("Offset",v)[2u].asDouble() ) );
         destination->setOffsetOri( DtTaitBryan(source.get("OffsetOri",v)[0u].asDouble(),
            source.get("OffsetOri",v)[1u].asDouble(),
            source.get("OffsetOri",v)[2u].asDouble() ) );
         destination->setObserver( source.get("Observer","none").asCString() );
         destination->setAttachedEntity( source.get("AttachedEntity","none").asCString() );
      }

      void DtVrvMsgTranslator::translate(
         const DtPortalVrvMouseEventInteraction& source, Json::Value* destination)
      {
        (*destination)["Observer"] = source.observerName().string();
        (*destination)["EventType"] = source.eventType().string();
        (*destination)["X"] = source.x();
        (*destination)["Y"] = source.y();
        (*destination)["Wheel"] = source.wheel();
        Json::Value mod(Json::objectValue);
        mod["Shift"] = source.shift();
        mod["Alt"] = source.alt();
        mod["Ctrl"] = source.ctrl();
        (*destination)["Modifiers"] = mod;
        Json::Value button(Json::objectValue);
        button["Left"] = source.left();
        button["Middle"] = source.middle();
        button["Right"] = source.right();
        (*destination)["Buttons"] = button;
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvMouseEventInteraction* destination)
      {
         Json::Value a(Json::objectValue);
         a = source.get("Modifiers",a);
         Json::Value b(Json::objectValue);
         b = source.get("Buttons",b);

         destination->setObserverName( source.get("ObserverName","Observer1").asCString() );
         destination->setEventType( source.get("EventType","Move").asCString() );
         destination->setX( source.get("X",0.0).asDouble() );
         destination->setY( source.get("Y",0.0).asDouble() );
         destination->setWheel( source.get("Wheel",0.0).asDouble() );
         destination->setLeft( b.get("Left",false).asBool() );
         destination->setMiddle( b.get("Middle",false).asBool() );
         destination->setRight( b.get("Right",false).asBool() );
         destination->setShift( a.get("Shift",false).asBool() );
         destination->setAlt( a.get("Alt",false).asBool() );
         destination->setCtrl( a.get("Ctrl",false).asBool() );
      }

      void DtVrvMsgTranslator::translate(
         const DtPortalVrvTrackHistoriesInteraction& source, Json::Value* destination)
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.vantage().site();
        v[1] = source.vantage().host();
        v[2] = source.vantage().entityNum();
        (*destination)["Vantage"] = v;
        (*destination)["ObserverMode"] = source.observerMode().string();
        (*destination)["TrackHistories"] = source.trackHistories();
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvTrackHistoriesInteraction* destination)
      {
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("Vantage",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setVantage( eid );
         destination->setObserverMode( source.get("ObserverMode","none").asCString() );
         destination->setTrackHistories( source.get("TrackHistories",false).asBool() );
      }

      void DtVrvMsgTranslator::translate(
         const DtPortalVrvDynamicOceanInteraction& source, Json::Value* destination)
      {
        Json::Value v(Json::arrayValue);
        v[0u] = source.vantage().site();
        v[1] = source.vantage().host();
        v[2] = source.vantage().entityNum();
        (*destination)["Vantage"] = v;
        (*destination)["ObserverMode"] = source.observerMode().string();
        (*destination)["DynamicOcean"] = source.dynamicOcean();
      }

      void DtVrvMsgTranslator::translate(
         const Json::Value& source, DtPortalVrvDynamicOceanInteraction* destination)
      {
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("Vantage",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setVantage( eid );
         destination->setObserverMode( source.get("ObserverMode","none").asCString() );
         destination->setDynamicOcean( source.get("DynamicOcean",false).asBool() );
      }


      void DtVrvMsgTranslator::processMsg( Json::Value* msg, DtClient* client )
      {
         DtPortalInteraction* pi;
         std::string type = msg->get("InteractionType","none").asString();
         std::map<std::string, int>::iterator it = myMessageTypes.find(type);
         if ( it == myMessageTypes.end() )
         {
            return;
         }

         switch ( it->second )
         {
         case 1: // "MAK:VrvMimicView"
         {
            DtPortalVrvMimicViewInteraction* destination = new DtPortalVrvMimicViewInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 2: // "MAK:VrvMimicTrackView"
         {
            DtPortalVrvMimicTrackViewInteraction* destination = new DtPortalVrvMimicTrackViewInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 3: // "MAK:VrvSensorMode"
         {
            DtPortalVrvSensorModeInteraction* destination = new DtPortalVrvSensorModeInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 4: // "MAK:VrvViewMagnification"
         {
            DtPortalVrvViewMagnificationInteraction* destination = new DtPortalVrvViewMagnificationInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 5: // "MAK:VrvObserverMode"
         {
            DtPortalVrvObserverModeInteraction* destination = new DtPortalVrvObserverModeInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 6: // "MAK:VrvUseSavedView"
         {
            DtPortalVrvUseSavedViewInteraction* destination = new DtPortalVrvUseSavedViewInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 7: // "MAK:VrvSetSystemState"
         {
            DtPortalVrvSetSystemStateInteraction* destination = new DtPortalVrvSetSystemStateInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 8: // "MAK:VrvModelSet"
         {
            DtPortalVrvModelSetInteraction* destination = new DtPortalVrvModelSetInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 9: // "MAK:VrvModelScaling"
         {
            DtPortalVrvModelScalingInteraction* destination = new DtPortalVrvModelScalingInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 10: // "MAK:VrvMoelScaleFactor"
         {
            DtPortalVrvModelScaleFactorInteraction* destination = new DtPortalVrvModelScaleFactorInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 11: // "MAK:VrvKeyPress"
         {
            DtPortalVrvKeyPressInteraction* destination = new DtPortalVrvKeyPressInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 12: // "MAK:VrvFollowView"
         {
            DtPortalVrvFollowViewInteraction* destination = new DtPortalVrvFollowViewInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 13: // "MAK:VrvTetherView"
         {
            DtPortalVrvTetherViewInteraction* destination = new DtPortalVrvTetherViewInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 14: // "MAK:VrvMouseEvent"
         {
            DtPortalVrvMouseEventInteraction* destination = new DtPortalVrvMouseEventInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 15: // "MAK:VrvTrackHistories"
         {
            DtPortalVrvTrackHistoriesInteraction* destination = new DtPortalVrvTrackHistoriesInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 16: // "MAK:VrvDynamicOcean"
         {
            DtPortalVrvDynamicOceanInteraction* destination = new DtPortalVrvDynamicOceanInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         default:
            return;
         }

         myBroker->portalConnection()->send( *pi );

         // Publish to all other WebLVC clients
         Json::FastWriter writer;
         std::string buffer = writer.write( *msg );
         webLvcBroker()->queueToSend( buffer, client );

         if ( myBroker->isTranslatorDebuggingOn(name()) )
         {
            printIncomingOutgoingStateReps( *msg, *pi );
         }

         DtDELETE( pi );
      }

      void DtVrvMsgTranslator::printIncomingOutgoingStateReps(
         const DtPortalMessage& incoming, const Json::Value& outgoing )
      {
         DtInfo << "========ORIG (Portal) - " << name() << " ========" << std::endl;
         DtInfo << incoming;
         DtInfo << "========NEW (WebLVC) - " << name() << " ========" << std::endl;
         DtInfo << outgoing.toStyledString();
         DtInfo << "------------------------------------------------" << std::endl;
      }

      void DtVrvMsgTranslator::printIncomingOutgoingStateReps(
         const Json::Value& incoming, const DtPortalMessage& outgoing )
      {
         DtInfo << "========ORIG (WebLVC) - " << name() << " ========" << std::endl;
         DtInfo << incoming.toStyledString();
         DtInfo << "========NEW (Portal) - " << name() << " ========" << std::endl;
         DtInfo << outgoing;
         DtInfo << "------------------------------------------------" << std::endl;
      }

      void DtVrvMsgTranslator::shutdown()
      {
         removeWebLvcCallbacks();
         removePortalCallbacks();
      }

      char DtVrvMsgTranslator::convertKey(Json::Value source)
      {
         bool failed = false;
         char out;
         std::string stringout;
         UINT uintOut;
         try 
         {
            source.get("Key", "none").asUInt();
            
         }
         catch(...)
         {
            failed = true;
         }
         if (!failed)
         {
            uintOut = source.get("Key", "none").asUInt();
            out = uintOut;
            return out;
         }
         else if (failed) 
         {
            try
            {
               source.get("Key", "none").asCString();
            }
            catch (...)
            {
               DtWarn << "Key conversion failed" << std::endl;
               return 'X';
            }
         }
         stringout = source.get("Key", "none").asCString();
         out = stringout[0];
         return out;

         //source.get("Key", "none").asCString()[0])
      }

   }
}
