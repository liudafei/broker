/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file omtObjectTranslator.cxx
//! \brief Contains the DtOmtObjectTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/omtObjectTranslator.h>

#include <omtReader/xmlFileReader.h>
#include <omtReader/omtFileReader.h>
#include <omtReader/stringTree.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtOmtObjectTranslator::DtOmtObjectTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalGenericObjectMessageKind )
         , myObjectModelTree( 0 )
         , myDatatypeManager( 0 )
      {
      }

      DtOmtObjectTranslator::~DtOmtObjectTranslator()
      {
         DtDELETE( myObjectModelTree );
      }

      bool DtOmtObjectTranslator::readObjectModel( const std::vector<DtString>& filenames )
      {
         // Abort if there are no OMT files.
         if ( filenames.empty() )
         {
            return true;
         }

         myObjectModelTree = new DtOMTTree();
         for( int i =0; i < filenames.size(); ++i )
         {
            DtOMTTree* t = NULL;
            DtFilename fName( filenames[i] );
            if ( fName.extension() == "xml" )
            {
               DtXMLFileReader fileReader;
               t = fileReader.readFile( fName, 0 );
            }
            else if ( fName.extension() == "omt" && filenames.size() == 1 )
            {
               DtOMTFileReader fileReader;
               t = fileReader.readFile( fName, 0 );
            }

            if ( t != NULL )
            {
               myObjectModelTree->merge( t );
               DtDELETE( t );
            }
         }

         if ( ! myDatatypeManager )
         {
            myDatatypeManager = DtDatatypeManager::defaultInstance();
         }
         myDatatypeManager->setDefaultDelimiter(",");
         myDatatypeManager->setArrayWrapper("[","]");

         if ( myObjectModelTree )
         {
            myDatatypeManager->initOMTData(myObjectModelTree);
            myDatatypeManager->fillDefaultDatatypeRepList();
            myDatatypeManager->readFile("datatypeWebLVC.mtl");

            DtInfo << "OMT Files loaded" << std::endl;
         }
         else
         {
            DtWarn << "OMT Files failed to load" << std::endl;
         }

         return true;
      }

      //Removing optimizations due to bug in VC8
#pragma optimize( "", off )
      void DtOmtObjectTranslator::translate( const Json::Value& source,
         DtPortalGenericObject* destination)
      {
         DtObjectClassFedNode* objectClassNode =
            myObjectModelTree->getObjectClassNode(source["ObjectType"].asString().c_str());
         if(!objectClassNode) return; //Error!

         destination->setClassName(source["ObjectType"].asString().c_str());

         DtAttributeValuePairList attributeList = destination->genericAttributeValuePairList();

         Json::Value::const_iterator pos = source.begin();
         for (; pos != source.end(); ++pos)
         {
            const DtAttributeFedNode* attributeNode = objectClassNode->findAttribute(pos.memberName());
            DtObjectClassFedNode* parentObjectClassNode = (DtObjectClassFedNode*)objectClassNode->getParentObject();;

            while(!attributeNode && parentObjectClassNode)
            {
               attributeNode = parentObjectClassNode->findAttribute(pos.memberName());
               parentObjectClassNode = (DtObjectClassFedNode*)parentObjectClassNode->getParentObject();
            }

            std::vector<char> result;
            if ( attributeNode )
            {
               const Json::Value& jsonChild = *pos ;

               populateFromJson(attributeNode->getDatatype(), jsonChild, result);
               DtAttributeValuePair attributePair;
               attributePair.first = attributeNode->getName();
                if(result.size() > 0)
                {
                   char* arrayResult = &result[0];
                   attributePair.second.setData(arrayResult, result.size());
                }
               attributeList.push_back(attributePair);
               result.clear();
            }
         }
         destination->setGenericAttributeValuePairList(attributeList);
      }
#pragma optimize( "", on )

      void DtOmtObjectTranslator::translate( const DtPortalGenericObject& source,
         Json::Value* destination )
      {
         (*destination)["ObjectType"] = source.className().c_str();

         DtObjectClassFedNode* objectClassNode = myObjectModelTree->getObjectClassNode(source.className());
         if ( ! objectClassNode )
         {
            return; //Error!
         }

         DtAttributeValuePairList::const_iterator pos = source.genericAttributeValuePairList().begin();
         DtAttributeValuePairList::const_iterator end = source.genericAttributeValuePairList().end();
         for ( ; pos != end; ++pos )
         {
            DtString attributeName = pos->first;
            const DtAttributeFedNode* attributeNode = objectClassNode->findAttribute(attributeName);
            DtObjectClassFedNode* parentObjectClassNode = (DtObjectClassFedNode*)objectClassNode->getParentObject();;
            while ( ! attributeNode && parentObjectClassNode )
            {
               attributeNode = parentObjectClassNode->findAttribute(attributeName);
               parentObjectClassNode = (DtObjectClassFedNode*)parentObjectClassNode->getParentObject();
            }

            if ( attributeNode )
            {
               int returnSize = 0;

               DtStringTree* stringTree = myDatatypeManager->createStringTreeRep( attributeNode,
                  pos->second.data(), pos->second.size(), returnSize );
               if ( stringTree )
               {
                  populateJson( stringTree, destination );
               }

               DtDELETE( stringTree );
            }
         }
      }

      void DtOmtObjectTranslator::populateJson( DtStringTree* stringTree, Json::Value* destination )
      {
         if(stringTree->myArray)
         {
            Json::Value childValue(Json::arrayValue);

            DtStringTree* arrayTree = stringTree;
            unsigned int arrayCount = 0;
            while (arrayTree)
            {
               if(arrayTree->myChild)
               {
                  DtStringTree* childTree = arrayTree->myChild;
                  while (childTree)
                  {
                     Json::Value arrayValue(Json::objectValue);
                     populateJson(childTree, &arrayValue);
                     childTree = arrayTree->myNext;
                     childValue[arrayCount] = arrayValue;
                  }
               }
               else
               {
                  childValue[arrayCount] = arrayTree->value().c_str();
               }


               arrayTree = arrayTree->myArray;
               ++arrayCount;
            }

            (*destination)[stringTree->key()] = childValue;
         }
         else if(stringTree->myChild)
         {
            DtStringTree* childTree = stringTree->myChild;
            Json::Value childValue(Json::objectValue);
            while (childTree)
            {
               populateJson(childTree, &childValue);
               childTree = childTree->myNext;
            }
            (*destination)[stringTree->key()] = (const Json::Value &)childValue;
         }
         else
         {
            (*destination)[stringTree->key()] = stringTree->value().c_str();
         }
      }

      void DtOmtObjectTranslator::populateFromJson( const DtString& datatypeName,
         const Json::Value& jsonTree, std::vector<char>& destination )
      {
         if ( jsonTree.isArray() )
         {
            Json::ValueIterator pos = jsonTree.begin();
            int posSize = jsonTree.size();
            DtArrayDatatypeNode* arrayNode = myObjectModelTree->getArrayDatatypeNode(datatypeName);

            for (int currLoc = 0; currLoc != posSize; ++currLoc)
            {
               populateFromJson(arrayNode->getDatatype(),*pos, destination);
               ++pos;
            }
         }
         else if ( jsonTree.isObject() )
         {
            switch ( myDatatypeManager->getDatatypeEnum(datatypeName) )
            {
            case DtDatatypeManager::COMPLEX:
               {
                  Json::ValueIterator pos = jsonTree.begin();
                  int posSize = jsonTree.size();
                  DtComplexDatatypeNode* complexNode = myObjectModelTree->getComplexDatatypeNode(datatypeName);

                  for (int currLoc = 0; currLoc != posSize; ++currLoc)
                  {
                     const char * memberName = pos.memberName();
                     DtComplexComponentNode* component = complexNode->getComponentNode(memberName);
                     if(component) populateFromJson(component->getDatatype(),*pos, destination);
                     ++pos;
                  }
                  break;
               }
            case DtDatatypeManager::FIXED:
               {
                  Json::ValueIterator pos = jsonTree.begin();
                  int posSize = jsonTree.size();
                  DtFixedDatatypeNode* fixedNode = myObjectModelTree->getFixedDatatypeNode(datatypeName);

                  for (int currLoc = 0; currLoc != posSize; ++currLoc)
                  {
                     const char * memberName = pos.memberName();
                     DtFieldComponentNode* component = fixedNode->getComponentNode(memberName);
                     if(component) populateFromJson(component->getDatatype(), *pos, destination);
                     ++pos;
                  }
                  break;
               }
            case DtDatatypeManager::VARIANT:
               // Not Yet Supported!
               break;

            default:
               if ( jsonTree.isString() )
               {
                  myDatatypeManager->getValueFromStringRep(datatypeName, jsonTree.asString().c_str(), destination);
               }
               else
               {
                  //value is a numeric
                  DtString val(0l);
                  if ( jsonTree.isNumeric() )
                  {
                     if ( jsonTree.isIntegral() )
                     {
                        if ( jsonTree.isUInt() )
                        {
                           unsigned int d = jsonTree.asUInt();
                           val = DtString(d);
                        }
                        else
                        {
                           int d = jsonTree.asInt();
                           val = DtString(d);
                        }
                     }
                     else
                     {
                        double data = jsonTree.asDouble();
                        val =  DtString(data);
                     }
                  }
                  myDatatypeManager->getValueFromStringRep(datatypeName, val, destination);
               }
               break;
            }
         }
         else
         {
            if ( jsonTree.isString() )
            {
               myDatatypeManager->getValueFromStringRep(datatypeName, jsonTree.asString().c_str(), destination);
            }
            else
            {
               //value is a numeric
               DtString val(0l);
               if ( jsonTree.isNumeric() )
               {
                  if ( jsonTree.isIntegral() )
                  {
                     if ( jsonTree.isUInt() )
                     {
                        unsigned int d = jsonTree.asUInt();
                        val = DtString(d);
                     }
                     else
                     {
                        int d = jsonTree.asInt();
                        val = DtString(d);
                     }
                  }
                  else
                  {
                     double data = jsonTree.asDouble();
                     val =  DtString(data);
                  }
               }
               myDatatypeManager->getValueFromStringRep( datatypeName, val, destination );
            }
         }
      }

   }
}
