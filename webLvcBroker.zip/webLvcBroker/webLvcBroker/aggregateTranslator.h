/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file aggregateTranslator.h
//! \brief Contains the DtAggregateTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#if ! _WIN64
#  ifndef _WIN32_WINNT
#     define _WIN32_WINNT 0x400
#  endif
#endif

#include <portal/pAggregate.h>
#include <broker/brokerObject.h>
#include <webLvcBroker/lvcObjectTranslator.h>
#include <omtReader/datatypeManager.h>
#include <omtReader/omtTree.h>

#define AGGREGATE_TEMPLATE_ARGS \
   DtPortalAggregate, DtPortalReflectedAggregate

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtAggregateTranslator are responsible for translating DtPortalAggregate to WebLVC:AggregateEntity.
      //!
      class DT_DLL_WEBLVCBROKER DtAggregateTranslator
         : public DtLvcObjectTranslator<AGGREGATE_TEMPLATE_ARGS>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:AggregateEntity" );

         //! \brief CTOR.
         DtAggregateTranslator( DtBroker* broker );

         //! \brief DTOR.
         virtual ~DtAggregateTranslator();

         //! Translators
         virtual void translate( const Json::Value& source, DtPortalAggregate* destination );
         virtual void translate( const DtPortalAggregate& source, Json::Value* destination );

         //! Add additional data for the object specified by name.
         virtual void addAdditionalDataValue( const DtString& name, const std::string& tag, const Json::Value& data );

         //! Clear out leftover name mappings and additional data when object goes away.
         virtual void removePortalObject( const DtPortalReflectedAggregate& obj );

      protected:

         std::map<DtString,Json::Value> myAdditionalDataMap;
         std::map<DtString,DtString> myNameLookup;

      };

   }
}
