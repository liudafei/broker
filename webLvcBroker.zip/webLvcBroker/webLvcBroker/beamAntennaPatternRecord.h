/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file beamAntennaPatternRecord.h
//! \brief Contains the DtBeamAntennaPatternRecord class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <vlpi/netStructs.h>
#include <matrix/vlTaitBryan.h>
#include <matrix/vlMath.h>
#include <vlpi/disEnums.h>

typedef struct DtNetBeamAntennaPatternRecord
{
   DtNetEulerAngles       angles;
   DtNetFloat32           azimuthWidth;
   DtNetFloat32           elevationWidth;
   DtNetU8                refSystem;
   DtNetU8                padding1;
   DtNetU16               padding2;
   DtNetFloat32           ez;
   DtNetFloat32           ex;
   DtNetFloat32           phase;
   DtNetU32               padding_32;
} DtNetBeamAntennaPatternRecord;


//! Instances of DtBeamAntennaPatternRecord are beam antenna pattern records
//! used in conjunction with DtRadioTransmitterStateRepository (TSR).
//! A DtAntennaPatternRecord obtained using the TSR's antennaPattern()
//! inspector can be used to initialize a DtBeamAntennaPatternRecord, whose
//! inspectors you can then use to view the data (assuming the AntennaPattern
//! Record really contained BeamAntennaPattern data.
//! Similarly, a DtBeamAntennaPatternRecord can be filled out and passed to
//! TSR's setAntennaPattern.
//! \ingroup vl
class DtBeamAntennaPatternRecord
{
public:

   //! default constructor
   DtBeamAntennaPatternRecord();

   //! copy constructor
   DtBeamAntennaPatternRecord(const DtBeamAntennaPatternRecord& orig);

   //! copy constructor using Network representation
   DtBeamAntennaPatternRecord(const DtNetBeamAntennaPatternRecord& net);

   //! destructor
   virtual ~DtBeamAntennaPatternRecord();

   //! assignment operator
   DtBeamAntennaPatternRecord& operator=(
      const DtBeamAntennaPatternRecord& orig);

   //! Initialize from bytes
   DtBeamAntennaPatternRecord(const void* net, int size);

   //! Set/Get the beam direction.
   virtual void setAngles(const DtTaitBryan &angles);
   virtual const DtTaitBryan &angles() const;

   //! Set/Get the azimuth bandwidth and elevation.
   virtual void setBeamwidth(DtFloat32 azimuth,
      DtFloat32 elevation);

   //! Get the azimuth beam bandwidth.
   virtual DtFloat32 azimuthBeamwidth() const;

   //! Get the elevation beam width.
   virtual DtFloat32 elevationBeamwidth() const;

   //! Set/Get the beam reference system.
   virtual void setReferenceSystem(const DtReferenceSys sys);
   virtual DtReferenceSys referenceSystem() const;

   //! Set electric field.
   virtual void setElectricField(DtFloat32 z, DtFloat32 x);

   //! Get electric field Z.
   virtual DtFloat32 electricFieldZ() const;

   //! Get electric field X.
   virtual DtFloat32 electricFieldX() const;

   //! Set/Get the phase.
   virtual void setPhase(DtFloat32 phase);
   virtual DtFloat32 phase() const;

   //! Set from network representation.
   virtual void setFromNet(const void* net, int size);

   //! Returns network representation, fills size with size of netRep.
   virtual const void* netRep(int* size = NULL) const;

   //! Returns size of network representation.
   virtual int netSize() const;

   //! Set from network representation.
   virtual void setFromNetBeam(const DtNetBeamAntennaPatternRecord& net);

   //! Also sets from network representation.  This function is here for
   //! backwards compatibility with pre-3.3 releases.
   virtual void setFromNet(const DtNetBeamAntennaPatternRecord& net);

   //! Returns network representation.
   virtual const DtNetBeamAntennaPatternRecord& netBeam() const;

   //! Also returns network representation.  This function is here for
   //! backwards compatibility with pre-3.3 releases.
   virtual const DtNetBeamAntennaPatternRecord& networkRepresentation() const;

protected:
   char* myNetRep;
   int myNetSize;

   DtTaitBryan    myBeamDirection;
   DtFloat32      myAzimuthBandwidth;
   DtFloat32      myElevationBeamwidth;
   DtReferenceSys myReferenceSystem;
   DtFloat32      myEz;
   DtFloat32      myEx;
   DtFloat32      myPhase;

   DtNetBeamAntennaPatternRecord myNetBeam;
};

inline const DtNetBeamAntennaPatternRecord&
   DtBeamAntennaPatternRecord::networkRepresentation() const
{
   return netBeam();
}

inline void DtBeamAntennaPatternRecord::setFromNet(
   const DtNetBeamAntennaPatternRecord& net)
{
   setFromNetBeam(net);
}
