/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcBroker.cxx
//! \brief Contains the DtWebLvcBroker class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <webLvcBroker/webLvcBrokerDialog.h>
#include <webLvcBroker/tcpConnectionServer.h>
#include <webLvcBroker/httpConnectionServer.h>
#include <webLvcBroker/client.h>
#include <webLvcBroker/tcpClient.h>
#include <webLvcBroker/vrfMsgTranslator.h>
#include <webLvcBroker/vrfBackEndTranslator.h>
#include <webLvcBroker/vrfAggregateTranslator.h>
#include <webLvcBroker/vrvMsgTranslator.h>
#include <webLvcBroker/loggerControlTranslator.h>
#include <webLvcBroker/dataTranslator.h>
#include <webLvcBroker/munitionDetonationTranslator.h>
#include <webLvcBroker/weaponFireTranslator.h>
#include <webLvcBroker/entityTranslator.h>
#include <webLvcBroker/aggregateTranslator.h>
#include <webLvcBroker/environmentalTranslator.h>
#include <webLvcBroker/omtObjectTranslator.h>
#include <webLvcBroker/omtInteractionTranslator.h>
#include <webLvcBroker/radioSignalTranslator.h>
#include <webLvcBroker/radioTransmitterTranslator.h>
#include <webLvcBroker/startResumeTranslator.h>
#include <webLvcBroker/stopFreezeTranslator.h>
#include <webLvcBroker/transferOwnershipTranslator.h>

#include <broker/statisticsManager.h>
#include <broker/brokerObject.h>
#include <broker/translator.h>

#include <portal/pLoggerPauseInteraction.h>
#include <portal/pLoggerStartInteraction.h>
#include <portal/pLoggerPlayInteraction.h>
#include <portal/pObjectPublisherTypes.h>
#include <portal/pDataInter.h>

#include <vl/entityStateRepository.h>
#include <vl/reflectedEntityList.h>
#include <vl/reflectedEntity.h>
#include <vl/exerciseConn.h>

#include <vlutil/vlProcessControl.h>

#include <vlpi/deadReckoner.h>

#include <Poco/Net/NetException.h>
#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/SocketAddress.h>
#include <Poco/Net/StreamSocket.h>

#include <matrix/geodeticCoord.h>
#include <matrix/topoCoord.h>

#include <iostream>
#include <sstream>
#include <ctime>


#define MAXNUMUNLICENSEDCLIENTS 1

using Poco::RWLock;
using Poco::Timestamp;
using Poco::TimeoutException;
using Poco::Net::NetException;
using Poco::Net::ServerSocket;
using Poco::Net::StreamSocket;
using Poco::Net::SocketAddress;
using Poco::Net::ConnectionAbortedException;
using Poco::Net::ConnectionResetException;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      RWLock DtWebLvcBroker::theRWLock;
      DtWebLvcBroker* DtWebLvcBroker::theWebLvcBroker = NULL;
      bool degraded = false;

      DtBroker* DtWebLvcBroker::create( DtBrokerInitializer* init )
      {
         DtWebLvcBroker* server = new DtWebLvcBroker();
         server->initialize( dynamic_cast<DtWebLvcBrokerInitializer*>(init) );
         return server;
      }

      DtWebLvcBroker::DtWebLvcBroker()
         : DtBroker()
         , myServers()
         , myTcpServer( 0 )
         , mySleepInterval( 0 )
         , myNumClients( 0 )
         , myStartTime( 0.0 )
         , numClientsSinceStart( 0 )
         , myAvgFrameTime( 0.0 )
         , myUpdateClients( false )
         , theClientList()
         , myManualTcpClient( 0 )
         , mySendQueue()
         , myAttributeUpdateTranslatorCBs()
         , myInteractionTranslatorCBs()
      {
         myBrokerType = WEBLVC;
         myStartTime = DtAbsRealTime();
      }

      DtWebLvcBroker::~DtWebLvcBroker()
      {
         assert( theClientList.size() == 0 );
         assert( myServers.size() == 0 );
         assert( myTcpServer == 0 );
      }

      void DtWebLvcBroker::initialize( DtWebLvcBrokerInitializer* init )
      {
         theWebLvcBroker = this;
         setupTranslators( init );
         DtBroker::initialize( init );
         DtBrokerConnectingMessage::addCallback(this->portalConnection(), processConnectCb, this);
      }

      void DtWebLvcBroker::setupTranslators( DtWebLvcBrokerInitializer* init )
      {
         // Set up the object translators.
         myObjectTranslatorFactory.addCreator<DtEntityTranslator>();
         myObjectTranslatorFactory.addCreator<DtVrfAggregateTranslator>();
         myObjectTranslatorFactory.addCreator<DtAggregateTranslator>();
         myObjectTranslatorFactory.addCreator<DtEnvironmentalTranslator>();
         myObjectTranslatorFactory.addCreator<DtVrfBackEndTranslator>();
         myObjectTranslatorFactory.addCreator<DtRadioTransmitterTranslator>();
         myObjectTranslatorFactory.addCreator<DtOmtObjectTranslator>();

         // Set up the interaction translators.
         myInteractionTranslatorFactory.addCreator<DtVrfMsgTranslator>();
         myInteractionTranslatorFactory.addCreator<DtVrvMsgTranslator>();
         myInteractionTranslatorFactory.addCreator<DtWeaponFireTranslator>();
         myInteractionTranslatorFactory.addCreator<DtMunitionDetonationTranslator>();
         myInteractionTranslatorFactory.addCreator<DtLoggerControlTranslator>();
         myInteractionTranslatorFactory.addCreator<DtRadioSignalTranslator>();
         myInteractionTranslatorFactory.addCreator<DtOmtInteractionTranslator>();
         myInteractionTranslatorFactory.addCreator<DtDataTranslator>();
         myInteractionTranslatorFactory.addCreator<DtStartResumeTranslator>();
         myInteractionTranslatorFactory.addCreator<DtStopFreezeTranslator>();
         myInteractionTranslatorFactory.addCreator<DtTransferOwnershipTranslator>();
      }

      void DtWebLvcBroker::startBroker()
      {
         DtWebLvcBrokerInitializer* init = webLvcInitializer();
         assert( myTcpServer == 0 );

         // Create a TCP server instance on the configured port (if enabled).
         if ( init->useTcpPort() )
         {
            // Set up a TCP server instance and start it.
            myTcpServer = new DtTcpConnectionServer( init->tcpSocketPort() );
            myTcpServer->start();
         }

         // Create HTTP Server instances for each configured port.
         std::vector<int> ports( init->webSocketPort() );
         std::vector<int>::iterator itr = ports.begin();
         std::vector<int>::iterator end = ports.end();
         for ( ; itr != end; ++itr )
         {
            // Set up an HTTP server instance and start it.
            DtHttpConnectionServer* s = new DtHttpConnectionServer( *itr );
            myServers.push_back( s );
            s->start();
         }

         // Call base implementation.
         DtBroker::startBroker();
      }

      void DtWebLvcBroker::initiateTcpConnection( const DtString& hostname, int port )
      {
         // Abort if there is already a manual TCP connection.
         if ( myManualTcpClient )
         {
            DtWarn << "Unable to open another manual TCP connection. Only one is supported at this time." << std::endl;
            return;
         }

         StreamSocket* socket = new StreamSocket( SocketAddress(hostname.c_str(),port) );
         myManualTcpClient = new DtTcpClient( socket );

         DtWebLvcBroker::theRWLock.writeLock();
         bool added = addClient( myManualTcpClient );
         DtWebLvcBroker::theRWLock.unlock();

         if ( added )
         {
            myManualTcpClient->start();

            Json::Value connectMsgJson;
            connectMsgJson["MessageKind"] = 3;
            connectMsgJson["WebLVCVersion"] = 1.0;
            connectMsgJson["ClientName"] = brokerName().c_str();
            connectMsgJson["RequestClientConnect"] = true;

            Json::FastWriter writer;
            std::string connectMsg = writer.write( connectMsgJson );
            myManualTcpClient->sendFrame( connectMsg.data(), (int) connectMsg.size() );
         }
      }

      DtWebLvcBrokerInitializer* DtWebLvcBroker::webLvcInitializer()
      {
         return (DtWebLvcBrokerInitializer*) myBrokerInitializer;
      }

      void DtWebLvcBroker::shutdown()
      {
         DtWebLvcBroker::theRWLock.writeLock();

         // Clean up the client list.
         std::list<DtClient*>::iterator itr = theClientList.begin();
         std::list<DtClient*>::iterator end = theClientList.end();
         for ( ; itr != end; )
         {
            DtDELETE( *itr );
            theClientList.erase( itr++ );
         }

         // Stop the HTTPServer
         if ( myServers.size() > 0 )
         {
            std::vector<DtReliableConnectionServer*>::iterator i = myServers.begin();
            std::vector<DtReliableConnectionServer*>::iterator e = myServers.end();
            for ( ; i != e; ++i )
            {
               (*i)->stop();
               DtDELETE( *i );
            }
            myServers.clear();
         }

         // Stop the Server
         if ( myTcpServer )
         {
            myTcpServer->stop();
            DtDELETE( myTcpServer );
         }

         // Shut down and destroy the translators.
         DtBroker::shutdown();

         DtWebLvcBroker::theRWLock.unlock();
      }

      void DtWebLvcBroker::loadTranslators()
      {
         DtBroker::loadTranslators();

         // Abort if we're just showing the connection dialog.
         if ( myBrokerInitializer->showConnectionInfoDialog() )
         {
            return;
         }

         // Get the OMT object and interaction translators.
         DtOmtObjectTranslator* objTranslator = (DtOmtObjectTranslator*)
            myObjectTranslatorMap[DtOmtObjectTranslator::translatorName()];
         DtOmtInteractionTranslator* intTranslator = (DtOmtInteractionTranslator*)
            myInteractionTranslatorMap[DtOmtInteractionTranslator::translatorName()];

         // Load the OMT files specified in the initializer.
         try
         {
            std::vector<DtString> tokens;
            ((DtWebLvcBrokerInitializer*)myBrokerInitializer)->omtFiles().tokenize( ';', tokens );
            objTranslator->readObjectModel( tokens );
            intTranslator->readObjectModel( tokens );
         }
         catch ( ... )
         {
         }
      }

      void DtWebLvcBroker::tick()
      {
         myStatisticsManager->startSection( DtFrameTimer::MESSAGE_PROC );
         std::list<DtClient*>::iterator iter = theClientList.begin();
         bool listchanged =false;
         while ( iter != theClientList.end() )
         {
            bool listEntryRemoved = false;

            if ( ! (*iter)->connected() )
            {

               //inform the translators of a client leaving so they can remove any publishers
               DtWebLvcBroker::NamedObjectTranslatorMap::const_iterator transItr = myObjectTranslatorMap.begin();
               DtWebLvcBroker::NamedObjectTranslatorMap::const_iterator transEnd = myObjectTranslatorMap.end();
               for ( ; transItr != transEnd; ++transItr )
               {
                  ((DtBaseWebLvcObjectTranslator*)transItr->second)->processClientRemoval( *iter );
               }

               time_t rawtime;
               struct tm * timeinfo;

               time ( &rawtime );
               timeinfo = localtime ( &rawtime );

               // If the client was the manually created client, clear it.
               if ( *iter == myManualTcpClient )
               {
                  myManualTcpClient = 0;
               }

               DtWarn("%s %s removing client %s \n",(*iter)->addrString().c_str(), asctime( timeinfo ), (*iter)->name().c_str()  );

               delete *iter;
               iter = theClientList.erase( iter );

               myUi->clientsUpdated();

               listEntryRemoved = true;
               listchanged = true;
            }

            if ( listEntryRemoved == false )
            {
               ++iter;
            }
         }

         if (  theClientList.size() != myNumClients || listchanged )
         {
            // this is just sloppy but quick its entirely possible to slip clients in without
            // the gui knowing.
            myNumClients = theClientList.size();
         }

         myStatisticsManager->endSection( DtFrameTimer::MESSAGE_PROC );

         //Clients now do this themselves
         //sendStateUpdateMessage();

         myStatisticsManager->startSection( DtFrameTimer::TRANSLATION );

         receiveFromWebClients();

         sendQueue();

         myStatisticsManager->endSection( DtFrameTimer::TRANSLATION );

      }

      void DtWebLvcBroker::processEvents()
      {
         myStatisticsManager->startFrame();

         myStatisticsManager->startSection( DtFrameTimer::INTERNAL );
         //lock object lists on translators
         //NamedObjectTranslatorMap::const_iterator itr = objectTranslators().begin();
         //NamedObjectTranslatorMap::const_iterator end = objectTranslators().end();
         //for( ; itr != end; ++itr )
         //{
         //   if ( itr->second->isPublishEnabled() || itr->second->isReflectEnabled() )
         //   {
         //      ((DtBaseWebLvcObjectTranslator*)itr->second)->lock()->writeLock();
         //   }
         //}

         try
         {
            portalConnection()->drainInput( myBrokerInitializer->maxControlMessages(),
               myBrokerInitializer->maxInteractionMessages(),
               myBrokerInitializer->maxObjectMessages() );
         }
         catch ( DtVrxDisconnectedException& e )
         {
            DtWarn << e.message();
            myShutdownRequestedFlag = true; //Shutdown if vrx is nonexistent
            //return;
         }
         catch ( ... )
         {
            DtWarn << "bad things happened in drain input" << std::endl;
         }

         //unlock translator obj managers
         //for ( itr = objectTranslators().begin() ; itr != end; ++itr )
         //{
         //   if ( itr->second->isPublishEnabled() || itr->second->isReflectEnabled() )
         //   {
         //      ((DtBaseWebLvcObjectTranslator*)itr->second)->lock()->unlock();
         //   }
         //}
         myStatisticsManager->endSection( DtFrameTimer::INTERNAL );

         myStatisticsManager->startSection( DtFrameTimer::EXTERNAL );

         if(myBrokerId != 0)
         {
            updateSimTime();
            try
            {
               tick(); //Only update once we have an updated brokerID.
            }
            catch (DtException& e)
            {
               shutdownWithError(e.message());
               return;
            }
         }
         myStatisticsManager->endSection( DtFrameTimer::EXTERNAL );

         myStatisticsManager->endFrame();
         myStatisticsManager->tick();
      }


      void DtWebLvcBroker::sendToWebClients( std::string buffer )
      {
         DtWebLvcBroker::theRWLock.writeLock();

         std::list<DtClient*>::iterator iter = theClientList.begin();
         for(; iter != theClientList.end(); ++iter )
         {
            (*iter)->sendMsg(buffer);
         }
         DtWebLvcBroker::theRWLock.unlock();
      }

      void DtWebLvcBroker::receiveFromWebClients()
      {
         Poco::ScopedWriteRWLock lock( DtWebLvcBroker::theRWLock );

         std::string msg;
         std::list<DtClient*>::iterator iter;
         for ( iter = theClientList.begin(); iter != theClientList.end(); ++iter )
         {
            while ( (*iter)->receiveMsg(msg) == true )
            {
               processInboundMessage( msg, *iter );
            }
         }
         if ( myUpdateClients && myUi )
         {
            myUpdateClients = false;
            myUi->clientsUpdated();
         }
      }

      int DtWebLvcBroker::processObjectUpdateSets( void* id )
      {
         int count = 0;
         NamedObjectTranslatorMap::iterator itr = myObjectTranslatorMap.begin();
         NamedObjectTranslatorMap::iterator end = myObjectTranslatorMap.end();
         for ( ; itr != end; ++itr )
         {
            count += ((DtBaseWebLvcObjectTranslator*)itr->second)->processUpdateSet( id );
         }
         return count;
      }

      void DtWebLvcBroker::processInboundMessage( std::string& msg, DtClient* client )
      {
         DtDebug << "ProcessInboundMessage: " << msg.c_str() << " from client: " << client->name() << std::endl;
         Json::Value root;
         Json::Reader reader;
         if (msg.find("MessageKind") == -1)
         {
            //TODO: Is there a better check we can do here?
            //message has no message kind, dont' process 
            return;
         }

         reader.parse( msg, root );

         int msgType = 9999;
         try
         {
            msgType = root.get("MessageKind",9999).asInt();
         }
         catch (...)
         {
            try
            {
               // Try a string. Sometimes its "1" not 1. There's some inconsistency here
               // as far as I can tell.
               msgType = atoi( root.get("MessageKind","9999").asString().c_str() );
            }
            catch (...)
            {
               time_t rawtime;
               struct tm * timeinfo;
               time ( &rawtime );
               timeinfo = localtime ( &rawtime );

               DtWarn("WARNING Bad message received from %s %s \n",client->addrString().c_str(), asctime( timeinfo )  );
               return;
            }
         }

         switch ( msgType )
         {
         case 0: // Other
            break;
         case 1: // AttributeUpdate
            processAttributeUpdateMessage( &root, client );
            break;
         case 2: // Interaction
            processInteractionMessage( &root, client );
            break;
         case 3: // Connect
            client->processConnectMsg( root );
            myUpdateClients = true;
            break;
         case 4: // Object Deletion
            processObjectDeletionMessage( &root, client );
            time_t rawtime;
            struct tm* timeinfo;
            time ( &rawtime );
            timeinfo = localtime( &rawtime );

            DtWarn("%s %s received deletion %s \n", client->addrString().c_str(), asctime( timeinfo ), msg.c_str()  );
            break;
         case 5: // Refresh
            client->sendStateUpdateMessages();
            break;
         default:
            DtWarn("unhandled inbound message:\n %s\n", msg.c_str() );
            break;
         }
      }

      void DtWebLvcBroker::addAttributeUpdateCB( const std::string& s, DtBaseWebLvcObjectTranslator* trans )
      {
         myAttributeUpdateTranslatorCBs[s] = trans;
      }

      void DtWebLvcBroker::removeAttributeUpdateCB( const std::string& s )
      {
         myAttributeUpdateTranslatorCBs.erase( s );
      }
      void DtWebLvcBroker::addInteractionCB( const std::string& s, DtBaseWebLvcInteractionTranslator* trans )
      {
         myInteractionTranslatorCBs[s] = trans;
      }

      void DtWebLvcBroker::removeInteractionCB( const std::string& s )
      {
         myInteractionTranslatorCBs.erase( s );
      }

      void DtWebLvcBroker::addAdditionalDataValue( const DtString& name,
         const std::string& tag, const Json::Value& source )
      {
         addAdditionalDataValue<DtVrfAggregateTranslator>( name, tag, source );
         addAdditionalDataValue<DtAggregateTranslator>( name, tag, source );
         addAdditionalDataValue<DtEntityTranslator>( name, tag, source );
      }

      template <typename T>
      void DtWebLvcBroker::addAdditionalDataValue( const DtString& name,
         const std::string& tag, const Json::Value& source )
      {
         T* translator = (T*) getObjectTranslator( T::translatorName() );
         if ( ! translator )
         {
            return;
         }

         translator->addAdditionalDataValue( name, tag, source );
      }

      inline void DtWebLvcBroker::processAttributeUpdateMessage( Json::Value* msg, DtClient* client )
      {
         try
         {
            std::string key = msg->get("ObjectType","none").asString();

            std::map<std::string, DtBaseWebLvcObjectTranslator*>::iterator i =
               myAttributeUpdateTranslatorCBs.find( key );
            if ( i != myAttributeUpdateTranslatorCBs.end() )
            {
               i->second->processMsg( msg, client );
            }
            else
            {
               // Could not find, try basic translator...
               i = myAttributeUpdateTranslatorCBs.find("OMT:Objects");
               if ( i != myAttributeUpdateTranslatorCBs.end() )
               {
                  i->second->processMsg( msg, client );
               }
            }
         }
         catch ( ... )
         {
            DtWarn << "Problem processing attribute update, bad objectType maybe?" << std::endl;
         }
      }

      inline void DtWebLvcBroker::processInteractionMessage( Json::Value* msg, DtClient* client )
      {
         try
         {
            std::string key = msg->get("InteractionType","none").asString();

            std::map<std::string,DtBaseWebLvcInteractionTranslator*>::iterator i = myInteractionTranslatorCBs.find( key );
            if ( i != myInteractionTranslatorCBs.end() )
            {
               i->second->processMsg( msg, client );
            }
            else
            {
               // Could not find, try basic translator...
               i = myInteractionTranslatorCBs.find( "OMT:Interactions" );
               if ( i != myInteractionTranslatorCBs.end() )
               {
                  i->second->processMsg(msg,client);
               }
            }

            time_t rawtime;
            struct tm * timeinfo;
            time ( &rawtime );
            timeinfo = localtime ( &rawtime );

            DtWarn("%s %s received interaction %s \n",client->addrString().c_str(), asctime( timeinfo ), key.c_str()  );
         }
         catch ( ... )
         {
            DtWarn << "Problem processing interaction, bad type maybe?" << std::endl;
         }

      }

      void DtWebLvcBroker::processObjectDeletionMessage( Json::Value* msg, DtClient* client )
      {
         NamedObjectTranslatorMap::const_iterator itr = objectTranslators().begin();
         NamedObjectTranslatorMap::const_iterator end = objectTranslators().end();
         std::string id = msg->get("ObjectName","none").asString();
         DtBrokerObject* obj = NULL;
         for ( ; itr != end; ++itr )
         {
            ((DtBaseWebLvcObjectTranslator*)itr->second)->removeClientObject( id );
         }
      }

      bool DtWebLvcBroker::addClient( DtClient* client )
      {
         int numClients = theWebLvcBroker->theClientList.size();
         if ( degraded && numClients >= MAXNUMUNLICENSEDCLIENTS )
         {
            DtWarn("You are running in Unlicensed mode. Clients outside of the first one have been dropped.");
            DtDELETE( client );
            return false;
         }
         numClientsSinceStart++;

         time_t rawtime;
         struct tm* timeinfo;

         time ( &rawtime );
         timeinfo = localtime ( &rawtime );

         DtWarn( "%s %s adding client %d \n", client->addrString().c_str(),
            asctime( timeinfo ), theWebLvcBroker->theClientList.size() + 1  );
         theWebLvcBroker->theClientList.push_back( client );
         client->setBroker( theWebLvcBroker );

         // add update sets for the client
         NamedObjectTranslatorMap::const_iterator itr = objectTranslators().begin();
         NamedObjectTranslatorMap::const_iterator end = objectTranslators().end();
         for ( ; itr != end; ++itr )
         {
            ((DtBaseWebLvcObjectTranslator*)itr->second)->createUpdateSet( client );
         }

         // Update the gui that there was a change.
         myUpdateClients = true;

         return true;
      }

      void DtWebLvcBroker::sendQueue()
      {
         DtWebLvcBroker::theRWLock.writeLock();

         SendQueue::iterator itr = mySendQueue.begin();
         SendQueue::iterator end = mySendQueue.end();
         for ( ; itr != end; ++itr )
         {
            std::list<DtClient*>::iterator clientItr = theClientList.begin();
            std::list<DtClient*>::iterator clientEnd = theClientList.end();
            for ( ; clientItr != clientEnd; ++clientItr )
            {
               if ( *clientItr != itr->first )
               {
                  (*clientItr)->sendMsg( itr->second );
               }
            }
         }
         mySendQueue.clear();

         DtWebLvcBroker::theRWLock.unlock();
      }

      void DtWebLvcBroker::queueToSend( std::string& msg, DtClient* client )
      {
         mySendQueue.push_back( std::make_pair(client,msg) );
      }

      void DtWebLvcBroker::processConnectCb(const DtBrokerConnectingMessage& msg, void* usr)
      {
         DtWebLvcBroker* broker = (DtWebLvcBroker*)usr;
         if (broker->brokerName() == msg.brokerName() && broker->brokerId() == msg.brokerId() )
         {
            degraded = true;
            DtWarn("You are running in Unlicensed mode. Clients outside of the first one have been dropped.");
         }

      }

   }
}
