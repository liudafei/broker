/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file entityTranslator.cxx
//! \brief Contains the DtEntityTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/entityTranslator.h>

#include <omtReader/xmlFileReader.h>
#include <omtReader/omtFileReader.h>

#include <vlpi/deadReckoner.h>
#include <matrix/geodeticCoord.h>
#include <matrix/topoCoord.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtEntityTranslator::DtEntityTranslator(DtBroker* broker)
         : ParentClass(broker, translatorName(), DtPortalEntityObjectMessageKind)
         , myAdditionalDataMap()
         , myNameLookup()
      {
      }

      DtEntityTranslator::~DtEntityTranslator()
      {
      }

      void DtEntityTranslator::translate(const Json::Value& source, DtPortalEntity* pEnt)
      {
         //entityId
         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = 0;
         entityIdentifier[1] = 0;
         entityIdentifier[2] = 0;
         //If message contains entityIdentifier, pull it out and set it.
         if (source.isMember("EntityIdentifier"))
         {
             Json::Value entId = source.get("EntityIdentifier", entityIdentifier);
             std::stringstream eid;
             if (entId.isString())
             {
                 pEnt->setEntityId(entId.asCString());
             }
             else
             {

                 eid << entId.get(0u, 1).asInt();
                 eid << ":" << entId.get(1, 1).asInt();
                 eid << ":" << entId.get(2, 1).asInt();
                 pEnt->setEntityId(eid.str().c_str());
             }
         }
         //entityType
         Json::Value entityType(Json::arrayValue);
         //If message contains EntityType, pull it out and set it.
         if (source.isMember("EntityType"))
         {
             Json::Value entType = source.get("EntityType", "0,0,0,0,0,0,0");
             if (entType.isString())
             {
                 pEnt->setEntityType(DtEntityType(entType.asCString()));
                 pEnt->setGuise(entType.asCString());
             }
             else
             {
                 pEnt->setEntityType(DtEntityType(entType.get(0u, -1).asInt(), entType.get(1, -1).asInt(),
                     entType.get(2, -1).asInt(), entType.get(3, -1).asInt(),
                     entType.get(4, -1).asInt(), entType.get(5, -1).asInt(),
                     entType.get(6, -1).asInt()));
                 pEnt->setGuise(DtEntityType(entType.get(0u, -1).asInt(), entType.get(1, -1).asInt(),
                     entType.get(2, -1).asInt(), entType.get(3, -1).asInt(),
                     entType.get(4, -1).asInt(), entType.get(5, -1).asInt(),
                     entType.get(6, -1).asInt()).string());
             }
         }
         //marking text
         if (source.isMember("Marking"))
         {
             pEnt->setMarkingText(source.get("Marking", pEnt->markingText().c_str()).asCString());
         }  
         Json::Value defVal(Json::arrayValue);
         defVal[0u] = 0.0;
         defVal[1] = 0.0;
         defVal[2] = 0.0;
         //translate an attribute update to a portal entity sr
         unsigned dr = source.get("DeadReckoningAlgorithm", -1).asInt();
         if (dr != -1)
         {
            pEnt->setAlgorithm(dr);
         }
         //world location
         if (source.isMember("WorldLocation"))
         {
             Json::Value wl = source.get("WorldLocation", defVal);
             if (wl.isArray())
             {
                 try {
                     pEnt->setLocation(DtVector(wl.get(0u, 0).asDouble(), wl.get(1, 0).asDouble(), wl.get(2, 0).asDouble()));
                 }
                 catch (...)
                 {
                 }
             }
             else
                 DtWarn(" Received non array world location \n");
         }
         //velocity
         if (source.isMember("VelocityVector"))
         {
             Json::Value vv = source.get("VelocityVector", defVal);
             if (vv.isArray())
             {
                 try {
                     pEnt->setVelocity(DtVector32(vv.get(0u, 0).asDouble(), vv.get(1, 0).asDouble(), vv.get(2, 0).asDouble()));
                 }
                 catch (...)
                 {
                 }
             }
             else
                 DtWarn(" Received non array velocity vector \n");
         }
         //acceleration
         if (source.isMember("AccelerationVector"))
         {
             Json::Value av = source.get("AccelerationVector", defVal);
             if (av.isArray())
             {
                 try {
                     pEnt->setAcceleration(DtVector32(av.get(0u, 0).asDouble(), av.get(1, 0).asDouble(), av.get(2, 0).asDouble()));
                 }
                 catch (...)
                 {
                 }
             }
             else
                 DtWarn(" Received non array Acceleration vector \n");
         }
         //orientation
         if (source.isMember("Orientation"))
         {
             Json::Value vor = source.get("Orientation", defVal);
             if (vor.isArray())
             {
                 try {
                     pEnt->setOrientation(DtTaitBryan(vor.get(0u, 0).asDouble(), vor.get(1, 0).asDouble(), vor.get(2, 0).asDouble()));
                 }
                 catch (...)
                 {
                 }
             }
             else
                 DtWarn(" Received non array Orientation vector \n");
         }
         //angular/rotational velocity
         if (source.isMember("AngularVelocity"))
         {
             Json::Value ang = source.get("AngularVelocity", defVal);
             if (ang.isArray())
             {
                 try {
                     pEnt->setRotationalVelocity(DtVector32(ang.get(0u, 0).asDouble(), ang.get(1, 0).asDouble(), ang.get(2, 0).asDouble()));
                 }
                 catch (...)
                 {
                 }
             }
             else
             {
                 DtWarn(" Received non array Angular velocity \n");
             }
         }
         int fid = source.get("ForceIdentifier", -1).asInt();
         if (fid != -1)
         {
            pEnt->setForceId(fid);
         }
         double dmg = source.get("DamageState", -1).asDouble();
         if (dmg != -1)
         {
            pEnt->setDamageState(dmg);
         }
         double firePowerDisabled = source.get("FirePowerDisabled", -1).asDouble();
         if (firePowerDisabled != -1)
         {
            pEnt->setFirePowerDisabled(firePowerDisabled);
         }
         double immobilized = source.get("Immobilized", -1).asDouble();
         if (immobilized != -1)
         {
            pEnt->setImmobilized(immobilized);
         }
         /* do I care about the timestamp the client is sending me?
         double t = m->get("Timestamp",-1).asDouble();
         if( t != -1 )
         {
         pe->sr()->setTimeRecieved(t);
         }
         */
         pEnt->setTimeReceived(myBroker->portalConnection()->clock()->simTime());

         pEnt->setHostId(source.get("HostId", "").asCString());
      }

      void DtEntityTranslator::translate(const DtPortalEntity&   source,
         Json::Value* destination)
      {
         DtTime dt = webLvcBroker()->portalConnection()->clock()->simTime() - source.timeReceived();

         DtVector loc;
         DtVector32 vel;
         DtDeadReckoner::deadReckonPosition(dt, (DtDeadReckonTypes)source.algorithm(), source.location(),
            source.velocity(), source.acceleration(), vel, loc);

         DtDcm newb2w;
         DtDeadReckoner::deadReckonOrientation(dt, (DtDeadReckonTypes)source.algorithm(),
            source.orientation(), source.rotationalVelocity(), newb2w);

         DtGeodeticCoord geodeticLocation;
         geodeticLocation.setGeocentric(loc);

         DtTaitBryan neworient;
         DtBodyToRef_to_Euler(newb2w, &neworient);

         DtCoordTransform geocToTopo;
         DtGeocToTopoTransform(geodeticLocation.lat(), geodeticLocation.lon(), &geocToTopo);

         DtTaitBryan topoEuler;
         geocToTopo.eulerTrans(neworient, &topoEuler);

         /*************************************************/
         // Create a JSON formatted message to send instead
         /*************************************************/

         // 1 � PhysicalEntity
         (*destination)["ObjectType"] = "WebLVC:PhysicalEntity";

         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = source.entityId().site();
         entityIdentifier[1] = source.entityId().host();
         entityIdentifier[2] = source.entityId().entityNum();

         (*destination)["EntityIdentifier"] = entityIdentifier;

         Json::Value entityType(Json::arrayValue);
         entityType[0u] = source.entityType().kind();
         entityType[1] = source.entityType().domain();
         entityType[2] = source.entityType().country();
         entityType[3] = source.entityType().category();
         entityType[4] = source.entityType().subCategory();
         entityType[5] = source.entityType().specific();
         entityType[6] = source.entityType().extra();

         (*destination)["EntityType"] = entityType;

         (*destination)["DeadReckoningAlgorithm"] = (unsigned int)source.algorithm();

         Json::Value worldLocation(Json::arrayValue);
         worldLocation[0u] = loc[0];
         worldLocation[1] = loc[1];
         worldLocation[2] = loc[2];

         (*destination)["WorldLocation"] = worldLocation;

         Json::Value velocity(Json::arrayValue);
         velocity[0u] = vel[0];
         velocity[1] = vel[1];
         velocity[2] = vel[2];

         (*destination)["VelocityVector"] = velocity;

         Json::Value acceleration(Json::arrayValue);
         acceleration[0u] = source.acceleration()[0];
         acceleration[1] = source.acceleration()[1];
         acceleration[2] = source.acceleration()[2];

         (*destination)["AccelerationVector"] = acceleration;

         Json::Value orientation(Json::arrayValue);
         orientation[0u] = neworient.psi();
         orientation[1] = neworient.theta();
         orientation[2] = neworient.phi();

         (*destination)["Orientation"] = orientation;

         Json::Value angularVelocity(Json::arrayValue);
         angularVelocity[0u] = source.rotationalVelocity()[0];
         angularVelocity[1] = source.rotationalVelocity()[1];
         angularVelocity[2] = source.rotationalVelocity()[2];

         //Frozen Bit - Need to have output here for frozen bool
         (*destination)["Frozen"] = (bool)source.frozen();

         (*destination)["AngularVelocity"] = angularVelocity;

         (*destination)["ForceIdentifier"] = (unsigned int)source.forceId();

         (*destination)["Marking"] = source.markingText().string();

         (*destination)["DamageState"] = (unsigned int)source.damageState();

         (*destination)["FirePowerDisabled"] = (unsigned int)source.firePowerDisabled();

         (*destination)["Immobilized"] = (unsigned int)source.immobilized();

         (*destination)["HostId"] = source.hostId().c_str();

		 std::string marking = source.markingText().c_str();
		 std::string ident = source.identifier().c_str();
       if (!marking.empty() && !ident.empty())
         {
            std::map<std::string, std::string>::const_iterator i = myNameLookup.find(marking);
            if (i == myNameLookup.end())
            {
               // Vrf does not know about the id business all that well
               myNameLookup[marking] = ident;
            }

            std::map<std::string, Json::Value>::const_iterator j = myAdditionalDataMap.find(marking);
            if (j != myAdditionalDataMap.end())
            {
               (*destination)["AdditionalData"] = j->second;
            }
         }
      }

      void DtEntityTranslator::addAdditionalDataValue(const DtString& name,
         const std::string& tag, const Json::Value& source)
      {
         myLock.writeLock();
            
         std::string strname = name.c_str();
         Json::Value v = myAdditionalDataMap[strname];
         v[tag] = source;
         myAdditionalDataMap[strname] = v;

         // if it is then this message beat the object update and
         // the data can hang out until the discovery
         std::map<std::string, std::string>::iterator i = myNameLookup.find(strname);
         if (i != myNameLookup.end())
         {
            // otherwise mark the entity for updating to the clients
            std::map<void*, std::set<DtString> >::iterator u = this->myLvcUpdateSet.begin();
            for (; u != this->myLvcUpdateSet.end(); ++u)
            {
               u->second.insert(i->second);
            }
         }

         myLock.unlock();
      }

      void DtEntityTranslator::removePortalObject(const DtPortalReflectedEntity& obj)
      {
         myLock.writeLock();

         std::string marking = obj.sr()->markingText().c_str();
         if (!marking.empty())
         {
            std::map<std::string, Json::Value>::iterator addIter = myAdditionalDataMap.find(marking);
            if (addIter != myAdditionalDataMap.end())
            {
               myAdditionalDataMap.erase(addIter);
            }

            std::map<std::string, std::string>::iterator nameIter = myNameLookup.find(marking);
            if (nameIter != myNameLookup.end())
            {
               myNameLookup.erase(nameIter);
            }
         }

         myLock.unlock();

         ParentClass::removePortalObject(obj);
      }

   }
}
