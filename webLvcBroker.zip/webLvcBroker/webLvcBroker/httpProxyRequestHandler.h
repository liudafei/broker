/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file httpProxyRequestHandler.h
//! \brief Contains the DtHttpProxyRequestHandler class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <Poco/Net/HTTPRequestHandler.h>
#include <Poco/Net/WebSocket.h>
#include <Poco/Timestamp.h>
#include <Poco/RWLock.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtWebSocketRequestHandler is a class that sets up a web
      //! socket connection to a client and then sends entity state updates through
      //! that connection.
      class DT_DLL_WEBLVCBROKER DtHttpProxyRequestHandler : public Poco::Net::HTTPRequestHandler
      {
      public:

         //! \brief CTOR.
         DtHttpProxyRequestHandler();

         //! \brief Virtual DTOR.
         virtual ~DtHttpProxyRequestHandler();

         //! Creates a websocket and adds it to the list of sockets in
         //! DtWebLvcBroker::theWebSocketList.
         void handleRequest( Poco::Net::HTTPServerRequest& request,
            Poco::Net::HTTPServerResponse& response );

      private:

         //! Copy Constructor not implemented - Copy Not Allowed.
         DtHttpProxyRequestHandler( const DtHttpProxyRequestHandler& other );

         //! Assignment Operator Not implemented - Assignment Not Allowed.
         DtHttpProxyRequestHandler& operator = ( const DtHttpProxyRequestHandler& other );

      };

   }
}
