/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file tcpSocketConnection.cxx
//! \brief Contains the DtTcpSocketConnection class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/tcpSocketConnection.h>
#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/tcpClient.h>

#include <vlutil/vlProcessControl.h>
#include <vlutil/vlPrint.h>

#include <Poco/RWLock.h>

using Poco::RWLock;
using Poco::Net::StreamSocket;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtTcpSocketConnection::DtTcpSocketConnection( const StreamSocket& socket )
         : TCPServerConnection( socket )
      {
      }

      DtTcpSocketConnection::~DtTcpSocketConnection()
      {
      }

      void DtTcpSocketConnection::run()
      {
         DtTcpClient* wc = new DtTcpClient( socket() );

         DtWebLvcBroker::theRWLock.writeLock();
         bool added = DtWebLvcBroker::theWebLvcBroker->addClient( wc );
         DtWebLvcBroker::theRWLock.unlock();

         if ( added )
         {
            wc->start();
         }

         DtInfo << "TCP connection established." << std::endl;

         while ( true )
         {
            DtSleep( 0.1 );
         }
      }

   }
}
