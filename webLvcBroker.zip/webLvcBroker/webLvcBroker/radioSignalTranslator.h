/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioSignalTranslator.h
//! \brief Contains the DtRadioSignalTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <webLvcBroker/lvcInteractionTranslator.h>
#include <portal/pRadioSignalInter.h>
#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtRadioSignalTranslator are responsible for translating DtPortalFireInteraction to WebLVC:RadioSignal.
      class DT_DLL_WEBLVCBROKER DtRadioSignalTranslator : public DtLvcInteractionTranslator<DtPortalRadioSignalInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:RadioSignal" );

         //! \brief CTOR.
         DtRadioSignalTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtRadioSignalTranslator();

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, DtPortalRadioSignalInteraction* destination );
         virtual void translate( const DtPortalRadioSignalInteraction& source, Json::Value* destination );

      };

   }
}
