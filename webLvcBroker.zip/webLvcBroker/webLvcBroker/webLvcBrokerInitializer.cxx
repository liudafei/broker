/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcBrokerInitializer.cxx
//! \brief Contains the DtWebLvcBrokerInitializer class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <mtl/mtlEnvironment.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtString theProxyHost = "127.0.0.1";
      int theProxyPort = 8080;
      bool theEnableHttpServer = true;
      DtString theLocalHttpDirectory = "../html";
      bool theEnableHttpProxy = true;
      DtString theLocalNonProxyDir = "local";
      bool theEnableStatusPage = true;
      DtString theSSLCertificate = "";


      DtWebLvcBrokerInitializer::DtWebLvcBrokerInitializer( int argc, char* argv[],
            const DtString& version )
         : DtBrokerInitializer( argc, argv, version )
         , myConfigVarWebSocketPort( &mySettings, "&webPort", "9101", "Web Server Port" )
         , myConfigVarUseTcpPort( &mySettings, "useTcpPort", false, "Use Tcp Server Port" )
         , myConfigVarTcpSocketPort( &mySettings, "tcp&ServerPort", 9102, "Tcp Server Port" )
         , mySleepInterval( &mySettings, "sleepInterval", 0.05, "Sleep Interval" )
         , myConfigVarOmtFiles( &mySettings, "omtFiles", "MAK-RPR2-1-3.omt", "OMT Translation File" )
         , myConfigVarProxyHost( &mySettings, "proxyDest", "localhost", "Proxy Destination" )
         , myConfigVarProxyPort(&mySettings, "proxyPort", 8080, "Proxy Destination Port")
         , myConfigEnableHttpServer(&mySettings, "httpServer", true, "Enable Web Server")
         , myConfigLocalHttpDirectory(&mySettings, "localHttpDirectory", "../html", "Local HTTP Directory")
         , myConfigEnableHttpProxy(&mySettings, "httpProxy", true, "Enable HTTP Proxy")
         , myConfigLocalNonProxyDir(&mySettings, "localNonProxyDir", "local", "Local Non-Proxy Dir")
         , myConfigEnableStatusPage(&mySettings, "statusPage", true, "Enable Status Page")
         , myConfigSSLCertificate(&mySettings, "sslCertificate", "", "SSL Certificate for HTTPS")
      {
         setPollingInterval( mySleepInterval.value() * 1000 );
         setPluginDirectory( "../plugins/webLvcBroker" );
         setLogFileName( "webLvcBroker.log" );
#ifdef DtHLA_1516_EVOLVED
         setFederateName( "WebLVC Server" );

         // Include VRF-AggregateExt1 FOM module by default in Evolved.
         std::vector<DtString> defaultModules;
         defaultModules.push_back( "VRF-AggregateExt1.xml" );
         setFomModules( defaultModules );
#endif
      }

      DtWebLvcBrokerInitializer::DtWebLvcBrokerInitializer( const DtWebLvcBrokerInitializer& other )
         : DtBrokerInitializer( 0, NULL, "0.0" )
         , myConfigVarWebSocketPort( &mySettings, "&webPort", "9101", "Web Server Port" )
         , myConfigVarUseTcpPort( &mySettings, "useTcpPort", false, "Use Tcp Server Port" )
         , myConfigVarTcpSocketPort( &mySettings, "tcp&ServerPort", 9102, "Tcp Server Port" )
         , mySleepInterval( &mySettings, "sleepInterval", 0.05, "Sleep Interval" )
         , myConfigVarOmtFiles( &mySettings, "omtFiles", "VR-Link.omt", "OMT Translation File" )
         , myConfigVarProxyHost( &mySettings, "proxyDest", "localhost", "Proxy Destination" )
         , myConfigVarProxyPort(&mySettings, "proxyPort", 8080, "Proxy Destination Port")
         , myConfigEnableHttpServer(&mySettings, "httpServer", true, "Enable Web Server")
         , myConfigLocalHttpDirectory(&mySettings, "localHttpDirectory", "../html", "Local HTTP Directory")
         , myConfigEnableHttpProxy(&mySettings, "httpProxy", true, "Enable HTTP Proxy")
         , myConfigLocalNonProxyDir(&mySettings, "localNonProxyDir", "local", "Local Non-Proxy Dir")
         , myConfigEnableStatusPage(&mySettings, "statusPage", true, "Enable Status Page")
         , myConfigSSLCertificate(&mySettings, "sslCertificate", "", "SSL Certificate for HTTPS")
      {
         DtBrokerInitializer::operator = ( other );

         myConfigVarWebSocketPort = other.myConfigVarWebSocketPort;
         myConfigVarUseTcpPort = other.myConfigVarUseTcpPort;
         myConfigVarTcpSocketPort = other.myConfigVarTcpSocketPort;
         mySleepInterval = other.mySleepInterval;
         myConfigVarOmtFiles = other.myConfigVarOmtFiles;
         myConfigVarProxyHost = other.myConfigVarProxyHost;
         myConfigVarProxyPort = other.myConfigVarProxyPort;
         myConfigEnableHttpServer = other.myConfigEnableHttpServer;
         myConfigLocalHttpDirectory = other.myConfigLocalHttpDirectory;
         myConfigEnableHttpProxy = other.myConfigEnableHttpProxy;
         myConfigLocalNonProxyDir = other.myConfigLocalNonProxyDir;
         myConfigEnableStatusPage = other.myConfigEnableStatusPage;
         myConfigSSLCertificate = other.myConfigSSLCertificate;
      }

      DtWebLvcBrokerInitializer& DtWebLvcBrokerInitializer::operator = (
         const DtWebLvcBrokerInitializer& other )
      {
         if ( this == &other )
         {
            return *this;
         }

         DtBrokerInitializer::operator = ( other );

         myConfigVarWebSocketPort = other.myConfigVarWebSocketPort;
         myConfigVarUseTcpPort = other.myConfigVarUseTcpPort;
         myConfigVarTcpSocketPort = other.myConfigVarTcpSocketPort;
         mySleepInterval = other.mySleepInterval;
         myConfigVarOmtFiles = other.myConfigVarOmtFiles;
         myConfigVarProxyHost = other.myConfigVarProxyHost;
         myConfigVarProxyPort = other.myConfigVarProxyPort;
         myConfigEnableHttpServer = other.myConfigEnableHttpServer;
         myConfigLocalHttpDirectory = other.myConfigLocalHttpDirectory;
         myConfigEnableHttpProxy = other.myConfigEnableHttpProxy;
         myConfigLocalNonProxyDir = other.myConfigLocalNonProxyDir;
         myConfigEnableStatusPage = other.myConfigEnableStatusPage;
         myConfigSSLCertificate = other.myConfigSSLCertificate;

         return *this;
      }

      DtWebLvcBrokerInitializer* DtWebLvcBrokerInitializer::clone() const
      {
         return new DtWebLvcBrokerInitializer( *this );
      }

      DtWebLvcBrokerInitializer::~DtWebLvcBrokerInitializer()
      {
      }

      std::vector<int> DtWebLvcBrokerInitializer::webSocketPort() const
      {
         std::vector<DtString> portString;
         DtString s( myConfigVarWebSocketPort.value() );
         s.tokenize( ';', portString );

         std::vector<int> ports;
         int numPorts = portString.size();
         for ( int i = 0; i < numPorts; ++i )
         {
            ports.push_back( portString[i].toInt() );
         }

         return ports;
      }

      DtString DtWebLvcBrokerInitializer::webSocketPortString() const
      {
         return myConfigVarWebSocketPort.value();
      }

      void DtWebLvcBrokerInitializer::setWebSocketPort( DtString value )
      {
         myConfigVarWebSocketPort.setValue( value );
      }

      int DtWebLvcBrokerInitializer::tcpSocketPort() const
      {
         return myConfigVarTcpSocketPort.value();
      }

      void DtWebLvcBrokerInitializer::setUseTcpPort( bool value )
      {
         myConfigVarUseTcpPort.setValue( value );
      }
     bool DtWebLvcBrokerInitializer::useTcpPort() const
      {
         return myConfigVarUseTcpPort.value();
      }

      void DtWebLvcBrokerInitializer::setTcpSocketPort( int value )
      {
         myConfigVarTcpSocketPort.setValue( value );
      }

      void DtWebLvcBrokerInitializer::setSleepInterval(double value)
      {
         mySleepInterval.setValue(value);
         setPollingInterval(mySleepInterval.value() * 1000);
      }

      double DtWebLvcBrokerInitializer::sleepInterval() const
      {
         return mySleepInterval.value();
      }


      void DtWebLvcBrokerInitializer::setOmtFiles( const DtString& files )
      {
         myConfigVarOmtFiles.setValue( files );
      }

      DtString DtWebLvcBrokerInitializer::omtFiles() const
      {
         return myConfigVarOmtFiles.value();
      }

      void DtWebLvcBrokerInitializer::setProxyHost( const DtString& mode )
      {
         myConfigVarProxyHost.setValue( mode );
         theProxyHost = mode;
      }

      DtString& DtWebLvcBrokerInitializer::proxyHost()
      {
         return theProxyHost;
      }

      void DtWebLvcBrokerInitializer::setProxyPort( int port )
      {
         myConfigVarProxyPort.setValue( port );
         theProxyPort = port;
      }

      int& DtWebLvcBrokerInitializer::proxyPort()
      {
         return theProxyPort;
      }

      void DtWebLvcBrokerInitializer::setEnableHttpServer(bool value)
      {
         myConfigEnableHttpServer.setValue(value);
         theEnableHttpServer = value;
      }

      bool DtWebLvcBrokerInitializer::enableHttpServer()
      {
         return theEnableHttpServer;
      }

      void DtWebLvcBrokerInitializer::setLocalHttpDirectory(const DtString& value)
      {
         myConfigLocalHttpDirectory.setValue(value);
         theLocalHttpDirectory = value;
      }

      DtString& DtWebLvcBrokerInitializer::localHttpDirectory()
      {
         return theLocalHttpDirectory;
      }

      void DtWebLvcBrokerInitializer::setEnableHttpProxy(bool value)
      {
         myConfigEnableHttpProxy.setValue(value);
         theEnableHttpProxy = value;
      }

      bool DtWebLvcBrokerInitializer::enableHttpProxy()
      {
         return theEnableHttpProxy;
      }

      void DtWebLvcBrokerInitializer::setLocalNonProxyDir(const DtString& value)
      {
         myConfigLocalNonProxyDir.setValue(value);
         theLocalNonProxyDir = value;
      }

      DtString& DtWebLvcBrokerInitializer::localNonProxyDir()
      {
         return theLocalNonProxyDir;
      }

      void DtWebLvcBrokerInitializer::setEnableStatusPage(bool value)
      {
         myConfigEnableStatusPage.setValue(value);
         theEnableStatusPage = value;
      }

      bool DtWebLvcBrokerInitializer::enableStatusPage()
      {
         return theEnableStatusPage;
      }

      void DtWebLvcBrokerInitializer::setSslCertificate(const DtString& value)
      {
         myConfigSSLCertificate.setValue(value);
         theSSLCertificate = value;
      }

      DtString& DtWebLvcBrokerInitializer::sslCertificate()
      {
         return theSSLCertificate;
      }

      void DtWebLvcBrokerInitializer::parseCmdLine()
      {
         DtBrokerInitializer::parseCmdLine();

         theProxyPort = myConfigVarProxyPort.value();
         theProxyHost = myConfigVarProxyHost.value();
         theEnableHttpServer = myConfigEnableHttpServer.value();
         theLocalHttpDirectory = myConfigLocalHttpDirectory.value();
         theEnableHttpProxy = myConfigEnableHttpProxy.value();
         theLocalNonProxyDir = myConfigLocalNonProxyDir.value();
         theEnableStatusPage = myConfigEnableStatusPage.value();
         theSSLCertificate = myConfigSSLCertificate.value();
      }

   }
}
