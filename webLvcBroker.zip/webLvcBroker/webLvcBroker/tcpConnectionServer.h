/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file tcpConnectionServer.h
//! \brief Contains the DtTcpConnectionServer class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/reliableConnectionServer.h>
#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/TCPServer.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtTcpConnectionServer is a class that listens for and handles
      //! to TCP connection requests.
      class DT_DLL_WEBLVCBROKER DtTcpConnectionServer : public DtReliableConnectionServer
      {
      public:

         //! \brief CTOR.
         DtTcpConnectionServer( int port );

         //! \brief Virtual DTOR.
         virtual ~DtTcpConnectionServer();

         //! Start listening for and handling connection requests
         virtual void start();

         //! Stop listening for and handling connection requests
         virtual void stop();

      private:

         //! Copy Constructor not implemented - Copy Not Allowed.
         DtTcpConnectionServer( const DtTcpConnectionServer& other );

         //! Assignment Operator Not implemented - Assignment Not Allowed.
         DtTcpConnectionServer& operator = ( const DtTcpConnectionServer& other );

      protected:

         // Socket we listen to for connection requests
         Poco::Net::ServerSocket* myServerSocket;

         // TCP server that handles connection requests.
         Poco::Net::TCPServer* myTCPServer;

      };

   }
}
