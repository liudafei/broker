/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file dataTranslator.cxx
//! \brief Contains the DtDataTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/dataTranslator.h>
#include <Poco/Base64Encoder.h>
#include <Poco/Base64Decoder.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtDataTranslator::DtDataTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtDataInteractionKind )
      {
      }

      DtDataTranslator::~DtDataTranslator()
      {
      }

      void DtDataTranslator::translate( const Json::Value& source,
         DtPortalDataInteraction* destination )
      {
         destination->setOriginatingEntity( source["OriginatingEntity"].asCString() );
         destination->setReceivingEntity( source["ReceivingEntity"].asCString() );
         destination->setRequestIdentifier( source["RequestIdentifier"].asUInt() );

         {  // Translate the Fixed Length Datums.
            Json::Value defaultFixedDatums( Json::arrayValue );
            Json::Value fixedDatums = source.get( "FixedDatums", defaultFixedDatums );
            if ( fixedDatums.isArray() )
            {
               DtFixedLengthDataArray destFixedDatums;
               int numFixedDatums = fixedDatums.size();
               for ( int i = 0; i < numFixedDatums; ++i )
               {
                  DtFixedLengthData destFixedDatum;
                  Json::Value fixedDatum = fixedDatums[i];
                  destFixedDatum.setId( fixedDatum["Id"].asUInt() );
                  destFixedDatum.setValue( fixedDatum["Value"].asUInt() );
                  destFixedDatums.push_back( destFixedDatum );
               }
               destination->setFixedDatums( destFixedDatums );
            }
         }

         {  // Translate the Variable Length Datums.
            Json::Value defaultVariableDatums( Json::arrayValue );
            Json::Value variableDatums = source.get( "VariableDatums", defaultVariableDatums );
            if ( variableDatums.isArray() )
            {
               DtAttributeValuePairList destVariableDatums;
               int numVariableDatums = variableDatums.size();
               for ( int i = 0; i < numVariableDatums; ++i )
               {
                  Json::Value variableDatum = variableDatums[i];

                  std::stringstream ss;
                  ss << variableDatum["Value"]["Data"].asCString();

                  std::vector<char> dataArray;
                  Poco::Base64Decoder decoder( ss );
                  while ( decoder.good() && ! decoder.eof() )
                  {
                     dataArray.push_back( decoder.get() );
                  }

                  DtVariableLengthData destVariableData;
                  destVariableData.setDataArray( dataArray );

                  DtAttributeValuePair destAvp;
                  destAvp.first = variableDatum["Attribute"].asCString();
                  destAvp.second = destVariableData;
                  destVariableDatums.push_back( destAvp );
               }
               destination->setVariableDatumSet( destVariableDatums );
            }
         }
      }

      void DtDataTranslator::translate( const DtPortalDataInteraction& source,
         Json::Value* destination )
      {
         (*destination)["OriginatingEntity"] = source.originatingEntity().c_str();
         (*destination)["ReceivingEntity"] = source.receivingEntity().c_str();
         (*destination)["RequestIdentifier"] = (unsigned int) source.requestIdentifier();

         {  // Translate Fixed Length Datums.
            unsigned int index = 0;
            Json::Value fixedDatums( Json::arrayValue );
            DtFixedLengthDataArray::const_iterator itr = source.fixedDatums().begin();
            DtFixedLengthDataArray::const_iterator end = source.fixedDatums().end();
            for ( ; itr != end; ++itr )
            {
               Json::Value fixedDatum;
               fixedDatum["Id"] = (unsigned int) itr->id();
               fixedDatum["Value"] = (unsigned int) itr->value();
               fixedDatums[index] = fixedDatum;
               ++index;
            }
            (*destination)["FixedDatums"] = fixedDatums;
         }

         {  // Translate Variable Length Datums.
            unsigned int index = 0;
            Json::Value variableDatums( Json::arrayValue );
            DtAttributeValuePairList::const_iterator itr = source.variableDatumSet().begin();
            DtAttributeValuePairList::const_iterator end = source.variableDatumSet().end();
            for ( ; itr != end; ++itr )
            {
               // Encode the data.
               std::stringstream ss;
               Poco::Base64Encoder encoder( ss );
               encoder.write( itr->second.data(), itr->second.size() );
               encoder.close();

               // Store the variable data.
               Json::Value variableData;
               variableData["Size"] = itr->second.size();
               variableData["Data"] = ss.str();

               // Store the variable datum.
               Json::Value variableDatum;
               variableDatum["Attribute"] = itr->first.c_str();
               variableDatum["Value"] = variableData;
               variableDatums[index] = variableDatum;
               ++index;
            }
            (*destination)["VariableDatums"] = variableDatums;
         }
      }

   }
}
