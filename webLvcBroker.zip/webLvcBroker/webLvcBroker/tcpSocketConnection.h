/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file tcpSocketConnection.h
//! \brief Contains the DtTcpSocketConnection class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <Poco/Net/TCPServerConnection.h>

class DtReflectedEntityList;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtTcpSocketConnection is a class that sets up a
      //! socket connection to a client and then sends entity state updates through
      //! that connection.
      class DT_DLL_WEBLVCBROKER DtTcpSocketConnection : public Poco::Net::TCPServerConnection
      {
      public:

         //! \brief CTOR.
         DtTcpSocketConnection( const Poco::Net::StreamSocket & socket );

         //! \brief Virtual DTOR.
         virtual ~DtTcpSocketConnection();

         void run();

      };

   }
}
