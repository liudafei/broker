/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file localHandler.h
//! \brief Contains the DtLocalRequestHandler class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <Poco/Net/HTTPRequestHandler.h>
#include <Poco/Timestamp.h>
#include <Poco/RWLock.h>
#include <map>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtLocalRequestHandler is a class that responds and fullfills web requests
      //! as long as they begin with the local keyword.
      class DT_DLL_WEBLVCBROKER DtLocalRequestHandler : public Poco::Net::HTTPRequestHandler
      {
      public:

         //! \brief Default CTOR.
         DtLocalRequestHandler();

         //! \brief CTOR.
         DtLocalRequestHandler( const std::string& URI );

         //! \brief Virtual DTOR.
         virtual ~DtLocalRequestHandler();

         //! returns webpages
         void handleRequest( Poco::Net::HTTPServerRequest& request,
            Poco::Net::HTTPServerResponse& response );

      private:

         //! Copy Constructor not implemented - Copy Not Allowed.
         DtLocalRequestHandler( const DtLocalRequestHandler& other );

         //! Assignment Operator Not implemented - Assignment Not Allowed.
         DtLocalRequestHandler& operator = ( const DtLocalRequestHandler& other );

      protected:

         std::string myURI;
         std::map<std::string,std::string> myMimetypesMap;

      };

   }
}
