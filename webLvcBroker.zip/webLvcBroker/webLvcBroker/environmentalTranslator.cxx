/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file environmentalTranslator.cxx
//! \brief Contains the DtEnvironmentalTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/environmentalTranslator.h>

#include <vl/environmentProcessPublisher.h>
#include <vlpi/deadReckoner.h>
#include <vlpi/disEnums.h>

#include <webLvcBroker/netEnvRecs.h>

#include <matrix/geodeticCoord.h>
#include <matrix/topoCoord.h>

const DtEnvironmentalRecordType DtEnvVrfObjectDataStateRecordType =
DtEnvironmentalRecordType(0x000000D0);

const DtEnvironmentalRecordType DtEnvObjectStateRecordType =
DtEnvironmentalRecordType(0x00000008);

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      typedef struct NetFlow
      {
         DtNetEnvironmentalRecord rec;
         DtNetU32 flow;
      } NetFlow;


      DtEnvironmentalTranslator::DtEnvironmentalTranslator(DtBroker* broker)
         : ParentClass(broker, translatorName(), DtEnvironmentProcessObjectKind)
      {
      }

      DtEnvironmentalTranslator::~DtEnvironmentalTranslator()
      {
      }

      void DtEnvironmentalTranslator::translate(const Json::Value& source,
         DtPortalEnvironmentProcessObject* pEnt)
      {
         //entityId
         Json::Value processIdentifier(Json::arrayValue);
         processIdentifier[0u] = 0;
         processIdentifier[1] = 0;
         processIdentifier[2] = 0;
         Json::Value entId = source.get("ProcessIdentifier", processIdentifier);
         std::stringstream eid;
         if (entId.isString())
         {
            pEnt->setProcessIdentifier(entId.asCString());
         }
         else
         {

            eid << entId.get(0u, 1).asInt();
            eid << ":" << entId.get(1, 1).asInt();
            eid << ":" << entId.get(2, 1).asInt();
            pEnt->setProcessIdentifier(eid.str().c_str());
         }

         //Type
         Json::Value entType(Json::arrayValue);
         entType = source.get("Type", "0,0,0,0,0,0,0");
         if (entType.isString())
         {
            pEnt->setType(DtEntityType(entType.asCString()));
         }
         else
         {
            DtEntityType et(entType.get(0u, -1).asInt(), entType.get(1, -1).asInt(),
               entType.get(2, -1).asInt(), entType.get(3, -1).asInt(),
               entType.get(4, -1).asInt(), entType.get(5, -1).asInt(),
               entType.get(6, -1).asInt());
            pEnt->setType(et);
         }


         /* do I care about the timestamp the client is sending me?
         double t = m->get("Timestamp",-1).asDouble();
         if( t != -1 )
         {
         pe->sr()->setTimeRecieved(t);
         }
         */

         pEnt->setTimeReceived(myBroker->portalConnection()->clock()->simTime());


         //TODO Add other Records
         DtAttributeValuePairList avpl;
         for (unsigned int rec = 0; rec < source.get("GeometryRecords", "").size(); ++rec)
         {
            Json::Value geom = source.get("GeometryRecords", "")[rec];
            std::string geomType = geom.get("type", "none").asString();
            if (geomType == "LineString")
            {
               Json::Value coords(Json::arrayValue);
               coords = geom.get("coordinates", "");

               for (unsigned int i = 0; i < coords.size(); ++i)
               {
                  Json::Value coord = coords[i];
                  DtNetEnvironmentalPointRecord rec;
                  rec.myHeader.myType = DtPointRecord1Type;
                  rec.myHeader.myIndex = 0;
                  rec.myHeader.myLength = sizeof(DtNetEnvironmentalPointRecord) * 8;
                  rec.myLocation = DtVector(coord[0u].asDouble(), coord[1].asDouble(), coord[2].asDouble());
                  DtAttributeValuePair avp(DtString(i), DtVariableLengthData((const char*)&rec, sizeof(DtNetEnvironmentalPointRecord)));
                  avpl.push_back(avp);
               }

            }
            else if (geomType == "Point")
            {
               Json::Value coord(Json::arrayValue);
               coord = geom.get("coordinates", "");

               DtNetEnvironmentalPointRecord rec;
               rec.myHeader.myType = DtPointRecord1Type;
               rec.myHeader.myIndex = 0;
               rec.myHeader.myLength = sizeof(DtNetEnvironmentalPointRecord) * 8;
               rec.myLocation = DtVector(coord[0u].asDouble(), coord[1].asDouble(), coord[2].asDouble());
               DtAttributeValuePair avp(DtString(0), DtVariableLengthData((const char*)&rec, sizeof(DtNetEnvironmentalPointRecord)));
               avpl.push_back(avp);

            }

            pEnt->setEnvironmentRecData(avpl);
         }
      }


      void DtEnvironmentalTranslator::translate(const DtPortalEnvironmentProcessObject&   source,
         Json::Value* destination)
      {

         /*************************************************/
         // Create a JSON formatted message to send instead
         /*************************************************/

         // 1 � PhysicalEntity
         (*destination)["ObjectType"] = "WebLVC:EnvironmentalEntity";

         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = source.processIdentifier().site();
         entityIdentifier[1] = source.processIdentifier().host();
         entityIdentifier[2] = source.processIdentifier().entityNum();

         (*destination)["ProcessIdentifier"] = entityIdentifier;

         Json::Value entityType(Json::arrayValue);
         entityType[0u] = source.type().kind();
         entityType[1] = source.type().domain();
         entityType[2] = source.type().country();
         entityType[3] = source.type().category();
         entityType[4] = source.type().subCategory();
         entityType[5] = source.type().specific();
         entityType[6] = source.type().extra();

         (*destination)["EntityType"] = entityType;

         //! \brief Model used for generating this Environmental Process. Defined in
         //! 1278.1a as being exercise specific.
         (*destination)["ModelType"] = (unsigned)source.modelType();

         //! \brief Defines the status of the Environmental Process. Generally used to
         //! indicate if the process is active or inactive.
         bool isProcessActive = ( source.environmentalStatus() & 0x10 );
         (*destination)["EnvironmentProcessActive"] = ( isProcessActive ? "false" : "true" );

         //! \brief This is an optional field used to support update sequencing.
         (*destination)["SequenceNumber"] = (unsigned short)source.sequenceNumber();

         //! \brief A "list" of environmental records; each of which representing a geometry
         //! or state record.
         //DtDEC_ATTRIBUTE( DtAttributeValuePairList, EnvironmentRecData, environmentRecData );
         //TODO EnvRecData!!
         Json::Value geometryRecords(Json::arrayValue);
         DtAttributeValuePairList::const_iterator i;
         int recordNum = 0;

         if (source.type().kind() == 17 && source.type().category() == 2)
         {
            // its a line so treat it as such
            Json::Value record;
            record["type"] = "LineString";
            Json::Value coords(Json::arrayValue);
            Json::Value coord(Json::arrayValue);
            unsigned int q = 0;
            for (i = source.environmentRecData().begin(); i != source.environmentRecData().end(); ++i)
            {
               const DtNetEnvironmentalRecord* sourceRecord = (const DtNetEnvironmentalRecord*)(*i).second.data();
               if (sourceRecord == 0)
               {
                  DtWarn("Null environmental record.\n");
               }
               switch (sourceRecord->myType) {
               case DtPointRecord1Type:
               {
                  const DtNetEnvironmentalPointRecord *prec = (const DtNetEnvironmentalPointRecord *)(*i).second.data();
                  Json::Value coord(Json::arrayValue);
                  coord[0u] = (double)prec->myLocation[0];
                  coord[1] = (double)prec->myLocation[1];
                  coord[2] = (double)prec->myLocation[2];
                  coords[q++] = coord;
               }
               break;
               default:
                  break;
               }

            }
            record["coordinates"] = coords;
            geometryRecords[0u] = record;
         }
         else if (source.type().kind() == 18)
         {
            // its a line so treat it as such
            Json::Value record;
            record["type"] = "Polygon";
            Json::Value coords(Json::arrayValue);
            Json::Value coord(Json::arrayValue);
            unsigned int q = 0;
            for (i = source.environmentRecData().begin(); i != source.environmentRecData().end(); ++i)
            {
               const DtNetEnvironmentalRecord* sourceRecord = (const DtNetEnvironmentalRecord*)(*i).second.data();
               if (sourceRecord == NULL)
               {
                  DtWarn("Null environmental record.\n");
               }
               else
               {
                  switch (sourceRecord->myType) {
                  case DtPointRecord1Type:
                  {
                     const DtNetEnvironmentalPointRecord *prec = (const DtNetEnvironmentalPointRecord *)(*i).second.data();
                     Json::Value coord(Json::arrayValue);
                     coord[0u] = (double)prec->myLocation[0];
                     coord[1] = (double)prec->myLocation[1];
                     coord[2] = (double)prec->myLocation[2];
                     coords[q++] = coord;
                  }
                  break;
                  default:
                     break;
                  }
               }

            }
            record["coordinates"] = coords;
            geometryRecords[0u] = record;
         }
         else
         {


            for (i = source.environmentRecData().begin(); i != source.environmentRecData().end(); ++i)
            {
               const DtNetEnvironmentalRecord* sourceRecord = (const DtNetEnvironmentalRecord*)(*i).second.data();
               if (sourceRecord == NULL)
               {
                  DtWarn("Null environmental record.\n");
               }
               else
               {
                  switch (sourceRecord->myType) {
                  case DtPointRecord1Type:
                  {
                     const DtNetEnvironmentalPointRecord *prec = (const DtNetEnvironmentalPointRecord *)(*i).second.data();
                     if (prec != NULL)
                     {
                         Json::Value record;
                         record["type"] = "Point";
                         Json::Value coord(Json::arrayValue);
                         coord[0u] = (double)prec->myLocation[0];
                         coord[1] = (double)prec->myLocation[1];
                         coord[2] = (double)prec->myLocation[2];
                         record["coordinates"] = coord;
                         geometryRecords[recordNum++] = record;
                     }
                     else
                     {
                         DtWarn("Null environmental point record.\n");
                     }
                  }
                  break;

                  case DtLineRecord1Type:
                  {
                     const DtNetEnvironmentalLineRecord *prec = (const DtNetEnvironmentalLineRecord *)(*i).second.data();
                     if (prec != NULL)
                     {
                         Json::Value record;
                         record["type"] = "Line";
                         Json::Value coords(Json::arrayValue);
                         Json::Value coord(Json::arrayValue);
                         coord[0u] = (double)prec->myStartLocation[0];
                         coord[1] = (double)prec->myStartLocation[1];
                         coord[2] = (double)prec->myStartLocation[2];
                         coords[0u] = coord;
                         coord[0u] = (double)prec->myEndLocation[0];
                         coord[1] = (double)prec->myEndLocation[1];
                         coord[2] = (double)prec->myEndLocation[2];
                         coords[1] = coord;
                         record["coordinates"] = coords;
                         geometryRecords[recordNum++] = record;
                     }
                     else
                     {
                         DtWarn("Null environmental line record.\n");
                     }
                  }
                  break;

                  default:
                     break;
                  }
               }
            }
         }
         (*destination)["GeometryRecords"] = geometryRecords;

         //scan through the rest of the records for things we can translate
         for (i = source.environmentRecData().begin(); i != source.environmentRecData().end(); ++i)
         {
            const DtNetEnvironmentalRecord* sourceRecord = (const DtNetEnvironmentalRecord*)i->second.data();
            if (sourceRecord == NULL)
            {
               DtWarn("Null environmental record.\n");
            }
            else
            {
               switch ((unsigned)sourceRecord->myType) {
               case DtEnvIntRecordType:
                  (*destination)[i->first.c_str()] = (unsigned int)((DtNetEnvironmentalIntRecord*)sourceRecord)->myValue;
                  break;
               case DtEnvDoubleRecordType:
                  (*destination)[i->first.c_str()] = (double)((DtNetEnvironmentalDoubleRecord*)sourceRecord)->myValue;
                  break;
               case DtEnvStringRecordType:
               {
                  DtNetEnvironmentalStringRecord* srec = ((DtNetEnvironmentalStringRecord*)sourceRecord) + 1;
                  (*destination)[i->first.c_str()] = std::string((char*)srec);
                  break;
               }
               case DtEnvIntArrayRecordType:
               {
                  DtNetEnvironmentalIntArrayRecord* srec = ((DtNetEnvironmentalIntArrayRecord*)sourceRecord);
                  int count = srec->myCount;
                  srec = srec + 1;
                  int* vals = (int*)srec;
                  Json::Value v(Json::arrayValue);
                  for (unsigned int j = 0; j < count; ++j)
                     v[j] = vals[j];
                  (*destination)[i->first.c_str()] = v;
               }
               break;
               case DtEnvDoubleArrayRecordType:
               {
                  DtNetEnvironmentalDoubleArrayRecord* srec = ((DtNetEnvironmentalDoubleArrayRecord*)sourceRecord);
                  int count = srec->myCount;
                  srec = srec + 1;
                  DtNetFloat64* vals = (DtNetFloat64*)srec;
                  Json::Value v(Json::arrayValue);
                  for (unsigned int j = 0; j < count; ++j)
                     v[j] = (double)vals[j];
                  (*destination)[i->first.c_str()] = v;
               }
               break;
               case DtEnvBoolRecordType:
                  (*destination)[i->first.c_str()] = ((DtNetEnvironmentalBoolRecord*)sourceRecord)->myValue;
                  break;
               case DtEnvJsonRecordType:
               {
                  DtNetEnvironmentalJsonRecord* srec = ((DtNetEnvironmentalJsonRecord*)sourceRecord) + 1;
                  Json::Reader r;
                  Json::Value v;
                  r.parse((char*)srec, v, false);
                  (*destination)[i->first.c_str()] = v;
                  break;
               }
               case DtEnvObjectStateRecordType:
                  break;
               case DtEnvVrfObjectDataStateRecordType:
                  break;
               default:
                  break;
               }
            }
         }
      }
   }
}
