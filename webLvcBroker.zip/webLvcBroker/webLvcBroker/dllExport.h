/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file dllExport.h
//! \brief Contains the DLL export macro.
//! \ingroup webLvcBroker

#pragma once

// Get proper local export symbol
#ifdef _WIN32
#  ifdef libwebLvcBroker_EXPORTS
#    define DT_DLL_WEBLVCBROKER __declspec ( dllexport )
#  else
#    define DT_DLL_WEBLVCBROKER __declspec ( dllimport )
#  endif
#else
#  define DT_DLL_WEBLVCBROKER
#endif
