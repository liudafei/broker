/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file transferOwnershipTranslator.h
//! \brief Contains the DtTransferOwnershipTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/lvcInteractionTranslator.h>
#include <portal/pTransferControlInteraction.h>
#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtTransferOwnershipTranslator are responsible for translating DtPortalTransferControlInteraction to WebLVC:TransferControl.
      class DT_DLL_WEBLVCBROKER DtTransferOwnershipTranslator : public DtLvcInteractionTranslator<DtPortalTransferControlInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:TransferOwnership" );

         //! \brief CTOR.
         DtTransferOwnershipTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtTransferOwnershipTranslator();

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, DtPortalTransferControlInteraction* destination );
         virtual void translate( const DtPortalTransferControlInteraction& source, Json::Value* destination );

      };

   }
}
