/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file client.h
//! \brief Contains the DtClient class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <vlutil/vlString.h>
#include <vlutil/vlTime.h>
#include <Poco/Runnable.h>
#include <Poco/RWLock.h>
#include <Poco/Thread.h>
#include <json/json.h>
#include <list>

namespace MAKVrExchange
{

   class DtObjectTranslator;

   namespace DtWebLvcBroker
   {

      class DtWebLvcBroker;
      class DtLockingReflectedEntityManager;

      //! \brief DtClient is the base class for all Clients (tcp and websocket).
      //! The class maintains state necessary and manages the clients update rate independantly
      //! of other clients and the main broker.
      class DT_DLL_WEBLVCBROKER DtClient : public Poco::Runnable
      {
      public:

         //! constructor
         DtClient();

         //! destructor
         virtual ~DtClient();

         //! \brief sends a message frame to this client
         virtual int sendFrame( const void* buffer, int length ) = 0;
         //! \brief recieves a message from this client
         virtual int receiveFrame( void* buffer, int length, int& flags ) = 0;

         //! \brief parses the connect message
         virtual bool processConnectMsg( Json::Value& msg );

         //! \brief Client name from connect message
         std::string name() { return myName; }

         //! \brief Client protocol version from Connect message
         double version() { return myProtocolVersion; }

         //! \brief Client peer address (if available)
         std::string addrString() { return myAddressString; }

         //! \brief Thread worker function
         virtual void run();
         //! \brief Start the thread running
         virtual void start();
         //! \brief stop the thread from running
         virtual void stop();

         virtual void sendMsg( const std::string& msg );
         virtual bool receiveMsg( std::string& msg );

         virtual bool connected() { return myConnected; }
         virtual const DtTime connectTime() const { return myConnectTime; }
         virtual void setBroker( DtWebLvcBroker* broker );

         virtual DtTime averageFrameTime() { return myAvgFrame; }
         virtual double averageUpdateCount() { return myAvgUpd; }

         virtual void checkAsSeenByRemote( const DtString& transname, const DtString& entName, Json::Value& val );
         virtual void removeAsSeenByRemote( const DtString& transname, const DtString& entName );

         virtual void sendStateUpdateMessages();

      protected:

         //! sends the contents of the send queue, called from run
         virtual void sendMessages();

         //! checks for inbound messages and copies to the receive queue, called from run
         virtual void receiveFromClient();

         virtual bool nextFrame( std::string& msg );
         virtual void addMsg( const std::string& msg );

         virtual void ping();

      private:

         //! Copy Constructor not implemented  -- Copy Not Allowed
         DtClient( const DtClient& other );

         //! Assignment Operator Not implemented -- Assignment Not Allowed
         DtClient& operator = ( const DtClient& other );

      protected:

         Poco::RWLock mySendRWLock;
         Poco::RWLock myRecvRWLock;
         Poco::Thread myThread;
         std::string myName;
         double myProtocolVersion;
         std::string myAddressString;
         std::list<std::string> mySendQueue;
         std::list<std::string> myReceiveQueue;
         std::vector<char> myReceiveBuffer;
         double sleepTime;
         bool myThreadRun;
         bool myConnected;
         DtWebLvcBroker* myBroker;

         double myPingTimer;
         DtTime myConnectTime;

         DtTime myAvgFrame;
         double myAvgUpd;

         std::map< DtString, std::map<DtString,Json::Value> > asSeenByRemote;
         std::string msgKind;
         std::string objectName;
         std::string objectType;

      };

   }
}
