/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file loggerControlTranslator.h
//! \brief Contains the DtLoggerControlTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <webLvcBroker/lvcInteractionTranslator.h>
#include <portal/pLoggerEmptyInteraction.h>
#include <portal/pLoggerConnectInteraction.h>
#include <portal/pLoggerTotalStateInteraction.h>
#include <string>

class DtPortalLoggerTotalStateInteraction;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtLoggerControlTranslator are responsible for translating DtPortalLoggerControlInteraction to MAK:LoggerControl.
      class DT_DLL_WEBLVCBROKER DtLoggerControlTranslator : public DtLvcInteractionTranslator<DtPortalLoggerControlInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "MAK:LoggerControl" );

         //! \brief CTOR.
         DtLoggerControlTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtLoggerControlTranslator();

         virtual void initializeWebLvcCallbacks();
         virtual void removeWebLvcCallbacks();

         virtual void initializePortalCallbacks();
         virtual void removePortalCallbacks();

         // Your translator must implement the translate functions.
         virtual void translate(const Json::Value& source,   DtPortalLoggerControlInteraction* destination);
         virtual void translate(const DtPortalLoggerControlInteraction& source, Json::Value* destination);
         virtual void translate(const DtPortalLoggerConnectInteraction& source, Json::Value* destination);
         virtual void translate(const DtPortalLoggerTotalStateInteraction& source, Json::Value* destination);

         // Due to the fact that our generated interaction is actually a subclass of DtPortalLoggerControlInteraction
         // we actually do most of the translation in this function instead of translate.
         virtual void processMsg( Json::Value* msg, DtClient* client );

         //! \brief Sends a WebLVC interaction.
         //!
         //! Takes \e incoming as a Portal interaction, translates it to WebLVC interaction,
         //! then sends this WebLVC interaction through #myBroker.
         //!
         //! \param [in] incoming Received Portal interaction.
         //!
         //! \pre \e incoming is a valid DtPortalLoggerControlInteraction object.
         virtual void createInteraction(const DtPortalLoggerControlInteraction& incoming);

         //! \brief The callback function registered by the constructor and used by
         //! the Portal.
         //!
         //! This function is called when a Portal loggercontrol interaction occurs.  Calls
         //! createInteraction() to send the Portal Interaction \e loggercontrol to
         //! DIS VR-Link.
         //!
         //! \param [in] loggercontrol Portal interaction to be sent.
         //! \param [in] usr DtLoggerControlInteractionTranslator object.
         //!
         //! \pre \e loggercontrol is a valid object.  \e usr must either be a valid
         //! DtLoggerControlInteractionTranslator object, or NULL.
         static void receivePortalInteraction(const MAKVrExchange::DtPortalLoggerConnectInteraction& loggerControl, void* usr);
         static void receivePortalInteraction(const MAKVrExchange::DtPortalLoggerTotalStateInteraction& loggerControl, void* usr);
      };

   }
}
