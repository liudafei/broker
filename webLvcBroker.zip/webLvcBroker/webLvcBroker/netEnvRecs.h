
/*********************************************************************
** Copyright (c) 1992-2013 VT MAK
** All rights reserved.
*********************************************************************/
#pragma once

//! \file netEnvRecs.h
//! \brief This file contains the declaration of some custom DtEnvironmentalRecords
//! used to transfer VRF custom evironmental PDU's 


#include <vl/packets/envProcP.h>

const DtEnvironmentalRecordType DtEnvIntRecordType =
        DtEnvironmentalRecordType(0x00002007);
const DtEnvironmentalRecordType DtEnvDoubleRecordType =
        DtEnvironmentalRecordType(0x00002008);
const DtEnvironmentalRecordType DtEnvStringRecordType =
        DtEnvironmentalRecordType(0x00002009);
const DtEnvironmentalRecordType DtEnvIntArrayRecordType =
        DtEnvironmentalRecordType(0x0000200a);
const DtEnvironmentalRecordType DtEnvDoubleArrayRecordType =
        DtEnvironmentalRecordType(0x0000200b);
const DtEnvironmentalRecordType DtEnvBoolRecordType =
        DtEnvironmentalRecordType(0x0000200c);
const DtEnvironmentalRecordType DtEnvJsonRecordType =
        DtEnvironmentalRecordType(0x0000200d);

struct DtNetEnvironmentalIntRecord //0x00002007
{
   DtNetEnvironmentalRecord myHeader;
   DtNetU64            myValue;
};

struct DtNetEnvironmentalDoubleRecord //0x00002008
{
   DtNetEnvironmentalRecord myHeader;
   DtNetFloat64            myValue;
};

struct DtNetEnvironmentalStringRecord //0x00002009
{
   DtNetEnvironmentalRecord myHeader;
};

struct DtNetEnvironmentalIntArrayRecord //0x0000200a
{
   DtNetEnvironmentalRecord myHeader;
   DtNetU64            myCount;
   //DtNetU64          array[myCount]
};

struct DtNetEnvironmentalDoubleArrayRecord //0x0000200b
{
   DtNetEnvironmentalRecord myHeader;
   DtNetU64            myCount;
   //DtNetFloat64          array[myCount]
};

struct DtNetEnvironmentalBoolRecord //0x0000200c
{
   DtNetEnvironmentalRecord myHeader;
   bool            myValue;
};

struct DtNetEnvironmentalJsonRecord //0x0000200d
{
   DtNetEnvironmentalRecord myHeader;
};
