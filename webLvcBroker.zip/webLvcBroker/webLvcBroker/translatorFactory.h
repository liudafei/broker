/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file translatorFactory.h
//! \brief Contains the DtTranslatorFactory class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/baseObjectTranslator.h>
#include <webLvcBroker/broker/baseInteractionTranslator.h>

#include <vlutil/vlString.h>
#include <vlutil/vlPrint.h>

#include <map>

namespace MAKVrExchange
{

   namespace WebLVCBroker
   {

      //! \brief A factory class for Translators.
      //! DtTranslatorFactory takes on template parameter, which is the type of
      //! the class produced by the creator functions.
      //! \ingroup webLvcBroker
      template <typename BrokerType, typename ProducedType>
      class DtTranslatorFactory
      {
      public:

         typedef ProducedType* (*DtObjectTranslatorCreatorFunction)(BrokerType*);
         typedef ProducedType* (*DtGenericObjectTranslatorCreatorFunction)(BrokerType*,const DtString& className );

      public:

         //! Default CTOR
         DtTranslatorFactory();

         //! Default DTOR - destroys factory, not instances created by the factory.
         virtual ~DtTranslatorFactory();

         //! Creates a generic translator using the className and broker provided.
         ProducedType* createGenericInstance( const DtString& className, BrokerType* broker );

         //! Creats an translator instance and returns it as a pointer of type ProducedType. The
         //! translator is created using transName and the CTOR is passed the broker pointer.
         ProducedType* createInstance( const DtString& transName, BrokerType* broker ) const;

         //! Removes the translator for class T using T::translatorName(). If there is no translator
         //! found, no action is taken.
         template <typename T>
         void removeCreator();

         //! removes the translator creator for translatorName if one is found. If not
         //! no action is taken.
         void removeCreator( const DtString& translatorName );

         //! removes all creators currently registered.
         void removeAllCreators();

         //! Sets T as the class to create when a generic Translator is requested. The default instanceFactory
         //! is used as the creator function.
         template <typename T>
         void addGenericCreator();

         //! Adds a creator for class T using the default instanceFactory Method. The creator is
         //! locked to the name in T::translatorName. If there is already a function assigned to
         //! that name, the new function replaces the old function.
         template <typename T> void addCreator();

         //! Adds a creator for class T using the default instanceFactory Method.
         //! If there is already a function assigned to
         //! that name, the new function replaces the old function.
         template <typename T> void addCreator( DtString str );

         //! For translator translatorName a creator function fn is used. If there is already a
         //! function assigned to that name, the new function replaces the old function.
         template <typename T>
         void addCreator( const DtString& translatorName, DtObjectTranslatorCreatorFunction fn );

         //! \brief Returns the set of translator names added through addCreator()
         std::set<DtString> creatorNames() const;

      protected:

         //! A static function which can be used to create instances of type T.
         template <typename T>
         static ProducedType* instanceFactory( BrokerType* broker );

         //! A static function which can be used to create instances of type T, where T takes
         //! a className in the CTOR.
         template <typename T>
         static ProducedType* genericInstanceFactory( BrokerType* broker, const DtString& className );

      private:

         //! Copy CTOR not implemented - do not copy
         DtTranslatorFactory( const DtTranslatorFactory& other );

         //! Assignment Operator not implemented - do not copy
         DtTranslatorFactory& operator = ( const DtTranslatorFactory& other );


      protected:

         typedef std::map<DtString,DtObjectTranslatorCreatorFunction> StringOtcMap;

         StringOtcMap myNamedCreatorMap;
         DtGenericObjectTranslatorCreatorFunction myGenericTranslatorCreator;

      };

   }
}

#define _translatorFactory_INL_
#include <webLvcBroker/translatorFactory.inl>
#undef _translatorFactory_INL_
