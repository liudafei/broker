/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file lvcInteractionTranslator.h
//! \brief Contains the DtLvcInteractionTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/baseWebLvcInteractionTranslator.h>
#include <webLvcBroker/webLvcBroker.h>
#include <broker/brokerObject.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief A translator is responsible for converting a specific message
      //! type between two protocols.
      //
      //! This analogy works best with DIS->HLA were
      //! a translator is used to convert DIS objects. This isn't always the
      //! best way to describe translators however, sometimes two messages on
      //! one side need to be bundled into one message on another, a translator
      //! would be used for that too.
      template <class T_PortalInteraction>
      class DtLvcInteractionTranslator
         : public DtBaseInteractionTranslator<T_PortalInteraction,DtBaseWebLvcInteractionTranslator>
      {
      public:

         //! \typedef DtLvcInteractionTranslator<T_PortalInteraction> ParentClass
         typedef DtLvcInteractionTranslator<T_PortalInteraction> ParentClass;

      public:

         //! \brief CTOR.
         DtLvcInteractionTranslator( DtBroker* broker, const DtString& name, DtPortalMessageKind kind );

         //! \brief Virtual DTOR.
         virtual ~DtLvcInteractionTranslator();

         virtual void tick();

         virtual DtWebLvcBroker* webLvcBroker();
         virtual const DtWebLvcBroker* webLvcBroker() const;

         virtual void createInteraction( const T_PortalInteraction& incoming );

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, T_PortalInteraction* destination ) = 0;
         virtual void translate( const T_PortalInteraction& source, Json::Value* destination ) = 0;

         virtual void createFullStateMsgs( std::list<std::string>& msgs, DtClient* client ) {}
         virtual void processMsg( Json::Value* msg, DtClient* client );

         virtual void printIncomingOutgoingStateReps( const DtPortalMessage& incoming,
            const Json::Value& outgoing );

         virtual void printIncomingOutgoingStateReps( const Json::Value& incoming,
            const DtPortalMessage& outgoing );

      private:

         //! Copy CTOR not implemented - do not copy
         DtLvcInteractionTranslator( const DtLvcInteractionTranslator& other );

         //! Assignment operator not implemented - do not copy
         DtLvcInteractionTranslator& operator = ( const DtLvcInteractionTranslator& other );

      };

   }
}

#define _lvcInteractionTranslator_INL_
#include <webLvcBroker/lvcInteractionTranslator.inl>
#undef _lvcInteractionTranslator_INL_
