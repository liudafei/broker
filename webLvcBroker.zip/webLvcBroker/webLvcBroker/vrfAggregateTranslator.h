/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file vrfAggregateTranslator.h
//! \brief Contains the DtVrfAggregateTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#if ! _WIN64
#  ifndef _WIN32_WINNT
#     define _WIN32_WINNT 0x400
#  endif
#endif

#include <portal/pAggregate.h>
#include <broker/brokerObject.h>
#include <webLvcBroker/lvcObjectTranslator.h>
#include <omtReader/datatypeManager.h>
#include <omtReader/omtTree.h>

#define VRF_AGGREGATE_TEMPLATE_ARGS \
   DtPortalVrfAggregate, DtPortalReflectedVrfAggregate

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtVrfAggregateTranslator are responsible for translating DtPortalVrfAggregate to WebLVC:AggregateEntity.
      class DT_DLL_WEBLVCBROKER DtVrfAggregateTranslator
         : public DtLvcObjectTranslator<VRF_AGGREGATE_TEMPLATE_ARGS>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "MAK:VRFAggregate" );

         //! \brief CTOR.
         DtVrfAggregateTranslator( DtBroker* broker );

         //! \brief DTOR.
         virtual ~DtVrfAggregateTranslator();

         //! Translators
         virtual void translate( const Json::Value& source, DtPortalVrfAggregate* destination );
         virtual void translate( const DtPortalVrfAggregate& source, Json::Value* destination );

         //! Add additional data for the object specified by name.
         virtual void addAdditionalDataValue( const DtString& name, const std::string& tag, const Json::Value& data );

         //! Clear out leftover name mappings and additional data when object goes away.
         virtual void removePortalObject( const DtPortalReflectedVrfAggregate& obj );

      protected:

         std::map<DtString,Json::Value> myAdditionalDataMap;
         std::map<DtString,DtString> myNameLookup;

      };

   }
}
