/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file startResumeTranslator.h
//! \brief Contains the DtStartResumeTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/lvcInteractionTranslator.h>
#include <vlpi/entityIdentifier.h>
#include <portal/pStartInter.h>
#include <vlutil/vlHashlist.h>
#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtStartResumeTranslator are responsible for translating DtPortalStartInteraction to WebLVC:StartResume.
      class DT_DLL_WEBLVCBROKER DtStartResumeTranslator : public DtLvcInteractionTranslator<DtPortalStartInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:StartResume" );

         //! \brief CTOR.
         DtStartResumeTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtStartResumeTranslator();

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, DtPortalStartInteraction* destination );
         virtual void translate( const DtPortalStartInteraction& source, Json::Value* destination );

      };

   }
}
