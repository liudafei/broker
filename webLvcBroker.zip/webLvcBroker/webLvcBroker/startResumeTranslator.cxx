/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file startResumeTranslator.cxx
//! \brief Contains the DtStartResumeTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/startResumeTranslator.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtStartResumeTranslator::DtStartResumeTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtStartInteractionKind )
      {
      }

      DtStartResumeTranslator::~DtStartResumeTranslator()
      {
      }

      void DtStartResumeTranslator::translate( const Json::Value& source,
         DtPortalStartInteraction* destination )
      {
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("OriginatingEntity",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setOriginatingEntity( eid.string() );

         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         v = source.get("ReceivingEntity",a);
         eid.setSite( v[0u].asInt() );
         eid.setHost( v[1].asInt() );
         eid.setEntityNum( v[2].asInt() );
         destination->setReceivingEntity( eid.string() );

         destination->setRequestIdentifier(source.get("RequestIdentifier",0).asUInt());
         destination->setRealWorldTime( source.get("RealWorldTime",0.0).asDouble());
         destination->setRealWorldTimeType((const DtTimeStampType)source.get("RealWorldTimeType",0).asUInt());
         destination->setSimulationTime( source.get("SimulationTime",0.0).asDouble());
         destination->setSimulationTimeType((const DtTimeStampType)source.get("SimulationTimeType",0).asUInt());
      }

      void DtStartResumeTranslator::translate( const DtPortalStartInteraction& source,
         Json::Value* destination )
      {
         // TODO
      }

   }
}
