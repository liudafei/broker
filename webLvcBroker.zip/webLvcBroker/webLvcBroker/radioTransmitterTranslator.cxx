/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioTransmitterTranslator.cxx
//! \brief Contains the DtRadioTransmitterTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/radioTransmitterTranslator.h>
#include <webLvcBroker/beamAntennaPatternRecord.h>

#include <omtReader/xmlFileReader.h>
#include <omtReader/omtFileReader.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtRadioTransmitterTranslator::DtRadioTransmitterTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtRadioTransmitterObjectKind )
      {
      }

      DtRadioTransmitterTranslator::~DtRadioTransmitterTranslator()
      {
      }

      void DtRadioTransmitterTranslator::translate( const Json::Value& source,
         DtPortalRadioTransmitterObject* destination )
      {
         //first the embedded system part
         //host object name
         Json::Value hostObjectId = source.get("HostObjectName","unknown");
         destination->setHostObjectIdentifier(hostObjectId.asCString());

         //entity id
         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = 0;
         entityIdentifier[1] = 0;
         entityIdentifier[2] =0;
         Json::Value entId = source.get("EntityIdentifier",entityIdentifier);
         std::stringstream eid;
         if ( entId.isString() )
         {
            destination->setEntityIdentifier(entId.asCString());
         }
         else
         {
            eid << entId.get(0u,1).asInt();
            eid << ":" << entId.get(1,1).asInt();
            eid << ":" << entId.get(2,1).asInt();
            destination->setEntityIdentifier(eid.str().c_str());
         }

         //relative location
         Json::Value relPos(Json::arrayValue);
         relPos[0u] = 0.0;
         relPos[1] = 0.0;
         relPos[2] = 0.0;
         Json::Value rp = source.get("RelativeAntennaLocation",relPos);
         if ( rp.isArray() )
         {
            try
            {
               destination->setRelativePosition( DtVector32( rp.get(0u,0).asDouble(), rp.get(1,0).asDouble(), rp.get(2,0).asDouble()));
            }
            catch ( ... )
            {
            }
         }
         else
         {
            DtWarn(" Received non array relative position\n");
         }

         //then the radio part
         int radioIndex = source.get("RadioIndex",-1).asInt();
         if ( radioIndex != -1 )
         {
            destination->setRadioIndex( radioIndex );
         }

         //radio type
         Json::Value radioType = source.get("RadioEntityType","0,0,0,0,0,0");
         if ( radioType.isString() )
         {
            destination->setRadioSystemType( DtRadioEntityType( radioType.asCString()).string());
         }
         else
         {
            destination->setRadioSystemType( DtRadioEntityType(
               radioType.get(0u,-1).asInt(),
               radioType.get(1,-1).asInt(),
               radioType.get(2,-1).asInt(),
               radioType.get(3,-1).asInt(),
               radioType.get(4,-1).asInt(),
               radioType.get(5,-1).asInt() ).string());
         }

         int cryptoMode = source.get("CryptoMode",0).asInt();
         destination->setCryptographicMode(cryptoMode);

         int cryptoSystem = source.get("CryptoSystem",0).asInt();
         destination->setCryptoSystem(cryptoSystem);

         int encryptKeyId = source.get("CryptoKey",0).asInt();
         destination->setEncryptionKeyIdentifier(encryptKeyId);

         double freq = source.get("Frequency",0).asDouble();
         destination->setFrequency(freq);

         double freqBand = source.get("TransmitBandwidth",0).asDouble();
         destination->setFrequencyBandwidth(freqBand);

         int radioSource = source.get("InputSource",0).asInt();
         destination->setRadioInputSource(radioSource);

         Json::Value modulationType(Json::objectValue);
         modulationType=source.get("ModulationType", modulationType);

         int spreadSpectrum = modulationType.get("SpreadSpectrum",0).asInt();
         destination->setSpreadSpectrumType(spreadSpectrum);

         int modSystem = modulationType.get("System",0).asInt();
         destination->setRFModulationSystemType(modSystem);

         int modType = modulationType.get("Major",0).asInt();
         destination->setRFModulationType(modType);

         int detailedModType = modulationType.get("Detail",0).asInt();
         destination->setDetailedModulationType(detailedModType);

         double transmitterPower = source.get("Power",0).asDouble();
         destination->setTransmittedPower(transmitterPower);

         int transOpStatus = source.get("TransmitState",0).asInt();
         destination->setTransmitterOperationalStatus(transOpStatus);

         bool pseudo=source.get("PseudoNoiseInUse", false).asBool();
         destination->setPseudoNoiseSpectrumInUse(pseudo);

         bool freqHop=source.get("FrequencyHopInUse", false).asBool();
         destination->setFrequencyHopInUse(freqHop);

         bool timeHop=source.get("TimeHopInUse", false).asBool();
         destination->setTimeHopInUse(timeHop);

         int antennaPatternType = source.get("AntennaPatternType",0).asInt();
         destination->setAntennaPatternType(antennaPatternType);

         Json::Value antennaPattern(Json::objectValue);
         antennaPattern=source.get("AntennaPatternParameters", antennaPattern);

         switch ( (DtAntennaPatternType)destination->antennaPatternType() )
         {
         case DtOmniDirectional:
            {
               //this should be an empty data structure
               DtVariableLengthData data;
               destination->setAntennaPatternData(data);
               break;
            }
         case DtBeam:
            {
               DtBeamAntennaPatternRecord beam;
               Json::Value angles(Json::arrayValue);
               angles[0u] = 0.0;
               angles[1] = 0.0;
               angles[2] = 0.0;
               Json::Value ang = antennaPattern.get("BeamDirection",angles);
               if ( ang.isArray() )
               {
                  try
                  {
                     beam.setAngles( DtTaitBryan( ang.get(0u,0).asDouble(), ang.get(1,0).asDouble(), ang.get(2,0).asDouble()));
                  }
                  catch ( ... )
                  {
                  }
               }
               else
               {
                  DtWarn(" Received non array beam angles\n");
               }

               beam.setBeamwidth(antennaPattern.get("AzimuthBeamwidth", 0).asDouble(), antennaPattern.get("ElevationBeamwidth", 0).asDouble());
               beam.setReferenceSystem((DtReferenceSys)antennaPattern.get("ReferenceSystem", 0).asUInt());
               beam.setElectricField(antennaPattern.get("Ez", 0).asDouble(), antennaPattern.get("Ex", 0).asDouble());
               beam.setPhase(antennaPattern.get("Phase", 0).asDouble());

               DtVariableLengthData data;
               data.setData((const char*)beam.netRep(), beam.netSize());
               destination->setAntennaPatternData(data);

               break;
            }
         case DtSphericalHarmonic:
            {
               //there is no VR-Link representation of this object, so skipping for now
               break;
            }
         }


         Json::Value worldLoc(Json::arrayValue);
         worldLoc[0u] = 0.0;
         worldLoc[1] = 0.0;
         worldLoc[2] = 0.0;
         Json::Value wl = source.get("WorldLocation",worldLoc);
         if ( wl.isArray() )
         {
            try
            {
               destination->setWorldLocation( DtVector( wl.get(0u,0).asDouble(), wl.get(1,0).asDouble(), wl.get(2,0).asDouble()));
            }
            catch ( ... )
            {
            }
         }
         else
         {
            DtWarn(" Received non array world location\n");
         }

         destination->setTimeReceived( myBroker->portalConnection()->clock()->simTime() );
      }

      void DtRadioTransmitterTranslator::translate( const DtPortalRadioTransmitterObject& source, Json::Value* destination )
      {
         (*destination)["ObjectType"] = "WebLVC:RadioTransmitter";

         //first the embedded system part
         (*destination)["HostObjectName"]=source.hostObjectIdentifier().c_str();

         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = source.entityIdentifier().site();
         entityIdentifier[1] = source.entityIdentifier().host();
         entityIdentifier[2] = source.entityIdentifier().entityNum();
         (*destination)["EntityIdentifier"] = entityIdentifier;

         Json::Value relativePosition(Json::arrayValue);
         relativePosition[0u] = source.relativePosition().x();
         relativePosition[1] = source.relativePosition().y();
         relativePosition[2] = source.relativePosition().z();
         (*destination)["RelativeAntennaLocation"] = relativePosition;

         //then the radio part
         (*destination)["RadioIndex"] = (unsigned int)source.radioIndex();

         Json::Value radioTypeJson(Json::arrayValue);
         DtRadioEntityType radioType=DtRadioEntityType(source.radioSystemType().c_str());
         radioTypeJson[0u] = radioType.kind();
         radioTypeJson[1] = radioType.domain();
         radioTypeJson[2] = radioType.country();
         radioTypeJson[3] = radioType.category();
         radioTypeJson[4] = radioType.nomenclatureVersion();
         radioTypeJson[5] = radioType.nomenclature();
         (*destination)["RadioEntityType"] = radioTypeJson;

         (*destination)["CryptoMode"] = (unsigned int) source.cryptographicMode();
         (*destination)["CryptoSystem"] = (unsigned int) source.cryptoSystem();
         (*destination)["CryptoKey"] = (unsigned int) source.encryptionKeyIdentifier();
         (*destination)["Frequency"] = (double) source.frequency();
         (*destination)["TransmitBandwidth"] = (double) source.frequencyBandwidth();
         (*destination)["InputSource"] = (unsigned int) source.radioInputSource();

         (*destination)["Power"] = (double) source.timeHopInUse();
         (*destination)["TransmitState"] = (unsigned int) source.transmitterOperationalStatus();
         (*destination)["PseudoNoiseInUse"] = source.pseudoNoiseSpectrumInUse();
         (*destination)["FrequencyHopInUse"] = source.frequencyHopInUse();
         (*destination)["TimeHopInUse"] = source.timeHopInUse();

         Json::Value modulation(Json::objectValue);
         modulation["SpreadSpectrum"]=(unsigned int) source.spreadSpectrumType();
         modulation["Major"]=(unsigned int) source.rfModulationType();
         modulation["Detail"]=(unsigned int) source.detailedModulationType();
         modulation["System"]=(unsigned int) source.rfModulationSystemType();
         (*destination)["ModulationType"]=modulation;

         (*destination)["AntennaPatternType"] = (unsigned int) source.antennaPatternType();
         Json::Value antennaPattern(Json::objectValue);
         switch((DtAntennaPatternType)source.antennaPatternType())
         {
         case DtOmniDirectional:
            {
               //do nothing.  this should mean the antenna data is an empty object
               break;
            }
         case DtBeam:
            {
               DtBeamAntennaPatternRecord beam(source.antennaPatternData().data(), source.antennaPatternData().size() );
               Json::Value angles(Json::arrayValue);
               angles[0u] = beam.angles().psi();
               angles[1] = beam.angles().theta();
               angles[2] = beam.angles().phi();
               antennaPattern["BeamDirection"] = angles;
               antennaPattern["AzimuthBeamwidth"]=(double)beam.azimuthBeamwidth();
               antennaPattern["ElevationBeamwidth"]=(double)beam.elevationBeamwidth();
               antennaPattern["ReferenceSystem"]=(unsigned int)beam.referenceSystem();
               antennaPattern["Ex"]=(double)beam.electricFieldX();
               antennaPattern["Ez"]=(double)beam.electricFieldZ();
               antennaPattern["Phase"]=(double)beam.phase();
               break;

            }
         case DtSphericalHarmonic:
            {
               //There is no VR-Link representation for these.  I quit
               antennaPattern["sphericalHarmonics"]="unsupported";
               break;
            }
         }

         (*destination)["AntennaPatternParameters"]=antennaPattern;

         //these also don't exist, but the translation of them aren't clear at this time
         //Json::Value modulationParameters(Json::arrayValue);

         Json::Value worldLocation(Json::arrayValue);
         worldLocation[0u] = source.worldLocation().x();
         worldLocation[1] = source.worldLocation().y();
         worldLocation[2] = source.worldLocation().z();
         (*destination)["WorldAntennaLocation"] = worldLocation;
      }

   }
}
