/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file loggerControlTranslator.cxx
//! \brief Contains the DtLoggerControlTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/loggerControlTranslator.h>
#include <portal/pLoggerControlInteraction.h>
#include <portal/pLoggerDeleteFileInteraction.h>
#include <portal/pLoggerEmptyInteraction.h>
#include <portal/pLoggerStopInteraction.h>
#include <portal/pLoggerEndInteraction.h>
#include <portal/pLoggerEndOfActionInteraction.h>
#include <portal/pLoggerHeartbeatInteraction.h>
#include <portal/pLoggerPauseInteraction.h>
#include <portal/pLoggerPlayActionInteraction.h>
#include <portal/pLoggerPlayFileInteraction.h>
#include <portal/pLoggerPlayInteraction.h>
#include <portal/pLoggerQuitInteraction.h>
#include <portal/pLoggerRecordActionInteraction.h>
#include <portal/pLoggerRecordFileInteraction.h>
#include <portal/pLoggerRecordInteraction.h>
#include <portal/pLoggerSetTimeInteraction.h>
#include <portal/pLoggerSkipTimeInteraction.h>
#include <portal/pLoggerStartInteraction.h>
#include <portal/pLoggerStateFlagInteraction.h>
#include <portal/pLoggerTimeoutInteraction.h>
#include <portal/pLoggerTimeScaleInteraction.h>
#include <portal/pLoggerTotalStateInteraction.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtLoggerControlTranslator::DtLoggerControlTranslator( DtBroker* broker )
         : DtLvcInteractionTranslator<DtPortalLoggerControlInteraction>(broker, translatorName(), DtLoggerControlInteractionKind)
      {
      }

      DtLoggerControlTranslator::~DtLoggerControlTranslator()
      {
         removeWebLvcCallbacks();
         removePortalCallbacks();
      }

      void DtLoggerControlTranslator::initializeWebLvcCallbacks()
      {
         webLvcBroker()->addInteractionCB( std::string(name().c_str()), this );
      }

      void DtLoggerControlTranslator::removeWebLvcCallbacks()
      {
         webLvcBroker()->removeInteractionCB( std::string(name().c_str()) );
      }

      void DtLoggerControlTranslator::initializePortalCallbacks()
      {
         // Only perform WebLVC -> Portal translation. Except for state and connect.
         DtPortalLoggerConnectInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalLoggerTotalStateInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this);
      }

      void DtLoggerControlTranslator::removePortalCallbacks()
      {
         // Only perform WebLVC -> Portal translation. Except for state and connect.
         DtPortalLoggerConnectInteraction::removeCallback(
            myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalLoggerTotalStateInteraction::removeCallback(
            myBroker->portalConnection(), receivePortalInteraction, this);
      }
      
      void DtLoggerControlTranslator::receivePortalInteraction(
         const MAKVrExchange::DtPortalLoggerTotalStateInteraction& loggerControl, void* usr)
      {
         DtLoggerControlTranslator* trans = (DtLoggerControlTranslator*)usr;
         trans->createInteraction(loggerControl);
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const MAKVrExchange::DtPortalLoggerConnectInteraction& loggerControl, void* usr)
      {
         DtLoggerControlTranslator* trans = (DtLoggerControlTranslator*)usr;
         trans->createInteraction(loggerControl);
      }

      void DtLoggerControlTranslator::translate(
         const Json::Value& source, DtPortalLoggerControlInteraction* destination )
      {
         DtString lgrEntIdStr("1:1:1");
         DtString selfEntIdStr("1:99:5");
         lgrEntIdStr = source.get("Target","1:1:1").asCString();
         destination->setSenderId(selfEntIdStr);
         destination->setReceiverId(lgrEntIdStr);

      }
      
      void DtLoggerControlTranslator::translate(
         const DtPortalLoggerControlInteraction& source, Json::Value* destination)
      {
         //Not implemented
      }

      void DtLoggerControlTranslator::translate(
         const DtPortalLoggerConnectInteraction& source, Json::Value* destination)
      {
         (*destination)["originatingId"] = source.senderId().c_str();
         (*destination)["receivingId"] = source.receiverId().c_str();

         (*destination)["loggerName"] = source.loggerName().c_str();
      }

      void DtLoggerControlTranslator::translate(
         const DtPortalLoggerTotalStateInteraction& source, Json::Value* destination)
      {
         (*destination)["originatingId"] = source.senderId().c_str();
         (*destination)["receivingId"] = source.receiverId().c_str();

         (*destination)["time"] = source.time();
         (*destination)["idealTime"] = source.idealTime();
         (*destination)["time"] = source.time();
         (*destination)["scale"] = source.scale();
         (*destination)["fileLength"] = source.fileLength();
         (*destination)["heartbeat"] = source.heartbeat();
         (*destination)["timeout"] = source.timeout();
         (*destination)["dataScaling"] = source.dataScaling();
         (*destination)["filePos"] = (int)source.filePos();
         (*destination)["mode"] = (int)source.mode();
         (*destination)["dataScaling"] = source.dataScaling();
         (*destination)["playAction"] = (int)source.playAction();
         (*destination)["recordAction"] = (int)source.recordAction();
         (*destination)["endOfAction"] = (int)source.endOfAction();
         (*destination)["timeConstrained"] = source.timeConstrained();
         (*destination)["timeRegulating"] = source.timeRegulating();
         (*destination)["usingOwnFedAmb"] = source.usingOwnFedAmb();
         (*destination)["loggerFile"] = source.loggerFile().c_str();
         (*destination)["annotationsFile"] = source.annotationsFile().c_str();
      }

      void DtLoggerControlTranslator::createInteraction(
         const DtPortalLoggerControlInteraction& incoming)
      {
         try
         {
            Json::Value root;
            root["MessageKind"] = 2;
            root["InteractionType"] = "MAK:LoggerControl";

            switch (incoming.loggerCommandType())
            {
            case DtLgrTotalState + 2: //DtLgrConnect:
            {
               const DtPortalLoggerConnectInteraction* actualPortalType =
                  dynamic_cast<const DtPortalLoggerConnectInteraction*>(&incoming);
               translate(*actualPortalType, &root);
               break;
            }
            case DtLgrTotalState:
            {
               const DtPortalLoggerTotalStateInteraction* actualPortalType =
                  dynamic_cast<const DtPortalLoggerTotalStateInteraction*>(&incoming);
               translate(*actualPortalType, &root);
               break;
            }
            default:
            {
               return;
            }
            }

            Json::FastWriter writer;
            std::string buffer = writer.write(root);
            webLvcBroker()->queueToSend(buffer, 0);

            if (this->myBroker->isTranslatorDebuggingOn(name()))
            {
               printIncomingOutgoingStateReps(incoming, root);
            }
         }
         DtCATCH_AND_PROPAGATE(DtException)
      }
      void DtLoggerControlTranslator::processMsg( Json::Value* msg, DtClient* client )
      {
         std::string key = msg->get("Command","none").asString();

         DtPortalLoggerControlInteraction* lgrCtrl = NULL;

         //should do something better here
         if( key == "LCPlay" )
         {
            //send a logger control play
            lgrCtrl = new DtPortalLoggerPlayInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrPlay);
         }
         else if( key == "LCPause" )
         {
            lgrCtrl = new DtPortalLoggerPauseInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrPause);

         }
         else if( key == "LCStart" )
         {
            lgrCtrl = new DtPortalLoggerStartInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrStart);
         }
         else if (key == "LCEnd")
         {
            lgrCtrl = new DtPortalLoggerEndInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrEnd);
         }
         else if (key == "LCRecordFile")
         {
            lgrCtrl = new DtPortalLoggerRecordFileInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrRecFile);
            ((DtPortalLoggerRecordFileInteraction*)lgrCtrl)->setFilename(msg->get("Filename", "none").asString());
         }
         else if (key == "LCPlayFile")
         {
            lgrCtrl = new DtPortalLoggerPlayFileInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrPbFile);
            ((DtPortalLoggerPlayFileInteraction*)lgrCtrl)->setFilename(msg->get("Filename", "none").asString());
         }
         else if (key == "LCDelFile")
         {
            lgrCtrl = new DtPortalLoggerDeleteFileInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrDelFile);
            ((DtPortalLoggerDeleteFileInteraction*)lgrCtrl)->setFilename(msg->get("Filename", "none").asString());
         }
         else if (key == "LCEmpty")
         {
            lgrCtrl = new DtPortalLoggerEmptyInteraction();
            lgrCtrl->setLoggerCommandType(22); //DtLgrEmpty
         }
         else if (key == "LCQuit")
         {
            lgrCtrl = new DtPortalLoggerQuitInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrQuit); 
         }
         else if (key == "LCStop")
         {
            lgrCtrl = new DtPortalLoggerStopInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrStop);
         }
         else if (key == "LCRecord")
         {
            lgrCtrl = new DtPortalLoggerRecordInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrRecord);
         }
         else if (key == "LCSetTime")
         {
            lgrCtrl = new DtPortalLoggerSetTimeInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrSetTime);
            ((DtPortalLoggerSetTimeInteraction*)lgrCtrl)->setSetTime(msg->get("Time", "none").asDouble());
         }
         else if (key == "LCSkipTime")
         {
            lgrCtrl = new DtPortalLoggerSkipTimeInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrSkipTime);
            ((DtPortalLoggerSkipTimeInteraction*)lgrCtrl)->setSkipTime(msg->get("Time", "none").asDouble());
         }
         else if (key == "LCTimeScale")
         {
            lgrCtrl = new DtPortalLoggerTimeScaleInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrTimeScale);
            ((DtPortalLoggerTimeScaleInteraction*)lgrCtrl)->setTimeScale(msg->get("TimeScale", "none").asDouble());
         }
         else if (key == "LCPlayAction")
         {
            lgrCtrl = new DtPortalLoggerPlayActionInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrPlayAction);
            ((DtPortalLoggerPlayActionInteraction*)lgrCtrl)->setAction(msg->get("Action", "none").asInt());
         }
         else if (key == "LCRecordAction")
         {
            lgrCtrl = new DtPortalLoggerRecordActionInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrRecordAction);
            ((DtPortalLoggerRecordActionInteraction*)lgrCtrl)->setAction(msg->get("Action", "none").asInt());
         }
         else if (key == "LCEofAction")
         {
            lgrCtrl = new DtPortalLoggerEndOfActionInteraction();
            lgrCtrl->setLoggerCommandType(DtLgrEofAction);
            ((DtPortalLoggerEndOfActionInteraction*)lgrCtrl)->setAction(msg->get("Action", "none").asInt());
         }
         else
         {
            DtWarn << "Unhandled logger control" << std::endl;
            return;
         }

         translate(*msg, lgrCtrl);

         ((DtWebLvcBroker*)myBroker)->portalConnection()->send(*lgrCtrl);
         delete lgrCtrl;

         // Publish to all other WebLVC clients
         Json::FastWriter writer;
         std::string buffer = writer.write( *msg );
         ((DtWebLvcBroker*)myBroker)->queueToSend( buffer, client );
      }

   }
}
