/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file lvcInteractionTranslator.inl
//! \brief Contains the DtLvcInteractionTranslator class definition.
//! \ingroup webLvcBroker

#ifndef _lvcInteractionTranslator_INL_
#error "Inline definitions file must be included from declaring header."
#endif

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      template <class T_PortalInteraction>
      DtLvcInteractionTranslator<T_PortalInteraction>::DtLvcInteractionTranslator(
            DtBroker* broker, const DtString& name, DtPortalMessageKind kind )
         : DtBaseInteractionTranslator<T_PortalInteraction,DtBaseWebLvcInteractionTranslator>(
            broker, name, kind )
      {
         webLvcBroker()->addInteractionCB( std::string(name.c_str()), this );
      }

      template <class T_PortalInteraction>
      DtLvcInteractionTranslator<T_PortalInteraction>::~DtLvcInteractionTranslator()
      {
         webLvcBroker()->removeInteractionCB( std::string(this->myTranslatorName.c_str()) );
      }

      template <class T_PortalInteraction>
      void DtLvcInteractionTranslator<T_PortalInteraction>::tick()
      {
         // TODO tick.
         return;
      }

      template <class T_PortalInteraction>
      DtWebLvcBroker* DtLvcInteractionTranslator<T_PortalInteraction>::webLvcBroker()
      {
         return (DtWebLvcBroker*) this->myBroker;
      }

      template <class T_PortalInteraction>
      const DtWebLvcBroker* DtLvcInteractionTranslator<T_PortalInteraction>::webLvcBroker() const
      {
         return (const DtWebLvcBroker*) this->myBroker;
      }

      template <class T_PortalInteraction>
      void DtLvcInteractionTranslator<T_PortalInteraction>::createInteraction(
         const T_PortalInteraction& obj )
      {
         Json::Value root;

         root["MessageKind"] = 2;
         root["InteractionType"] = obj.name().string();

         translate( obj, &root );

         Json::FastWriter writer;
         std::string buffer = writer.write( root );
         this->webLvcBroker()->queueToSend( buffer, 0 );

         if ( this->myBroker->isTranslatorDebuggingOn(this->name()) )
         {
            printIncomingOutgoingStateReps( obj, root );
         }

         ++this->myNumInteractions;
      }

      template <class T_PortalInteraction>
      void DtLvcInteractionTranslator<T_PortalInteraction>::processMsg( Json::Value* msg, DtClient* client )
      {
         T_PortalInteraction* destination = new T_PortalInteraction();
         translate( *msg, destination );
         webLvcBroker()->portalConnection()->send( *destination );

         // Publish to all other WebLVC clients
         Json::StyledWriter writer;
         std::string buffer;
         buffer = writer.write( *msg );
         webLvcBroker()->queueToSend( buffer, client );

         if ( this->myBroker->isTranslatorDebuggingOn(this->name()) )
         {
            printIncomingOutgoingStateReps( *msg, *destination );
         }

         ++this->myNumInteractions;

         DtDELETE( destination );
      }

      template <class T_PortalInteraction>
      void DtLvcInteractionTranslator<T_PortalInteraction>::printIncomingOutgoingStateReps(
         const DtPortalMessage& incoming, const Json::Value& outgoing )
      {
         DtInfo << "========ORIG (Portal) - " << this->name() << " ========" << std::endl;
         DtInfo << incoming;
         DtInfo << "========NEW (WebLVC) - " << this->name() << " ========" << std::endl;
         DtInfo << outgoing.toStyledString();
         DtInfo << "------------------------------------------------" << std::endl;
      }

      template <class T_PortalInteraction>
      void DtLvcInteractionTranslator<T_PortalInteraction>::printIncomingOutgoingStateReps(
         const Json::Value& incoming, const DtPortalMessage& outgoing )
      {
         DtInfo << "========ORIG (WebLVC) - " << this->name() << " ========" << std::endl;
         DtInfo << incoming.toStyledString();
         DtInfo << "========NEW (Portal) - " << this->name() << " ========" << std::endl;
         DtInfo << outgoing;
         DtInfo << "------------------------------------------------" << std::endl;
      }

   }
}
