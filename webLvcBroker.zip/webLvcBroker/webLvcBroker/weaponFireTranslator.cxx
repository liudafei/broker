/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file weaponFireTranslator.cxx
//! \brief Contains the DtWeaponFireTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/weaponFireTranslator.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtWeaponFireTranslator::DtWeaponFireTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalFireInteractionMessageKind )
      {
      }

      DtWeaponFireTranslator::~DtWeaponFireTranslator()
      {
      }

      void DtWeaponFireTranslator::translate(  const Json::Value& source,
         DtPortalFireInteraction* destination )
      {
         //AttackerID
         destination->setAttackerId(source.get("AttackerId", "unknown").asCString());
         //TargetID
         destination->setTargetId(source.get("TargetId", "unknown").asCString());
         //EntityType
         destination->setEntityType(source.get("EntityType", "0:0:0:0:0:0:0").asCString());
         //MunitionType
         destination->setMunitionType(source.get("MunitionType", "0:0:0:0:0:0:0").asCString());
         //MunitionID
         destination->setMunitionId(source.get("MunitionId", "unknown").asCString());
         //EventID
         destination->setEventId(source.get("EventId", "unknown").asCString());
         //WarheadType
         destination->setWarheadType(source.get("WarheadType", 0).asUInt());
         //FireMissionIndex
         destination->setFireMissionIndex(source.get("FireMissionIndex", 0).asUInt());
         //FuseType
         destination->setFuseType(source.get("FuseType", 0).asUInt());
         //Quantity
         destination->setQuantity(source.get("Quantity", 0).asUInt());
         //Rate
         destination->setRate(source.get("Rate", 0).asUInt());
         //Range
         destination->setRange(source.get("Range", 0).asDouble());
         //Location
         Json::Value def(Json::arrayValue);
         def[0u] = 0;
         def[1] = 0;
         def[2] = 0;
         Json::Value worldLocation = source.get("WorldLocation", def);
         destination->setLocation(DtVector(worldLocation[0u].asDouble(), worldLocation[1].asDouble(), worldLocation[2].asDouble()));
         //Velocity
         Json::Value velocity = source.get("Velocity", def);
         destination->setVelocity(DtVector32(velocity[0u].asDouble(), velocity[1].asDouble(), velocity[2].asDouble()));

      }

      void DtWeaponFireTranslator::translate( const DtPortalFireInteraction& source,
         Json::Value* destination )
      {
         (*destination)["MessageKind"] = 2;
         (*destination)["InteractionType"] = translatorName().c_str();

         //! AttackerID is the name of the object which fired the weapon.
         (*destination)["AttackerId"] = source.attackerId().c_str();

         //! \brief TargetID is the name of the object which was targeted by the Attacker.
         //! For indirect fire this field can be left blank.
         if ( source.targetId() != DtString::nullString() )
         {
            (*destination)["TargetId"] = source.targetId().c_str();
         }

         //! \brief The EntityType of the Fired Object if it is simulated as an entity Object.
         //! This noted as "N:N:N:N:N:N:N" This field can be left empty
         if ( source.entityType() != DtString::nullString() )
         {
            (*destination)["EntityType"] = source.entityType().c_str();
         }

         //! \brief The Type of the Munition Object.
         //! This is noted as "N:N:N:N:N:N:N". This
         //! field can be left empty, as 0:0:0:0:0:0:0. Types follow the rules of the DIS
         //! Enumerations Document
         if ( source.munitionType() != "0:0:0:0:0:0:0" )
         {
            (*destination)["MunitionType"] = source.munitionType().c_str();
         }

         //! \brief A String Identifier for the Munition
         (*destination)["MunitionId"] = source.munitionId().c_str();

         //! A string representation of an EventID
         (*destination)["EventId"] = source.eventId().c_str();

         //! The Warhead type as specified by the DIS Enumerations
         (*destination)["WarheadType"] = (unsigned)source.warheadType();

         //! The Fire Mission Index
         (*destination)["FireMissionIndex"] = (unsigned)source.fireMissionIndex();

         //! The fuze as specified by the DIS Enumerations Document
         (*destination)["FuseType"] = (unsigned)source.fuseType();

         //! \brief The quantity of munition discharged for this event when a burst is fired.
         //! zero indicates it was a single round.
         (*destination)["Quantity"] = (unsigned)source.quantity();

         //! \brief The Rate at which munitions are discharged in rounds per minute.
         (*destination)["Rate"] = (unsigned)source.rate();

         //! \brief Range in meters assumed by firing entity in computing the fire control solution.
         (*destination)["Range"] = source.range();

         //! \brief The location in Geocentric Coordinates from which the munition was launched.
         Json::Value worldLocation(Json::arrayValue);
         worldLocation[0u] = source.location()[0];
         worldLocation[1] = source.location()[1];
         worldLocation[2] = source.location()[2];
         (*destination)["Location"] = worldLocation;

         //! \brief The velocity of the munition at the point of the muzzle flash (if applicable)
         Json::Value velocity(Json::arrayValue);
         velocity[0u] = source.velocity()[0];
         velocity[1] = source.velocity()[1];
         velocity[2] = source.velocity()[2];
         (*destination)["Velocity"] = velocity;
      }

   }
}
