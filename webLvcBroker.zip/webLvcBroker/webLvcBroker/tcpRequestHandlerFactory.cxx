/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file tcpRequestHandlerFactory.cxx
//! \brief Contains the DtTcpRequestHandlerFactory class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/tcpRequestHandlerFactory.h>
#include <webLvcBroker/tcpSocketConnection.h>

#include <Poco/Net/TCPServerConnectionFactory.h>
#include <Poco/Net/TCPServerConnection.h>

using Poco::Net::StreamSocket;
using Poco::Net::TCPServerConnection;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtTcpRequestHandlerFactory::DtTcpRequestHandlerFactory()
         : TCPServerConnectionFactory()
      {
      }

      DtTcpRequestHandlerFactory::~DtTcpRequestHandlerFactory()
      {
      }

      TCPServerConnection* DtTcpRequestHandlerFactory::createConnection(
         const StreamSocket& socket )
      {
         return new DtTcpSocketConnection( socket );
      }

   }
}
