/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file vrfMsgTranslator.cxx
//! \brief Contains the DtVrfMsgTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/entityTranslator.h>
#include <webLvcBroker/vrfMsgTranslator.h>
#include <portal/pDataInter.h>
#include <json/json.h>
#include <vector>
#include <string>
#include <sstream>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {
      void fromJSON(const Json::Value& jsonArrayValue, DtEntityIdentifier& entityIdentifier) {
         entityIdentifier.setSite(jsonArrayValue[0u].asInt());
         entityIdentifier.setHost(jsonArrayValue[1].asInt());
         entityIdentifier.setEntityNum(jsonArrayValue[2].asInt());
      }

      void toJSON(const DtEntityIdentifier& entityIdentifier, Json::Value& jsonArrayValue) {
         jsonArrayValue[0u] = entityIdentifier.site();
         jsonArrayValue[1] = entityIdentifier.host();
         jsonArrayValue[2] = entityIdentifier.entityNum();
      }

      void toJSON(const DtVector& vrlVector, Json::Value& jsonArrayValue) {
         jsonArrayValue[0u] = vrlVector[0];
         jsonArrayValue[1] = vrlVector[1];
         jsonArrayValue[2] = vrlVector[2];
      }

      void toJSON(const DtVector32& vrlVector, Json::Value& jsonArrayValue) {
         jsonArrayValue[0u] = vrlVector[0];
         jsonArrayValue[1] = vrlVector[1];
         jsonArrayValue[2] = vrlVector[2];
      }

      void toJSON(const DtTaitBryan& taitBryan, Json::Value& jsonArrayValue) {
         jsonArrayValue[0u] = taitBryan.psi();
         jsonArrayValue[1] = taitBryan.theta();
         jsonArrayValue[2] = taitBryan.phi();
      }

      void fromJSON(const Json::Value& jsonArrayValue, DtEntityType& entityType) {
         entityType.setKind(jsonArrayValue[0u].asInt());
         entityType.setDomain(jsonArrayValue[1].asInt());
         entityType.setCountry(jsonArrayValue[2].asInt());
         entityType.setCategory(jsonArrayValue[3].asInt());
         entityType.setSubCategory(jsonArrayValue[4].asInt());
         entityType.setSpecific(jsonArrayValue[5].asInt());
         entityType.setExtra(jsonArrayValue[6].asInt());
      }

      void toJSON(const DtEntityType& entityType, Json::Value& jsonArrayValue) {
         jsonArrayValue[0u] = entityType.kind();
         jsonArrayValue[1] = entityType.domain();
         jsonArrayValue[2] = entityType.country();
         jsonArrayValue[3] = entityType.category();
         jsonArrayValue[4] = entityType.subCategory();
         jsonArrayValue[5] = entityType.specific();
         jsonArrayValue[6] = entityType.extra();
      }

      void toJSON(const std::vector<DtInt32>& integerVector, Json::Value& jsonArrayValue) {
         unsigned int index = 0u;
         for (index = 0; index < integerVector.size(); ++index) {
            jsonArrayValue[index] = integerVector[index];
         }
      }

      DtVrfMsgTranslator::DtVrfMsgTranslator( DtBroker* broker )
         : DtBaseWebLvcInteractionTranslator( broker, translatorName(), DtPortalVrfScriptedTaskInteractionKind )
      {
         myVariableTypeMap["Unknown"] = DtPortalVrfScriptedTaskInteraction::Unknown;
         myVariableTypeMap["AggregateFormation"] = DtPortalVrfScriptedTaskInteraction::AggregateFormation;
         myVariableTypeMap["AltitudeMSL"] = DtPortalVrfScriptedTaskInteraction::AltitudeMSL;
         myVariableTypeMap["BombResource"] = DtPortalVrfScriptedTaskInteraction::BombResource;
         myVariableTypeMap["Boolean"] = DtPortalVrfScriptedTaskInteraction::Boolean;
         myVariableTypeMap["ChoiceDropDownList"] = DtPortalVrfScriptedTaskInteraction::ChoiceDropDownList;
         myVariableTypeMap["ChoiceOptionButton"] = DtPortalVrfScriptedTaskInteraction::ChoiceOptionButton;
         myVariableTypeMap["DIGuyAnimation"] = DtPortalVrfScriptedTaskInteraction::DIGuyAnimation;
         myVariableTypeMap["DIGuyAppearance"] = DtPortalVrfScriptedTaskInteraction::DIGuyAppearance;
         myVariableTypeMap["Distance"] = DtPortalVrfScriptedTaskInteraction::Distance;
         myVariableTypeMap["DepthMSL"] = DtPortalVrfScriptedTaskInteraction::DepthMSL;
         myVariableTypeMap["Emitter"] = DtPortalVrfScriptedTaskInteraction::Emitter;
         myVariableTypeMap["EntityType"] = DtPortalVrfScriptedTaskInteraction::EntityType;
         myVariableTypeMap["Force"] = DtPortalVrfScriptedTaskInteraction::Force;
         myVariableTypeMap["Heading"] = DtPortalVrfScriptedTaskInteraction::Heading;
         myVariableTypeMap["Integer"] = DtPortalVrfScriptedTaskInteraction::Integer;
         myVariableTypeMap["LocationWithAltitude"] = DtPortalVrfScriptedTaskInteraction::LocationWithAltitude;
         myVariableTypeMap["LocationWithoutAltitude"] = DtPortalVrfScriptedTaskInteraction::LocationWithoutAltitude;
         myVariableTypeMap["MunitionResource"] = DtPortalVrfScriptedTaskInteraction::MunitionResource;
         myVariableTypeMap["OffsetLocation"] = DtPortalVrfScriptedTaskInteraction::OffsetLocation;
         myVariableTypeMap["Real"] = DtPortalVrfScriptedTaskInteraction::Real;
         myVariableTypeMap["Resource"] =  DtPortalVrfScriptedTaskInteraction::Resource;
         myVariableTypeMap["SimulationObjectSingle"] = DtPortalVrfScriptedTaskInteraction::SimulationObjectSingle;
         myVariableTypeMap["SimulationObjectMultiple"] = DtPortalVrfScriptedTaskInteraction::SimulationObjectMultiple;
         myVariableTypeMap["Speed"] = DtPortalVrfScriptedTaskInteraction::Speed;
         myVariableTypeMap["String"] = DtPortalVrfScriptedTaskInteraction::String;
         myVariableTypeMap["Time"] = DtPortalVrfScriptedTaskInteraction::Time;
         myVariableTypeMap["TurnRate"] = DtPortalVrfScriptedTaskInteraction::TurnRate;

         myMessageTypes["MAK:VrfScriptedTask"] = 1;
         myMessageTypes["MAK:VrfCurrentResourceRequest"] = 2;
         myMessageTypes["MAK:VrfResourceMonitorResponse"] = 3;
         myMessageTypes["MAK:VrfEntityResourceResponse"] = 4;
         myMessageTypes["MAK:VrfControl"] = 5;
         myMessageTypes["MAK:VrfSet"] = 6;
         myMessageTypes["MAK:VrfChangeTimeOfDay"] = 7;
         myMessageTypes["MAK:VrfChangeGlobalWeather"] = 8;
         myMessageTypes["MAK:VrfCreateObject"] = 9;
         myMessageTypes["MAK:VrfTextReport"] = 10;
         myMessageTypes["MAK:VrfScenario"] = 11;
         myMessageTypes["MAK:VrfDeleteObject"] = 12;
         myMessageTypes["MAK:VrfTask"] = 13;
         myMessageTypes["MAK:VrfSensorData"] = 14;
         myMessageTypes["MAK:VrfSensorDataRequest"] = 15;
      }

      DtVrfMsgTranslator::~DtVrfMsgTranslator()
      {
         removeWebLvcCallbacks();
         removePortalCallbacks();
      }

      DtWebLvcBroker* DtVrfMsgTranslator::webLvcBroker()
      {
         return (DtWebLvcBroker*) myBroker;
      }

      const DtWebLvcBroker* DtVrfMsgTranslator::webLvcBroker() const
      {
         return (const DtWebLvcBroker*) myBroker;
      }

      void DtVrfMsgTranslator::enableReflectTranslator( bool enabled )
      {
         if ( myReflectEnabled != enabled )
         {
            if ( enabled )
            {
               initializeWebLvcCallbacks();
            }
            else
            {
               removeWebLvcCallbacks();
            }
            myReflectEnabled = enabled;
         }
      }

      void DtVrfMsgTranslator::enablePublishTranslator( bool enabled )
      {
         if ( myPublishEnabled != enabled )
         {
            if ( enabled )
            {
               initializePortalCallbacks();
            }
            else
            {
               removePortalCallbacks();
            }
            myPublishEnabled = enabled;
         }
      }

      void DtVrfMsgTranslator::initializeWebLvcCallbacks()
      {
         std::map<std::string,int>::iterator itr = myMessageTypes.begin();
         std::map<std::string,int>::iterator end = myMessageTypes.end();
         for ( ; itr != end; ++itr )
         {
            webLvcBroker()->addInteractionCB( itr->first, this );
         }
      }

      void DtVrfMsgTranslator::removeWebLvcCallbacks()
      {
         std::map<std::string,int>::iterator itr = myMessageTypes.begin();
         std::map<std::string,int>::iterator end = myMessageTypes.end();
         for ( ; itr != end; ++itr )
         {
            webLvcBroker()->removeInteractionCB( itr->first );
         }
      }

      void DtVrfMsgTranslator::initializePortalCallbacks()
      {
         DtPortalVrfCurrentResourceRequestInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfResourceMonitorResponseInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfEntityResourceResponseInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfScriptedTaskInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfControlInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfSetDataInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfCurrentTasksInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfChangeTimeOfDayCommandInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfChangeGlobalWeatherCommandInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfCreateObjInteraction::addCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfDeleteObjInteraction::addCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfTextReportInteraction::addCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfScenarioInteraction::addCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfSpotReportInteraction::addCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfTaskInteraction::addCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfSensorDataInteraction::addCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfSensorDataRequestInteraction::addCallback(myBroker->portalConnection(), receivePortalInteraction, this);
      }

      void DtVrfMsgTranslator::removePortalCallbacks()
      {
         DtPortalVrfCurrentResourceRequestInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfResourceMonitorResponseInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfEntityResourceResponseInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfScriptedTaskInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfControlInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfSetDataInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfCurrentTasksInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfChangeTimeOfDayCommandInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfChangeGlobalWeatherCommandInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfCreateObjInteraction::removeCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfDeleteObjInteraction::removeCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfTextReportInteraction::removeCallback( myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalVrfScenarioInteraction::removeCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfSpotReportInteraction::removeCallback(myBroker->portalConnection(), receivePortalInteraction, this);
         DtPortalVrfTaskInteraction::removeCallback(myBroker->portalConnection(), receivePortalInteraction, this);
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfCurrentResourceRequestInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction( const DtPortalVrfCurrentResourceRequestInteraction& incoming )
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfCurrentResourceRequestInteraction* destination )
      {
         destination->setOriginatingEntity( source.get("OriginatingEntity","").asCString() );
         destination->setReceivingEntity( source.get("ReceivingEntity","").asCString() );
         destination->setObjectName( source.get("ReceivingEntity","").asCString() );
         destination->setRequestId( source.get("RequestId",0).asUInt() );

         std::vector<DtString> res;
         Json::Value v( Json::arrayValue );
         v = source.get( "Resources", v );
         for ( int i =0 ; i < v.size(); ++i )
         {
            res.push_back( v[i].asCString() );
         }
         destination->setResources( res );
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfCurrentResourceRequestInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfResourceMonitorResponseInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction(
         const DtPortalVrfResourceMonitorResponseInteraction& obj )
      {
         Json::Value root;
         root["MessageKind"] = 2;
         root["InteractionType"] = "MAK:VrfResourceMonitorResponse";

         translate( obj, &root );

         Json::FastWriter writer;
         std::string buffer = writer.write( root );
         webLvcBroker()->queueToSend( buffer, 0 );

         if ( this->myBroker->isTranslatorDebuggingOn(name()) )
         {
            printIncomingOutgoingStateReps( obj, root );
         }
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfResourceMonitorResponseInteraction* destination )
      {
         //TODO fill out
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfResourceMonitorResponseInteraction& source,
         Json::Value* destination )
      {
//         DtResource newResource;
//
//         newResource.myResourceName = fullName;
//         newResource.myResourceType = resource->type();
//
//         if ( newResource.myResourceType == DtRealResourceType )
//         {
//            DtRealResource * realResource = (DtRealResource*) resource;
//            newResource.myCurrentAmount = (DtNetFloat64)realResource->amount();
//            newResource.myFullAmount = (DtNetFloat64)realResource->fullAmount();
//            newResource.myResourceEntityType = DtEntityType::nullType();
//         }
//         else if ( newResource.myResourceType == DtIntegerResourceType )
//         {
//            DtIntegerResource * intResource = (DtIntegerResource*) resource;
//            newResource.myCurrentAmount = (DtNetFloat64)intResource->amount();
//            newResource.myFullAmount = (DtNetFloat64)intResource->fullAmount();
//            newResource.myResourceEntityType = DtEntityType::nullType();
//         }
//         else if ( newResource.myResourceType == DtMunitionResourceType )
//         {
//            DtMunitionResource * intResource = (DtMunitionResource *)resource;
//            newResource.myCurrentAmount = (DtNetFloat64)intResource->amount();
//            newResource.myFullAmount = (DtNetFloat64)intResource->fullAmount();
//            newResource.myResourceEntityType = intResource->munitionType().munitionType();
//         }
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfEntityResourceResponseInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction(
         const DtPortalVrfEntityResourceResponseInteraction& obj )
      {
//         // pass as message is no longer supported
//         Json::Value root;
//         root["MessageKind"] = 2;
//         root["InteractionType"] = "MAK:VrfEntityResourceResponse";
//
//         translate( obj, &root );
//
//         Json::FastWriter writer;
//         std::string buffer;
//         buffer = writer.write(root);
//
//         webLvcBroker()->queueToSend(buffer);
//
//         if ( this->myBroker->isTranslatorDebuggingOn(name()) )
//         {
//            printIncomingOutgoingStateReps( obj, root );
//         }

         // add the resource data to the additional data value
         DtEntityTranslator* entTrans =
            (DtEntityTranslator*) webLvcBroker()->getObjectTranslator( DtEntityTranslator::translatorName() );
         if ( ! entTrans )
         {
            return;
         }

         Json::Value resources( Json::arrayValue );

         for ( int i = 0; i < obj.resources().size(); ++i )
         {
            DtAttributeValuePairList avpl;
            obj.getResource( i, avpl );
            Json::Value val( Json::objectValue );
            convertResource( avpl, val );
            resources[i] = val;
         }

         webLvcBroker()->addAdditionalDataValue( obj.objectName(), "Resources", resources );
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfEntityResourceResponseInteraction* destination )
      {
         //TODO fill out
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfEntityResourceResponseInteraction& source,
         Json::Value* destination )
      {
         (*destination)["ObjectName"] = source.objectName().c_str();
         Json::Value resources( Json::arrayValue );

         for ( int i = 0; i < source.resources().size(); ++i )
         {
            DtAttributeValuePairList avpl;
            source.getResource( i, avpl );
            Json::Value val( Json::objectValue );
            convertResource( avpl, val );
            resources[i] = val;
         }

         (*destination)["Resources"] = resources;
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfScriptedTaskInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction( const DtPortalVrfScriptedTaskInteraction& incoming )
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfScriptedTaskInteraction* destination )
      {
         convertScriptedTask( source, destination );
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfScriptedTaskInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfTaskInteraction& inter, void* usr)
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction(inter);
      }

      void DtVrfMsgTranslator::createInteraction(const DtPortalVrfTaskInteraction& incoming)
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate(const Json::Value& source,
         DtPortalVrfTaskInteraction* destination)
      {
         convertTask(source, destination);
      }

      void DtVrfMsgTranslator::translate(const DtPortalVrfTaskInteraction& source,
         Json::Value* destination)
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfControlInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction( const DtPortalVrfControlInteraction& incoming )
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfControlInteraction* destination )
      {
         destination->setControlType( source.get("ControlType","Unknown").asString().c_str());
         destination->setTime( source.get("Time",0.0).asDouble() );
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfControlInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfSetDataInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction( const DtPortalVrfSetDataInteraction& incoming )
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfSetDataInteraction* destination )
      {
         convertSetData( source, destination );
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfSetDataInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfCurrentTasksInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction(
         const DtPortalVrfCurrentTasksInteraction& obj )
      {
         Json::Value v;

         bool done = false;
         // Entity can have more than one task
         MAKVrExchange::DtAttributeValuePairList::const_iterator ti = obj.taskList().begin();
         while ( ti != obj.taskList().end() && ! done )
         {
            std::string s( ti->second.data(), ti->second.size() );
            Json::Reader reader;
            reader.parse( s, v );

            if ( v.get("TaskName","").asString() != "TabletTask" )
            {
               done = true;
            }
            else
            {
               ti++;
               v.clear();
            }
         }

         webLvcBroker()->addAdditionalDataValue( obj.originatingEntity(), "CurrentTask", v );
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfCurrentTasksInteraction* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfCurrentTasksInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfChangeTimeOfDayCommandInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction( const DtPortalVrfChangeTimeOfDayCommandInteraction& incoming )
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfChangeTimeOfDayCommandInteraction* destination )
      {
         destination->setSecondsPastMidnight( source.get("SecondsPastMidnight",0.0).asDouble());
         destination->setTimeOfDayAdvanceSpeed( source.get("TimeOfDayAdvanceSpeed",0.0).asDouble() );
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfChangeTimeOfDayCommandInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

#define DtTRANSLATEDOUBLE( T, N, n ) \
   if ( source.isMember(n) ) \
   { \
      destination->set##N( source.get(n,0.0).asDouble() ); \
   }
#define DtTRANSLATEINT( T, N, n ) \
   if ( source.isMember(n) ) \
   { \
      destination->set##N( source.get(n,0).asInt() ); \
   }
#define DtTRANSLATEBOOL( T, N, n ) \
   if ( source.isMember(n) ) \
   { \
      destination->set##N( source.get(n,0).asBool() ); \
   }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfChangeGlobalWeatherCommandInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction( const DtPortalVrfChangeGlobalWeatherCommandInteraction& incoming )
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfChangeGlobalWeatherCommandInteraction* destination )
      {
         DtTRANSLATEDOUBLE( double, AirTurbidity, "AirTurbidity" );
         DtTRANSLATEDOUBLE( double, AmbientAirTemperature, "AmbientAirTemperature" );
         DtTRANSLATEINT( int, CloudState, "CloudState" );
         DtTRANSLATEDOUBLE( double, PrecipitationIntensity, "PrecipitationIntensity" );
         DtTRANSLATEINT( int, PrecipitationType, "PrecipitationType" );
         DtTRANSLATEDOUBLE( double, Visibility, "Visibility" );
         DtTRANSLATEDOUBLE( double, WindDirection, "WindDirection" );
         DtTRANSLATEDOUBLE( double, WindSpeed, "WindSpeed" );
         DtTRANSLATEDOUBLE( double, UnderwaterVisibility, "UnderwaterVisibility" );
         DtTRANSLATEDOUBLE( double, SurfaceTransparency, "SurfaceTransparency" );
         DtTRANSLATEDOUBLE( double, WaterCurrentSpeed, "WaterCurrentSpeed" );
         DtTRANSLATEDOUBLE( double, WaterCurrentDirection, "WaterCurrentDirection" );
         DtTRANSLATEDOUBLE( double, AmbientWaterTemperature, "AmbientWaterTemperature" );
         DtTRANSLATEDOUBLE( double, TidalOffset, "TidalOffset" );
         DtTRANSLATEDOUBLE( double, TidalDirection, "TidalDirection" );
         DtTRANSLATEINT( int, SwellState, "SwellState" );
         DtTRANSLATEDOUBLE( double, SwellStateDirection, "SwellStateDirection");
         DtTRANSLATEINT( int, SeaState,  "SeaState" );
         DtTRANSLATEDOUBLE( double, SeaStateDirection, "SeaStateDirection" );
         DtTRANSLATEBOOL( bool, WindDrivenSeaStateEnabled, "WindDrivenSeaStateEnabled" );
         DtTRANSLATEDOUBLE( double, Choppiness, "Choppiness" );
         DtTRANSLATEDOUBLE( double, SurgeDepth, "SurgeDepth" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer1Depth, "ThermoclineLayer1Depth" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer1Permeability, "ThermoclineLayer1Permeability" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer2Depth, "ThermoclineLayer2Depth" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer2Permeability, "ThermoclineLayer2Permeability" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer3Depth, "ThermoclineLayer3Depth" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer3Permeability, "ThermoclineLayer3Permeability" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer4Depth, "ThermoclineLayer4Depth" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer4Permeability, "ThermoclineLayer4Permeability" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer5Depth, "ThermoclineLayer5Depth" );
         DtTRANSLATEDOUBLE( double, ThermoclineLayer5Permeability, "ThermoclineLayer5Permeability" );

         translateWindLevels(source, destination);

      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfChangeGlobalWeatherCommandInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfCreateObjInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction( const DtPortalVrfCreateObjInteraction& incoming )
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfCreateObjInteraction* destination )
      {
         Json::Value a( Json::arrayValue );
         a[0u] = -1;
         a[1u] = -1;
         Json::Value v = source.get( "Address", a );
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(), -1 );
         destination->setAddress( eid );

         destination->setName( source.get("Name","").asString().c_str() );

         Json::Value b( Json::arrayValue );
         b[0u] = -1;
         b[1u] = -1;
         b[2u] = -1;
         b[3u] = -1;
         b[4u] = -1;
         b[5u] = -1;
         b[6u] = -1;
         Json::Value v1 = source.get("ObjectType",b);
         DtEntityType etype( v1[0u].asInt(),v1[1].asInt(), v1[2].asInt(),v1[3].asInt(),v1[4].asInt(),v1[5].asInt(),v1[6].asInt());
         destination->setObjectType( etype );

         destination->setForceType( source.get("ForceType",0).asInt() );
         destination->setLabel( source.get("Label","").asString().c_str());
         destination->setHeading( source.get("Heading",0.0).asDouble());
         destination->setProjection( source.get("Projection",false).asBool());
         destination->setClosedFigure( source.get("ClosedFigure",false).asBool());
         destination->setAppearance( source.get("Appearance",0).asInt() );
         destination->setCreateSubObjects( source.get("CreateSubObjects",false).asBool());
         destination->setClampToGround(source.get("ClampToGround", true).asBool()); //default in VRF is to ground clamp

         //Vertices
         Json::Value verts(Json::arrayValue);
         verts = source.get("Vertices",verts);

         for ( unsigned i = 0; i < verts.size(); ++i )
         {
            destination->addVertex( DtVector( verts[i][0u].asDouble(), verts[i][1].asDouble(), verts[i][2].asDouble() ) );
         }
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfCreateObjInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfDeleteObjInteraction& inter, void* usr)
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction(inter);
      }

      void DtVrfMsgTranslator::createInteraction(const DtPortalVrfDeleteObjInteraction& incoming)
      {
         // for now don't translate.
      }

      void DtVrfMsgTranslator::translate(const Json::Value& source,
         DtPortalVrfDeleteObjInteraction* destination)
      {
         destination->setName(source.get("Name", "").asString().c_str());
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfDeleteObjInteraction& source,
         Json::Value* destination )
      {
         // TODO fill out
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfTextReportInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction(
         const DtPortalVrfTextReportInteraction& obj )
      {
         Json::Value root;
         root["MessageKind"] = 2;
         root["InteractionType"] = "MAK:VrfTextReport";

         translate( obj, &root );

         Json::FastWriter writer;
         std::string buffer = writer.write( root );
         webLvcBroker()->queueToSend( buffer, 0 );

         if (this->myBroker->isTranslatorDebuggingOn(name()) )
         {
            printIncomingOutgoingStateReps( obj, root );
         }
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfTextReportInteraction* destination )
      {
         destination->setMessage( source.get("message","").asCString() );
         destination->setOriginatingEntity( source.get("originatingEntity","").asCString() );
         destination->setReceivingEntity( source.get("receivingEntity","").asCString() );
      }

      void DtVrfMsgTranslator::translate( const DtPortalVrfTextReportInteraction& source,
         Json::Value* destination )
      {
         (*destination)["originatingEntity"] = source.originatingEntity().c_str();
         (*destination)["receivingEntity"] = source.receivingEntity().c_str();
         (*destination)["message"] = source.message().c_str();
      }

      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfScenarioInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction(
         const DtPortalVrfScenarioInteraction& obj )
      {
         Json::Value root;
         root["MessageKind"] = 2;
         root["InteractionType"] = "MAK:VrfScenario";

         translate( obj, &root );

         Json::FastWriter writer;
         std::string buffer = writer.write( root );
         webLvcBroker()->queueToSend( buffer, 0 );

         if ( this->myBroker->isTranslatorDebuggingOn(name()) )
         {
            printIncomingOutgoingStateReps( obj, root );
         }
      }

      void DtVrfMsgTranslator::translate( const Json::Value& source,
         DtPortalVrfScenarioInteraction* destination )
      {
         destination->setScenarioCommand( source.get("Command","").asCString() );
         destination->setScenarioFilename(source.get("ScenarioFilename", "").asCString());
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         Json::Value v = source.get("Address", a);
         DtString addr = DtString(v[0u].asInt()) + DtString(":") + DtString(v[1].asInt());
         destination->setAddress(addr);
      }

      void DtVrfMsgTranslator::translate(  const DtPortalVrfScenarioInteraction& source,
         Json::Value* destination )
      {
         (*destination)["Command"] = source.scenarioCommand().c_str();
         (*destination)["ScenarioFilename"] = source.scenarioFilename().c_str();
         (*destination)["Address"] = source.address().c_str();
      }


      void DtVrfMsgTranslator::receivePortalInteraction(
         const DtPortalVrfSpotReportInteraction& inter, void* usr )
      {
         ((DtVrfMsgTranslator*)usr)->createInteraction( inter );
      }

      void DtVrfMsgTranslator::createInteraction( const DtPortalVrfSpotReportInteraction& obj )
      {
         Json::Value root;

         root["MessageKind"] = 2;
         root["InteractionType"] = "MAK:VrfSpotReport";

         translate( obj, &root );

         Json::FastWriter writer;
         std::string buffer = writer.write( root );
         webLvcBroker()->queueToSend( buffer, 0 );

         if ( this->myBroker->isTranslatorDebuggingOn(name()) )
         {
            printIncomingOutgoingStateReps( obj, root );
         }
      }

   void DtVrfMsgTranslator::translate(
      const Json::Value& source, DtPortalVrfSpotReportInteraction* destination)
   {
      // TODO
   }

   void DtVrfMsgTranslator::translate(
      const DtPortalVrfSpotReportInteraction& source, Json::Value* destination)
   {
      const DtSensorContactInfo& contactInfo = source.contactInfo();

      (*destination)["SpotterName"] = source.spotterName().c_str();
      (*destination)["EngagementResult"] = source.engagementResult().c_str();
      (*destination)["DateAndTimeOfReport"] = source.dateAndTimeOfReport();
      (*destination)["SimulationTime"] = source.simulationTime();
      (*destination)["UseGroundTruth"] = source.useGroundTruth();
      (*destination)["Reason"] = source.reason();
      (*destination)["ExpirationTime"] = source.expirationTime();
      (*destination)["ContactName"] = contactInfo.contactName().c_str();

      Json::Value jsonEntityIdentifier(Json::arrayValue);
      toJSON(contactInfo.id(), jsonEntityIdentifier);
      (*destination)["Id"] = jsonEntityIdentifier;

      (*destination)["OriginalTimeOfDetection"] = contactInfo.originalTimeOfDetection();
      (*destination)["OriginalDateAndTimeOfDetection"] = contactInfo.originalDateAndTimeOfDetection();
      (*destination)["LastTimeOfDetection"] = contactInfo.lastTimeOfDetection();
      (*destination)["LastDateAndTimeOfDetection"] = contactInfo.lastDateAndTimeOfDetection();
      (*destination)["CombatIdentificationLevel"] = contactInfo.combatIdentificationLevel();
      (*destination)["DetectionError"] = contactInfo.detectionError();

      Json::Value jsonContactPosition(Json::arrayValue);
      toJSON(contactInfo.contactPosition(), jsonContactPosition);
      (*destination)["ContactPosition"] = jsonContactPosition;

      Json::Value jsonContactOrientation(Json::arrayValue);
      toJSON(contactInfo.contactOrientation(), jsonContactOrientation);
      (*destination)["ContactOrientation"] = jsonContactOrientation;

      Json::Value jsonContactVelocity(Json::arrayValue);
      toJSON(contactInfo.contactVelocity(), jsonContactVelocity);
      (*destination)["ContactVelocity"] = jsonContactVelocity;

      (*destination)["ContactSuperType"] = static_cast<unsigned int>(contactInfo.contactSuperType());

      Json::Value jsonContactEntityType(Json::arrayValue);
      toJSON(contactInfo.contactEntityType(), jsonContactEntityType);
      (*destination)["ContactEntityType"] = jsonContactEntityType;

      (*destination)["ContactForce"] = static_cast<unsigned int>(contactInfo.contactForce());

      Json::Value jsonIntegerArray(Json::arrayValue);
      toJSON(contactInfo.contactSourceTypes(), jsonIntegerArray);
      (*destination)["ContactSourceTypes"] = jsonIntegerArray;

      (*destination)["ContactFormation"] = static_cast<unsigned int>(contactInfo.contactFormation());
      (*destination)["ContactActivity"] = contactInfo.contactActivity().c_str();
      (*destination)["ContactAppearance"] = static_cast<unsigned int>(contactInfo.contactAppearance());
      (*destination)["ContactRadius"] = contactInfo.contactRadius();
      (*destination)["HealthPercentage"] = contactInfo.healthPercentage();
      (*destination)["IsBreached"] = contactInfo.isBreached();
   }

   void DtVrfMsgTranslator::receivePortalInteraction(
      const DtPortalVrfSensorDataInteraction& inter, void* usr)
   {
      ((DtVrfMsgTranslator*)usr)->createInteraction(inter);
   }

   void DtVrfMsgTranslator::createInteraction(
      const DtPortalVrfSensorDataInteraction& obj)
   {
      Json::Value root;
      root["MessageKind"] = 2;
      root["InteractionType"] = "MAK:VrfSensorData";

      translate(obj, &root);

      Json::FastWriter writer;
      std::string buffer = writer.write(root);
      webLvcBroker()->queueToSend(buffer, 0);

      if (this->myBroker->isTranslatorDebuggingOn(name()))
      {
         printIncomingOutgoingStateReps(obj, root);
      }
   }

   void DtVrfMsgTranslator::translate(const Json::Value& src,
      DtPortalVrfSensorDataInteraction* dest)
   {
      dest->setSensorName(src.get("SensorName", "").asCString());
      dest->setSensorEnabled(src.get("SensorEnabled", "").asBool());
      dest->setSourceEntity(src.get("SourceEntity", "").asCString());
      dest->setSensorType(src.get("SensorType", "").asUInt());
      dest->sensorDataEntryList().clear();
      Json::Value a(Json::arrayValue);
      a[0u] = -1;
      Json::Value v = src.get("SensorDataList", a);
      Json::ValueIterator data = v.begin();
      Json::ValueIterator dataEnd = v.end();
      for (; data != dataEnd; data++)
      {
         Json::Value item = *data;
         DtPortalVrfSensorDataEntry entry;
         entry.setTarget(item.get("Target", "").asCString());
         entry.setContactType(item.get("ContactType", "").asCString());
         entry.setContactSuperType(item.get("ContactSuperType", "").asUInt());
         entry.setCombatIdentificationLevel(item.get("CombatIdentificationLevel", "").asUInt());
         entry.setForceType(item.get("ForceType", "").asUInt());
         dest->sensorDataEntryList().push_back(entry);
      }
   }

   void DtVrfMsgTranslator::translate(const DtPortalVrfSensorDataInteraction& source,
      Json::Value* destination)
   {
      (*destination)["SensorName"] = source.sensorName().c_str();
      (*destination)["SensorEnabled"] = source.isEnabled();
      (*destination)["SourceEntity"] = source.sourceEntity().c_str();
      (*destination)["SensorType"] = (unsigned int) source.sensorType();

      Json::Value sdList(Json::arrayValue);
      DtPortalVrfSensorDataEntryList::const_iterator data = source.sensorDataEntryList().cbegin();
      DtPortalVrfSensorDataEntryList::const_iterator endData = source.sensorDataEntryList().cend();
      for (; data != endData; data++)
      {
         Json::Value sdEntry(Json::objectValue);
         sdEntry["Target"] = data->target().c_str();
         sdEntry["ContactType"] = data->contactType().c_str();
         sdEntry["ContactSuperType"] = (unsigned int) data->contactSuperType();
         sdEntry["CombatIdentificationLevel"] = (unsigned int) data->combatIdentificationLevel();
         sdEntry["ForceType"] = (unsigned int)data->forceType();
         sdList.append(sdEntry);
      }
      (*destination)["SensorDataList"] = sdList;
   }

   void DtVrfMsgTranslator::receivePortalInteraction(
      const DtPortalVrfSensorDataRequestInteraction& inter, void* usr)
   {
      ((DtVrfMsgTranslator*)usr)->createInteraction(inter);
   }

   void DtVrfMsgTranslator::createInteraction(
      const DtPortalVrfSensorDataRequestInteraction& obj)
   {
      Json::Value root;
      root["MessageKind"] = 2;
      root["InteractionType"] = "MAK:VrfSensorDataRequest";

      translate(obj, &root);

      Json::FastWriter writer;
      std::string buffer = writer.write(root);
      webLvcBroker()->queueToSend(buffer, 0);

      if (this->myBroker->isTranslatorDebuggingOn(name()))
      {
         printIncomingOutgoingStateReps(obj, root);
      }
   }

   void DtVrfMsgTranslator::translate(const Json::Value& src,
      DtPortalVrfSensorDataRequestInteraction* dest)
   {
      dest->setSubscribe(src.get("Subscribe", "").asBool());
      dest->setRequestedMarkingText(src.get("RequestedMarkingText", "").asCString());
   }

   void DtVrfMsgTranslator::translate(const DtPortalVrfSensorDataRequestInteraction& source,
      Json::Value* destination)
   {
      (*destination)["Subscribe"] = source.subscribe();
      (*destination)["RequestedMarkingText"] = source.requestedMarkingText().c_str();
   }

   void DtVrfMsgTranslator::processMsg( Json::Value* msg, DtClient* client )
      {
         DtPortalInteraction* pi;
         std::string type = msg->get("InteractionType","none").asString();
         std::map<std::string, int>::iterator it = myMessageTypes.find( type );
         if ( it == myMessageTypes.end() )
         {
            return;
         }

         switch ( it->second )
         {
         case 1: // "MAK:VrfScriptedTask"
            {
               DtPortalVrfScriptedTaskInteraction* destination = new DtPortalVrfScriptedTaskInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 2: // "MAK:VrfCurrentResourceRequest"
            {
               DtPortalVrfCurrentResourceRequestInteraction* destination = new DtPortalVrfCurrentResourceRequestInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 3: // "MAK:VrfResourceMonitorResponse"
            {
               DtPortalVrfResourceMonitorResponseInteraction* destination = new DtPortalVrfResourceMonitorResponseInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 4: // "MAK:VrfEntityResourceResponse"
            {
               DtPortalVrfEntityResourceResponseInteraction* destination = new DtPortalVrfEntityResourceResponseInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 5: // MAK:VrfControl
            {
               DtPortalVrfControlInteraction* destination = new DtPortalVrfControlInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 6: // MAK:VrfSet
            {
               DtPortalVrfSetDataInteraction* destination = new DtPortalVrfSetDataInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 7: // MAK:VrfChangeTimeOfDayCommand
            {
               DtPortalVrfChangeTimeOfDayCommandInteraction* destination = new DtPortalVrfChangeTimeOfDayCommandInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 8: // MAK:VrfChangeGlobalWeatherCommand
            {
               DtPortalVrfChangeGlobalWeatherCommandInteraction* destination = new DtPortalVrfChangeGlobalWeatherCommandInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 9: // MAK:VrfCreateObject
            {
               DtPortalVrfCreateObjInteraction* destination = new DtPortalVrfCreateObjInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 10: // MAK:VrfTextReport
            {
               DtPortalVrfTextReportInteraction* destination = new DtPortalVrfTextReportInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 11: // MAK:VrfScenario
            {
               DtPortalVrfScenarioInteraction* destination = new DtPortalVrfScenarioInteraction();
               translate(*msg, destination);
               pi = destination;
            }
            break;
         case 12: // MAK:VrfDeleteObject
         {
            DtPortalVrfDeleteObjInteraction* destination = new DtPortalVrfDeleteObjInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 13: // "MAK:VrfTask"
         {
            DtPortalVrfTaskInteraction* destination = new DtPortalVrfTaskInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 14: // "MAK:VrfSensorData"
         {
            DtPortalVrfSensorDataInteraction* destination = new DtPortalVrfSensorDataInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         case 15: // "MAK:VrfSensorDataRequest"
         {
            DtPortalVrfSensorDataRequestInteraction* destination = new DtPortalVrfSensorDataRequestInteraction();
            translate(*msg, destination);
            pi = destination;
         }
         break;
         default:
            return;
         }

         myBroker->portalConnection()->send( *pi );

         // Publish to all other WebLVC clients
         Json::FastWriter writer;
         std::string buffer = writer.write( *msg );
         webLvcBroker()->queueToSend( buffer, client );

         if ( myBroker->isTranslatorDebuggingOn(name()) )
         {
            printIncomingOutgoingStateReps( *msg, *pi );
         }

         DtDELETE( pi );
      }

      void DtVrfMsgTranslator::printIncomingOutgoingStateReps(
         const DtPortalMessage& incoming, const Json::Value& outgoing )
      {
         DtInfo << "========ORIG (Portal) - " << name() << " ========" << std::endl;
         DtInfo << incoming;
         DtInfo << "========NEW (WebLVC) - " << name() << " ========" << std::endl;
         DtInfo << outgoing.toStyledString();
         DtInfo << "------------------------------------------------" << std::endl;
      }

      void DtVrfMsgTranslator::printIncomingOutgoingStateReps(
         const Json::Value& incoming, const DtPortalMessage& outgoing )
      {
         DtInfo << "========ORIG (WebLVC) - " << name() << " ========" << std::endl;
         DtInfo << incoming.toStyledString();
         DtInfo << "========NEW (Portal) - " << name() << " ========" << std::endl;
         DtInfo << outgoing;
         DtInfo << "------------------------------------------------" << std::endl;
      }

      void DtVrfMsgTranslator::convertScriptedTask( const Json::Value& value, DtPortalVrfScriptedTaskInteraction* inter )
      {
         // fill in the values

         std::string OriginatingEntity = value.get("OriginatingApplicationName","DtVrfFrontEnd").asString();
         std::string ReceivingEntity = value.get("ReceivingApplicationName","DtBroadcast").asString();
         inter->setOriginatingEntity(OriginatingEntity.c_str());
         inter->setReceivingEntity(ReceivingEntity.c_str());

         bool subtask = value.get("Subtask",false).asBool();
         inter->setSubtask(subtask);

         Json::Value scriptedTaskVar(Json::objectValue);
         scriptedTaskVar = value.get("ScriptedTask", scriptedTaskVar);

         std::string scriptID = scriptedTaskVar.get("ScriptID", "").asString();
         inter->setScriptID(scriptID.c_str());
         Json::Value scriptVars(Json::arrayValue);
         scriptVars = scriptedTaskVar.get("ScriptVariables",scriptVars);

         DtAttributeValuePairList avpl;
         for( int i = 0; i < scriptVars.size(); ++i )
         {
            // for each script variable
            // create the attributevalue for it
            // push it on the list
            std::string type = scriptVars[i].get("type","Unknown").asString();
            std::map<std::string, DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType>::iterator kind = myVariableTypeMap.find(type);
            if( kind !=  myVariableTypeMap.end() )
            {
               switch (kind->second)
               {
               case DtPortalVrfScriptedTaskInteraction::Boolean:
               case DtPortalVrfScriptedTaskInteraction::ChoiceDropDownList:
               case DtPortalVrfScriptedTaskInteraction::ChoiceOptionButton:
               case DtPortalVrfScriptedTaskInteraction::DIGuyAnimation:
               case DtPortalVrfScriptedTaskInteraction::DIGuyAppearance:
               case DtPortalVrfScriptedTaskInteraction::Emitter:
               case DtPortalVrfScriptedTaskInteraction::Force:
               case DtPortalVrfScriptedTaskInteraction::Integer:
               case DtPortalVrfScriptedTaskInteraction::MunitionResource:
               case DtPortalVrfScriptedTaskInteraction::Resource:
                  processIntValue(kind->second,scriptVars[i],avpl);
                  break;
               case DtPortalVrfScriptedTaskInteraction::LocationWithAltitude:
               case DtPortalVrfScriptedTaskInteraction::LocationWithoutAltitude:
               case DtPortalVrfScriptedTaskInteraction::OffsetLocation:
                  processVectorValue(kind->second,scriptVars[i],avpl);
                  break;
               case DtPortalVrfScriptedTaskInteraction::BombResource:
               case DtPortalVrfScriptedTaskInteraction::String:
               case DtPortalVrfScriptedTaskInteraction::SimulationObjectSingle:
               case DtPortalVrfScriptedTaskInteraction::SimulationObjectMultiple:
               case DtPortalVrfScriptedTaskInteraction::EntityType:
               case DtPortalVrfScriptedTaskInteraction::AggregateFormation:
                  processStringValue(kind->second,scriptVars[i],avpl);
                  break;
               case DtPortalVrfScriptedTaskInteraction::AltitudeMSL:
               case DtPortalVrfScriptedTaskInteraction::DepthMSL:
               case DtPortalVrfScriptedTaskInteraction::Distance:
               case DtPortalVrfScriptedTaskInteraction::Heading:
               case DtPortalVrfScriptedTaskInteraction::Real:
               case DtPortalVrfScriptedTaskInteraction::Speed:
               case DtPortalVrfScriptedTaskInteraction::Time:
               case DtPortalVrfScriptedTaskInteraction::TurnRate:
                  processDoubleValue(kind->second,scriptVars[i],avpl);
                  break;
               case DtPortalVrfScriptedTaskInteraction::Unknown:
               default:
                  break;
               }
            }
         }
         inter->setAttributeValuePairList(avpl);
      }

      void DtVrfMsgTranslator::convertTask(const Json::Value& value, DtPortalVrfTaskInteraction* inter)
      {
         // fill in the values
         std::string OriginatingEntity = value.get("OriginatingApplicationName", "DtVrfFrontEnd").asString();
         std::string ReceivingEntity = value.get("ReceivingApplicationName", "DtBroadcast").asString();
         inter->setOriginatingEntity(OriginatingEntity.c_str());
         inter->setReceivingEntity(ReceivingEntity.c_str());

         bool subtask = value.get("Subtask", false).asBool();
         inter->setSubtask(subtask);

         Json::Value taskVar(Json::objectValue);
         taskVar = value.get("Task", taskVar);

         std::string scriptID = taskVar.get("TaskID", "").asString();
         inter->setScriptID(scriptID.c_str());
         Json::Value scriptVars(Json::arrayValue);
         scriptVars = taskVar.get("Variables", scriptVars);

         if (scriptID == "TurnToHeading")
         {
            double heading = scriptVars.get("heading", "").asDouble();
            DtAttributeValuePair attr("Heading", DtVariableLengthData((const char*)&heading, 8));
            inter->attributeValuePairList().push_front(attr);
         }
      }

      void DtVrfMsgTranslator::convertSetData( const Json::Value& value, DtPortalVrfSetDataInteraction* inter )
      {
         // fill in the values

         std::string OriginatingEntity = value.get("OriginatingApplicationName","DtVrfFrontEnd").asString();
         std::string ReceivingEntity = value.get("ReceivingApplicationName","DtBroadcast").asString();
         inter->setOriginatingEntity(OriginatingEntity.c_str());
         inter->setReceivingEntity(ReceivingEntity.c_str());

         Json::Value scriptVars(Json::arrayValue);
         scriptVars = value.get("DataVariables",scriptVars);

         DtAttributeValuePairList avpl;
         for( int i = 0; i < scriptVars.size(); ++i )
         {
            // for each script variable
            // create the attributevalue for it
            // push it on the list
            std::string type = scriptVars[i].get("type","Unknown").asString();
            std::map<std::string, DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType>::iterator kind = myVariableTypeMap.find(type);
            if( kind !=  myVariableTypeMap.end() )
            {
               switch (kind->second)
               {
               case DtPortalVrfScriptedTaskInteraction::Boolean:
               case DtPortalVrfScriptedTaskInteraction::ChoiceDropDownList:
               case DtPortalVrfScriptedTaskInteraction::ChoiceOptionButton:
               case DtPortalVrfScriptedTaskInteraction::DIGuyAnimation:
               case DtPortalVrfScriptedTaskInteraction::DIGuyAppearance:
               case DtPortalVrfScriptedTaskInteraction::Emitter:
               case DtPortalVrfScriptedTaskInteraction::Force:
               case DtPortalVrfScriptedTaskInteraction::Integer:
               case DtPortalVrfScriptedTaskInteraction::MunitionResource:
               case DtPortalVrfScriptedTaskInteraction::Resource:
                  processIntValue(kind->second,scriptVars[i],avpl);
                  break;
               case DtPortalVrfScriptedTaskInteraction::LocationWithAltitude:
               case DtPortalVrfScriptedTaskInteraction::LocationWithoutAltitude:
               case DtPortalVrfScriptedTaskInteraction::OffsetLocation:
                  processVectorValue(kind->second,scriptVars[i],avpl);
                  break;
               case DtPortalVrfScriptedTaskInteraction::BombResource:
               case DtPortalVrfScriptedTaskInteraction::String:
               case DtPortalVrfScriptedTaskInteraction::SimulationObjectSingle:
               case DtPortalVrfScriptedTaskInteraction::SimulationObjectMultiple:
               case DtPortalVrfScriptedTaskInteraction::EntityType:
               case DtPortalVrfScriptedTaskInteraction::AggregateFormation:
                  processStringValue(kind->second,scriptVars[i],avpl);
                  break;
               case DtPortalVrfScriptedTaskInteraction::AltitudeMSL:
               case DtPortalVrfScriptedTaskInteraction::Distance:
               case DtPortalVrfScriptedTaskInteraction::Heading:
               case DtPortalVrfScriptedTaskInteraction::Real:
               case DtPortalVrfScriptedTaskInteraction::Speed:
               case DtPortalVrfScriptedTaskInteraction::Time:
               case DtPortalVrfScriptedTaskInteraction::TurnRate:
                  processDoubleValue(kind->second,scriptVars[i],avpl);
                  break;
               case DtPortalVrfScriptedTaskInteraction::Unknown:
               default:
                  break;
               }
            }
         }
         inter->setAttributeValuePairList(avpl);
      }

      void DtVrfMsgTranslator::processDoubleValue( DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType t, const Json::Value& value, DtAttributeValuePairList& avpl)
      {
         DtPortalVrfScriptedTaskInteraction::MsgDouble msg;
         msg.header.type = t;
         msg.value = value.get("value",0.0).asDouble();
         std::string name = value.get("name","").asString();
         DtAttributeValuePair avp(name.c_str(),DtVariableLengthData((const char*)&msg, sizeof(DtPortalVrfScriptedTaskInteraction::MsgDouble)));
         avpl.push_back(avp);
      }

      void DtVrfMsgTranslator::processStringValue( DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType t, const Json::Value& value, DtAttributeValuePairList& avpl)
      {
         std::string str = value.get("value","").asString();
         int len = str.size() + sizeof(DtPortalVrfScriptedTaskInteraction::MsgString);
         char *buffer = new char[  len ];
         memcpy( buffer + sizeof(DtPortalVrfScriptedTaskInteraction::MsgString), str.c_str(), str.size() );
         DtPortalVrfScriptedTaskInteraction::MsgString *msg = (DtPortalVrfScriptedTaskInteraction::MsgString *)buffer;
         msg->header.type = t;
         msg->len = str.size();
         std::string name = value.get("name","").asString();
         DtAttributeValuePair avp(name.c_str(),DtVariableLengthData((const char*)buffer, len));
         avpl.push_back(avp);
         delete [] buffer;
      }

      void DtVrfMsgTranslator::processIntValue( DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType t, const Json::Value& value, DtAttributeValuePairList& avpl)
      {
         DtPortalVrfScriptedTaskInteraction::MsgInt msg;
         msg.header.type = t;
         msg.value = value.get("value",0.0).asInt();
         std::string name = value.get("name","").asString();
         DtAttributeValuePair avp(name.c_str(),DtVariableLengthData((const char*)&msg, sizeof(DtPortalVrfScriptedTaskInteraction::MsgInt)));
         avpl.push_back(avp);
      }

      void DtVrfMsgTranslator::processVectorValue( DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType t, const Json::Value& value, DtAttributeValuePairList& avpl)
      {
         DtPortalVrfScriptedTaskInteraction::MsgVector msg;
         Json::Value v(Json::arrayValue);
         v = value.get("value",v);
         DtVector vect;
         if(v.size() > 1)
         {
            vect.setX(v[0u].asDouble());
            vect.setY(v[1u].asDouble());
         }
         if(v.size() > 2)
         {
            vect.setZ(v[2u].asDouble());
         }
         msg.header.type = t;
         msg.value = vect;
         std::string name = value.get("name","").asString();
         DtAttributeValuePair avp(name.c_str(),DtVariableLengthData((const char*)&msg, sizeof(DtPortalVrfScriptedTaskInteraction::MsgVector)));
         avpl.push_back(avp);
      }

      void DtVrfMsgTranslator::convertResource( DtAttributeValuePairList &resource, Json::Value& val)
      {
         DtAttributeValuePairList::iterator i = resource.begin();

         while( i != resource.end() )
         {
            DtString s = i->first;
            // This is messy and not good for performance, however it is pretty quick
            // to write and easy to debug.  Fix it when performance is a problem
            if( s == "ResourceName" )
               val["ResourceName"] = std::string(i->second.data(),i->second.size());
            else if( s == "CurrentAmount" )
               val["CurrentAmount"] = (double)*(DtNetFloat64*)i->second.data();
            else if( s == "FullAmount" )
               val["FullAmount"] = (double)*(DtNetFloat64*)i->second.data();
            else if( s == "ResourceType" )
               val["ResourceType"] = std::string(i->second.data(),i->second.size());
            else if( s == "ResourceEntityType" )
               val["ResourceEntityType"] = std::string(i->second.data(),i->second.size());
            ++i;
         }
      }

      void DtVrfMsgTranslator::shutdown()
      {
         removeWebLvcCallbacks();
         removePortalCallbacks();
      }

      void DtVrfMsgTranslator::translateWindLevels(const Json::Value& source,
         DtPortalVrfChangeGlobalWeatherCommandInteraction* destination)
      {
         const Json::Value arrayOfWindLevels = source["WindLevels"];
         for (int counter = 0; counter < arrayOfWindLevels.size(); ++counter)
         {
            myPortalWindLevels windLevel;
            windLevel.myBaseAltitude = arrayOfWindLevels[counter].get("BaseAltitude", 0.0).asDouble();
            windLevel.myWindSpeed = arrayOfWindLevels[counter].get("WindSpeed", 0.0).asDouble();
            windLevel.myWindDirection = arrayOfWindLevels[counter].get("WindDirection", 0.0).asDouble();
            windLevel.myVisibilityDistance = arrayOfWindLevels[counter].get("VisibilityDistance", 0.0).asDouble();
            windLevel.myVisibilityObscurant = arrayOfWindLevels[counter].get("VisibilityObscurant", 0).asUInt();
            windLevel.myCloudType = arrayOfWindLevels[counter].get("CloudType", 0).asInt();
            windLevel.myCloudDensity = arrayOfWindLevels[counter].get("CloudDensity", 0.0).asDouble();
            windLevel.mySkyCoverage = arrayOfWindLevels[counter].get("SkyCoverage", 0.0).asDouble();
            destination->addWindLevel(windLevel);
         }
      }

   }
}
