/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file httpConnectionServer.h
//! \brief Contains the DtHttpConnectionServer class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/reliableConnectionServer.h>
#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/HTTPServer.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtHttpConnectionServer is a class that listens for and handles
      //! to TCP connection requests.
      class DT_DLL_WEBLVCBROKER DtHttpConnectionServer : public DtReliableConnectionServer
      {
      public:

         //! \brief CTOR.
         DtHttpConnectionServer( int port );

         //! \brief Virtual DTOR.
         virtual ~DtHttpConnectionServer();

         //! Start listening for and handling connection requests
         virtual void start();

         //! Stop listening for and handling connection requests
         virtual void stop();

      private:

         //! Copy Constructor not implemented - Copy Not Allowed.
         DtHttpConnectionServer( const DtHttpConnectionServer& other );

         //! Assignment Operator Not implemented - Assignment Not Allowed.
         DtHttpConnectionServer& operator = ( const DtHttpConnectionServer& other );

      protected:

         // Socket we listen to for connection requests
         Poco::Net::ServerSocket* myServerSocket;

         // TCP server that handles connection requests.
         Poco::Net::HTTPServer* myHTTPServer;

      };

   }
}
