/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file httpProxyRequestHandler.cxx
//! \brief Contains the DtHttpProxyRequestHandler class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/httpProxyRequestHandler.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <webLvcBroker/webSocketClient.h>
#include <webLvcBroker/webLvcBroker.h>

#include <Poco/Net/HTTPServerResponse.h>
#include <Poco/Net/HTTPServerRequest.h>
#include <Poco/Net/HTTPClientSession.h>
#include <Poco/Net/NetException.h>
#include <Poco/StreamCopier.h>
#include <Poco/RWLock.h>

#include <vlutil/vlPrint.h>

#include <iostream>

using Poco::Net::HTTPRequestHandler;
using Poco::Net::WebSocketException;
using Poco::Net::HTTPServerResponse;
using Poco::Net::HTTPServerRequest;
using Poco::Net::HTTPClientSession;
using Poco::Net::HTTPResponse;
using Poco::Net::HTTPRequest;
using Poco::Net::WebSocket;
using Poco::StreamCopier;
using Poco::Timestamp;
using Poco::RWLock;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtHttpProxyRequestHandler::DtHttpProxyRequestHandler()
         : HTTPRequestHandler()
      {
      }

      DtHttpProxyRequestHandler::~DtHttpProxyRequestHandler()
      {
      }

      void DtHttpProxyRequestHandler::handleRequest( HTTPServerRequest& request,
         HTTPServerResponse& response )
      {
         try
         {
            response.setStatus( HTTPResponse::HTTP_OK );

            HTTPRequest req( request.getMethod(), request.getURI() );
            req.setHost( DtWebLvcBrokerInitializer::proxyHost().c_str(),
               DtWebLvcBrokerInitializer::proxyPort() );
            HTTPClientSession session( DtWebLvcBrokerInitializer::proxyHost().c_str(),
               DtWebLvcBrokerInitializer::proxyPort() );
            session.sendRequest( req );
            HTTPResponse res;

            std::istream &is = session.receiveResponse( res );
            Poco::Net::NameValueCollection* res2 = (HTTPResponse*) &response;
            res2->operator=( res );
            std::ostream& out = response.send();

            char buffer[4096];
            std::streamsize len = 0;
            is.read( buffer, 4096 );
            std::streamsize n = is.gcount();
            while ( n > 0 )
            {
               len += n;
               out.write( buffer, n );
               if ( is && out )
               {
                  is.read( buffer, 4096 );
                  n = is.gcount();
               }
               else
                  n = 0;
            }
            out.flush();
         }
         catch ( Poco::Exception & )
         {
            return;
         }
         catch ( ... )
         {
         }
      }

   }
}
