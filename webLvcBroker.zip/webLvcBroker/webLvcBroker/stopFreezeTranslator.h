/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file stopFreezeTranslator.h
//! \brief Contains the DtStopFreezeTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/lvcInteractionTranslator.h>
#include <vlpi/entityIdentifier.h>
#include <vlutil/vlHashlist.h>
#include <portal/pStopInter.h>
#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtStopFreezeTranslator are responsible for translating DtPortalStartInteraction to WebLVC:StopFreeze.
      class DT_DLL_WEBLVCBROKER DtStopFreezeTranslator : public DtLvcInteractionTranslator<DtPortalStopInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:StopFreeze" );

         //! \brief CTOR.
         DtStopFreezeTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtStopFreezeTranslator();

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, DtPortalStopInteraction* destination );
         virtual void translate( const DtPortalStopInteraction& source, Json::Value* destination );

      };

   }
}
