/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file munitionDetonationTranslator.h
//! \brief Contains the DtMunitionDetonationTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <webLvcBroker/lvcInteractionTranslator.h>
#include <portal/pDetonationInter.h>
#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtMunitionDetonationTranslator are responsible for translating DtPortalDetonationInteraction to WebLVC:MunitionDetonation.
      class DT_DLL_WEBLVCBROKER DtMunitionDetonationTranslator
         : public DtLvcInteractionTranslator<DtPortalDetonationInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:MunitionDetonation" );

         //! \brief CTOR.
         DtMunitionDetonationTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtMunitionDetonationTranslator();

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, DtPortalDetonationInteraction* destination );
         virtual void translate( const DtPortalDetonationInteraction& source, Json::Value* destination );

      };

   }
}
