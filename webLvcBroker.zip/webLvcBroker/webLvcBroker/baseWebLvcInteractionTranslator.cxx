/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file baseWebLvcInteractionTranslator.cxx
//! \brief Contains the DtBaseWebLvcInteractionTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/baseWebLvcInteractionTranslator.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtBaseWebLvcInteractionTranslator::DtBaseWebLvcInteractionTranslator(
            DtBroker* broker, const DtString& name, DtPortalMessageKind kind )
         : DtInteractionTranslator( broker, name, kind )
         , myLvcUpdateSet()
      {
      }

      DtBaseWebLvcInteractionTranslator::~DtBaseWebLvcInteractionTranslator()
      {
      }

      int DtBaseWebLvcInteractionTranslator::processUpdateSet( void* id )
      {
         return 0;
      }

      void DtBaseWebLvcInteractionTranslator::createUpdateSet( void* id )
      {
      }

      void DtBaseWebLvcInteractionTranslator::processClientRemoval( DtClient* )
      {
      }

      void DtBaseWebLvcInteractionTranslator::processMsg( Json::Value* msg, DtClient* client )
      {
      }

      Poco::RWLock* DtBaseWebLvcInteractionTranslator::lock()
      {
         return NULL;
      }

      void DtBaseWebLvcInteractionTranslator::removePortalObject( const std::string& refObj )
      {
      }

      DtString DtBaseWebLvcInteractionTranslator::status()
      {
         return DtString("default status\n");
      }

   }
}
