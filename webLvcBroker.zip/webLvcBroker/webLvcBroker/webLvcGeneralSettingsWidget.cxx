/*****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcGeneralSettingsWidget.cxx
//! \brief Contains the DtWebLvcGeneralSettingsWidget class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/webLvcGeneralSettingsWidget.h>

#include <commonWidgets/propertyEditorWidget.h>
#include <commonWidgets/propertyListViewItem.h>
#include <commonWidgets/propertyTypeFactory.h>
#include <commonWidgets/collectionEditor.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      // Default Connection Settings.
      bool DtWebLvcGeneralSettingsWidget::theDefaultUseTcpPort = false;
      int DtWebLvcGeneralSettingsWidget::theDefaultTcpServerPort = 9102;
      QString DtWebLvcGeneralSettingsWidget::theDefaultWebServerPort = "9101";
      QString DtWebLvcGeneralSettingsWidget::theDefaultProxyDest = "localhost";
      int DtWebLvcGeneralSettingsWidget::theDefaultProxyPort = 8080;
      QString DtWebLvcGeneralSettingsWidget::theDefaultOmtFiles = "vrlink.omt";
      bool DtWebLvcGeneralSettingsWidget::theDefaultEnableHttpServer = true;
      QString DtWebLvcGeneralSettingsWidget::theDefaultLocalHttpAddress = "../html";
      bool DtWebLvcGeneralSettingsWidget::theDefaultEnableHttpProxy = true;
      QString DtWebLvcGeneralSettingsWidget::theDefaultLocalNonProxyDir = "local";
      bool DtWebLvcGeneralSettingsWidget::theDefaultEnableStatusPage = true;
      QString DtWebLvcGeneralSettingsWidget::theDefaultSslCertificate = "";


      DtWebLvcGeneralSettingsWidget::DtWebLvcGeneralSettingsWidget( QWidget* parent /* = 0 */ )
         : DtGeneralSettingsWidget( parent )
         , myObjCollectionEditor(new MAKCommonWidgets::DtCollectionEditor(this))
      {
      }

      DtWebLvcGeneralSettingsWidget::~DtWebLvcGeneralSettingsWidget()
      {
      }

      DtWebLvcBrokerInitializer* DtWebLvcGeneralSettingsWidget::webLvcInitializer()
      {
         return (DtWebLvcBrokerInitializer*) myInitializer;
      }

      void DtWebLvcGeneralSettingsWidget::initializeQtStrings()
      {
         // Common Broker Settings.
         DtGeneralSettingsWidget::initializeQtStrings();

         // Connection Settings.
         connectionSettingsProperty = tr("WebLVC Settings");
         webServerPortProperty = tr("Web Server Port");
         useTcpPortProperty = tr("Turn on TCP Server");
         tcpServerPortProperty = tr("TCP Server Port");
         proxyDestProperty = tr("Host to proxy for");
         proxyPortProperty = tr("Port for proxy");
         omtFilesProperty = tr("OMT Files");
         enableHttpServerProperty = tr("Enable web server");
         localHttpDirectoryProperty = tr("Local web server directory");
         enableHttpProxyProperty = tr("Enable proxy");
         localNonProxyDirProperty = tr("Non-proxied directory");
         enableStatusPageProperty = tr("Enable status page");
         sslCertificateProperty = tr("SSL Certificate for HTTPS");
      }

      void DtWebLvcGeneralSettingsWidget::initializeProperties()
      {
         // Initialize Common Settings.
         DtGeneralSettingsWidget::initializeProperties();

         MAKCommonWidgets::DtPropertyTypeFactory* types = MAKCommonWidgets::DtPropertyTypeFactory::create();
         MAKCommonWidgets::DtPropertyListViewItem* propItem;

         QTreeWidgetItem* connectionSettings = new QTreeWidgetItem(this, QStringList(connectionSettingsProperty));

         // Connection Settings //

         propItem = addProperty(MAKCommonWidgets::DtProperty((enableHttpServerProperty), types->boolType(), theDefaultEnableHttpServer), connectionSettings);
         propItem->setToolTip(0, tr("Enable HTTP/Web Server"));

         propItem = addProperty(MAKCommonWidgets::DtProperty((webServerPortProperty), types->stringType(), theDefaultWebServerPort), connectionSettings);
         propItem->setToolTip(0, tr("HTTP/Web Server Port"));

         propItem = addProperty(MAKCommonWidgets::DtProperty((sslCertificateProperty), types->stringType(), theDefaultSslCertificate), connectionSettings);
         propItem->setToolTip(0, tr("the path to the file or directory containing the CA/root certificates. If not found, the webserver will support HTTP instead."));

         propItem = addProperty(MAKCommonWidgets::DtProperty((localHttpDirectoryProperty), types->stringType(), theDefaultLocalHttpAddress), connectionSettings);
         propItem->setToolTip(0, tr("Directory in your local hard drive where the html files to be hosted by the Web Server are located."));

         propItem = addProperty(MAKCommonWidgets::DtProperty((useTcpPortProperty), types->boolType(), theDefaultUseTcpPort), connectionSettings);
         propItem->setToolTip(0,tr("Enable Alternate TCP Server"));

         propItem = addProperty(MAKCommonWidgets::DtProperty((tcpServerPortProperty), types->intType(), theDefaultTcpServerPort), connectionSettings);
         propItem->setToolTip(0,tr("Alternate TCP Server Port"));

         propItem = addProperty(MAKCommonWidgets::DtProperty((enableHttpProxyProperty), types->boolType(), theDefaultEnableHttpProxy), connectionSettings);
         propItem->setToolTip(0, tr("Enable web proxy. This sends HTTP data to be forwarded to a different location thus allowing for multiple web servers to play together."));

         propItem = addProperty(MAKCommonWidgets::DtProperty((localNonProxyDirProperty), types->stringType(), theDefaultLocalNonProxyDir), connectionSettings);
         propItem->setToolTip(0, tr("If the Web Server and the Web Proxy are both on, this html directory in the client-side signals for a page to be served without getting proxied."));

         propItem = addProperty(MAKCommonWidgets::DtProperty((proxyDestProperty), types->stringType(), theDefaultProxyDest), connectionSettings);
         propItem->setToolTip(0,tr("Destination host for proxied pages"));

         propItem = addProperty(MAKCommonWidgets::DtProperty((proxyPortProperty), types->intType(), theDefaultProxyPort), connectionSettings);
         propItem->setToolTip(0, tr("Destination port for proxied pages"));

         propItem = addProperty(MAKCommonWidgets::DtProperty((enableStatusPageProperty), types->boolType(), theDefaultEnableStatusPage), connectionSettings);
         propItem->setToolTip(0, tr("Enable the status page that displays internal information on current connections. Accessible using http://YOURSERVER/status."));

         propItem = addProperty(MAKCommonWidgets::DtProperty((omtFilesProperty), types->stringType(), theDefaultOmtFiles), connectionSettings);
         propItem->setToolTip(0,tr("HLA OMT or XML FED files for automatic WebLVC generation."));

         delete types;
      }

      void DtWebLvcGeneralSettingsWidget::updateConfiguration()
      {
         // Common Broker Settings.
         DtGeneralSettingsWidget::updateConfiguration();

         // Connection Settings.
         webLvcInitializer()->setWebSocketPort( webSocketPort().toStdString().c_str() );
         webLvcInitializer()->setTcpSocketPort( tcpSocketPort() );
         webLvcInitializer()->setUseTcpPort( useTcpPort() );
         webLvcInitializer()->setProxyHost( proxyDest().toLatin1().data() );
         webLvcInitializer()->setProxyPort( proxyPort() );
         webLvcInitializer()->setOmtFiles( omtFiles().toLatin1().data() );
         webLvcInitializer()->setEnableHttpServer(enableHttpServer());
         webLvcInitializer()->setLocalHttpDirectory(localHttpDirectory().toLatin1().data());
         webLvcInitializer()->setEnableHttpProxy(enableHttpProxy());
         webLvcInitializer()->setLocalNonProxyDir(localNonProxyDir().toLatin1().data());
         webLvcInitializer()->setEnableStatusPage(enableStatusPage());
         webLvcInitializer()->setSslCertificate(sslCertificate().toLatin1().data());
      }

      void DtWebLvcGeneralSettingsWidget::revertConfiguration()
      {
         // Common Broker Settings.
         DtGeneralSettingsWidget::revertConfiguration();

         // Connection Settings.
         DtString s;
         for ( int i = 0; i != webLvcInitializer()->webSocketPort().size(); ++i )
         {
            if ( i != 0 )
            {
               s += ";";
            }
            s += DtString( webLvcInitializer()->webSocketPort()[i] );
         }
         setWebSocketPort( s.c_str() );
         setUseTcpPort(webLvcInitializer()->useTcpPort() );
         setTcpSocketPort(webLvcInitializer()->tcpSocketPort() );
         setProxyDest(webLvcInitializer()->proxyHost().c_str() );
         setProxyPort(webLvcInitializer()->proxyPort() );
         setOmtFiles(webLvcInitializer()->omtFiles().c_str());
         setEnableHttpServer(webLvcInitializer()->enableHttpServer());
         setLocalHttpDirectory(QString(webLvcInitializer()->localHttpDirectory().c_str()));
         setEnableHttpProxy(webLvcInitializer()->enableHttpProxy());
         setLocalNonProxyDir(webLvcInitializer()->localNonProxyDir().c_str());
         setEnableStatusPage(webLvcInitializer()->enableStatusPage());
         setSslCertificate(webLvcInitializer()->sslCertificate().c_str());
      }


      //
      // Connection Settings Setters/Getters
      //

      void DtWebLvcGeneralSettingsWidget::setWebSocketPort( QString nl )
      {
         setProperty( connectionSettingsProperty, webServerPortProperty, nl );
      }

      QString DtWebLvcGeneralSettingsWidget::webSocketPort() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property( connectionSettingsProperty, webServerPortProperty );
         if ( aProperty->value().type() == QVariant::String )
         {
            return aProperty->value().toString();
         }
         return 0;
      }

      void DtWebLvcGeneralSettingsWidget::setUseTcpPort( bool nl )
      {
         setProperty( connectionSettingsProperty, useTcpPortProperty, nl );
      }

      bool DtWebLvcGeneralSettingsWidget::useTcpPort() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property( connectionSettingsProperty, useTcpPortProperty );
         if ( aProperty && (aProperty->value().type() == QVariant::Bool ))
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtWebLvcGeneralSettingsWidget::setTcpSocketPort( int nl )
      {
         setProperty( connectionSettingsProperty, tcpServerPortProperty, nl );
      }

      int DtWebLvcGeneralSettingsWidget::tcpSocketPort() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property( connectionSettingsProperty, tcpServerPortProperty );
         if ( aProperty->value().type() == QVariant::Int )
         {
            return aProperty->value().toInt();
         }
         return 0;
      }
      void DtWebLvcGeneralSettingsWidget::setOmtFiles( QString nl )
      {
         setProperty( connectionSettingsProperty, omtFilesProperty, nl );
      }

      QString DtWebLvcGeneralSettingsWidget::omtFiles() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property( connectionSettingsProperty, omtFilesProperty );
         if ( aProperty->value().type() == QVariant::String )
         {
            return aProperty->value().toString();
         }
         return 0;
      }

      void DtWebLvcGeneralSettingsWidget::setProxyPort( int nl )
      {
         setProperty( connectionSettingsProperty, proxyPortProperty, nl );
      }

      int DtWebLvcGeneralSettingsWidget::proxyPort() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property( connectionSettingsProperty, proxyPortProperty );
         if ( aProperty->value().type() == QVariant::Int )
         {
            return aProperty->value().toInt();
         }
         return 0;
      }

      void DtWebLvcGeneralSettingsWidget::setProxyDest( QString lfn )
      {
         setProperty( connectionSettingsProperty, proxyDestProperty, lfn );
      }

      QString DtWebLvcGeneralSettingsWidget::proxyDest() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property( connectionSettingsProperty, proxyDestProperty );
         if ( aProperty->value().type() == QVariant::String )
         {
            return aProperty->value().toString();
         }
         return 0;
      }

      void DtWebLvcGeneralSettingsWidget::setEnableHttpServer(bool nl)
      {
         setProperty(connectionSettingsProperty, enableHttpServerProperty, nl);
      }

      bool DtWebLvcGeneralSettingsWidget::enableHttpServer() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property(connectionSettingsProperty, enableHttpServerProperty);
         if (aProperty && (aProperty->value().type() == QVariant::Bool))
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtWebLvcGeneralSettingsWidget::setLocalHttpDirectory(QString nl)
      {
         setProperty(connectionSettingsProperty, localHttpDirectoryProperty, nl);
      }

      QString DtWebLvcGeneralSettingsWidget::localHttpDirectory() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property(connectionSettingsProperty, localHttpDirectoryProperty);
         if (aProperty->value().type() == QVariant::String)
         {
            return aProperty->value().toString();
         }
         return 0;
      }

      void DtWebLvcGeneralSettingsWidget::setEnableHttpProxy(bool nl)
      {
         setProperty(connectionSettingsProperty, enableHttpProxyProperty, nl);
      }

      bool DtWebLvcGeneralSettingsWidget::enableHttpProxy() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property(connectionSettingsProperty, enableHttpProxyProperty);
         if (aProperty && (aProperty->value().type() == QVariant::Bool))
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtWebLvcGeneralSettingsWidget::setLocalNonProxyDir(QString nl)
      {
         setProperty(connectionSettingsProperty, localNonProxyDirProperty, nl);
      }

      QString DtWebLvcGeneralSettingsWidget::localNonProxyDir() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property(connectionSettingsProperty, localNonProxyDirProperty);
         if (aProperty->value().type() == QVariant::String)
         {
            return aProperty->value().toString();
         }
         return 0;
      }

      void DtWebLvcGeneralSettingsWidget::setEnableStatusPage(bool nl)
      {
         setProperty(connectionSettingsProperty, enableStatusPageProperty, nl);
      }

      bool DtWebLvcGeneralSettingsWidget::enableStatusPage() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property(connectionSettingsProperty, enableStatusPageProperty);
         if (aProperty && (aProperty->value().type() == QVariant::Bool))
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtWebLvcGeneralSettingsWidget::setSslCertificate(QString nl)
      {
         setProperty(connectionSettingsProperty, sslCertificateProperty, nl);
      }

      QString DtWebLvcGeneralSettingsWidget::sslCertificate() const
      {
         const MAKCommonWidgets::DtProperty* aProperty =
            property(connectionSettingsProperty, sslCertificateProperty);
         if (aProperty->value().type() == QVariant::String)
         {
            return aProperty->value().toString();
         }
         return 0;
      }
   }
}
