/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file vrfBackEndTranslator.cxx
//! \brief Contains the DtVrfBackEndTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/vrfBackEndTranslator.h>
#include <vlutil/vlInetAddr.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtVrfBackEndTranslator::DtVrfBackEndTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalVrfBackEndObjectKind )
      {
      }

      DtVrfBackEndTranslator::~DtVrfBackEndTranslator()
      {
      }

      void DtVrfBackEndTranslator::translate( const Json::Value& source,
         DtPortalVrfBackEndObject* pEnt )
      {
         // This shouldn't happen at the moment as there is no
         // WebLVC based VR-Forces.
      }

      void DtVrfBackEndTranslator::translate( const DtPortalVrfBackEndObject& source,
         Json::Value* destination )
      {
         (*destination)["ObjectType"] = "MAK:VRFBackEnd";

         (*destination)["ControlState"] = (unsigned)source.controlState();
         (*destination)["ExerciseStartTime"] = source.exerciseStartTime();
         (*destination)["GuiTerrainName"] = std::string(source.guiTerrainName().string());
         (*destination)["InetAddr"] = std::string(DtInetAddr( source.inetAddr() ).toDtString().string());
         (*destination)["IsCurrentParameterDb"] = source.isCurrentParameterDb();
         (*destination)["IsLoaded"] = source.isLoaded();
         (*destination)["IsResourceMonitorEnabled"] = source.isResourceMonitorEnabled();
         (*destination)["IsTimeManaged"] = source.isTimeManaged();
         (*destination)["LoadedNewScenario"] = source.loadedNewScenario();
         (*destination)["Port"] = (unsigned)source.port();
         (*destination)["ScenarioName"] = std::string(source.scenarioName().string());
         (*destination)["ScenarioFilename"] = std::string(source.scenarioFilename().string());
         (*destination)["SimEngineId"] = (unsigned)source.simEngineId();
         (*destination)["SimStartTime"] = source.simStartTime();
         (*destination)["SimTime"] = source.simTime();
         (*destination)["TimeMultiplier"] = source.timeMultiplier();
      }

   }
}
