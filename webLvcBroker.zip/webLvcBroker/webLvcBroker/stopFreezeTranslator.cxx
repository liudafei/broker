/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file stopFreezeTranslator.h
//! \brief Contains the DtStopFreezeTranslator class declaration.
//! \ingroup webLvcBroker

#include <webLvcBroker/stopFreezeTranslator.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtStopFreezeTranslator::DtStopFreezeTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtStopInteractionKind )
      {
      }

       DtStopFreezeTranslator::~DtStopFreezeTranslator()
      {
      }

      void DtStopFreezeTranslator::translate( const Json::Value& source,
         DtPortalStopInteraction* destination )
      {
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("OriginatingEntity",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setOriginatingEntity( eid.string() );

         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         v = source.get("ReceivingEntity",a);
         eid.setSite( v[0u].asInt() );
         eid.setHost( v[1].asInt() );
         eid.setEntityNum( v[2].asInt() );
         destination->setReceivingEntity( eid.string() );

         destination->setRequestIdentifier(source.get("RequestIdentifier",0).asUInt());
         destination->setRealWorldTime( source.get("RealWorldTime",0.0).asDouble());
         destination->setReason((const DtU32)source.get("Reason",0).asUInt());
         destination->setReflectValues( source.get("ReflectValues",false).asBool() );
         destination->setRunInternalSimulationClock( source.get("RunInternalSimulationClock",false).asBool() );
         destination->setUpdateAttributes( source.get("UpdateAttributes",false).asBool() );
      }

      void DtStopFreezeTranslator::translate( const DtPortalStopInteraction& source,
         Json::Value* destination )
      {
         // TODO
      }

   }
}
