/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file httpRequestHandlerFactory.cxx
//! \brief Contains the DtHttpRequestHandlerFactory class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/httpRequestHandlerFactory.h>
#include <webLvcBroker/webSocketRequestHandler.h>
#include <webLvcBroker/httpProxyRequestHandler.h>
#include <webLvcBroker/statusHandler.h>
#include <webLvcBroker/localHandler.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <Poco/Net/HTTPServerRequest.h>

using Poco::Net::HTTPRequestHandlerFactory;
using Poco::Net::HTTPRequestHandler;
using Poco::Net::HTTPServerRequest;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtHttpRequestHandlerFactory::DtHttpRequestHandlerFactory()
         : HTTPRequestHandlerFactory()
      {
      }

      DtHttpRequestHandlerFactory::~DtHttpRequestHandlerFactory()
      {
      }

      HTTPRequestHandler* DtHttpRequestHandlerFactory::createRequestHandler(
         const HTTPServerRequest& request )
      {
         std::string ws( "/ws" );
         if ( request.getURI().compare( 0, ws.length(), ws ) == 0 )
         {
            return new DtWebSocketRequestHandler();
         }
         else if (DtWebLvcBrokerInitializer::enableHttpServer())
         {
            if (DtWebLvcBrokerInitializer::enableStatusPage() && request.getURI().compare(0, 7, "/status") == 0)
            {
               return new DtStatusRequestHandler(request.getURI());
            }
            else if (!DtWebLvcBrokerInitializer::enableHttpProxy() ||
               DtWebLvcBrokerInitializer::localNonProxyDir().size() == 0 ||
               (request.getURI().compare(0, 1 + DtWebLvcBrokerInitializer::localNonProxyDir().size(), 
                  "/" + DtWebLvcBrokerInitializer::localNonProxyDir()) == 0))
            {
               return new DtLocalRequestHandler(request.getURI());
            }
         }
         if (DtWebLvcBrokerInitializer::enableHttpProxy())
         {
            return new DtHttpProxyRequestHandler();
         }

         return 0; //FAIL
      }

   }
}
