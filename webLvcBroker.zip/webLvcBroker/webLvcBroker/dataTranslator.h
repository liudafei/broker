/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file dataTranslator.h
//! \brief Contains the DtDataTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <webLvcBroker/lvcInteractionTranslator.h>
#include <portal/pDataInter.h>
#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtDataTranslator are responsible for translating DtPortalDataInteraction to WebLVC:Data.
      class DT_DLL_WEBLVCBROKER DtDataTranslator : public DtLvcInteractionTranslator<DtPortalDataInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:Data" );

         //! \brief CTOR.
         DtDataTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtDataTranslator();

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, DtPortalDataInteraction* destination );
         virtual void translate( const DtPortalDataInteraction& source, Json::Value* destination );

      };

   }
}
