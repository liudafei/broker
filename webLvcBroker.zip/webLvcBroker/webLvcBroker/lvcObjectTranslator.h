/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file lvcObjectTranslator.h
//! \brief Contains the DtLvcObjectTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/baseWebLvcObjectTranslator.h>
#include <webLvcBroker/lockingReflectedObjMgr.h>
#include <webLvcBroker/webLvcBroker.h>
#include <Poco/RWLock.h>
#include <string>
#include <list>

#define LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST \
   template \
   < class T_PortalObject \
   , class T_PortalReflectedObject >

#define LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION \
   T_PortalObject, T_PortalReflectedObject

namespace MAKVrExchange
{

   class DtPortalObject;
   class DtRequestTranslationDiagnosticMessage;

   namespace DtWebLvcBroker
   {

      class DtClient;

      //! \brief A translator is responsible for converting a specific message
      //! type between two protocols.
      //
      //! This analogy works best with DIS->HLA were
      //! a translator is used to convert DIS objects. This isn't always the
      //! best way to describe translators however, sometimes two messages on
      //! one side need to be bundled into one message on another, a translator
      //! would be used for that too.
      LVC_OBJECT_TRANSLATOR_TEMPLATE_LIST
      class DtLvcObjectTranslator
         : public DtBaseObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION,DtBaseWebLvcObjectTranslator>
      {
      public:

         typedef DtLvcObjectTranslator<LVC_OBJECT_TRANSLATOR_TEMPLATE_FUNCTION> ParentClass;

      public:

         //! \brief CTOR.
         DtLvcObjectTranslator( DtBroker* broker, const DtString& name, DtPortalMessageKind kind );

         //! \brief Virtual DTOR.
         virtual ~DtLvcObjectTranslator();

         virtual void tick();

         //! @name Portal Callback Initialization
         //! Overridden to instantiate and manage locking portal
         //! reflected manager instead of default type.
         //! @{

         virtual void initializePortalCallbacks();
         virtual void removePortalCallbacks();

         //! @}

         virtual DtWebLvcBroker* webLvcBroker();
         virtual const DtWebLvcBroker* webLvcBroker() const;

         virtual void discoverPortalObject( const T_PortalReflectedObject &obj );
         virtual void receivePortalUpdate( const T_PortalReflectedObject &obj );
         virtual void removePortalObject( const T_PortalReflectedObject &obj );

         virtual void removeClientObject( const std::string& refObj );

         //! @name Broker Object Management Methods
         //! @{

         //! Creates a broker object for the given reflected object.
         virtual DtBrokerObject* createBrokerObject( const T_PortalReflectedObject* refObj );

         //! Find the broker object for the given reflected object.
         //! Returns NULL if the requested broker object doesn't exist.
         virtual DtBrokerObject* findBrokerObject( const std::string& refObj );
         virtual DtBrokerObject* findBrokerObject( const T_PortalReflectedObject* refObj );

         //! Find the broker object for the object with the given name.
         //! Returns NULL if the requested broker object doesn't exist.
         virtual DtBrokerObject* findBrokerObject( const DtString& objectName );

         //! Find the broker object for the given reflected object.
         //! Returns NULL if the requested broker object doesn't exist.
         //! Unregisters the broker object - caller is responsible for deletion.
         virtual DtBrokerObject* releaseBrokerObject( const std::string& refObj );
         virtual DtBrokerObject* releaseBrokerObject( const T_PortalReflectedObject* refObj );

         //! @}

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, T_PortalObject* destination ) = 0;
         virtual void translate( const T_PortalObject& source, Json::Value* destination ) = 0;

         virtual Poco::RWLock* lock();
         virtual DtString status();

         // for each id in the update set create a msg and pass it to the broker
         virtual int processUpdateSet( void* client );
         virtual void createUpdateSet( void* client );

         virtual void processClientRemoval( DtClient* client );

         // create and send a remove obj message
         virtual void sendRemoveObjMessage( const char* identifier, DtClient* client );

         //! Create a JSON message for each object currently in the reflected obj mgr.
         //! The state messages will be sent to the given client, so messages
         //! should not be constructed for any objects from that client.
         virtual void createFullStateMsgs( std::list<std::string>& msgs, DtClient* client );

         virtual void processMsg( Json::Value* msg, DtClient* client );

         virtual void printIncomingOutgoingStateReps(
            const DtPortalMessage& incoming,
            const Json::Value& outgoing,
            const DtString& objectName );

         virtual void printIncomingOutgoingStateReps(
            const Json::Value& incoming,
            const DtPortalMessage& outgoing,
            const DtString& objectName );

         //! \brief Build and send debugging message for GUI debugging.
         //! Protocol independent version - looks up object with given name
         //! and calls the appropriate version of ::performPortalDebugging.
         virtual void performPortalDebugging( const DtString& objectName );

         virtual void performPortalDebugging( const DtPortalObject& incoming,
            const Json::Value& outgoing );

         virtual void performPortalDebugging( const Json::Value& incoming,
            const DtPortalObject& outgoing );

         //! Returns the current number of objects.
         virtual unsigned int numObjects() const;

      protected:

         static void requestTransDiagCb( const DtRequestTranslationDiagnosticMessage& msg, void* usr );

         virtual void requestTransDiagCb( const DtRequestTranslationDiagnosticMessage& msg );

      private:

         //! Copy CTOR not implemented - do not copy
         DtLvcObjectTranslator( const DtLvcObjectTranslator& other );

         //! Assignment operator not implemented - do not copy
         DtLvcObjectTranslator& operator = ( const DtLvcObjectTranslator& other );

      protected:

         DtLockingReflectedObjectManager< DtPortalReflectedObjectTemplate<T_PortalObject> >* myLockingPortalReflectedManager;

         typedef std::set<DtString> TransDebugObjectNamesSet;
         TransDebugObjectNamesSet myTransDebugNames;

         typedef std::map<const T_PortalReflectedObject*,DtBrokerObject*> PortalToLvcReflectedMap;
         typedef std::map<const std::string,DtBrokerObject*> LvcToPortalReflectedMap;

         LvcToPortalReflectedMap myPortalPublisherMap;
         PortalToLvcReflectedMap myLvcPublisherMap;

         Poco::RWLock myLock;

      };

   }
}

#define _lvcObjectTranslator_INL_
#include <webLvcBroker/lvcObjectTranslator.inl>
#undef _lvcObjectTranslator_INL_
