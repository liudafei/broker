/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file tcpRequestHandlerFactory.h
//! \brief Contains the DtTcpRequestHandlerFactory class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <Poco/Net/TCPServerConnectionFactory.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtRequestHandlerFactory extends the base
      //! factory for handling HTTP requests to handle requests for web sockets
      //! using the WebSocketRequestHandler class.
      class DT_DLL_WEBLVCBROKER DtTcpRequestHandlerFactory
         : public Poco::Net::TCPServerConnectionFactory
      {
      public:

         //! \brief CTOR.
         DtTcpRequestHandlerFactory();

         //! \brief Virtual DTOR.
         virtual ~DtTcpRequestHandlerFactory();

      public:

         //! Creates an instance of a subclass of TCPServerConnection,
         //! using the given StreamSocket.
         virtual Poco::Net::TCPServerConnection* createConnection(
            const Poco::Net::StreamSocket& socket );

      };

   }
}
