/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webSocketClient.h
//! \brief Contains the DtWebSocketClient class definition.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/client.h>
#include <Poco/Net/WebSocket.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtWebSocketClient is responsible for maintaining
      //! the connection an active web client.
      //! Each web client has its own message thread in the server
      //! that is associated to instances of this class.
      class DT_DLL_WEBLVCBROKER DtWebSocketClient : public DtClient
      {
      public:

         //! \brief CTOR.
         DtWebSocketClient( Poco::Net::WebSocket* ws );

         //! \brief CTOR.
         DtWebSocketClient( Poco::Net::HTTPServerRequest& request,
            Poco::Net::HTTPServerResponse& response );

         //! \brief Virtual DTOR.
         virtual ~DtWebSocketClient();

         virtual int sendFrame( const void* buffer, int length );
         virtual int receiveFrame( void* buffer, int length, int& flags );

      private:

         //! Copy Constructor not implemented - Copy Not Allowed.
         DtWebSocketClient( const DtWebSocketClient& other );

         //! Assignment Operator Not implemented - Assignment Not Allowed.
         DtWebSocketClient& operator = ( const DtWebSocketClient& other );

      protected:

         Poco::Net::WebSocket* myWebSocket;

      };

   }
}
