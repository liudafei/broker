/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file omtInteractionTranslator.h
//! \brief Contains the DtOmtInteractionTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#if ! _WIN64
#  ifndef _WIN32_WINNT
#     define _WIN32_WINNT 0x400
#  endif
#endif

#include <webLvcBroker/dllExport.h>
#include <webLvcBroker/lvcInteractionTranslator.h>
#include <portal/pGenericInter.h>
#include <omtReader/datatypeManager.h>
#include <omtReader/omtTree.h>
#include <json/json.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtOmtInteractionTranslator are responsible for translating
      //! DtPortalGenericInteraction to WebLVC by way of the VR-Link OMT Translator
      class DT_DLL_WEBLVCBROKER DtOmtInteractionTranslator
         : public DtLvcInteractionTranslator<DtPortalGenericInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "OMT:Interactions" );

         //! \brief CTOR.
         DtOmtInteractionTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtOmtInteractionTranslator();

         virtual bool readObjectModel( const std::vector<DtString>& filenames );

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, DtPortalGenericInteraction* destination );
         virtual void translate( const DtPortalGenericInteraction& source, Json::Value* destination );

      protected:

         virtual void populateJson( DtStringTree* stringTree, Json::Value* destination );
         virtual void populateFromJson( const DtString& datatypeName, const Json::Value& jsonTree, std::vector<char>& destination );

      protected:

         DtOMTTree* myObjectModelTree;
         DtDatatypeManager* myDatatypeManager;

      };

   }
}
