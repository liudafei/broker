/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file reliableConnectionServer.cxx
//! \brief Contains the DtReliableConnectionServer class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/reliableConnectionServer.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtReliableConnectionServer::DtReliableConnectionServer()
      {
      }

      DtReliableConnectionServer::~DtReliableConnectionServer()
      {
      }

   }
}
