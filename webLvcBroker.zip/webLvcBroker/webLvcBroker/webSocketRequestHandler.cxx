/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webSocketRequestHandler.cxx
//! \brief Contains the DtWebSocketRequestHandler class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/webSocketRequestHandler.h>
#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/webSocketClient.h>

#include <Poco/Net/HTTPServerResponse.h>
#include <Poco/Net/NetException.h>
#include <Poco/RWLock.h>

#include <vlutil/vlPrint.h>

using Poco::Net::HTTPRequestHandler;
using Poco::Net::HTTPServerResponse;
using Poco::Net::WebSocketException;
using Poco::Net::HTTPServerRequest;
using Poco::Net::HTTPResponse;
using Poco::Net::WebSocket;
using Poco::Timestamp;
using Poco::RWLock;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtWebSocketRequestHandler::DtWebSocketRequestHandler()
         : HTTPRequestHandler()
      {
      }

      DtWebSocketRequestHandler::~DtWebSocketRequestHandler()
      {
      }

      void DtWebSocketRequestHandler::handleRequest( HTTPServerRequest& request,
         HTTPServerResponse& response )
      {
         try
         {
            WebSocket* ws = new WebSocket( request, response );
            DtWebSocketClient * wc = new DtWebSocketClient( ws );

            DtWebLvcBroker::theRWLock.writeLock();
            bool added = DtWebLvcBroker::theWebLvcBroker->addClient( wc );
            DtWebLvcBroker::theRWLock.unlock();

            if ( added )
            {
               wc->start();
            }

            DtInfo << "WebSocket connection established." << std::endl;
         }
         catch ( WebSocketException& exc )
         {
            switch ( exc.code() )
            {
            case WebSocket::WS_ERR_HANDSHAKE_UNSUPPORTED_VERSION:
               response.set( "Sec-WebSocket-Version", WebSocket::WEBSOCKET_VERSION );
               // fallthrough
            case WebSocket::WS_ERR_NO_HANDSHAKE:
            case WebSocket::WS_ERR_HANDSHAKE_NO_VERSION:
            case WebSocket::WS_ERR_HANDSHAKE_NO_KEY:
               response.setStatusAndReason( HTTPResponse::HTTP_BAD_REQUEST );
               //response.setContentLength( 0 );
               response.send();
               break;
            }
         }
         catch ( ... )
         {
            DtWarn( "unhandled connection exception\n" );
         }
      }

   }
}
