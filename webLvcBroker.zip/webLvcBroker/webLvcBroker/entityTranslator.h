/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file entityTranslator.h
//! \brief Contains the DtEntityTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#if ! _WIN64
#  ifndef _WIN32_WINNT
#     define _WIN32_WINNT 0x400
#  endif
#endif

#include <portal/pEntity.h>
#include <broker/brokerObject.h>
#include <webLvcBroker/lvcObjectTranslator.h>
#include <omtReader/datatypeManager.h>
#include <omtReader/omtTree.h>

#define ENTITY_TEMPLATE_ARGS \
   DtPortalEntity, DtPortalReflectedEntity

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtEntityTranslator are responsible for translating DtPortalEntity to WebLVC:PhysicalEntity.
      class DT_DLL_WEBLVCBROKER DtEntityTranslator
         : public DtLvcObjectTranslator<ENTITY_TEMPLATE_ARGS>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:PhysicalEntity" );

         //! \brief CTOR.
         DtEntityTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtEntityTranslator();

         virtual void translate( const Json::Value& source, DtPortalEntity* destination );
         virtual void translate( const DtPortalEntity& source, Json::Value* destination );

         //! Add additional data for the object specified by name.
         virtual void addAdditionalDataValue( const DtString& name, const std::string& tag, const Json::Value& data );

         //! Clear out leftover name mappings and additional data when object goes away.
         virtual void removePortalObject( const DtPortalReflectedEntity& obj );

      protected:

         std::map<std::string,Json::Value> myAdditionalDataMap;
         std::map<std::string,std::string> myNameLookup;

      };

   }
}
