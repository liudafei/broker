/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file translatorFactory.inl
//! \brief Contains the DtTranslatorFactory inline class definition.
//! \ingroup webLvcBroker

#ifndef _translatorFactory_INL_
#error "Inline definitions file must be included from declaring header."
#endif

namespace MAKVrExchange
{

   namespace WebLVCBroker
   {

      template <typename BrokerType,typename ProducedType>
      DtTranslatorFactory<BrokerType,ProducedType>::DtTranslatorFactory()
         : myNamedCreatorMap()
         , myGenericTranslatorCreator( 0 )
      {
      }

      template <typename BrokerType,typename ProducedType>
      DtTranslatorFactory<BrokerType,ProducedType>::~DtTranslatorFactory()
      {
         myNamedCreatorMap.clear();
      }

      template <typename BrokerType,typename ProducedType>
      ProducedType* DtTranslatorFactory<BrokerType,ProducedType>::createGenericInstance(
         const DtString& className, BrokerType* broker )
      {
         if ( myGenericTranslatorCreator )
         {
            return (*myGenericTranslatorCreator)( broker, className );
         }
         DtWarn << "Broker: Could not create Generic Instance for translator " << className << std::endl;
         return 0;
      }

      template <typename BrokerType,typename ProducedType>
      ProducedType* DtTranslatorFactory<BrokerType,ProducedType>::createInstance(
         const DtString& transName, BrokerType* broker ) const
      {
         const typename StringOtcMap::const_iterator pos = myNamedCreatorMap.find( transName );
         if ( pos != myNamedCreatorMap.end() )
         {
            return (*pos->second)( broker );
         }
         DtWarn << "Broker: Could not create Instance for translator " << transName << ". No creator\n";
         return 0;
      }

      template <typename BrokerType,typename ProducedType>
      template <typename T>
      ProducedType* DtTranslatorFactory<BrokerType,ProducedType>::instanceFactory( BrokerType* broker )
      {
         return new T( broker );
      }

      template <typename BrokerType,typename ProducedType>
      template <typename T>
      ProducedType* DtTranslatorFactory<BrokerType,ProducedType>::genericInstanceFactory(
         BrokerType* broker, const DtString& className )
      {
         return new T( broker, className );
      }

      template <typename BrokerType,typename ProducedType>
      void DtTranslatorFactory<BrokerType,ProducedType>::removeCreator( const DtString& translatorName )
      {
         const typename StringOtcMap::iterator pos = myNamedCreatorMap.find( translatorName );
         if ( pos != myNamedCreatorMap.end() )
         {
            myNamedCreatorMap.erase( pos );
         }
      }

      template <typename BrokerType,typename ProducedType>
      template <typename T>
      void DtTranslatorFactory<BrokerType,ProducedType>::removeCreator()
      {
         removeCreator( T::translatorName() );
      }

      template <typename BrokerType,typename ProducedType>
      void DtTranslatorFactory<BrokerType,ProducedType>::removeAllCreators()
      {
         myNamedCreatorMap.clear();
      }

      template <typename BrokerType,typename ProducedType>
      template <typename T>
      void DtTranslatorFactory<BrokerType,ProducedType>::addGenericCreator()
      {
         myGenericTranslatorCreator = genericInstanceFactory<T>;
      }

      template <typename BrokerType,typename ProducedType>
      template <typename T>
      void DtTranslatorFactory<BrokerType,ProducedType>::addCreator()
      {
         DtString str = T::translatorName();
         myNamedCreatorMap[str] = instanceFactory<T>;
      }

      template <typename BrokerType,typename ProducedType>
      template <typename T>
      void DtTranslatorFactory<BrokerType,ProducedType>::addCreator( DtString str )
      {
         myNamedCreatorMap[str] = instanceFactory<T>;
      }

      template <typename BrokerType,typename ProducedType>
      template <typename T>
      void DtTranslatorFactory<BrokerType,ProducedType>::addCreator(
         const DtString& translatorName, DtObjectTranslatorCreatorFunction fn )
      {
         myNamedCreatorMap[translatorName] = fn;
      }

      template <typename BrokerType,typename ProducedType>
      std::set<DtString> DtTranslatorFactory<BrokerType,ProducedType>::creatorNames() const
      {
         typename StringOtcMap::const_iterator itr = myNamedCreatorMap.begin();
         typename StringOtcMap::const_iterator end = myNamedCreatorMap.end();
         std::set<DtString> addedCreators;
         for ( ; itr != end; ++itr )
         {
            addedCreators.insert( itr->first );
         }
         return addedCreators;
      }

   }
}
