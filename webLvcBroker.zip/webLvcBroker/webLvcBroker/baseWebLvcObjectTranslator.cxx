/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file baseWebLvcObjectTranslator.cxx
//! \brief Contains the DtBaseWebLvcObjectTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/baseWebLvcObjectTranslator.h>
#include <portal/pObjectPublisher.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtBaseWebLvcObjectTranslator::DtBaseWebLvcObjectTranslator( DtBroker* broker,
         const DtString& name, DtPortalMessageKind kind )
         : DtObjectTranslator( broker, name, kind )
         , myLvcUpdateSet()
      {
      }

      DtBaseWebLvcObjectTranslator::~DtBaseWebLvcObjectTranslator( )
      {
      }

      int DtBaseWebLvcObjectTranslator::processUpdateSet( void* id )
      {
         return 0;
      }

      void DtBaseWebLvcObjectTranslator::createUpdateSet( void* id )
      {
         myLvcUpdateSet[id] = StringSet();
      }

      void DtBaseWebLvcObjectTranslator::processClientRemoval( DtClient* id)
      {
         myLvcUpdateSet.erase(id);
      }

      void DtBaseWebLvcObjectTranslator::processMsg( Json::Value* msg, DtClient* client )
      {
      }

      Poco::RWLock* DtBaseWebLvcObjectTranslator::lock()
      {
         return NULL;
      }

      void DtBaseWebLvcObjectTranslator::removeClientObject( const std::string& refObj )
      {
      }

      DtString DtBaseWebLvcObjectTranslator::status()
      {
         return DtString("default status\n");
      }

      DtWebLvcBroker* DtBaseWebLvcObjectTranslator::webLvcBroker()
      {
         return (DtWebLvcBroker*) myBroker;
      }

   }
}
