/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file vrfMsgTranslator.h
//! \brief Contains the DtVrfMsgTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/baseWebLvcInteractionTranslator.h>
#include <portal/pVrfCurrentResourceReq.h>
#include <portal/pVrfResourceMonResponse.h>
#include <portal/pVrfEntityResourceResponse.h>
#include <portal/pVrfScriptedTask.h>
#include <portal/pVrfTask.h>
#include <portal/pVrfControl.h>
#include <portal/pVrfSetData.h>
#include <portal/pVrfCurrentTasks.h>
#include <portal/pVrfChangeTimeOfDayCommand.h>
#include <portal/pVrfChangeGlobalWeatherCommand.h>
#include <portal/pVrfCreateObj.h>
#include <portal/pVrfDeleteObj.h>
#include <portal/pVrfTextReport.h>
#include <portal/pVrfScenario.h>
#include <portal/pVrfSpotReport.h>
#include <portal/pVrfSensorData.h>

#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtVrfMsgTranslator are responsible for translating DtPortalVRF(...) messages to MAK:VRFMessages.
      //! (currently only DtScriptedTaskTask and resource messages are supported)
      class DT_DLL_WEBLVCBROKER DtVrfMsgTranslator : public DtBaseWebLvcInteractionTranslator
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "MAK:VRFMessage" );

         //! \brief CTOR.
         DtVrfMsgTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtVrfMsgTranslator();

         virtual void tick() {}

         virtual DtWebLvcBroker* webLvcBroker();
         virtual const DtWebLvcBroker* webLvcBroker() const;

         virtual void enableReflectTranslator( bool enabled );
         virtual void enablePublishTranslator( bool enabled );

         virtual void initializeWebLvcCallbacks();
         virtual void removeWebLvcCallbacks();

         virtual void initializePortalCallbacks();
         virtual void removePortalCallbacks();

         //! @name Translation Methods
         //! @{

         static void receivePortalInteraction( const DtPortalVrfCurrentResourceRequestInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfCurrentResourceRequestInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfCurrentResourceRequestInteraction* destination );
         virtual void translate( const DtPortalVrfCurrentResourceRequestInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfResourceMonitorResponseInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfResourceMonitorResponseInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfResourceMonitorResponseInteraction* destination );
         virtual void translate( const DtPortalVrfResourceMonitorResponseInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfEntityResourceResponseInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfEntityResourceResponseInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfEntityResourceResponseInteraction* destination );
         virtual void translate( const DtPortalVrfEntityResourceResponseInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfScriptedTaskInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfScriptedTaskInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfScriptedTaskInteraction* destination );
         virtual void translate(const DtPortalVrfScriptedTaskInteraction& source, Json::Value* destination);

         static void receivePortalInteraction(const DtPortalVrfTaskInteraction& inter, void* usr);
         virtual void createInteraction(const DtPortalVrfTaskInteraction& incoming);
         virtual void translate(const Json::Value& source, DtPortalVrfTaskInteraction* destination);
         virtual void translate(const DtPortalVrfTaskInteraction& source, Json::Value* destination);

         static void receivePortalInteraction( const DtPortalVrfControlInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfControlInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfControlInteraction* destination );
         virtual void translate( const DtPortalVrfControlInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfSetDataInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfSetDataInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfSetDataInteraction* destination );
         virtual void translate( const DtPortalVrfSetDataInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfCurrentTasksInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfCurrentTasksInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfCurrentTasksInteraction* destination );
         virtual void translate( const DtPortalVrfCurrentTasksInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfChangeTimeOfDayCommandInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfChangeTimeOfDayCommandInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfChangeTimeOfDayCommandInteraction* destination );
         virtual void translate( const DtPortalVrfChangeTimeOfDayCommandInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfChangeGlobalWeatherCommandInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfChangeGlobalWeatherCommandInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfChangeGlobalWeatherCommandInteraction* destination );
         virtual void translate( const DtPortalVrfChangeGlobalWeatherCommandInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfCreateObjInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfCreateObjInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfCreateObjInteraction* destination );
         virtual void translate(const DtPortalVrfCreateObjInteraction& source, Json::Value* destination );

         static void receivePortalInteraction(const DtPortalVrfDeleteObjInteraction& inter, void* usr);
         virtual void createInteraction(const DtPortalVrfDeleteObjInteraction& incoming);
         virtual void translate(const Json::Value& source, DtPortalVrfDeleteObjInteraction* destination );
         virtual void translate(const DtPortalVrfDeleteObjInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfTextReportInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfTextReportInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfTextReportInteraction* destination );
         virtual void translate( const DtPortalVrfTextReportInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfScenarioInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfScenarioInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfScenarioInteraction* destination );
         virtual void translate( const DtPortalVrfScenarioInteraction& source, Json::Value* destination );

         static void receivePortalInteraction( const DtPortalVrfSpotReportInteraction& inter, void* usr );
         virtual void createInteraction( const DtPortalVrfSpotReportInteraction& incoming );
         virtual void translate( const Json::Value& source, DtPortalVrfSpotReportInteraction* destination );
         virtual void translate( const DtPortalVrfSpotReportInteraction& source, Json::Value* destination );

         static void receivePortalInteraction(const DtPortalVrfSensorDataInteraction& inter, void* usr);
         virtual void createInteraction(const DtPortalVrfSensorDataInteraction& incoming);
         virtual void translate(const Json::Value& source, DtPortalVrfSensorDataInteraction* destination);
         virtual void translate(const DtPortalVrfSensorDataInteraction& source, Json::Value* destination);

         static void receivePortalInteraction(const DtPortalVrfSensorDataRequestInteraction& inter, void* usr);
         virtual void createInteraction(const DtPortalVrfSensorDataRequestInteraction& incoming);
         virtual void translate(const Json::Value& source, DtPortalVrfSensorDataRequestInteraction* destination);
         virtual void translate(const DtPortalVrfSensorDataRequestInteraction& source, Json::Value* destination);

         //Takes JSON message of windLevels, and puts it into vector held by portal.
         virtual void translateWindLevels(const Json::Value& source, DtPortalVrfChangeGlobalWeatherCommandInteraction* destination);

         //! @}

         virtual void processMsg( Json::Value* msg, DtClient* client );

         virtual void printIncomingOutgoingStateReps( const DtPortalMessage& incoming,
            const Json::Value& outgoing );

         virtual void printIncomingOutgoingStateReps( const Json::Value& incoming,
            const DtPortalMessage& outgoing );

         virtual void createFullStateMsgs( std::list<std::string>& msgs, DtClient* client ) {}

         //! \brief Unregisters callbacks.
         virtual void shutdown();

      protected:

         // Scripted task functions
         //         virtual void convertOrbitTask( const Json::Value& value, DtPortalVrfScriptedTaskInteraction* inter );
         virtual void convertTask(const Json::Value& value, DtPortalVrfTaskInteraction* inter);
         virtual void convertScriptedTask( const Json::Value& value, DtPortalVrfScriptedTaskInteraction* inter );
         virtual void convertSetData( const Json::Value& value, DtPortalVrfSetDataInteraction* inter );
         virtual void processDoubleValue( DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType type, const Json::Value& value, DtAttributeValuePairList& avpl);
         virtual void processStringValue( DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType type, const Json::Value& value, DtAttributeValuePairList& avpl);
         virtual void processIntValue( DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType type, const Json::Value& value, DtAttributeValuePairList& avpl);
         virtual void processVectorValue(DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType type,  const Json::Value& value, DtAttributeValuePairList& avpl);

         // Method to convert an entity resource to Json
         virtual void convertResource( DtAttributeValuePairList &resource, Json::Value& val );

      protected:

         // Map of variable types for Scripted Task
         std::map<std::string, DtPortalVrfScriptedTaskInteraction::ScriptedTaskVariableType> myVariableTypeMap;

         std::map<std::string, int> myMessageTypes;

      };

   }
}
