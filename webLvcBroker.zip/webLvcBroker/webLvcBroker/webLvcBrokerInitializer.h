/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcBrokerInitializer.h
//! \brief Contains the DtWebLvcBrokerInitializer class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <broker/brokerInitializer.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Contains command line and configuration file initialization parameters
      //! for the DtWebLvcBroker class.
      //! \ingroup webLvcBroker
      class DT_DLL_WEBLVCBROKER DtWebLvcBrokerInitializer : public MAKVrExchange::DtBrokerInitializer
      {
      public:

         //! \brief CTOR.
         DtWebLvcBrokerInitializer( int argc, char* argv[],
            const DtString& version = "SWS VRX 1.0" );

         //! \brief Virtual DTOR.
         virtual ~DtWebLvcBrokerInitializer();

         //! Copy Constructor
         DtWebLvcBrokerInitializer( const DtWebLvcBrokerInitializer& other );

         //! Assignment Operator
         DtWebLvcBrokerInitializer& operator = ( const DtWebLvcBrokerInitializer& other );

         //! \brief Clone method.
         //! Creates a copy of this initializer - caller is responsible for deletion.
         virtual DtWebLvcBrokerInitializer* clone() const;

      public:

         //! Ports used for connections to web clients.  Default value of 9101.
         virtual void setWebSocketPort( DtString portString );
         virtual std::vector<int> webSocketPort() const;
         virtual DtString webSocketPortString() const;

         //! optional Port used for connections to tcp clients. Default value of false.
         virtual void setUseTcpPort( bool on );
         virtual bool useTcpPort() const;

         //! Port used for connections to tcp clients.  Default value of 9102.
         virtual void setTcpSocketPort( int port );
         virtual int tcpSocketPort() const;

         //! Sleep interval each frame.  Default is 0.05 seconds.
         virtual void setSleepInterval( double value );
         virtual double sleepInterval() const;

         //! Set the OMT files used for the omtTranslator.
         //! Note that you can set multiple OMT files by separating them
         //! with semicolons (;)
         virtual void setOmtFiles( const DtString& value );
         virtual DtString omtFiles() const;

         //! Proxy Host
         virtual void setProxyHost( const DtString& value );
         static DtString& proxyHost();

         //! Proxy Port
         virtual void setProxyPort( int value );
         static int& proxyPort();

         //! \brief Set Enable HTTP Server
         virtual void setEnableHttpServer(bool);
         //! \brief Get Enable HTTP Server
         static bool enableHttpServer();

         //! \brief Set Local HTTP Directory
         virtual void setLocalHttpDirectory(const DtString&);
         //! \brief Get Local HTTP Directory
         static DtString& localHttpDirectory();

         //! \brief Set Enable HTTP Proxy
         virtual void setEnableHttpProxy(bool);
         //! \brief Get Enable HTTP Proxy
         static bool enableHttpProxy();

         //! \brief Set Local Non Proxy Directory
         virtual void setLocalNonProxyDir(const DtString&);
         //! \brief Get Local Non Proxy Directory
         static DtString& localNonProxyDir();

         //! \brief Set Enable Status Page
         virtual void setEnableStatusPage(bool);
         //! \brief Get Enable Status Page
         static bool enableStatusPage();

         //! \brief Set the SSL certificate for HTTPS support
         virtual void setSslCertificate(const DtString&);
         //! \brief Get the SSL certificate for HTTPS support
         static DtString& sslCertificate();

         virtual void parseCmdLine();

      protected:

         DtConfigVariable<DtString> myConfigVarWebSocketPort;
         DtConfigVariable<bool> myConfigVarUseTcpPort;
         DtConfigVariable<int> myConfigVarTcpSocketPort;
         DtConfigVariable<double> mySleepInterval;
         DtConfigVariable<DtString> myConfigVarProxyHost;
         DtConfigVariable<DtString> myConfigVarOmtFiles;
         DtConfigVariable<int> myConfigVarProxyPort;
         DtConfigVariable<bool> myConfigEnableHttpServer;
         DtConfigVariable<DtString> myConfigLocalHttpDirectory;
         DtConfigVariable<bool> myConfigEnableHttpProxy;
         DtConfigVariable<DtString> myConfigLocalNonProxyDir;
         DtConfigVariable<bool> myConfigEnableStatusPage;
         DtConfigVariable<DtString> myConfigSSLCertificate;
      };

   }
}
