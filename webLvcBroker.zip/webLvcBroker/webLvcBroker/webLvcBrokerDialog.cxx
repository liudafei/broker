/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcBrokerDialog.cxx
//! \brief Contains the DtWebLvcBrokerDialog class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/webLvcBrokerDialog.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <webLvcBroker/webLvcGeneralSettingsWidget.h>
#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/client.h>

#include <Poco/Net/SocketAddress.h>
#include <Poco/Net/StreamSocket.h>

#include <broker/brokerObject.h>

#include <widgets/widgetIconStyleManager.h>

#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtGui/QFocusEvent>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QLabel>

using Poco::Net::SocketAddress;
using Poco::Net::StreamSocket;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtBrokerDialog* DtWebLvcBrokerDialog::create( DtBroker* broker,
         DtBrokerInitializer* init, QWidget* parent /* = 0 */ )
      {
         DtWebLvcBrokerDialog* dialog = new DtWebLvcBrokerDialog(
            (DtWebLvcBroker*)broker, (DtWebLvcBrokerInitializer*)init, parent );
         dialog->initialize();
         return dialog;
      }

      DtWebLvcBrokerDialog::DtWebLvcBrokerDialog( DtWebLvcBroker* broker,
            DtWebLvcBrokerInitializer* init, QWidget* parent /* = 0 */ )
         : DtBrokerDialog( broker, init, parent )
         , myClientsListWidget( 0 )
         , myWebLvcBroker( broker )
         , myClientHostnameLabel( 0 )
         , myClientConnectHostLineEdit( 0 )
         , myClientPortLabel( 0 )
         , myClientConnectPortSpinBox( 0 )
         , myClientConnectButton( 0 )
      {
      }

      DtWebLvcBrokerDialog::~DtWebLvcBrokerDialog()
      {
      }

      DtWebLvcBrokerInitializer* DtWebLvcBrokerDialog::webLvcInitializer()
      {
         return (DtWebLvcBrokerInitializer*) myBrokerInitializer;
      }

      void DtWebLvcBrokerDialog::initialize()
      {
         setWidgetIconStyleManager(new DtWidgetIconStyleManager(this));
         initObjectListViews();
         initClientsPage();
         initSettingsWidget(); 
         initFilterWidget();
         initTranslatorListView();

         setCurrentPage( 0 );
         resize( 483, 550 );

         myClientConnectHostLineEdit->installEventFilter( this );
         myClientConnectPortSpinBox->installEventFilter( this );
      }

      void DtWebLvcBrokerDialog::initClientsPage()
      {
         QWidget* clientsListPage = new QWidget();
         QVBoxLayout* mainLayout = new QVBoxLayout();
         mainLayout->setSpacing( 0 );
         mainLayout->setMargin( 0 );
         {
            myClientsListWidget = new DtGenericListView();
            mainLayout->addWidget( myClientsListWidget );

            QHBoxLayout* tcpConnectionLayout = new QHBoxLayout();
            {
               // Label for client hostname field.
               myClientHostnameLabel = new QLabel( tr("TCP Client: Hostname:") );
               myClientHostnameLabel->setToolTip( tr("TCP Client to connect to.") );
               tcpConnectionLayout->addWidget( myClientHostnameLabel );

               // Line edit for inputting hostname / ip address.
               myClientConnectHostLineEdit = new QLineEdit();
               myClientConnectHostLineEdit->setToolTip( tr("Target hostname or IP Address.") );
               tcpConnectionLayout->addWidget( myClientConnectHostLineEdit );

               // Label for port field.
               myClientPortLabel = new QLabel( tr("Port:") );
               myClientPortLabel->setToolTip( tr("Target port.") );
               tcpConnectionLayout->addWidget( myClientPortLabel );

               // Spin box for inputting port.
               myClientConnectPortSpinBox = new QSpinBox();
               myClientConnectPortSpinBox->setRange( 0, 65535 );
               myClientConnectPortSpinBox->setToolTip( tr("Target port.") );
               tcpConnectionLayout->addWidget( myClientConnectPortSpinBox );

               // Button for performing the connect.
               myClientConnectButton = new QPushButton( tr("Connect") );
               myClientConnectButton->setToolTip( tr("Press to connect.") );
               tcpConnectionLayout->addWidget( myClientConnectButton );

               // Connect signal to button press to perform connect.
               connect( myClientConnectButton, SIGNAL(released()),
                  SLOT(on_clientConnectButton_released()) );
            }
            mainLayout->addLayout( tcpConnectionLayout );
         }
         clientsListPage->setLayout( mainLayout );
         clientsListPage->setProperty("pageIndex", 2);
         clientsListPage->setProperty("iconFilename", "../data/images/NetworkConnected.svg");

         myClientsListWidget->listView()->header()->setSortIndicatorShown( true );
         myClientsListWidget->listView()->header()->setSectionsClickable( true );
         myClientsListWidget->listView()->setSortingEnabled( false );

         addPage( clientsListPage, QIcon(myClientsListWidget->property("iconFilename").toString()), tr("Clients"), true );
         myClientsListWidget->listView()->header()->viewport()->installEventFilter( this );

         QStringList columnHeaders;
         columnHeaders << tr("Name") << tr("WebLVC Version") << tr( "Remote Address" ) ;

         QString title = tr("WebLVC Clients Connected");
         myClientsListWidget->titleLabel()->setText( title );

         myClientsListWidget->listView()->setColumnCount( 3 );
         myClientsListWidget->listView()->setHeaderLabels( columnHeaders );
         myClientsListWidget->listView()->setColumnWidth( 0, 150 );
         myClientsListWidget->listView()->setColumnWidth( 1, 100 );
         myClientsListWidget->listView()->setColumnWidth( 2, 85 );

         myClientsListWidget->listView()->headerItem()->setToolTip( 0, tr("Clients given name from Connect Message.") );
         myClientsListWidget->listView()->headerItem()->setToolTip( 1, tr("Protocol version client is communicating with.") );
         myClientsListWidget->listView()->headerItem()->setToolTip( 2, tr("The remote address of the client.") );
      }

      DtConnectionSettingsWidget* DtWebLvcBrokerDialog::instantiateConnectionSettingsWidget()
      {
         // No connection settings page.
         return 0;
      }

      DtGeneralSettingsWidget* DtWebLvcBrokerDialog::instantiateGeneralSettingsWidget()
      {
         return new DtWebLvcGeneralSettingsWidget();
      }

      bool DtWebLvcBrokerDialog::eventFilter( QObject* obj, QEvent* event )
      {
         // Change the button activated when pressing enter while the client fields have focus.
         // If the user presses enter after inputting hostname/port it should connect (not hide the dialog).
         if ( obj == myClientConnectHostLineEdit || obj == myClientConnectPortSpinBox )
         {
            if ( event->type() == QEvent::FocusIn )
            {
               myClientConnectButton->setDefault( true );
            }
            else if ( event->type() == QEvent::FocusOut )
            {
               myButtonBox->button( QDialogButtonBox::Ok )->setDefault( true );
            }
         }

         return DtBrokerDialog::eventFilter( obj, event );
      }

      void DtWebLvcBrokerDialog::initObjectListViewHeaders()
      {
         QStringList columnHeaders;
         columnHeaders << tr("Type") << tr("Name");


         QString title = tr("Published objects.");
         QTreeWidget* pubList = myPublishedObjectsWidget->listView();
         myPublishedObjectsWidget->titleLabel()->setText(title);

         pubList->setColumnCount(2);
         pubList->setHeaderLabels(columnHeaders);
         pubList->setColumnWidth(StatusCol, 150);
         pubList->setColumnWidth(NameCol, 85);

         QTreeWidgetItem* pubHeader = pubList->headerItem();
         pubHeader->setToolTip(StatusCol, tr("The type of object published."));
         pubHeader->setToolTip(NameCol, tr("The internal name of the published object."));


         title = tr("Reflected objects.");
         QTreeWidget* subList = myReflectedObjectsWidget->listView();
         myReflectedObjectsWidget->titleLabel()->setText(title);

         subList->setColumnCount(2);
         subList->setHeaderLabels(columnHeaders);
         subList->setColumnWidth(StatusCol, 150);
         subList->setColumnWidth(NameCol, 85);

         QTreeWidgetItem* subHeader = subList->headerItem();
         subHeader->setToolTip(StatusCol, tr("The type of reflected object."));
         subHeader->setToolTip(NameCol, tr("The name of the reflected object."));
      }

      void DtWebLvcBrokerDialog::updateObjectText( const DtBrokerObject* brokerObject,
         QTreeWidgetItem* item, const QString& status )
      {
         item->setText(StatusCol, status);
         item->setText(NameCol, brokerObject->objectName().c_str());

         // Set the drop reason in a tooltip if the object was dropped.
         if (!status.isEmpty())
         {
            item->setToolTip(StatusCol, brokerObject->dropReason().c_str());
         }

         // Resize the name column once there's a name there (only once).
         static bool firstUpdate = true;
         if (firstUpdate && !brokerObject->objectName().isEmpty())
         {
            item->treeWidget()->resizeColumnToContents(NameCol);
            firstUpdate = false;
         }
      }

      void DtWebLvcBrokerDialog::on_clientConnectButton_released()
      {
         DtString hostname = myClientConnectHostLineEdit->text().toLatin1().data();
         int port = myClientConnectPortSpinBox->value();

         try
         {
            myWebLvcBroker->initiateTcpConnection( hostname, port );
         }
         catch ( const std::exception& ex )
         {
            QString errorMsg = tr("An error was encountered while connecting to ");
            errorMsg += QString(hostname.c_str()) + ":" + QString::number(port) + "\n";
            errorMsg += tr("Error: ") + ex.what();

            QMessageBox::critical( this, tr("Connection Failed"), errorMsg );
         }
      }

      void DtWebLvcBrokerDialog::setTcpConnectEnabled( bool onOff )
      {
         myClientHostnameLabel->setEnabled( onOff );
         myClientConnectHostLineEdit->setEnabled( onOff );
         myClientPortLabel->setEnabled( onOff );
         myClientConnectPortSpinBox->setEnabled( onOff );
         myClientConnectButton->setEnabled( onOff );
      }

      void DtWebLvcBrokerDialog::clientsUpdated()
      {
         myClientsListWidget->listView()->clear();

         std::list<DtClient*>::iterator itr = myWebLvcBroker->clientList().begin();
         std::list<DtClient*>::iterator end = myWebLvcBroker->clientList().end();
         while ( itr != end )
         {
            QTreeWidgetItem* objectItem = new QTreeWidgetItem( myClientsListWidget->listView() );
            objectItem->setText( 0, (*itr)->name().c_str() );
            objectItem->setText( 1, DtString((*itr)->version()).c_str() );
            objectItem->setText( 2, (*itr)->addrString().c_str() );
            ++itr;
         }
         myClientsListWidget->listView()->resizeColumnToContents( 0 );
         myClientsListWidget->listView()->resizeColumnToContents( 1 );
         myClientsListWidget->listView()->resizeColumnToContents( 2 );

         // Enable or disable the TCP fields, depending on whether a connection is active already.
         setTcpConnectEnabled( myWebLvcBroker->manualTcpClient() == 0 );
      }

   }
}
