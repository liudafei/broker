/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file client.cxx
//! \brief Contains the DtClient class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/client.h>
#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/lockingReflectedObjMgr.h>
#include <webLvcBroker/baseWebLvcObjectTranslator.h>
#include <vlutil/vlProcessControl.h>
#include <vlutil/vlPrint.h>
#include <Poco/Net/NetException.h>
#include <matrix/geodeticCoord.h>
#include <matrix/topoCoord.h>
#include <vlpi/deadReckoner.h>

using Poco::Net::ConnectionAbortedException;
using Poco::Net::ConnectionResetException;
using Poco::Net::NetException;
using Poco::TimeoutException;

double thePingCountdown = 2.5;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtClient::DtClient()
         : myName("unknown")
         , myProtocolVersion(-1)
         , myAddressString("unknown")
         , sleepTime(0.05)
         , myThreadRun(true)
         , myConnected(true)
         , myBroker(NULL)
         , myPingTimer(0.0)
         , msgKind("MessageKind")
         , objectName("ObjectName")
         , objectType("ObjectType")
         , myReceiveBuffer(1000)
      {
         myConnectTime = DtAbsRealTime();
      }

      DtClient::~DtClient()
      {
         if ( myThread.isRunning() )
         {
            stop();
         }
      }

      void DtClient::setBroker( DtWebLvcBroker* broker )
      {
         myBroker = broker;
      }

      bool DtClient::processConnectMsg( Json::Value& msg )
      {
         myName = msg.get("ClientName","unknown").asString();
         myProtocolVersion = msg.get("WebLVCVersion",0.0).asDouble();

         DtWarn << "Client Connect Msg: " << myName << " " << myAddressString << std::endl;

         // If the client requested a connect message from us, send it.
         if ( msg.get("RequestClientConnect",false).asBool() )
         {
            Json::Value connectMsgJson;
            connectMsgJson["MessageKind"] = 3;
            connectMsgJson["WebLVCVersion"] = 1.0;
            connectMsgJson["ClientName"] = myBroker->brokerName().c_str();

            Json::FastWriter writer;
            std::string connectMsg = writer.write( connectMsgJson );
            sendFrame( connectMsg.data(), (int) connectMsg.size() );
         }

         return true;
      }

      void DtClient::run()
      {
         // Send an initial round of updates of all objects to get the client up to date.
         sendStateUpdateMessages();

         int count = 0;
         int updateCount = 0;
         DtTime runningSum = 0;
         while ( myThreadRun )
         {
            // this line will send the 20hz updates, turning it off for now as
            // we move to on demand updating
            // sendStateUpdateMessages();
            DtTime start = DtGetElapsedRealTime();
            receiveFromClient();
            if ( myBroker )
            {
               updateCount += myBroker->processObjectUpdateSets( this );
            }

            sendMessages();
            ping();

            // wait some determined time
            DtTime stop = DtGetElapsedRealTime();
            DtSleep( sleepTime - ( stop - start ) );
            stop = DtGetElapsedRealTime();
            count++;
            runningSum += stop - start;
            if ( count == 10 )
            {
               count = 0;
               myAvgUpd = updateCount / 10.0;
               myAvgFrame = runningSum / 10;
               runningSum = 0;
               updateCount = 0;
            }
         }
         DtInfo << "Client Shutting Down" << std::endl;
      }

      bool DtClient::nextFrame( std::string& s )
      {
         Poco::ScopedWriteRWLock lock(mySendRWLock);
         bool retval = false;
         if( mySendQueue.size() > 0 )
         {
            s = mySendQueue.front();
            mySendQueue.pop_front();
            retval = true;
         }
         return retval;
      }

      void DtClient::sendMsg( const std::string& msg )
      {
         Poco::ScopedWriteRWLock lock(mySendRWLock);
         mySendQueue.push_back(msg);
      }

      bool DtClient::receiveMsg( std::string& msg )
      {
         Poco::ScopedWriteRWLock lock( myRecvRWLock );
         if ( myReceiveQueue.size() <= 0 )
         {
            return false;
         }
         msg = myReceiveQueue.front();
         myReceiveQueue.pop_front();
         return true;
      }

      void DtClient::addMsg( const std::string& msg )
      {
         Poco::ScopedWriteRWLock lock( myRecvRWLock );
         myReceiveQueue.push_back( msg );
      }

      void DtClient::ping()
      {
         myPingTimer = myPingTimer-sleepTime;
         if ( myPingTimer <= 0.0 )
         {
            myPingTimer = thePingCountdown;
            std::string str = "{\"MessageKind\":99,\"ping\":1}";
            sendMsg( str );
         }
      }

      void DtClient::sendMessages()
      {
         std::string s;
         try
         {
            while ( myThreadRun && nextFrame(s) )
            {
               sendFrame( s.c_str(), s.size() );
            }
         }
         catch ( ConnectionAbortedException& exc )
         {
            //app.logger().log(exc);
            DtInfo << "Websocket connection closed. - exc.code(): " << exc.code() << std::endl;
            myConnected = false;
         }
         catch ( ConnectionResetException& exc )
         {
            //app.logger().log(exc);
            std::cout << "ConnectionResetException - exc.code(): " << exc.code() << std::endl;
            myConnected = false;
         }
         catch ( TimeoutException )
         {
            //std::cout << "timeoutException - exc.code(): " << exc.code() << std::endl;
         }
         catch ( NetException& exc )
         {
            std::cout << "NetException - exc.code(): " << exc.code() << std::endl;
            myConnected = false;
         }
      }

      void DtClient::sendStateUpdateMessages()
      {
         if ( myBroker == NULL )
         {
            return;
         }

         DtWebLvcBroker::NamedObjectTranslatorMap::const_iterator itr = myBroker->objectTranslators().begin();
         DtWebLvcBroker::NamedObjectTranslatorMap::const_iterator end = myBroker->objectTranslators().end();
         std::list<std::string>::iterator msgiter;
         std::list<std::string> msgs;
         for ( ; itr != end; ++itr )
         {
            ((DtBaseWebLvcObjectTranslator*)itr->second)->createFullStateMsgs( msgs, this );
            for ( msgiter = msgs.begin(); msgiter != msgs.end(); ++msgiter )
            {
               sendMsg( *msgiter );
            }
            msgs.clear();
         }
      }

      void DtClient::receiveFromClient()
      {
         if ( ! myConnected || ! myThreadRun )
         {
            return;
         }
         //Reset buffer with 0 data
         int length = myReceiveBuffer.size();
         myReceiveBuffer.assign(length, 0);
         
         int flags = 0;
         DtTime stop = DtAbsRealTime() + .1; //Run for .1 seconds. Then pause for air. I might want to adjust moving forward

         try
         {
            int data = receiveFrame((char*)&(myReceiveBuffer[0]), length, flags );
            while ( DtAbsRealTime() <= stop && data > 0 )
            {
               std::string s = (char*)&myReceiveBuffer[0];
               addMsg( s );
               //Reset buffer before calling receiveFrame again.  Makes sure buffer is clean
               //and doesnt include any old messages.
               int length = myReceiveBuffer.size();
               myReceiveBuffer.assign(length, 0);

               data = receiveFrame((char*)&(myReceiveBuffer[0]), length, flags );
            }

            if ( data == -1 )
            {
               myConnected = false;
            }
         }
         catch ( ConnectionAbortedException& exc )
         {
            //app.logger().log(exc);
            DtInfo << "Websocket connection closed. - exc.code(): " << exc.code() << std::endl;
            myConnected = false;
         }
         catch ( ConnectionResetException& exc )
         {
            //app.logger().log(exc);
            DtWarn << "ConnectionResetException - exc.code(): " << exc.code() << std::endl;
            myConnected = false;
         }
         catch ( TimeoutException )
         {
            //std::cout << "timeoutException - exc.code(): " << exc.code() << std::endl;
         }
         catch ( NetException& exc )
         {
            std::cout << "NetException - exc.code(): " << exc.code() << std::endl;
            myConnected = false;
         }

      }

      void DtClient::start()
      {
         myThread.start(*this);
      }

      void DtClient::stop()
      {
         myThreadRun = false;
         myThread.join();
      }

      void DtClient::checkAsSeenByRemote( const DtString& transname,
         const DtString& entName, Json::Value& val )
      {
         Json::Value cache = val;
         std::map< DtString, std::map<DtString,Json::Value> >::iterator i = asSeenByRemote.find( transname );
         if ( i != asSeenByRemote.end() )
         {
            std::map< DtString, Json::Value >::iterator j = i->second.find( entName );
            if ( j != i->second.end() && j->second.size() == val.size() )
            {
               Json::Value::iterator remoteIter = j->second.begin();
               Json::Value::iterator incomingIter = val.begin();
               std::string memName;
               while ( incomingIter != val.end() )
               {
                  memName = incomingIter.memberName();
                  if ( memName != msgKind && memName != objectName
                     && memName != objectType && *incomingIter == *remoteIter )
                  {
                     ++incomingIter;
                     ++remoteIter;
                     val.removeMember( memName );
                  }
                  else
                  {
                     ++incomingIter;
                     ++remoteIter;
                  }
               }
            }
            else
            {
               i->second[entName] = val;
            }
         }
         else
         {
            std::map< DtString, Json::Value > p;
            p[entName] = val;
            asSeenByRemote[transname] = p;
         }

         asSeenByRemote[transname][entName] = cache;
      }

      void DtClient::removeAsSeenByRemote( const DtString& transname, const DtString& entName )
      {
         std::map< DtString, std::map<DtString,Json::Value> >::iterator i = asSeenByRemote.find( transname );
         if ( i != asSeenByRemote.end() )
         {
            i->second.erase( entName );
         }
      }

   }
}
