/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webSocketClient.cxx
//! \brief Contains the DtWebSocketClient class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/webSocketClient.h>
#include <vlutil/vlPrint.h>
#include <vlutil/vlUtil.h>
#include <stdio.h>

using Poco::Net::WebSocket;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtWebSocketClient::DtWebSocketClient( Poco::Net::WebSocket* ws )
         : myWebSocket( ws )
      {
         myAddressString = myWebSocket->peerAddress().toString();
         myWebSocket->setReceiveTimeout( Poco::Timespan(0,10) );
      }

      DtWebSocketClient::DtWebSocketClient( Poco::Net::HTTPServerRequest& request,
         Poco::Net::HTTPServerResponse& response )
      {
         myWebSocket = new Poco::Net::WebSocket( request, response );
         myAddressString = myWebSocket->peerAddress().toString();
         myWebSocket->setReceiveTimeout( Poco::Timespan(0,10) );
      }

      DtWebSocketClient::~DtWebSocketClient()
      {
         myThreadRun = false;
         try
         {
            myWebSocket->shutdown();
         }
         catch ( ... )
         {
            DtWarn( "client gone before shutdown\n" );
         }
         DtDELETE( myWebSocket );
      }

      int DtWebSocketClient::sendFrame( const void* buffer, int length )
      {
         return myWebSocket->sendFrame( buffer, length, WebSocket::FRAME_TEXT );
      }

      int DtWebSocketClient::receiveFrame( void* buffer, int length, int& flags )
      {
         if (myWebSocket->available() == 0) return 0;
         //create temp poco webBuffer which can be dynamically resized in receiveFrame.
         //Prevents the socket from closing due to larger messages.
         Poco::Buffer<char> webBuffer(0);
         int data = myWebSocket->receiveFrame(webBuffer, flags );
         if ( data == 0 )
         {
            return -1;
         }
         else
         {
            if (data > length)
            {
               //got a message longer than our set buffer length.
               //resize buffer then save message.
               div_t ratio = div(data, length);
               size_t newSize = myReceiveBuffer.size() * (ratio.quot + 1);
               //Make sure newSize is below maximum size limit
               if (newSize > myReceiveBuffer.max_size())
               {
                  return -1;
               }
               myReceiveBuffer.resize(newSize);
            }
            memcpy(&myReceiveBuffer[0], &webBuffer[0], data);
         }
         return data;
      }

   }
}
