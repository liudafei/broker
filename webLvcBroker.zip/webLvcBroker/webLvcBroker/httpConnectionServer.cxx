/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file httpConnectionServer.cxx
//! \brief Contains the DtHttpConnectionServer class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/httpConnectionServer.h>
#include <webLvcBroker/httpRequestHandlerFactory.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>

#include <Poco/Net/HTTPServer.h>
#include <Poco/Net/HTTPServerParams.h>
#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/SecureServerSocket.h>
#include <Poco/Net/InvalidCertificateHandler.h>
#include <Poco/Net/RejectCertificateHandler.h>
#include <Poco/Net/SSLManager.h>

#include <vlutil/vlUtil.h>

using Poco::Net::HTTPServer;
using Poco::Net::HTTPServerParams;
using Poco::Net::ServerSocket;
using Poco::Net::SecureServerSocket;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtHttpConnectionServer::DtHttpConnectionServer( int port )
         : DtReliableConnectionServer()
         , myServerSocket( 0 )
         , myHTTPServer( 0 )
      {
         DtFilename sslFile = DtWebLvcBrokerInitializer::sslCertificate().c_str();
         if (sslFile.exists())
         {
            Poco::SharedPtr<Poco::Net::InvalidCertificateHandler> pCert = new Poco::Net::RejectCertificateHandler(true);
            Poco::Net::Context::Ptr pContext = new Poco::Net::Context(
               Poco::Net::Context::SERVER_USE, sslFile.c_str(), Poco::Net::Context::VERIFY_RELAXED); 

            Poco::Net::SSLManager::instance().initializeServer(0, pCert, pContext);

            try
            {
               myServerSocket = new SecureServerSocket(port);
            }
            catch (...)
            {
               //Socket failed. So go with HTTP Only.
               DtWarn << "SSL Certificate loading failed, trying without SSL Support." << std::endl;
               myServerSocket = new ServerSocket(port);
            }
         }
         else
         {
            DtWarn << "No SSL Certificate found. Initializing HTTP Only." << std::endl;
            myServerSocket = new ServerSocket(port);
         }

         myHTTPServer = new HTTPServer( new DtHttpRequestHandlerFactory(),
            *myServerSocket, new HTTPServerParams() );
      }

      DtHttpConnectionServer::~DtHttpConnectionServer()
      {
         myHTTPServer->stop();
         DtDELETE( myHTTPServer );
         DtDELETE( myServerSocket );
      }

      void DtHttpConnectionServer::start()
      {
         myHTTPServer->start();
      }

      void DtHttpConnectionServer::stop()
      {
         myHTTPServer->stop();
      }

   }
}
