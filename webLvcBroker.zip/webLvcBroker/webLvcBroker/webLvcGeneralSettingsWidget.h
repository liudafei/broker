/*****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcGeneralSettingsWidget.h
//! \brief Contains the DtWebLvcGeneralSettingsWidget class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <widgets/generalSettingsWidget.h>

namespace MAKCommonWidgets
{
   class DtCollectionEditor;
}

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Provides an interface for configuring WebLVC connection settings.
      //! \ingroup webLvcBroker
      class DT_DLL_WEBLVCBROKER DtWebLvcGeneralSettingsWidget : public DtGeneralSettingsWidget
      {  Q_OBJECT;
      public:

         //! \brief CTOR.
         //! \throw DtQAppStartingUp is thrown is the qApp is not started up yet.
         DtWebLvcGeneralSettingsWidget( QWidget* parent = 0 );

         //! \brief Virtual DTOR.
         virtual ~DtWebLvcGeneralSettingsWidget();

         //! \brief Accessor for casted WebLVC Initializer.
         virtual DtWebLvcBrokerInitializer* webLvcInitializer();

         //! @name Connection Settings Setters/Getters
         //! @{

         //! \brief Set web socket port value.
         virtual void setWebSocketPort( QString );
         //! \brief Get web socket port value.
         virtual QString webSocketPort() const;

         //! \brief Set tcp socket port value.
         virtual void setUseTcpPort( bool );
         //! \brief Get tcp socket port value.
         virtual bool useTcpPort() const;

         //! \brief Set tcp socket port value.
         virtual void setTcpSocketPort( int );
         //! \brief Get tcp socket port value.
         virtual int tcpSocketPort() const;

         //! \brief Set proxy socket port value.
         virtual void setProxyPort( int );
         //! \brief Get tcp socket port value.
         virtual int proxyPort() const;

         //! \brief Set proxy socket port value.
         virtual void setProxyDest( QString );
         //! \brief Get tcp socket port value.
         virtual QString proxyDest() const;

         //! \brief Set Omt Files.
         virtual void setOmtFiles( QString );
         //! \brief Get Omt Filess.
         virtual QString omtFiles() const;

         //! \brief Set Enable HTTP Server
         virtual void setEnableHttpServer(bool);
         //! \brief Get Enable HTTP Server
         virtual bool enableHttpServer() const;

         //! \brief Set Local HTTP Directory
         virtual void setLocalHttpDirectory(QString);
         //! \brief Get Local HTTP Directory
         virtual QString localHttpDirectory() const;

         //! \brief Set Enable HTTP Proxy
         virtual void setEnableHttpProxy(bool);
         //! \brief Get Enable HTTP Proxy
         virtual bool enableHttpProxy() const;

         //! \brief Set Local Non Proxy Directory
         virtual void setLocalNonProxyDir(QString);
         //! \brief Get Local Non Proxy Directory
         virtual QString localNonProxyDir() const;

         //! \brief Set Enable Status Page
         virtual void setEnableStatusPage(bool);
         //! \brief Get Enable Status Page
         virtual bool enableStatusPage() const;

         //! \brief Set Local Non Proxy Directory
         virtual void setSslCertificate(QString);
         //! \brief Get Local Non Proxy Directory
         virtual QString sslCertificate() const;

         //! @}

      protected:

         //! \brief Initialize translated Qt property names.
         //! Overridden to initialize DIS specific property names.
         virtual void initializeQtStrings();

         //! \brief Initialize the property entries for the settings.
         //! Overridden to initialize DIS specific properties.
         virtual void initializeProperties();

         //! \brief Update the initializer with the dialog's current settings.
         //! Overridden to update DIS specific configuration options.
         virtual void updateConfiguration();

         //! \brief Update the dialog with the initializer's current settings.
         //! Overridden to revert DIS specific configuration options.
         virtual void revertConfiguration();

      protected:

         // Connection Settings.
         QString connectionSettingsProperty;
         QString webServerPortProperty;
         QString useTcpPortProperty;
         QString tcpServerPortProperty;
         QString proxyDestProperty;
         QString proxyPortProperty;
         QString omtFilesProperty;
         QString enableHttpServerProperty;
         QString localHttpDirectoryProperty;
         QString enableHttpProxyProperty;
         QString localNonProxyDirProperty;
         QString enableStatusPageProperty;
         QString sslCertificateProperty;

         // Default Connection Settings.
         static QString theDefaultWebServerPort;
         static int theDefaultTcpServerPort;
         static bool theDefaultUseTcpPort;
         static QString theDefaultProxyDest;
         static int theDefaultProxyPort;
         static QString theDefaultOmtFiles;
         static bool theDefaultEnableHttpServer;
         static QString theDefaultLocalHttpAddress;
         static bool theDefaultEnableHttpProxy;
         static QString theDefaultLocalNonProxyDir;
         static bool theDefaultEnableStatusPage;
         static QString theDefaultSslCertificate;

         MAKCommonWidgets::DtCollectionEditor* myObjCollectionEditor;

      };

   }
}
