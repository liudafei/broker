/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file lockingReflectedObjMgr.h
//! \brief Contains the DtLockingReflectedObjectManager class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <portal/pReflectedObjectManagerTypes.h>
#include <portal/pReflectedObjectManager.h>
#include <Poco/RWLock.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtLockingReflectedObjectManager is a DtPortalReflectedObjectManager with the addition of
      //!        of a locking mechanism to maintain thread safety between clients.
      //!
      template < class T_DtPortalObject >
      class DtLockingReflectedObjectManager
         : public DtPortalReflectedObjectManager<T_DtPortalObject >
      {
      public:

            DtLockingReflectedObjectManager(DtPortalConnection *conn, const bool ignoreFiltering = false )
               : DtPortalReflectedObjectManager<T_DtPortalObject >(conn,ignoreFiltering)
            {
            }

         virtual ~DtLockingReflectedObjectManager() {}

         Poco::RWLock& lock() {return myRWLock;}

         std::map<DtString, T_DtPortalObject *>&  reflectedObjectMap() { return  DtPortalReflectedObjectManager<T_DtPortalObject >::myReflectedObjectMap; }
         virtual void updateObj( const T_DtPortalObject &obj) { this->processUpdate(*obj.sr()); }
         virtual void removeObj( const T_DtPortalObject &obj) { this->processRemoval(*obj.baseObject()); }

      protected:

         Poco::RWLock myRWLock;

      };

   }
}
