/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioTransmitterTranslator.h
//! \brief Contains the DtRadioTransmitterTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#if ! _WIN64
#  ifndef _WIN32_WINNT
#     define _WIN32_WINNT 0x400
#  endif
#endif

#include <broker/brokerObject.h>
#include <portal/pRadioTransmitterObject.h>
#include <webLvcBroker/lvcObjectTranslator.h>
#include <omtReader/datatypeManager.h>
#include <omtReader/omtTree.h>

#define RADIO_XMIT_TEMPLATE_ARGS \
   DtPortalRadioTransmitterObject, DtPortalReflectedRadioTransmitterObject

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtRadioTransmitterTranslator are responsible for translating DtPortalRadio to WebLVC:RadioTransmitter.
      class DT_DLL_WEBLVCBROKER DtRadioTransmitterTranslator
         : public DtLvcObjectTranslator<RADIO_XMIT_TEMPLATE_ARGS>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:RadioTransmitter" );

         //! \brief CTOR.
         DtRadioTransmitterTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtRadioTransmitterTranslator();

         virtual void translate( const Json::Value& source, DtPortalRadioTransmitterObject* destination );
         virtual void translate( const DtPortalRadioTransmitterObject& source, Json::Value* destination );

      protected:

         std::map<DtString,Json::Value> myAdditionalDataMap;
         std::map<DtString,DtString> myNameLookup;

      };

   }
}
