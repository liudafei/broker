/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file tcpClient.cxx
//! \brief Contains the DtTcpClient class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/tcpClient.h>
#include <vlutil/vlNetTypes.h>
#include <vlutil/vlPrint.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtTcpClient::DtTcpClient( Poco::Net::StreamSocket* ws )
         : DtClient()
         , mySocket( *ws )
         , mySocketIsOwned( true )
      {
         myAddressString = mySocket.peerAddress().toString();
      }

      DtTcpClient::DtTcpClient( Poco::Net::StreamSocket& ws )
         : DtClient()
         , mySocket( ws )
         , mySocketIsOwned( false )
      {
         myAddressString = mySocket.peerAddress().toString();
      }

      DtTcpClient::~DtTcpClient()
      {
         if ( mySocketIsOwned )
         {
            delete &mySocket;
         }
      }

      int DtTcpClient::sendFrame( const void* buffer, int length )
      {
         DtNetU32 netLength = (DtU32)length;
         mySocket.sendBytes( &netLength, sizeof(DtNetU32), 0 );
         return mySocket.sendBytes( buffer, length, 0 );
      }

      int DtTcpClient::receiveFrame( void* buffer, int length, int& flags )
      {
         if ( mySocket.available() > 0 )
         {
            // Read the 4-byte integer length of the message content
            int bytesRequested = sizeof(DtNetU32);
            int bytesRemaining = bytesRequested;
            char* ptr = (char*)&(myReceiveBuffer[0]);

            do
            {
               int bytesReceived = mySocket.receiveBytes( ptr + (bytesRequested - bytesRemaining), bytesRemaining, flags );
               if ( bytesReceived < 0 )
               {
                  DtWarn << "DtTCPClient::receiveFrame() - unexpected bytes received: " << bytesReceived << std::endl;
                  return 0;
               }
               bytesRemaining -= bytesReceived;
            } while ( bytesRemaining != 0 );

            // Read in the message content
            DtNetU32* net = (DtNetU32*)ptr;
            DtU32 length = *net;
            bytesRequested = length;
            if ( bytesRequested > 0 )
            {
               if (bytesRequested > myReceiveBuffer.size())
               {
                  //got a message longer than our set buffer length.
                  //resize buffer
                  div_t ratio = div(bytesRequested, length);
                  size_t newSize = myReceiveBuffer.size() * (ratio.quot + 1);
                  //Make sure newSize is below maximum size limit
                  if (newSize > myReceiveBuffer.max_size())
                  {
                     return 0;
                  }
                  myReceiveBuffer.resize(newSize);

               }
               bytesRemaining = bytesRequested;
               char* ptr = (char*)&(myReceiveBuffer[0]);
               do
               {
                  int bytesReceived = mySocket.receiveBytes(ptr + (bytesRequested - bytesRemaining), bytesRemaining, flags);
                  if ( bytesReceived < 0 )
                  {
                     DtWarn << "DtTCPClient::receiveFrame() - unexpected bytes received: " << bytesReceived << std::endl;
                     return 0;
                  }
                  bytesRemaining -= bytesReceived;
               } while ( bytesRemaining != 0 );

               return bytesRequested;
            }
            else
            {
               DtWarn << "DtTCPClient::receiveFrame() - Invalid frame length " << bytesRequested << std::endl;
               return 0;
            }
         }

         return 0;
      }

   }
}
