/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file httpRequestHandlerFactory.h
//! \brief Contains the DtHttpRequestHandlerFactory class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <Poco/Net/HTTPRequestHandlerFactory.h>

class Poco::Net::HTTPServerRequest;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief Class DtRequestHandlerFactory extends the base
      //! factory for handling HTTP requests to handle requests for web sockets
      //! using the WebSocketRequestHandler class.
      class DT_DLL_WEBLVCBROKER DtHttpRequestHandlerFactory
         : public Poco::Net::HTTPRequestHandlerFactory
      {
      public:

         //! \brief CTOR.
         DtHttpRequestHandlerFactory();

         //! \brief Virtual DTOR.
         virtual ~DtHttpRequestHandlerFactory();

         //! If incoming request is of type '/ws', return a new WebSocketRequestHandler.
         //! Otherwise, call down to base class to create build-in handler.
         Poco::Net::HTTPRequestHandler* createRequestHandler(
            const Poco::Net::HTTPServerRequest& request );

      };

   }
}
