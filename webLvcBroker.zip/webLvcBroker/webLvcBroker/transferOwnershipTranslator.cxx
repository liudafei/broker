/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file transferOwnershipTranslator.cxx
//! \brief Contains the DtTransferOwnershipTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/transferOwnershipTranslator.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtTransferOwnershipTranslator::DtTransferOwnershipTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtTransferControlInteractionKind )
      {
      }

      DtTransferOwnershipTranslator::~DtTransferOwnershipTranslator()
      {
      }

      void DtTransferOwnershipTranslator::translate( const Json::Value& source,
         DtPortalTransferControlInteraction* destination )
      {
         Json::Value a(Json::arrayValue);
         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         Json::Value v = source.get("OriginatingEntity",a);
         DtEntityIdentifier eid( v[0u].asInt(),v[1].asInt(),v[2].asInt() );
         destination->setOriginatingEntity( eid.string() );

         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         v = source.get("ReceivingEntity",a);
         eid.setSite( v[0u].asInt() );
         eid.setHost( v[1].asInt() );
         eid.setEntityNum( v[2].asInt() );
         destination->setReceivingEntity( eid.string() );

         destination->setRequestIdentifier(source.get("RequestIdentifier",0).asUInt());

         a[0u] = -1;
         a[1u] = -1;
         a[2u] = -1;
         v = source.get("TransferEntity",a);
         eid.setSite( v[0u].asInt() );
         eid.setHost( v[1].asInt() );
         eid.setEntityNum( v[2].asInt() );
         destination->setTransferredEntityID( eid.string() );
         destination->setTransferType(source.get("TransferType", 0).asUInt());
      }

      void DtTransferOwnershipTranslator::translate( const DtPortalTransferControlInteraction& source,
         Json::Value* destination )
      {
         // TODO
      }

   }
}
