/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file baseWebLvcObjectTranslator.h
//! \brief Contains the DtBaseWebLvcObjectTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <broker/baseObjectTranslator.h>
#include <Poco/RWLock.h>
#include <json/json.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      class DtClient;
      class DtWebLvcBroker;

      //! \brief DtBaseObjectTranslators are responsible for translating
      //! messages for things that have state. To this end the DtBrokerObject
      //! class is used to represent these objects with state.
      class DT_DLL_WEBLVCBROKER DtBaseWebLvcObjectTranslator : public DtObjectTranslator
      {
      public:

         //! \brief The Default CTOR
         DtBaseWebLvcObjectTranslator( DtBroker* broker, const DtString& name, DtPortalMessageKind kind );

         //! \brief The Default DTOR
         virtual ~DtBaseWebLvcObjectTranslator();

         // for each id in the update set create a msg and pass it to the broker
         virtual int processUpdateSet( void* id );
         virtual void createUpdateSet( void* id );

         //! Notification that a client is beiong removed, translator may need to delete
         //! objects related to a specific client
         virtual void processClientRemoval( DtClient* );

         //! when a new client is added a translator is asked to send a full update to
         //! that specific client.  This method creates all the state messages for this
         //! client
         virtual void createFullStateMsgs( std::list<std::string>& msgs, DtClient* forClient ) = 0;

         //! Called for incoming WebLVC messages that have been registered for
         virtual void processMsg( Json::Value* msg, DtClient* client );

         virtual Poco::RWLock* lock();

         //! called when a registered portal object is removed.
         virtual void removeClientObject( const std::string& refObj );

         //! called when building the status html page
         virtual DtString status();

         virtual DtWebLvcBroker* webLvcBroker();

      protected:

         typedef std::set<DtString> StringSet;
         typedef std::map<void*,StringSet> UpdateSetMap;
         UpdateSetMap myLvcUpdateSet;

      };

   }
}
