/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file weaponFireTranslator.h
//! \brief Contains the DtWeaponFireTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <webLvcBroker/lvcInteractionTranslator.h>
#include <portal/pFireInter.h>
#include <string>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtWeaponFireTranslator are responsible for translating DtPortalFireInteraction to WebLVC:WeaponFire.
      class DT_DLL_WEBLVCBROKER DtWeaponFireTranslator : public DtLvcInteractionTranslator<DtPortalFireInteraction>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:WeaponFire" );

         //! \brief CTOR.
         DtWeaponFireTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtWeaponFireTranslator();

         // Your translator must implement the translate functions.
         virtual void translate( const Json::Value& source, DtPortalFireInteraction* destination );
         virtual void translate( const DtPortalFireInteraction& source, Json::Value* destination );

      };

   }
}
