/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file localHandler.cxx
//! \brief Contains the DtLocalRequestHandler class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/localHandler.h>
#include <webLvcBroker/webLvcBroker.h>
#include <webLvcBroker/webSocketClient.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <Poco/Net/HTTPServerResponse.h>
#include <Poco/Net/HTTPServerRequest.h>
#include <Poco/Net/HTTPClientSession.h>
#include <Poco/Net/NetException.h>
#include <Poco/StreamCopier.h>
#include <Poco/RWLock.h>
#include <vlutil/vlPrint.h>
#include <sys/stat.h>
#include <iostream>
#include <stdio.h>

using Poco::Net::HTTPRequestHandler;
using Poco::Net::HTTPServerResponse;
using Poco::Net::WebSocketException;
using Poco::Net::HTTPClientSession;
using Poco::Net::HTTPServerRequest;
using Poco::Net::HTTPResponse;
using Poco::Net::HTTPRequest;
using Poco::Net::WebSocket;
using Poco::StreamCopier;
using Poco::Timestamp;
using Poco::RWLock;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtLocalRequestHandler::DtLocalRequestHandler()
         : HTTPRequestHandler()
         , myURI()
         , myMimetypesMap()
      {
      }

      DtLocalRequestHandler::DtLocalRequestHandler( const std::string& URI )
         : HTTPRequestHandler()
         , myURI( URI )
         , myMimetypesMap()
      {
         myMimetypesMap["3d"] = "x-world/x-3dmf";
         myMimetypesMap["3dmf"] = "x-world/x-3dmf";
         myMimetypesMap["a"] = "application/octet-stream";
         myMimetypesMap["aab"] = "application/x-authorware-bin";
         myMimetypesMap["aam"] = "application/x-authorware-map";
         myMimetypesMap["aas"] = "application/x-authorware-seg";
         myMimetypesMap["abc"] = "text/vnd.abc";
         myMimetypesMap["acgi"] = "text/html";
         myMimetypesMap["afl"] = "video/animaflex";
         myMimetypesMap["ai"] = "application/postscript";
         myMimetypesMap["aif"] = "audio/aiff";
         myMimetypesMap["aifc"] = "audio/aiff";
         myMimetypesMap["aiff"] = "audio/aiff";
         myMimetypesMap["aim"] = "application/x-aim";
         myMimetypesMap["aip"] = "text/x-audiosoft-intra";
         myMimetypesMap["ani"] = "application/x-navi-animation";
         myMimetypesMap["aos"] = "application/x-nokia-9000-communicator-add-on-software";
         myMimetypesMap["aps"] = "application/mime";
         myMimetypesMap["arc"] = "application/octet-stream";
         myMimetypesMap["arj"] = "application/arj";
         myMimetypesMap["art"] = "image/x-jg";
         myMimetypesMap["asf"] = "video/x-ms-asf";
         myMimetypesMap["asm"] = "text/x-asm";
         myMimetypesMap["asp"] = "text/asp";
         myMimetypesMap["asx"] = "application/x-mplayer2";
         myMimetypesMap["asx"] = "video/x-ms-asf";
         myMimetypesMap["au"] = "audio/basic";
         myMimetypesMap["avi"] = "video/avi";
         myMimetypesMap["avs"] = "video/avs-video";
         myMimetypesMap["bcpio"] = "application/x-bcpio";
         myMimetypesMap["bin"] = "application/octet-stream";
         myMimetypesMap["bm"] = "image/bmp";
         myMimetypesMap["bmp"] = "image/bmp";
         myMimetypesMap["boo"] = "application/book";
         myMimetypesMap["book"] = "application/book";
         myMimetypesMap["boz"] = "application/x-bzip2";
         myMimetypesMap["bsh"] = "application/x-bsh";
         myMimetypesMap["bz"] = "application/x-bzip";
         myMimetypesMap["bz2"] = "application/x-bzip2";
         myMimetypesMap["c"] = "text/plain";
         myMimetypesMap["c++"] = "text/plain";
         myMimetypesMap["cat"] = "application/vnd.ms-pki.seccat";
         myMimetypesMap["cc"] = "text/plain";
         myMimetypesMap["ccad"] = "application/clariscad";
         myMimetypesMap["cco"] = "application/x-cocoa";
         myMimetypesMap["cdf"] = "application/cdf";
         myMimetypesMap["cer"] = "application/pkix-cert";
         myMimetypesMap["cha"] = "application/x-chat";
         myMimetypesMap["chat"] = "application/x-chat";
         myMimetypesMap["class"] = "application/java";
         myMimetypesMap["com"] = "text/plain";
         myMimetypesMap["conf"] = "text/plain";
         myMimetypesMap["cpio"] = "application/x-cpio";
         myMimetypesMap["cpp"] = "text/x-c";
         myMimetypesMap["cpt"] = "application/mac-compactpro";
         myMimetypesMap["crl"] = "application/pkcs-crl";
         myMimetypesMap["crt"] = "application/pkix-cert";
         myMimetypesMap["csh"] = "text/x-script.csh";
         myMimetypesMap["css"] = "text/css";
         myMimetypesMap["cxx"] = "text/plain";
         myMimetypesMap["dcr"] = "application/x-director";
         myMimetypesMap["deepv"] = "application/x-deepv";
         myMimetypesMap["def"] = "text/plain";
         myMimetypesMap["der"] = "application/x-x509-ca-cert";
         myMimetypesMap["dif"] = "video/x-dv";
         myMimetypesMap["dir"] = "application/x-director";
         myMimetypesMap["dl"] = "video/dl";
         myMimetypesMap["doc"] = "application/msword";
         myMimetypesMap["dot"] = "application/msword";
         myMimetypesMap["dp"] = "application/commonground";
         myMimetypesMap["drw"] = "application/drafting";
         myMimetypesMap["dump"] = "application/octet-stream";
         myMimetypesMap["dv"] = "video/x-dv";
         myMimetypesMap["dvi"] = "application/x-dvi";
         myMimetypesMap["dwf"] = "model/vnd.dwf";
         myMimetypesMap["dwg"] = "application/acad";
         myMimetypesMap["dxf"] = "application/dxf";
         myMimetypesMap["dxr"] = "application/x-director";
         myMimetypesMap["el"] = "text/x-script.elisp";
         myMimetypesMap["elc"] = "application/x-elc";
         myMimetypesMap["env"] = "application/x-envoy";
         myMimetypesMap["eps"] = "application/postscript";
         myMimetypesMap["es"] = "application/x-esrehber";
         myMimetypesMap["etx"] = "text/x-setext";
         myMimetypesMap["evy"] = "application/envoy";
         myMimetypesMap["evy"] = "application/x-envoy";
         myMimetypesMap["exe"] = "application/octet-stream";
         myMimetypesMap["f"] = "text/plain";
         myMimetypesMap["f77"] = "text/x-fortran";
         myMimetypesMap["f90"] = "text/plain";
         myMimetypesMap["fdf"] = "application/vnd.fdf";
         myMimetypesMap["fif"] = "image/fif";
         myMimetypesMap["fli"] = "video/fli";
         myMimetypesMap["flo"] = "image/florian";
         myMimetypesMap["flx"] = "text/vnd.fmi.flexstor";
         myMimetypesMap["fmf"] = "video/x-atomic3d-feature";
         myMimetypesMap["for"] = "text/plain";
         myMimetypesMap["fpx"] = "image/vnd.fpx";
         myMimetypesMap["frl"] = "application/freeloader";
         myMimetypesMap["funk"] = "audio/make";
         myMimetypesMap["g"] = "text/plain";
         myMimetypesMap["g3"] = "image/g3fax";
         myMimetypesMap["gif"] = "image/gif";
         myMimetypesMap["gl"] = "video/gl";
         myMimetypesMap["gsd"] = "audio/x-gsm";
         myMimetypesMap["gsm"] = "audio/x-gsm";
         myMimetypesMap["gsp"] = "application/x-gsp";
         myMimetypesMap["gss"] = "application/x-gss";
         myMimetypesMap["gtar"] = "application/x-gtar";
         myMimetypesMap["gz"] = "application/x-gzip";
         myMimetypesMap["gzip"] = "application/x-gzip";
         myMimetypesMap["h"] = "text/plain";
         myMimetypesMap["hdf"] = "application/x-hdf";
         myMimetypesMap["help"] = "application/x-helpfile";
         myMimetypesMap["hgl"] = "application/vnd.hp-hpgl";
         myMimetypesMap["hh"] = "text/plain";
         myMimetypesMap["hlb"] = "text/x-script";
         myMimetypesMap["hlp"] = "application/hlp";
         myMimetypesMap["hpg"] = "application/vnd.hp-hpgl";
         myMimetypesMap["hpgl"] = "application/vnd.hp-hpgl";
         myMimetypesMap["hqx"] = "application/binhex";
         myMimetypesMap["hta"] = "application/hta";
         myMimetypesMap["htc"] = "text/x-component";
         myMimetypesMap["htm"] = "text/html";
         myMimetypesMap["html"] = "text/html";
         myMimetypesMap["htmls"] = "text/html";
         myMimetypesMap["htt"] = "text/webviewhtml";
         myMimetypesMap["htx"] = "text/html";
         myMimetypesMap["ice"] = "x-conference/x-cooltalk";
         myMimetypesMap["ico"] = "image/x-icon";
         myMimetypesMap["idc"] = "text/plain";
         myMimetypesMap["ief"] = "image/ief";
         myMimetypesMap["iefs"] = "image/ief";
         myMimetypesMap["iges"] = "application/iges";
         myMimetypesMap["igs"] = "application/iges";
         myMimetypesMap["ima"] = "application/x-ima";
         myMimetypesMap["imap"] = "application/x-httpd-imap";
         myMimetypesMap["inf"] = "application/inf";
         myMimetypesMap["ins"] = "application/x-internett-signup";
         myMimetypesMap["ip"] = "application/x-ip2";
         myMimetypesMap["isu"] = "video/x-isvideo";
         myMimetypesMap["it"] = "audio/it";
         myMimetypesMap["iv"] = "application/x-inventor";
         myMimetypesMap["ivr"] = "i-world/i-vrml";
         myMimetypesMap["ivy"] = "application/x-livescreen";
         myMimetypesMap["jam"] = "audio/x-jam";
         myMimetypesMap["jav"] = "text/plain";
         myMimetypesMap["java"] = "text/plain";
         myMimetypesMap["jcm"] = "application/x-java-commerce";
         myMimetypesMap["jfif"] = "image/jpeg";
         myMimetypesMap["jfif-tbnl"] = "image/jpeg";
         myMimetypesMap["jpe"] = "image/jpeg";
         myMimetypesMap["jpeg"] = "image/jpeg";
         myMimetypesMap["jpg"] = "image/jpeg";
         myMimetypesMap["jps"] = "image/x-jps";
         myMimetypesMap["js"] = "application/x-javascript";
         myMimetypesMap["json"] = "text/json";
         myMimetypesMap["jut"] = "image/jutvision";
         myMimetypesMap["kar"] = "audio/midi";
         myMimetypesMap["kmz"] = "application/vnd.google-earth.kmz";
         myMimetypesMap["ksh"] = "text/x-script.ksh";
         myMimetypesMap["la"] = "audio/nspaudio";
         myMimetypesMap["lam"] = "audio/x-liveaudio";
         myMimetypesMap["latex"] = "application/x-latex";
         myMimetypesMap["lha"] = "application/lha";
         myMimetypesMap["lhx"] = "application/octet-stream";
         myMimetypesMap["list"] = "text/plain";
         myMimetypesMap["lma"] = "audio/nspaudio";
         myMimetypesMap["log"] = "text/plain";
         myMimetypesMap["lsp"] = "application/x-lisp";
         myMimetypesMap["lst"] = "text/plain";
         myMimetypesMap["lsx"] = "text/x-la-asf";
         myMimetypesMap["ltx"] = "application/x-latex";
         myMimetypesMap["lzh"] = "application/octet-stream";
         myMimetypesMap["lzx"] = "application/lzx";
         myMimetypesMap["m"] = "text/plain";
         myMimetypesMap["m1v"] = "video/mpeg";
         myMimetypesMap["m2a"] = "audio/mpeg";
         myMimetypesMap["m2v"] = "video/mpeg";
         myMimetypesMap["m3u"] = "audio/x-mpequrl";
         myMimetypesMap["man"] = "application/x-troff-man";
         myMimetypesMap["map"] = "application/x-navimap";
         myMimetypesMap["mar"] = "text/plain";
         myMimetypesMap["mbd"] = "application/mbedlet";
         myMimetypesMap["mc$"] = "application/x-magic-cap-package-1.0";
         myMimetypesMap["mcd"] = "application/mcad";
         myMimetypesMap["mcf"] = "text/mcf";
         myMimetypesMap["mcp"] = "application/netmc";
         myMimetypesMap["me"] = "application/x-troff-me";
         myMimetypesMap["mht"] = "message/rfc822";
         myMimetypesMap["mhtml"] = "message/rfc822";
         myMimetypesMap["mid"] = "audio/midi";
         myMimetypesMap["midi"] = "audio/midi";
         myMimetypesMap["mif"] = "application/x-mif";
         myMimetypesMap["mime"] = "www/mime";
         myMimetypesMap["mjf"] = "audio/x-vnd.audioexplosion.mjuicemediafile";
         myMimetypesMap["mjpg"] = "video/x-motion-jpeg";
         myMimetypesMap["mm"] = "application/base64";
         myMimetypesMap["mme"] = "application/base64";
         myMimetypesMap["mod"] = "audio/mod";
         myMimetypesMap["moov"] = "video/quicktime";
         myMimetypesMap["mov"] = "video/quicktime";
         myMimetypesMap["movie"] = "video/x-sgi-movie";
         myMimetypesMap["mp2"] = "video/mpeg";
         myMimetypesMap["mp3"] = "audio/mpeg3";
         myMimetypesMap["mpa"] = "audio/mpeg";
         myMimetypesMap["mpc"] = "application/x-project";
         myMimetypesMap["mpe"] = "video/mpeg";
         myMimetypesMap["mpeg"] = "video/mpeg";
         myMimetypesMap["mpg"] = "video/mpeg";
         myMimetypesMap["mpga"] = "audio/mpeg";
         myMimetypesMap["mpp"] = "application/vnd.ms-project";
         myMimetypesMap["mpt"] = "application/x-project";
         myMimetypesMap["mpv"] = "application/x-project";
         myMimetypesMap["mpx"] = "application/x-project";
         myMimetypesMap["mrc"] = "application/marc";
         myMimetypesMap["ms"] = "application/x-troff-ms";
         myMimetypesMap["mv"] = "video/x-sgi-movie";
         myMimetypesMap["my"] = "audio/make";
         myMimetypesMap["mzz"] = "application/x-vnd.audioexplosion.mzz";
         myMimetypesMap["nap"] = "image/naplps";
         myMimetypesMap["naplps"] = "image/naplps";
         myMimetypesMap["nc"] = "application/x-netcdf";
         myMimetypesMap["ncm"] = "application/vnd.nokia.configuration-message";
         myMimetypesMap["nif"] = "image/x-niff";
         myMimetypesMap["niff"] = "image/x-niff";
         myMimetypesMap["nix"] = "application/x-mix-transfer";
         myMimetypesMap["nsc"] = "application/x-conference";
         myMimetypesMap["nvd"] = "application/x-navidoc";
         myMimetypesMap["o"] = "application/octet-stream";
         myMimetypesMap["oda"] = "application/oda";
         myMimetypesMap["omc"] = "application/x-omc";
         myMimetypesMap["omcd"] = "application/x-omcdatamaker";
         myMimetypesMap["omcr"] = "application/x-omcregerator";
         myMimetypesMap["p"] = "text/x-pascal";
         myMimetypesMap["p10"] = "application/pkcs10";
         myMimetypesMap["p12"] = "application/pkcs-12";
         myMimetypesMap["p7a"] = "application/x-pkcs7-signature";
         myMimetypesMap["p7c"] = "application/pkcs7-mime";
         myMimetypesMap["p7m"] = "application/pkcs7-mime";
         myMimetypesMap["p7r"] = "application/x-pkcs7-certreqresp";
         myMimetypesMap["p7s"] = "application/pkcs7-signature";
         myMimetypesMap["part"] = "application/pro_eng";
         myMimetypesMap["pas"] = "text/pascal";
         myMimetypesMap["pbm"] = "image/x-portable-bitmap";
         myMimetypesMap["pcl"] = "application/vnd.hp-pcl";
         myMimetypesMap["pct"] = "image/x-pict";
         myMimetypesMap["pcx"] = "image/x-pcx";
         myMimetypesMap["pdb"] = "chemical/x-pdb";
         myMimetypesMap["pdf"] = "application/pdf";
         myMimetypesMap["pfunk"] = "audio/make";
         myMimetypesMap["pgm"] = "image/x-portable-graymap";
         myMimetypesMap["pic"] = "image/pict";
         myMimetypesMap["pict"] = "image/pict";
         myMimetypesMap["pkg"] = "application/x-newton-compatible-pkg";
         myMimetypesMap["pko"] = "application/vnd.ms-pki.pko";
         myMimetypesMap["pl"] = "text/plain";
         myMimetypesMap["plx"] = "application/x-pixclscript";
         myMimetypesMap["pm"] = "image/x-xpixmap";
         myMimetypesMap["pm4"] = "application/x-pagemaker";
         myMimetypesMap["pm5"] = "application/x-pagemaker";
         myMimetypesMap["png"] = "image/png";
         myMimetypesMap["pnm"] = "image/x-portable-anymap";
         myMimetypesMap["pot"] = "application/mspowerpoint";
         myMimetypesMap["pov"] = "model/x-pov";
         myMimetypesMap["ppa"] = "application/vnd.ms-powerpoint";
         myMimetypesMap["ppm"] = "image/x-portable-pixmap";
         myMimetypesMap["pps"] = "application/mspowerpoint";
         myMimetypesMap["ppt"] = "application/mspowerpoint";
         myMimetypesMap["ppz"] = "application/mspowerpoint";
         myMimetypesMap["pre"] = "application/x-freelance";
         myMimetypesMap["prt"] = "application/pro_eng";
         myMimetypesMap["ps"] = "application/postscript";
         myMimetypesMap["psd"] = "application/octet-stream";
         myMimetypesMap["pvu"] = "paleovu/x-pv";
         myMimetypesMap["pwz"] = "application/vnd.ms-powerpoint";
         myMimetypesMap["py"] = "text/x-script.phyton";
         myMimetypesMap["pyc"] = "applicaiton/x-bytecode.python";
         myMimetypesMap["qcp"] = "audio/vnd.qcelp";
         myMimetypesMap["qd3"] = "x-world/x-3dmf";
         myMimetypesMap["qd3d"] = "x-world/x-3dmf";
         myMimetypesMap["qif"] = "image/x-quicktime";
         myMimetypesMap["qt"] = "video/quicktime";
         myMimetypesMap["qtc"] = "video/x-qtc";
         myMimetypesMap["qti"] = "image/x-quicktime";
         myMimetypesMap["qtif"] = "image/x-quicktime";
         myMimetypesMap["ra"] = "audio/x-realaudio";
         myMimetypesMap["ram"] = "audio/x-pn-realaudio";
         myMimetypesMap["ras"] = "image/cmu-raster";
         myMimetypesMap["rast"] = "image/cmu-raster";
         myMimetypesMap["rexx"] = "text/x-script.rexx";
         myMimetypesMap["rf"] = "image/vnd.rn-realflash";
         myMimetypesMap["rgb"] = "image/x-rgb";
         myMimetypesMap["rm"] = "application/vnd.rn-realmedia";
         myMimetypesMap["rmi"] = "audio/mid";
         myMimetypesMap["rmm"] = "audio/x-pn-realaudio";
         myMimetypesMap["rmp"] = "audio/x-pn-realaudio";
         myMimetypesMap["rng"] = "application/ringing-tones";
         myMimetypesMap["rnx"] = "application/vnd.rn-realplayer";
         myMimetypesMap["roff"] = "application/x-troff";
         myMimetypesMap["rp"] = "image/vnd.rn-realpix";
         myMimetypesMap["rpm"] = "audio/x-pn-realaudio-plugin";
         myMimetypesMap["rt"] = "text/richtext";
         myMimetypesMap["rtf"] = "application/rtf";
         myMimetypesMap["rtx"] = "application/rtf";
         myMimetypesMap["rv"] = "video/vnd.rn-realvideo";
         myMimetypesMap["s"] = "text/x-asm";
         myMimetypesMap["s3m"] = "audio/s3m";
         myMimetypesMap["saveme"] = "application/octet-stream";
         myMimetypesMap["sbk"] = "application/x-tbook";
         myMimetypesMap["scm"] = "application/x-lotusscreencam";
         myMimetypesMap["sdml"] = "text/plain";
         myMimetypesMap["sdp"] = "application/sdp";
         myMimetypesMap["sdr"] = "application/sounder";
         myMimetypesMap["sea"] = "application/sea";
         myMimetypesMap["set"] = "application/set";
         myMimetypesMap["sgm"] = "text/sgml";
         myMimetypesMap["sgml"] = "text/sgml";
         myMimetypesMap["sh"] = "application/x-sh";
         myMimetypesMap["shar"] = "application/x-shar";
         myMimetypesMap["shtml"] = "text/html";
         myMimetypesMap["sid"] = "audio/x-psid";
         myMimetypesMap["sit"] = "application/x-sit";
         myMimetypesMap["skd"] = "application/x-koan";
         myMimetypesMap["skm"] = "application/x-koan";
         myMimetypesMap["skp"] = "application/x-koan";
         myMimetypesMap["skt"] = "application/x-koan";
         myMimetypesMap["sl"] = "application/x-seelogo";
         myMimetypesMap["smi"] = "application/smil";
         myMimetypesMap["smil"] = "application/smil";
         myMimetypesMap["snd"] = "audio/basic";
         myMimetypesMap["sol"] = "application/solids";
         myMimetypesMap["spc"] = "application/x-pkcs7-certificates";
         myMimetypesMap["spl"] = "application/futuresplash";
         myMimetypesMap["spr"] = "application/x-sprite";
         myMimetypesMap["sprite"] = "application/x-sprite";
         myMimetypesMap["src"] = "application/x-wais-source";
         myMimetypesMap["ssi"] = "text/x-server-parsed-html";
         myMimetypesMap["ssm"] = "application/streamingmedia";
         myMimetypesMap["sst"] = "application/vnd.ms-pki.certstore";
         myMimetypesMap["step"] = "application/step";
         myMimetypesMap["stl"] = "application/sla";
         myMimetypesMap["stp"] = "application/step";
         myMimetypesMap["sv4cpio"] = "application/x-sv4cpio";
         myMimetypesMap["sv4crc"] = "application/x-sv4crc";
         myMimetypesMap["svf"] = "image/vnd.dwg";
         myMimetypesMap["svr"] = "application/x-world";
         myMimetypesMap["svg"] = "image/svg+xml";
         myMimetypesMap["swf"] = "application/x-shockwave-flash";
         myMimetypesMap["t"] = "application/x-troff";
         myMimetypesMap["talk"] = "text/x-speech";
         myMimetypesMap["tar"] = "application/x-tar";
         myMimetypesMap["tbk"] = "application/toolbook";
         myMimetypesMap["tcl"] = "application/x-tcl";
         myMimetypesMap["tcsh"] = "text/x-script.tcsh";
         myMimetypesMap["tex"] = "application/x-tex";
         myMimetypesMap["texi"] = "application/x-texinfo";
         myMimetypesMap["texinfo"] = "application/x-texinfo";
         myMimetypesMap["text"] = "text/plain";
         myMimetypesMap["tgz"] = "application/gnutar";
         myMimetypesMap["tif"] = "image/tiff";
         myMimetypesMap["tiff"] = "image/tiff";
         myMimetypesMap["tr"] = "application/x-troff";
         myMimetypesMap["tsi"] = "audio/tsp-audio";
         myMimetypesMap["tsp"] = "application/dsptype";
         myMimetypesMap["tsv"] = "text/tab-separated-values";
         myMimetypesMap["ttf"] = "application/x-font-ttf";
         myMimetypesMap["turbot"] = "image/florian";
         myMimetypesMap["txt"] = "text/plain";
         myMimetypesMap["uil"] = "text/x-uil";
         myMimetypesMap["uni"] = "text/uri-list";
         myMimetypesMap["unis"] = "text/uri-list";
         myMimetypesMap["unv"] = "application/i-deas";
         myMimetypesMap["uri"] = "text/uri-list";
         myMimetypesMap["uris"] = "text/uri-list";
         myMimetypesMap["ustar"] = "application/x-ustar";
         myMimetypesMap["uu"] = "text/x-uuencode";
         myMimetypesMap["uue"] = "text/x-uuencode";
         myMimetypesMap["vcd"] = "application/x-cdlink";
         myMimetypesMap["vcs"] = "text/x-vcalendar";
         myMimetypesMap["vda"] = "application/vda";
         myMimetypesMap["vdo"] = "video/vdo";
         myMimetypesMap["vew"] = "application/groupwise";
         myMimetypesMap["viv"] = "video/vivo";
         myMimetypesMap["vivo"] = "video/vivo";
         myMimetypesMap["vmd"] = "application/vocaltec-media-desc";
         myMimetypesMap["vmf"] = "application/vocaltec-media-file";
         myMimetypesMap["voc"] = "audio/voc";
         myMimetypesMap["vos"] = "video/vosaic";
         myMimetypesMap["vox"] = "audio/voxware";
         myMimetypesMap["vqe"] = "audio/x-twinvq-plugin";
         myMimetypesMap["vqf"] = "audio/x-twinvq";
         myMimetypesMap["vql"] = "audio/x-twinvq-plugin";
         myMimetypesMap["vrml"] = "model/vrml";
         myMimetypesMap["vrt"] = "x-world/x-vrt";
         myMimetypesMap["vsd"] = "application/x-visio";
         myMimetypesMap["w60"] = "application/wordperfect6.0";
         myMimetypesMap["w61"] = "application/wordperfect6.1";
         myMimetypesMap["w6w"] = "application/msword";
         myMimetypesMap["wav"] = "audio/wav";
         myMimetypesMap["wb1"] = "application/x-qpro";
         myMimetypesMap["wbmp"] = "image/vnd.wap.wbmp";
         myMimetypesMap["web"] = "application/vnd.xara";
         myMimetypesMap["wiz"] = "application/msword";
         myMimetypesMap["wk1"] = "application/x-123";
         myMimetypesMap["wmf"] = "windows/metafile";
         myMimetypesMap["wml"] = "text/vnd.wap.wml";
         myMimetypesMap["wmlc"] = "application/vnd.wap.wmlc";
         myMimetypesMap["wmls"] = "text/vnd.wap.wmlscript";
         myMimetypesMap["wmlsc"] = "application/vnd.wap.wmlscriptc";
         myMimetypesMap["word"] = "application/msword";
         myMimetypesMap["wp"] = "application/wordperfect";
         myMimetypesMap["wp5"] = "application/wordperfect";
         myMimetypesMap["wp6"] = "application/wordperfect";
         myMimetypesMap["wpd"] = "application/wordperfect";
         myMimetypesMap["wq1"] = "application/x-lotus";
         myMimetypesMap["wri"] = "application/mswrite";
         myMimetypesMap["wrl"] = "model/vrml";
         myMimetypesMap["wrz"] = "model/vrml";
         myMimetypesMap["wsc"] = "text/scriplet";
         myMimetypesMap["wsrc"] = "application/x-wais-source";
         myMimetypesMap["wtk"] = "application/x-wintalk";
         myMimetypesMap["xbm"] = "image/xbm";
         myMimetypesMap["xdr"] = "video/x-amt-demorun";
         myMimetypesMap["xgz"] = "xgl/drawing";
         myMimetypesMap["xif"] = "image/vnd.xiff";
         myMimetypesMap["xl"] = "application/excel";
         myMimetypesMap["xla"] = "application/excel";
         myMimetypesMap["xlb"] = "application/excel";
         myMimetypesMap["xlc"] = "application/excel";
         myMimetypesMap["xld"] = "application/excel";
         myMimetypesMap["xlk"] = "application/excel";
         myMimetypesMap["xll"] = "application/excel";
         myMimetypesMap["xlm"] = "application/excel";
         myMimetypesMap["xls"] = "application/excel";
         myMimetypesMap["xlt"] = "application/excel";
         myMimetypesMap["xlv"] = "application/excel";
         myMimetypesMap["xlw"] = "application/excel";
         myMimetypesMap["xm"] = "audio/xm";
         myMimetypesMap["xml"] = "text/xml";
         myMimetypesMap["xmz"] = "xgl/movie";
         myMimetypesMap["xpix"] = "application/x-vnd.ls-xpix";
         myMimetypesMap["xpm"] = "image/xpm";
         myMimetypesMap["x-png"] = "image/png";
         myMimetypesMap["xsr"] = "video/x-amt-showrun";
         myMimetypesMap["xwd"] = "image/x-xwd";
         myMimetypesMap["xyz"] = "chemical/x-pdb";
         myMimetypesMap["z"] = "application/x-compressed";
         myMimetypesMap["zip"] = "application/zip";
         myMimetypesMap["zoo"] = "application/octet-stream";
         myMimetypesMap["zsh"] = "text/x-script.zsh";
      }

      DtLocalRequestHandler::~DtLocalRequestHandler()
      {
      }

      void DtLocalRequestHandler::handleRequest( HTTPServerRequest& request,
         HTTPServerResponse& response )
      {
         bool stripNonProxyDir = DtWebLvcBrokerInitializer::localNonProxyDir().size() &&
            DtWebLvcBrokerInitializer::enableHttpProxy();
         try
         {
            if (stripNonProxyDir)
            {
               myURI.erase(0, DtWebLvcBrokerInitializer::localNonProxyDir().size() + 1); //remove the /local

               // make sure there is no shenanigans
               while (myURI.compare(0, 3, "/..") == 0 || myURI.compare(0, 3, "../") == 0)
               {
                  myURI.erase(0, 3);
               }
            }

            //strip url params
            unsigned pos = myURI.find( '?' );
            if ( pos != std::string::npos ) myURI = myURI.substr( 0, pos );
            pos = myURI.find( '#' );
            if ( pos != std::string::npos ) myURI = myURI.substr( 0, pos );

            std::string theFile = std::string( DtWebLvcBrokerInitializer::localHttpDirectory() ) + myURI;

            response.setStatus( HTTPResponse::HTTP_OK );

            response.set( "Cache-Control", "max-age=3600" );
            response.set( "Access-Control-Allow-Origin", "*" );
            DtFilename f( theFile.c_str() );

            // test if its a dir and if it is add index.html to it
            struct stat st;
            stat( f.c_str(), &st );
            if ( st.st_mode & S_IFDIR )
            {
               if ( myURI[myURI.size() - 1] != '/' )
               {
                  std::string tempuri = myURI;
                  if (stripNonProxyDir)
                  {
                     tempuri = std::string("/" + DtWebLvcBrokerInitializer::localNonProxyDir().size()) + tempuri;
                  }
                  response.setStatus( HTTPResponse::HTTP_MOVED_PERMANENTLY );
                  response.set( "Location", tempuri + std::string( "/" ) );
                  std::ostream& out = response.send();
                  out.flush();
                  return;
               }
            }

            if ( theFile[theFile.size() - 1] == '/' )
            {
               f += "index.html";
            }

            if ( stat( f.c_str(), &st ) != 0 )
            {
               response.setStatus( HTTPResponse::HTTP_NOT_FOUND );
               DtWarn( "localHandler %s file not found\n", f.c_str() );
               std::ostream& out = response.send();
               out.flush();
               return;
            }

            DtString ext = f.extension();
            ext.toLower();

            response.setContentType( myMimetypesMap[ext.c_str()] );

            std::ostream& out = response.send();

            std::ifstream fileStream( f.c_str(), std::ios::binary );

            Poco::StreamCopier::copyStream( fileStream, out );

            out.flush();

         }
         catch ( Poco::Exception & )
         {
            return;
         }
         catch ( ... )
         {
         }
      }
   }
}
