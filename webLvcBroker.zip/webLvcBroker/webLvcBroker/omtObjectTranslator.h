/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file omtObjectTranslator.h
//! \brief Contains the DtOmtObjectTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#if ! _WIN64
#  ifndef _WIN32_WINNT
#     define _WIN32_WINNT 0x400
#  endif
#endif

#include <broker/brokerObject.h>
#include <portal/pGenericObject.h>
#include <webLvcBroker/lvcObjectTranslator.h>
#include <omtReader/datatypeManager.h>
#include <omtReader/omtTree.h>

#define OMTOBJ_TEMPLATE_ARGS \
   DtPortalGenericObject, DtPortalReflectedGenericObject

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtOmtObjectTranslator are responsible for translating DtPortalGenericObject to WebLVC by way of the VR-Link OMT Translator.
      class DT_DLL_WEBLVCBROKER DtOmtObjectTranslator
         : public DtLvcObjectTranslator<OMTOBJ_TEMPLATE_ARGS>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "OMT:Objects" );

         //! \brief CTOR.
         DtOmtObjectTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtOmtObjectTranslator();

         virtual bool readObjectModel( const std::vector<DtString>& filenames );

         virtual void translate( const Json::Value& source, DtPortalGenericObject* destination );
         virtual void translate( const DtPortalGenericObject& source, Json::Value* destination );

      protected:

         virtual void populateJson( DtStringTree* stringTree, Json::Value* destination );
         virtual void populateFromJson( const DtString& datatypeName, const Json::Value& jsonTree, std::vector<char>& destination );

      protected:

         DtOMTTree* myObjectModelTree;
         DtDatatypeManager* myDatatypeManager;

      };

   }
}
