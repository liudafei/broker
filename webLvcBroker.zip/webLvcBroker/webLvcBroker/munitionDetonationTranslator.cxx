/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file munitionDetonationTranslator.cxx
//! \brief Contains the DtMunitionDetonationTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/munitionDetonationTranslator.h>
#include <matrix/vlVector.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtMunitionDetonationTranslator::DtMunitionDetonationTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalDetonationInteractionMessageKind )
      {
      }

      DtMunitionDetonationTranslator::~DtMunitionDetonationTranslator()
      {
      }

      void DtMunitionDetonationTranslator::translate(
         const Json::Value& source, DtPortalDetonationInteraction* destination )
      {
         destination->setAttackerId( source.get("AttackerId","unknown").asCString() );
         destination->setTargetId( source.get("TargetId","unknown").asCString() );
         destination->setMunitionId( source.get("MunitionId","unknown").asCString() );
         destination->setMunitionType( source.get("MunitionType","0:0:0:0:0:0:0").asCString() );
         destination->setEventId( source.get("EventId","unknown").asCString() );

         Json::Value def( Json::arrayValue );
         def[0u] = 0;
         def[1] = 0;
         def[2] = 0;
         Json::Value velocity = source.get( "Velocity", def );
         destination->setVelocity( DtVector32(velocity[0u].asDouble(),velocity[1].asDouble(),velocity[2].asDouble()) );

         Json::Value worldLocation = source.get( "WorldLocation", def );
         destination->setWorldLocation( DtVector(worldLocation[0u].asDouble(),worldLocation[1].asDouble(),worldLocation[2].asDouble()) );

         Json::Value entityLocation = source.get( "EntityLocation", def );
         destination->setEntityLocation( DtVector32(entityLocation[0u].asDouble(),entityLocation[1].asDouble(),entityLocation[2].asDouble()) );

         destination->setResult( source.get("Result",0).asUInt() );
         destination->setFuseType( source.get("FuseType",0).asUInt() );
         destination->setQuantity( source.get("Quantity",0).asUInt() );
         destination->setRate( source.get("Rate",0).asUInt() );
         destination->setWarheadType( source.get("WarheadType",0).asUInt() );
      }

      void DtMunitionDetonationTranslator::translate(
         const DtPortalDetonationInteraction& source, Json::Value* destination )
      {
         (*destination)["MessageKind"] = 2;
         (*destination)["InteractionType"] = translatorName().c_str();

         //! AttackerID is the name of the object which fired the weapon.
         (*destination)["AttackerId"] = source.attackerId().c_str();

         //! \brief TargetID is the name of the object which was targeted by the Attacker.
         //! For indirect fire this field can be left blank.
         if ( source.targetId() != DtString::nullString() )
         {
            (*destination)["TargetId"] = source.targetId().c_str();
         }

         //! \brief A String Identifier for the Munition
         (*destination)["MunitionId"] = source.munitionId().c_str();

         //! \brief The Type of the Munition Object.
         //! This is noted as "N:N:N:N:N:N:N". This
         //! field can be left empty, as 0:0:0:0:0:0:0. Types follow the rules of the DIS
         //! Enumerations Document
         if ( source.munitionType() != "0:0:0:0:0:0:0" )
         {
            (*destination)["MunitionType"] = source.munitionType().c_str();
         }

         //! A string representation of an EventID
         (*destination)["EventId"] = source.eventId().c_str();

         //! \brief The velocity of the munition at the moment of detonation
         Json::Value velocity(Json::arrayValue);
         velocity[0u] = source.velocity()[0];
         velocity[1] = source.velocity()[1];
         velocity[2] = source.velocity()[2];

         (*destination)["Velocity"] = velocity;

         //! \brief The location in Geocentric Coordinates from which the munition was launched.
         Json::Value worldLocation(Json::arrayValue);
         worldLocation[0u] = source.worldLocation()[0];
         worldLocation[1] = source.worldLocation()[1];
         worldLocation[2] = source.worldLocation()[2];
         (*destination)["WorldLocation"] = worldLocation;

         //! \brief Location, in coordinates relative to the target entity, at which the
         //! munition detonated.
         Json::Value entityLocation(Json::arrayValue);
         worldLocation[0u] = source.entityLocation()[0];
         worldLocation[1] = source.entityLocation()[1];
         worldLocation[2] = source.entityLocation()[2];
         (*destination)["EntityLocation"] = worldLocation;

         //! \brief The Result of the detonation as specified by the DIS Enumerations Document.
         (*destination)["Result"] = (unsigned)source.result();

         //! The fuze as specified by the DIS Enumerations Document
         (*destination)["FuseType"] = (unsigned)source.fuseType();

         //! \brief The quantity of munition discharged for this event when a burst is fired.
         //! zero indicates it was a single round.
         (*destination)["Quantity"] = (unsigned)source.quantity();

         //! \brief The Rate at which munitions are discharged in rounds per minute.
         (*destination)["Rate"] = (unsigned)source.rate();

         //! The Warhead type as specified by the DIS Enumerations
         (*destination)["WarheadType"] = (unsigned)source.warheadType();
      }

   }
}
