/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file tcpConnectionServer.cxx
//! \brief Contains the DtTcpConnectionServer class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/tcpConnectionServer.h>
#include <webLvcBroker/tcpRequestHandlerFactory.h>
#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/TCPServer.h>
#include <vlutil/vlUtil.h>

using Poco::Net::ServerSocket;
using Poco::Net::TCPServer;

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtTcpConnectionServer::DtTcpConnectionServer( int port )
         : DtReliableConnectionServer()
         , myServerSocket( 0 )
         , myTCPServer( 0 )
      {
         myServerSocket = new ServerSocket( port );
         myTCPServer = new TCPServer( new DtTcpRequestHandlerFactory(), *myServerSocket );
      }

      DtTcpConnectionServer::~DtTcpConnectionServer()
      {
         myTCPServer->stop();
         DtDELETE( myServerSocket );
         DtDELETE( myTCPServer );
      }

      void DtTcpConnectionServer::start()
      {
         myTCPServer->start();
      }

      void DtTcpConnectionServer::stop()
      {
         myTCPServer->stop();
      }

   }
}
