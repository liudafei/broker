/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file aggregateTranslator.cxx
//! \brief Contains the DtAggregateTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/aggregateTranslator.h>

#include <omtReader/xmlFileReader.h>
#include <omtReader/omtFileReader.h>

#include <vlpi/deadReckoner.h>
#include <matrix/geodeticCoord.h>
#include <matrix/topoCoord.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtAggregateTranslator::DtAggregateTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalEntityObjectMessageKind )
         , myAdditionalDataMap()
         , myNameLookup()
      {
      }

      DtAggregateTranslator::~DtAggregateTranslator()
      {
      }

      void DtAggregateTranslator::translate( const Json::Value& source,
         DtPortalAggregate* pEnt )
      {
         //entityId
         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = 0;
         entityIdentifier[1] = 0;
         entityIdentifier[2] =0;
         Json::Value entId = source.get("EntityIdentifier",entityIdentifier);
         std::stringstream eid;
         if( entId.isString() )
         {
            pEnt->setEntityId(entId.asCString());
         }
         else
         {

            eid << entId.get(0u,1).asInt();
            eid << ":" << entId.get(1,1).asInt();
            eid << ":" << entId.get(2,1).asInt();
            pEnt->setEntityId(eid.str().c_str());
         }

         //entityType
         Json::Value entityType(Json::arrayValue);
         Json::Value entType = source.get("EntityType","0,0,0,0,0,0,0");
         if( entType.isString() )
         {
            pEnt->setEntityType( DtEntityType( entType.asCString() ));
         }
         else
         {
            pEnt->setEntityType( DtEntityType(entType.get(0u,-1).asInt(),entType.get(1,-1).asInt(),
               entType.get(2,-1).asInt(),entType.get(3,-1).asInt(),
               entType.get(4,-1).asInt(),entType.get(5,-1).asInt(),
               entType.get(6,-1).asInt()));
         }

         //marking text
         pEnt->setMarkingText( source.get("Marking",eid.str().c_str()).asCString());
         myLockingPortalReflectedManager->lock().writeLock();
         myLockingPortalReflectedManager->updateObj( *pEnt );
         myLockingPortalReflectedManager->lock().unlock();

         Json::Value defVal(Json::arrayValue);
         defVal[0u] = 0.0;
         defVal[1] = 0.0;
         defVal[2] = 0.0;
         //translate an attribute update to a portal entity sr
         unsigned dr = source.get("DeadReckoningAlgorithm",-1).asInt();
         if(dr != -1 )
         {
            pEnt->setAlgorithm(dr);
         }

         Json::Value wl = source.get("WorldLocation",defVal);
         if( wl.isArray() )
         {
            try{
               pEnt->setLocation( DtVector( wl.get(0u,0).asDouble(), wl.get(1,0).asDouble(),wl.get(2,0).asDouble()));
            }
            catch (...)
            {
            }
         }
         else
            DtWarn(" Recieved non array world location \n");

         Json::Value vv = source.get("VelocityVector",defVal);
         if( vv.isArray() )
         {
            try{
               pEnt->setVelocity( DtVector32( vv.get(0u,0).asDouble(), vv.get(1,0).asDouble(),vv.get(2,0).asDouble()));
            }
            catch (...)
            {
            }
         }
         else
            DtWarn(" Recieved non array velocity vector \n");

         Json::Value av = source.get("AccelerationVector",defVal);
         if( av.isArray() )
         {
            try{
               pEnt->setAcceleration(DtVector32(av.get(0u, 0).asDouble(), av.get(1, 0).asDouble(), av.get(2, 0).asDouble()));
            }
            catch (...)
            {
            }
         }
         else
            DtWarn(" Recieved non array Acceleration vector \n");

         Json::Value vor = source.get("Orientation",defVal);
         if( vor.isArray() )
         {
            try{
               pEnt->setOrientation( DtTaitBryan( vor.get(0u,0).asDouble(), vor.get(1,0).asDouble(),vor.get(2,0).asDouble()));
            }
            catch (...)
            {
            }
         }
         else
            DtWarn(" Recieved non array Orientation vector \n");

         Json::Value ang = source.get("AngularVelocity",defVal);
         if( ang.isArray() )
         {
            try{
               pEnt->setRotationalVelocity(DtVector32(ang.get(0u, 0).asDouble(), ang.get(1, 0).asDouble(), ang.get(2, 0).asDouble()));
            }
            catch ( ... )
            {
            }
         }
         else
            DtWarn( " Recieved non array Angular velocity \n");

         int fid = source.get("ForceIdentifier",-1).asInt();
         if ( fid != -1 )
         {
            pEnt->setForceId( fid );
         }
         /* do I care about the timestamp the client is sending me?
         double t = m->get("Timestamp",-1).asDouble();
         if( t != -1 )
         {
         pe->sr()->setTimeRecieved(t);
         }
         */
         pEnt->setTimeReceived( webLvcBroker()->portalConnection()->clock()->simTime() );
      }


      void DtAggregateTranslator::translate( const DtPortalAggregate& source,
         Json::Value* destination )
      {
         DtTime dt = webLvcBroker()->portalConnection()->clock()->simTime() - source.timeReceived();

         DtVector loc;
         DtVector32 vel;
         DtDeadReckoner::deadReckonPosition( dt, (DtDeadReckonTypes) source.algorithm(),
            source.location(), source.velocity(), source.acceleration(), vel, loc );

         DtDcm newb2w;
         DtDeadReckoner::deadReckonOrientation( dt, (DtDeadReckonTypes) source.algorithm(),
            source.orientation(), source.rotationalVelocity(), newb2w );

         DtGeodeticCoord geodeticLocation;
         geodeticLocation.setGeocentric( loc );

         DtTaitBryan neworient;
         DtBodyToRef_to_Euler( newb2w, &neworient );

         DtCoordTransform geocToTopo;
         DtGeocToTopoTransform( geodeticLocation.lat(), geodeticLocation.lon(), &geocToTopo );

         DtTaitBryan topoEuler;
         geocToTopo.eulerTrans( neworient, &topoEuler );

         /*************************************************/
         // Create a JSON formatted message to send instead
         /*************************************************/

         // 1 � PhysicalEntity
         (*destination)["ObjectType"] = "WebLVC:AggregateEntity";

         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = source.entityId().site();
         entityIdentifier[1] = source.entityId().host();
         entityIdentifier[2] = source.entityId().entityNum();

         (*destination)["EntityIdentifier"] = entityIdentifier;

         Json::Value entityType(Json::arrayValue);
         entityType[0u] = source.entityType().kind();
         entityType[1] = source.entityType().domain();
         entityType[2] = source.entityType().country();
         entityType[3] = source.entityType().category();
         entityType[4] = source.entityType().subCategory();
         entityType[5] = source.entityType().specific();
         entityType[6] = source.entityType().extra();

         (*destination)["EntityType"] = entityType;

         (*destination)["DeadReckoningAlgorithm"] = (unsigned int)source.algorithm();

         Json::Value worldLocation(Json::arrayValue);
         worldLocation[0u] = loc[0];
         worldLocation[1] = loc[1];
         worldLocation[2] = loc[2];

         (*destination)["WorldLocation"] = worldLocation;

         Json::Value velocity(Json::arrayValue);
         velocity[0u] = vel[0];
         velocity[1] = vel[1];
         velocity[2] = vel[2];

         (*destination)["VelocityVector"] = velocity;

         Json::Value acceleration(Json::arrayValue);
         acceleration[0u] = source.acceleration()[0];
         acceleration[1] = source.acceleration()[1];
         acceleration[2] = source.acceleration()[2];

         (*destination)["AccelerationVector"] = acceleration;

         Json::Value orientation(Json::arrayValue);
         orientation[0u] = neworient.psi();
         orientation[1] = neworient.theta();
         orientation[2] = neworient.phi();

         (*destination)["Orientation"] = orientation;

         Json::Value angularVelocity(Json::arrayValue);
         angularVelocity[0u] = source.rotationalVelocity()[0];
         angularVelocity[1] = source.rotationalVelocity()[1];
         angularVelocity[2] = source.rotationalVelocity()[2];

         (*destination)["AngularVelocity"] = angularVelocity;

         (*destination)["ForceIdentifier"] = (unsigned int)source.forceId();

         (*destination)["Marking"] = source.markingText().string();

         (*destination)["Timestamp"] = (double)source.timeReceived() + dt;

         (*destination)["Aggregate State"] = (double)source.aggregateState();

         (*destination)["Formation"] = (double)source.formation();

         Json::Value dimensions(Json::arrayValue);
         dimensions[0u] = source.dimensions()[0];
         dimensions[1] = source.dimensions()[1];
         dimensions[2] = source.dimensions()[2];

         (*destination)["Dimensions"] = dimensions;

         Json::Value subordinates(Json::arrayValue);
         int i = 0;
         for( ; i < source.subaggregates().size(); ++i )
         {
            subordinates[i] = source.subaggregates()[i].c_str();
         }
         for( int j = 0; j < source.entities().size(); ++i, ++j)
         {
            subordinates[i] = source.entities()[j].c_str();
         }
         if( i > 0 )
            (*destination)["Subordinates"] = subordinates;

         Json::Value SilentSubordinates(Json::arrayValue);
         i = 0;
         for( ; i < source.silentAggregates().size(); ++i )
         {
            Json::Value silentAgg;
            Json::Value entityType(Json::arrayValue);
            entityType[0u] = source.silentAggregates()[i].entityType().kind();
            entityType[1] = source.silentAggregates()[i].entityType().domain();
            entityType[2] = source.silentAggregates()[i].entityType().country();
            entityType[3] = source.silentAggregates()[i].entityType().category();
            entityType[4] = source.silentAggregates()[i].entityType().subCategory();
            entityType[5] = source.silentAggregates()[i].entityType().specific();
            entityType[6] = source.silentAggregates()[i].entityType().extra();
            silentAgg["ObjectType"] = entityType;
            silentAgg["count"] = (unsigned)source.silentAggregates()[i].numberOfAggregates();
            SilentSubordinates[i] = silentAgg;
         }
         for ( int j = 0 ; j < source.silentEntities().size(); ++i, ++j )
         {
            Json::Value silentEnt;
            Json::Value entityType(Json::arrayValue);
            entityType[0u] = source.silentEntities()[j].entityType().kind();
            entityType[1] = source.silentEntities()[j].entityType().domain();
            entityType[2] = source.silentEntities()[j].entityType().country();
            entityType[3] = source.silentEntities()[j].entityType().category();
            entityType[4] = source.silentEntities()[j].entityType().subCategory();
            entityType[5] = source.silentEntities()[j].entityType().specific();
            entityType[6] = source.silentEntities()[j].entityType().extra();
            silentEnt["ObjectType"] = entityType;
            silentEnt["count"] = (unsigned)source.silentEntities()[j].numberOfEntities();
            SilentSubordinates[i] = silentEnt;
         }
         if ( i > 0 )
         {
            (*destination)["SilentSubordinates"] = SilentSubordinates;
         }

         if ( ! source.markingText().isEmpty() && ! source.identifier().isEmpty() )
         {
            std::map<DtString,DtString>::const_iterator i = myNameLookup.find( source.markingText() );
            if ( i == myNameLookup.end() )
            {
               // Vrf does not know about the id business all that well
               myNameLookup[source.markingText()] = source.identifier();
            }

            std::map<DtString,Json::Value>::const_iterator j = myAdditionalDataMap.find( source.markingText() );
            if ( j != myAdditionalDataMap.end() )
            {
               (*destination)["AdditionalData"] = j->second;
            }
         }
      }

      void DtAggregateTranslator::addAdditionalDataValue( const DtString& name,
         const std::string& tag, const Json::Value& source )
      {
         Json::Value v = myAdditionalDataMap[name];
         v[tag] = source;
         myAdditionalDataMap[name] = v;

         // if it is then this message beat the object update and
         // the data can hang out until the discovery
         std::map<DtString,DtString>::iterator i = myNameLookup.find( name );
         if ( i != myNameLookup.end() )
         {
            // otherwise mark the entity for updating to the clients
            myLock.writeLock();

            std::map<void*, std::set<DtString> >::iterator u = this->myLvcUpdateSet.begin();
            for ( ; u != this->myLvcUpdateSet.end(); ++u )
            {
               u->second.insert( i->second );
            }

            myLock.unlock();
         }
      }

      void DtAggregateTranslator::removePortalObject( const DtPortalReflectedAggregate& obj )
      {
         myLock.writeLock();

         myAdditionalDataMap.erase( obj.sr()->markingText() );
         myNameLookup.erase( obj.sr()->markingText() );

         myLock.unlock();

         ParentClass::removePortalObject( obj );
      }

   }
}
