/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file baseWebLvcInteractionTranslator.h
//! \brief Contains the DtBaseWebLvcInteractionTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <webLvcBroker/dllExport.h>
#include <broker/baseInteractionTranslator.h>
#include <Poco/RWLock.h>
#include <json/json.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      class DtClient;
      class DtWebLvcBroker;

      //! \brief DtBaseInteractionTranslator are responsible for translating
      //! messages for things that do not have state.
      class DT_DLL_WEBLVCBROKER DtBaseWebLvcInteractionTranslator : public DtInteractionTranslator
      {
      public:

         //! \brief CTOR.
         DtBaseWebLvcInteractionTranslator( DtBroker* broker,
            const DtString& name, DtPortalMessageKind kind );

         //! \brief Virtual DTOR.
         virtual ~DtBaseWebLvcInteractionTranslator();

         // for each id in the update set create a msg and pass it to the broker
         virtual int processUpdateSet( void* id );
         virtual void createUpdateSet( void* id );

         //! Notification that a client is beiong removed, translator may need to delete
         //! objects related to a specific client
         virtual void processClientRemoval( DtClient* );

         //! when a new client is added a translator is asked to send a full update to
         //! that specific client.  This method creates all the state messages for this
         //! client
         virtual void createFullStateMsgs( std::list<std::string>& msgs, DtClient* client ) = 0;

         //! Called for incoming WebLVC messages that have been registered for
         virtual void processMsg( Json::Value* msg, DtClient* client );

         virtual Poco::RWLock* lock();

         //! called when a registered portal object is removed.
         virtual void removePortalObject( const std::string& refObj );

         //! called when building the status html page
         virtual DtString status();

      private:

         //! Private Copy CTOR not implemented - do not copy.
         DtBaseWebLvcInteractionTranslator( const DtBaseWebLvcInteractionTranslator& other );

         //! Private Assignment operator not implemented - do not copy.
         DtBaseWebLvcInteractionTranslator& operator = ( const DtBaseWebLvcInteractionTranslator& other );

      protected:

         typedef std::set<DtString> StringSet;
         typedef std::map<void*,StringSet> UpdateSetMap;
         UpdateSetMap myLvcUpdateSet;

      };

   }
}
