/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file vrfAggregateTranslator.cxx
//! \brief Contains the DtVrfAggregateTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/vrfAggregateTranslator.h>

#include <omtReader/xmlFileReader.h>
#include <omtReader/omtFileReader.h>

#include <vlpi/deadReckoner.h>
#include <matrix/geodeticCoord.h>
#include <matrix/topoCoord.h>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      void convertAmountRecord( const DtAmountRecord& amountRecord, Json::Value& jsonValue )
      {
         jsonValue["Amount"] = (DtFloat64)amountRecord.amount();
         if ( ! amountRecord.pacingTracking().isEmpty() )
         {
            jsonValue["PacingTracking"] = amountRecord.pacingTracking().c_str();
         }
      }

      void convertTypedRateRecord( const DtTypedRateRecord& typedRateRecord, Json::Value& jsonValue )
      {
         jsonValue["Type"] = typedRateRecord.type().c_str();
         jsonValue["Rate"] = (DtFloat64) typedRateRecord.rate();
      }

      void convertTypedRateRecordList( const DtTypedRateRecordList& typedRateRecordList, Json::Value& jsonValue )
      {
         DtTypedRateRecordList::const_iterator itr = typedRateRecordList.begin();
         DtTypedRateRecordList::const_iterator end = typedRateRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value typedRateRecord( Json::objectValue );
            convertTypedRateRecord( *itr, typedRateRecord );
            jsonValue[index] = typedRateRecord;
         }
      }

      void convertEWAttackDefendingRecord( const DtEWAttackDefendingRecord& EWAttackDefendingRecord, Json::Value& jsonValue )
      {
         jsonValue["Attacker"] = EWAttackDefendingRecord.attacker().string();
         jsonValue["Type"] = EWAttackDefendingRecord.type().string();
         jsonValue["Strength"] = (DtInt32) EWAttackDefendingRecord.strength();
         jsonValue["CurrentRandomDraw"] = (DtFloat64) EWAttackDefendingRecord.currentRandomDraw();
      }

      void convertEWAttackDefendingRecordList( const DtEWAttackDefendingRecordList& EWAttackDefendingRecordList, Json::Value& jsonValue )
      {
         DtEWAttackDefendingRecordList::const_iterator itr = EWAttackDefendingRecordList.begin();
         DtEWAttackDefendingRecordList::const_iterator end = EWAttackDefendingRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value EWAttackDefendingRecord( Json::objectValue );
            convertEWAttackDefendingRecord( *itr, EWAttackDefendingRecord );
            jsonValue[index] = EWAttackDefendingRecord;
         }
      }

      void convertEWAttackRecord( const DtEWAttackRecord& EWAttackRecord, Json::Value& jsonValue )
      {
         jsonValue["Target"] = EWAttackRecord.target().c_str();
         jsonValue["Type"] = EWAttackRecord.type().c_str();
         jsonValue["Strength"] = (DtInt32) EWAttackRecord.strength();
      }

      void convertEWAttackRecordList( const DtEWAttackRecordList& EWAttackRecordList, Json::Value& jsonValue )
      {
         DtEWAttackRecordList::const_iterator itr = EWAttackRecordList.begin();
         DtEWAttackRecordList::const_iterator end = EWAttackRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value EWAttackRecord( Json::objectValue );
            convertEWAttackRecord( *itr, EWAttackRecord );
            jsonValue[index] = EWAttackRecord;
         }
      }

      void convertTypedAmountRecord( const DtTypedAmountRecord& typedAmountRecord, Json::Value& jsonValue )
      {
         jsonValue["Type"] = typedAmountRecord.type().c_str();
         Json::Value amountRecord( Json::objectValue );
         convertAmountRecord( typedAmountRecord.amount(), amountRecord );
         jsonValue["Amount"] = amountRecord;
      }

      void convertTypedAmountRecordList( const DtTypedAmountRecordList& typedAmountRecordList, Json::Value& jsonValue )
      {
         DtTypedAmountRecordList::const_iterator itr = typedAmountRecordList.begin();
         DtTypedAmountRecordList::const_iterator end = typedAmountRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value typedAmountRecord( Json::objectValue );
            convertTypedAmountRecord( *itr, typedAmountRecord );
            jsonValue[index] = typedAmountRecord;
         }
      }

      void convertTypedResupplyAmountRecord(
         const DtTypedResupplyAmountRecord& typedResupplyAmountRecord, Json::Value& jsonValue )
      {
         jsonValue["Type"] = typedResupplyAmountRecord.type().c_str();

         Json::Value amountRecord( Json::objectValue );
         convertAmountRecord( typedResupplyAmountRecord.amount(), amountRecord );
         jsonValue["Amount"] = amountRecord;

         jsonValue["ResupplyRate"] = typedResupplyAmountRecord.resupplyRate();
      }

      void convertTypedResupplyAmountRecordList(
         const DtTypedResupplyAmountRecordList& typedResupplyAmountRecordList, Json::Value& jsonValue )
      {
         DtTypedResupplyAmountRecordList::const_iterator itr = typedResupplyAmountRecordList.begin();
         DtTypedResupplyAmountRecordList::const_iterator end = typedResupplyAmountRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value typedAmountRecord( Json::objectValue );
            convertTypedResupplyAmountRecord( *itr, typedAmountRecord );
            jsonValue[index] = typedAmountRecord;
         }
      }

      void convertEffectModifierRecord( const DtEffectModifierRecord& effectModifierRecord, Json::Value& jsonValue )
      {
         jsonValue["Type"] = effectModifierRecord.type().string();
         jsonValue["Modifier"] = (DtFloat64) effectModifierRecord.modifier();
         jsonValue["Factor"] = (DtFloat64) effectModifierRecord.factor();
      }

      void convertEffectModifierRecordList( const DtEffectModifierRecordList& effectModifierRecordList, Json::Value& jsonValue )
      {
         DtEffectModifierRecordList::const_iterator itr = effectModifierRecordList.begin();
         DtEffectModifierRecordList::const_iterator end = effectModifierRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value effectModifierRecord( Json::objectValue );
            convertEffectModifierRecord( *itr, effectModifierRecord );
            jsonValue[index] = effectModifierRecord;
         }
      }

      void convertCasualtyReportRecord( const DtCasualtyReportRecord& casualtyReportRecord, Json::Value& jsonValue )
      {
         jsonValue["Attacker"] = casualtyReportRecord.attacker().c_str();
         jsonValue["NumberKilled"] = (DtInt32) casualtyReportRecord.numberKilled();
         jsonValue["NumberCaptured"] = (DtInt32) casualtyReportRecord.numberCaptured();
         jsonValue["NumberWounded"] = (DtInt32) casualtyReportRecord.numberWounded();
         jsonValue["NumberMissing"] = (DtInt32) casualtyReportRecord.numberMissing();
      }

      void convertCasualtyReportRecordList( const DtCasualtyReportRecordList& casualtyReportRecordList, Json::Value& jsonValue )
      {
         DtCasualtyReportRecordList::const_iterator itr = casualtyReportRecordList.begin();
         DtCasualtyReportRecordList::const_iterator end = casualtyReportRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value casualtyReportRecord( Json::objectValue );
            convertCasualtyReportRecord( *itr, casualtyReportRecord );
            jsonValue[index] = casualtyReportRecord;
         }
      }

      void convertRangedPowerRecord( const DtRangedPowerRecord& rangedPowerRecord, Json::Value& jsonValue )
      {
         jsonValue["Type"] = rangedPowerRecord.type().string();
         jsonValue["Range"] = (DtFloat64) rangedPowerRecord.range();
         jsonValue["Factor"] = (DtFloat64) rangedPowerRecord.factor();
         jsonValue["Strength"] = (DtInt32) rangedPowerRecord.strength();
      }

      void convertIndirectFirePowerRecord( const DtIndirectFirePowerRecord& indirectFirePowerRecord, Json::Value& jsonValue )
      {
         jsonValue["Type"] = indirectFirePowerRecord.type().c_str();
         jsonValue["Range"] = (DtFloat64) indirectFirePowerRecord.range();
         jsonValue["Radius"] = (DtFloat64) indirectFirePowerRecord.radius();
         jsonValue["MaxSheafRadius"] = (DtFloat64) indirectFirePowerRecord.max_Sheaf_Radius();
         jsonValue["HitFactor"] = (DtFloat64) indirectFirePowerRecord.hit_Factor();
         jsonValue["SecondsPerAttack"] = (DtFloat64) indirectFirePowerRecord.seconds_Per_Attack();
         jsonValue["StrengthPerAttack"] = (DtInt32) indirectFirePowerRecord.strength_Per_Attack();
         jsonValue["AmmunitionPerAttack"] = (DtInt32) indirectFirePowerRecord.ammunition_Per_Attack();
         jsonValue["DamageType"] = indirectFirePowerRecord.damage_Type().c_str();
         jsonValue["CanBeRadarJammed"] = (bool) indirectFirePowerRecord.can_Be_Radar_Jammed();
         jsonValue["JammingDefenseFactor"] = (DtFloat64) indirectFirePowerRecord.jamming_Defense_Factor();
         jsonValue["MaxAltitude"] = (DtFloat64) indirectFirePowerRecord.max_Altitude();
         jsonValue["AllowedPostures"] = indirectFirePowerRecord.allowed_Postures().c_str();
      }

      void convertIndirectFirePowerRecordList( const DtIndirectFirePowerRecordList& indirectFirePowerRecordList, Json::Value& jsonValue )
      {
         DtIndirectFirePowerRecordList::const_iterator itr = indirectFirePowerRecordList.begin();
         DtIndirectFirePowerRecordList::const_iterator end = indirectFirePowerRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value indirectFirePowerRecord( Json::objectValue );
            convertIndirectFirePowerRecord( *itr, indirectFirePowerRecord );
            jsonValue[index] = indirectFirePowerRecord;
         }
      }

      void convertRangedPowerRecordList( const DtRangedPowerRecordList& rangedPowerRecordList, Json::Value& jsonValue )
      {
         DtRangedPowerRecordList::const_iterator itr = rangedPowerRecordList.begin();
         DtRangedPowerRecordList::const_iterator end = rangedPowerRecordList.end();
         for ( int index = 0; itr != end; ++itr, ++index )
         {
            Json::Value rangedPowerRecord( Json::objectValue );
            convertRangedPowerRecord( *itr, rangedPowerRecord );
            jsonValue[index] = rangedPowerRecord;
         }
      }

      void convertTypedQuantityRecord( const DtTypedQuantityRecord& typedQuantityRecord, Json::Value& jsonValue )
      {
         jsonValue["Type"] = typedQuantityRecord.type().c_str();
         jsonValue["Count"] = (DtInt32) typedQuantityRecord.count();
         if ( ! typedQuantityRecord.pacingTracking().isEmpty() )
         {
            jsonValue["PacingTracking"] = typedQuantityRecord.pacingTracking().c_str();
         }
         if ( ! typedQuantityRecord.category().isEmpty() )
         {
            jsonValue["Category"] = typedQuantityRecord.category().c_str();
         }
      }

      void convertTypedQuantityRecordList( const DtTypedQuantityRecordList& typedQuantityRecordList, Json::Value& jsonValue )
      {
         DtTypedQuantityRecordList::const_iterator itr = typedQuantityRecordList.begin();
         DtTypedQuantityRecordList::const_iterator end = typedQuantityRecordList.end();
         for ( int index = 0; itr != end;  ++itr, ++index )
         {
            Json::Value typedAmountRecord( Json::objectValue );
            convertTypedQuantityRecord( *itr, typedAmountRecord );
            jsonValue[index] = typedAmountRecord;
         }
      }


      DtVrfAggregateTranslator::DtVrfAggregateTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalEntityObjectMessageKind )
      {
      }

      DtVrfAggregateTranslator::~DtVrfAggregateTranslator()
      {
      }

      void DtVrfAggregateTranslator::translate( const Json::Value& source,
         DtPortalVrfAggregate* pEnt )
      {
         //NOTE: VR-Forces True Aggregate specific functions are not currently supported
         //from WebLVC.

         //entityId
         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = 0;
         entityIdentifier[1] = 0;
         entityIdentifier[2] =0;
         Json::Value entId = source.get("EntityIdentifier",entityIdentifier);
         std::stringstream eid;
         if( entId.isString() )
         {
            pEnt->setEntityId(entId.asCString());
         }
         else
         {

            eid << entId.get(0u,1).asInt();
            eid << ":" << entId.get(1,1).asInt();
            eid << ":" << entId.get(2,1).asInt();
            pEnt->setEntityId(eid.str().c_str());
         }

         //entityType
         Json::Value entityType(Json::arrayValue);
         Json::Value entType = source.get("EntityType","0,0,0,0,0,0,0");
         if( entType.isString() )
         {
            pEnt->setEntityType( DtEntityType( entType.asCString() ));
         }
         else
         {
            pEnt->setEntityType( DtEntityType(entType.get(0u,-1).asInt(),entType.get(1,-1).asInt(),
               entType.get(2,-1).asInt(),entType.get(3,-1).asInt(),
               entType.get(4,-1).asInt(),entType.get(5,-1).asInt(),
               entType.get(6,-1).asInt()));
         }

         //marking text
         pEnt->setMarkingText( source.get("Marking",eid.str().c_str()).asCString());
         myLockingPortalReflectedManager->lock().writeLock();
         myLockingPortalReflectedManager->updateObj( *pEnt );
         myLockingPortalReflectedManager->lock().unlock();

         Json::Value defVal(Json::arrayValue);
         defVal[0u] = 0.0;
         defVal[1] = 0.0;
         defVal[2] = 0.0;
         //translate an attribute update to a portal entity sr
         unsigned dr = source.get("DeadReckoningAlgorithm",-1).asInt();
         if(dr != -1 )
         {
            pEnt->setAlgorithm(dr);
         }

         Json::Value wl = source.get("WorldLocation",defVal);
         if( wl.isArray() )
         {
            try{
               pEnt->setLocation( DtVector( wl.get(0u,0).asDouble(), wl.get(1,0).asDouble(),wl.get(2,0).asDouble()));
            }
            catch (...)
            {
            }
         }
         else
            DtWarn(" Received non array world location \n");

         Json::Value vv = source.get("VelocityVector",defVal);
         if( vv.isArray() )
         {
            try{
               pEnt->setVelocity( DtVector32( vv.get(0u,0).asDouble(), vv.get(1,0).asDouble(),vv.get(2,0).asDouble()));
            }
            catch (...)
            {
            }
         }
         else
            DtWarn(" Received non array velocity vector \n");

         Json::Value av = source.get("AccelerationVector",defVal);
         if( av.isArray() )
         {
            try{
               pEnt->setAcceleration(DtVector32(av.get(0u, 0).asDouble(), av.get(1, 0).asDouble(), av.get(2, 0).asDouble()));
            }
            catch (...)
            {
            }
         }
         else
            DtWarn(" Received non array Acceleration vector \n");

         Json::Value vor = source.get("Orientation",defVal);
         if( vor.isArray() )
         {
            try{
               pEnt->setOrientation( DtTaitBryan( vor.get(0u,0).asDouble(), vor.get(1,0).asDouble(),vor.get(2,0).asDouble()));
            }
            catch (...)
            {
            }
         }
         else
            DtWarn(" Received non array Orientation vector \n");

         Json::Value ang = source.get("AngularVelocity",defVal);
         if( ang.isArray() )
         {
            try{
               pEnt->setRotationalVelocity(DtVector32(ang.get(0u, 0).asDouble(), ang.get(1, 0).asDouble(), ang.get(2, 0).asDouble()));
            }
            catch ( ... )
            {
            }
         }
         else
            DtWarn( " Received non array Angular velocity \n");

         int fid = source.get("ForceIdentifier",-1).asInt();
         if ( fid != -1 )
         {
            pEnt->setForceId( fid );
         }
         /* do I care about the timestamp the client is sending me?
         double t = m->get("Timestamp",-1).asDouble();
         if( t != -1 )
         {
         pe->sr()->setTimeReceived(t);
         }
         */
         pEnt->setTimeReceived( webLvcBroker()->portalConnection()->clock()->simTime() );
      }


      void DtVrfAggregateTranslator::translate( const DtPortalVrfAggregate& source,
         Json::Value* destination )
      {
         DtTime dt = webLvcBroker()->portalConnection()->clock()->simTime() - source.timeReceived();

         DtVector loc;
         DtVector32 vel;
         DtDeadReckoner::deadReckonPosition( dt, (DtDeadReckonTypes) source.algorithm(),
            source.location(), source.velocity(), source.acceleration(), vel, loc );

         DtDcm newb2w;
         DtDeadReckoner::deadReckonOrientation( dt, (DtDeadReckonTypes) source.algorithm(),
            source.orientation(), source.rotationalVelocity(), newb2w );

         DtGeodeticCoord geodeticLocation;
         geodeticLocation.setGeocentric( loc );

         DtTaitBryan neworient;
         DtBodyToRef_to_Euler( newb2w, &neworient );

         DtCoordTransform geocToTopo;
         DtGeocToTopoTransform( geodeticLocation.lat(), geodeticLocation.lon(), &geocToTopo );

         DtTaitBryan topoEuler;
         geocToTopo.eulerTrans( neworient, &topoEuler );

         /*************************************************/
         // Create a JSON formatted message to send instead
         /*************************************************/

         // 1 � PhysicalEntity
         (*destination)["ObjectType"] = "MAK:VRFAggregate";

         Json::Value entityIdentifier(Json::arrayValue);
         entityIdentifier[0u] = source.entityId().site();
         entityIdentifier[1] = source.entityId().host();
         entityIdentifier[2] = source.entityId().entityNum();

         (*destination)["EntityIdentifier"] = entityIdentifier;

         Json::Value entityType(Json::arrayValue);
         entityType[0u] = source.entityType().kind();
         entityType[1] = source.entityType().domain();
         entityType[2] = source.entityType().country();
         entityType[3] = source.entityType().category();
         entityType[4] = source.entityType().subCategory();
         entityType[5] = source.entityType().specific();
         entityType[6] = source.entityType().extra();

         (*destination)["EntityType"] = entityType;

         (*destination)["DeadReckoningAlgorithm"] = (unsigned int)source.algorithm();

         Json::Value worldLocation(Json::arrayValue);
         worldLocation[0u] = loc[0];
         worldLocation[1] = loc[1];
         worldLocation[2] = loc[2];

         (*destination)["WorldLocation"] = worldLocation;

         Json::Value velocity(Json::arrayValue);
         velocity[0u] = vel[0];
         velocity[1] = vel[1];
         velocity[2] = vel[2];

         (*destination)["VelocityVector"] = velocity;

         Json::Value acceleration(Json::arrayValue);
         acceleration[0u] = source.acceleration()[0];
         acceleration[1] = source.acceleration()[1];
         acceleration[2] = source.acceleration()[2];

         (*destination)["AccelerationVector"] = acceleration;

         Json::Value orientation(Json::arrayValue);
         orientation[0u] = neworient.psi();
         orientation[1] = neworient.theta();
         orientation[2] = neworient.phi();

         (*destination)["Orientation"] = orientation;

         Json::Value angularVelocity(Json::arrayValue);
         angularVelocity[0u] = source.rotationalVelocity()[0];
         angularVelocity[1] = source.rotationalVelocity()[1];
         angularVelocity[2] = source.rotationalVelocity()[2];

         (*destination)["AngularVelocity"] = angularVelocity;

         (*destination)["ForceIdentifier"] = (unsigned int)source.forceId();

         (*destination)["Marking"] = source.markingText().string();

         (*destination)["Timestamp"] = (double)source.timeReceived() + dt;

         (*destination)["Aggregate State"] = (double)source.aggregateState();

         (*destination)["Formation"] = (double)source.formation();

         Json::Value dimensions(Json::arrayValue);
         dimensions[0u] = source.dimensions()[0];
         dimensions[1] = source.dimensions()[1];
         dimensions[2] = source.dimensions()[2];

         (*destination)["Dimensions"] = dimensions;

         Json::Value subordinates(Json::arrayValue);
         int i = 0;
         for( ; i < source.subaggregates().size(); ++i )
         {
            subordinates[i] = source.subaggregates()[i].c_str();
         }
         for( int j = 0; j < source.entities().size(); ++i, ++j)
         {
            subordinates[i] = source.entities()[j].c_str();
         }
         if( i > 0 )
            (*destination)["Subordinates"] = subordinates;

         Json::Value SilentSubordinates(Json::arrayValue);
         i = 0;
         for( ; i < source.silentAggregates().size(); ++i )
         {
            Json::Value silentAgg;
            Json::Value entityType(Json::arrayValue);
            entityType[0u] = source.silentAggregates()[i].entityType().kind();
            entityType[1] = source.silentAggregates()[i].entityType().domain();
            entityType[2] = source.silentAggregates()[i].entityType().country();
            entityType[3] = source.silentAggregates()[i].entityType().category();
            entityType[4] = source.silentAggregates()[i].entityType().subCategory();
            entityType[5] = source.silentAggregates()[i].entityType().specific();
            entityType[6] = source.silentAggregates()[i].entityType().extra();
            silentAgg["ObjectType"] = entityType;
            silentAgg["count"] = (unsigned)source.silentAggregates()[i].numberOfAggregates();
            SilentSubordinates[i] = silentAgg;
         }
         for ( int j = 0 ; j < source.silentEntities().size(); ++i, ++j )
         {
            Json::Value silentEnt;
            Json::Value entityType(Json::arrayValue);
            entityType[0u] = source.silentEntities()[j].entityType().kind();
            entityType[1] = source.silentEntities()[j].entityType().domain();
            entityType[2] = source.silentEntities()[j].entityType().country();
            entityType[3] = source.silentEntities()[j].entityType().category();
            entityType[4] = source.silentEntities()[j].entityType().subCategory();
            entityType[5] = source.silentEntities()[j].entityType().specific();
            entityType[6] = source.silentEntities()[j].entityType().extra();
            silentEnt["ObjectType"] = entityType;
            silentEnt["count"] = (unsigned)source.silentEntities()[j].numberOfEntities();
            SilentSubordinates[i] = silentEnt;
         }
         if ( i > 0 )
         {
            (*destination)["SilentSubordinates"] = SilentSubordinates;
         }

         if ( ! source.markingText().isEmpty() && ! source.identifier().isEmpty() )
         {
            std::map<DtString,DtString>::const_iterator i = myNameLookup.find( source.markingText() );
            if ( i == myNameLookup.end() )
            {
               // Vrf does not know about the id business all that well
               myNameLookup[source.markingText()] = source.identifier();
            }

            std::map<DtString,Json::Value>::const_iterator j = myAdditionalDataMap.find( source.markingText() );
            if ( j != myAdditionalDataMap.end() )
            {
               (*destination)["AdditionalData"] = j->second;
            }
         }

         // This are VR-Forces specific things
         (*destination)["PhysicalFootprint"] = (DtFloat64)source.physicalFootprint();
         (*destination)["Morale"] = (DtFloat64)source.morale();
         (*destination)["Health"] = (DtInt32)source.health();
         (*destination)["BaseHealth"] = (DtInt32)source.baseHealth();
         (*destination)["MOPPLevel"] = (DtInt32)source.MOPPLevel();

         (*destination)["PersonnelOfficers"] = (DtInt32)source.personnelOfficers();
         (*destination)["BasePersonnelOfficers"] = (DtInt32)source.basePersonnelOfficers();
         (*destination)["PersonnelWOs"] = (DtInt32)source.personnelWOs();
         (*destination)["BasePersonnelWOs"] = (DtInt32)source.basePersonnelWOs();
         (*destination)["PersonnelNCOs"] = (DtInt32)source.personnelNCOs();
         (*destination)["BasePersonnelNCOs"] = (DtInt32)source.basePersonnelNCOs();
         (*destination)["PersonnelEnlisted"] = (DtInt32)source.personnelEnlisted();
         (*destination)["BasePersonnelEnlisted"] = (DtInt32)source.basePersonnelEnlisted();

         (*destination)["NumberKilled"] = (DtInt32)source.numberKilled();
         (*destination)["NumberCaptured"] = (DtInt32)source.numberCaptured();
         (*destination)["NumberWounded"] = (DtInt32)source.numberWounded();
         (*destination)["NumberMissing"] = (DtInt32)source.numberMissing();

         Json::Value sectorSizes;
         sectorSizes["Front"] = (DtFloat64)source.sectorSizes().front();
         sectorSizes["RightFlank"] = (DtFloat64)source.sectorSizes().rightFlank();
         sectorSizes["Rear"] = (DtFloat64)source.sectorSizes().rear();
         sectorSizes["LeftFlank"] = (DtFloat64)source.sectorSizes().leftFlank();

         (*destination)["SectorSizes"] = sectorSizes;

         (*destination)["AttritionRate"] = (DtFloat64)source.attritionRate();
         (*destination)["JammingStrengthOn"] = (DtFloat64)source.jammingStrengthOn();
         (*destination)["EWCommsDegradationPercent"] = (DtFloat64)source.EWCommsDegradationPercent();
         (*destination)["AutoResupplyPeriod"] = (DtFloat64)source.autoResupplyPeriod();

         (*destination)["CombatEffectiveness"] = source.combatEffectiveness().c_str();
         (*destination)["Posture"] = source.posture().c_str();

         Json::Value postureTransition;
         const DtPostureTransitionRecord& postureTrans = source.postureTransition();
         postureTransition["IsTransitioning"] = (bool)postureTrans.isTransitioning();
         postureTransition["NewPosture"] = postureTrans.newPosture().c_str();
         postureTransition["TimeStarted"] = (DtFloat64)postureTrans.timeStarted();
         postureTransition["TimeFinished"] = (DtFloat64)postureTrans.timeFinished();

         (*destination)["PostureTransition"] = postureTransition;

         Json::Value equipment(Json::arrayValue);
         convertTypedQuantityRecordList(source.equipment(), equipment);
         (*destination)["Equipment"] = equipment;

         Json::Value baseEquipment(Json::arrayValue);
         convertTypedQuantityRecordList(source.baseEquipment(), baseEquipment);
         (*destination)["BaseEquipment"] = baseEquipment;

         Json::Value weapons(Json::arrayValue);
         convertTypedQuantityRecordList(source.weapons(), weapons);
         (*destination)["Weapons"] = weapons;

         Json::Value baseWeapons(Json::arrayValue);
         convertTypedQuantityRecordList(source.baseWeapons(), baseWeapons);
         (*destination)["BaseWeapons"] = baseWeapons;

         Json::Value ammunition(Json::arrayValue);
         convertTypedQuantityRecordList(source.ammunition(), ammunition);
         (*destination)["Ammunition"] = ammunition;

         Json::Value baseAmmunition(Json::arrayValue);
         convertTypedQuantityRecordList(source.baseAmmunition(), baseAmmunition);
         (*destination)["BaseAmmunition"] = baseAmmunition;

         Json::Value food(Json::objectValue);
         convertAmountRecord(source.food(), food);
         (*destination)["Food"] = food;

         Json::Value baseFood(Json::objectValue);
         convertAmountRecord(source.baseFood(), baseFood);
         (*destination)["BaseFood"] = baseFood;

         Json::Value water(Json::objectValue);
         convertAmountRecord(source.water(), water);
         (*destination)["Water"] = water;

         Json::Value baseWater(Json::objectValue);
         convertAmountRecord(source.baseWater(), baseWater);
         (*destination)["BaseWater"] = baseWater;

         Json::Value motorGas(Json::objectValue);
         convertAmountRecord(source.motorGas(), motorGas);
         (*destination)["MotorGas"] = motorGas;

         Json::Value baseMotorGas(Json::objectValue);
         convertAmountRecord(source.baseMotorGas(), baseMotorGas);
         (*destination)["BaseMotorGas"] = baseMotorGas;

         Json::Value aviationFuel(Json::objectValue);
         convertAmountRecord(source.aviationFuel(), aviationFuel);
         (*destination)["AviationFuel"] = aviationFuel;

         Json::Value baseAviationFuel(Json::objectValue);
         convertAmountRecord(source.baseAviationFuel(), baseAviationFuel);
         (*destination)["BaseAviationFuel"] = baseAviationFuel;

         Json::Value dieselFuel(Json::objectValue);
         convertAmountRecord(source.dieselFuel(), dieselFuel);
         (*destination)["DieselFuel"] = dieselFuel;

         Json::Value baseDieselFuel(Json::objectValue);
         convertAmountRecord(source.baseDieselFuel(), baseDieselFuel);
         (*destination)["BaseDieselFuel"] = baseDieselFuel;

         Json::Value oil(Json::objectValue);
         convertAmountRecord(source.oil(), oil);
         (*destination)["Oil"] = oil;

         Json::Value baseOil(Json::objectValue);
         convertAmountRecord(source.baseOil(), baseOil);
         (*destination)["BaseOil"] = baseOil;

         Json::Value lubricant(Json::objectValue);
         convertAmountRecord(source.lubricant(), lubricant);
         (*destination)["Lubricant"] = lubricant;

         Json::Value baseLubricant(Json::objectValue);
         convertAmountRecord(source.baseLubricant(), baseLubricant);
         (*destination)["BaseLubricant"] = baseLubricant;

         Json::Value MOPPTransition;
         MOPPTransition["IsTransitioning"] = (bool)source.MOPPTransition().isTransitioning();
         MOPPTransition["NewLevel"] = (DtInt32)source.MOPPTransition().newLevel();
         MOPPTransition["TimeStarted"] = (DtFloat64)source.MOPPTransition().timeStarted();
         MOPPTransition["TimeFinished"] = (DtFloat64)source.MOPPTransition().timeFinished();
         (*destination)["MOPPTransition"] = MOPPTransition;

         (*destination)["Activity"] = source.activity().c_str();

         (*destination)["EngagementResults"] = source.engagementResults().c_str();

         Json::Value indirectFirePower(Json::arrayValue);
         convertIndirectFirePowerRecordList( source.indirectFirePower(), indirectFirePower );
         (*destination)["IndirectFirePower"] = indirectFirePower;

         Json::Value combatPower(Json::arrayValue);
         convertRangedPowerRecordList(source.combatPower(), combatPower);
         (*destination)["CombatPower"] = combatPower;

         Json::Value vulnerability(Json::arrayValue);
         convertEffectModifierRecordList(source.vulnerability(), vulnerability);
         (*destination)["Vulnerability"] = vulnerability;

         Json::Value casualtiesPerAttacker( Json::arrayValue );
         convertCasualtyReportRecordList( source.casualtiesPerAttacker(), casualtiesPerAttacker );
         (*destination)["CasualtiesPerAttacker"] = casualtiesPerAttacker;

         Json::Value resources(Json::arrayValue);
         convertTypedAmountRecordList(source.resources(), resources);
         (*destination)["Vulnerability"] = resources;

         Json::Value baseResources(Json::arrayValue);
         convertTypedResupplyAmountRecordList( source.baseResources(), baseResources);
         (*destination)["Vulnerability"] = baseResources;

         (*destination)["Contamination"] = source.contamination().c_str();

         Json::Value EWAttacks(Json::arrayValue);
         convertEWAttackRecordList(source.EWAttacks(), EWAttacks);
         (*destination)["EWAttacks"] = EWAttacks;

         Json::Value EWAttacksDefending(Json::arrayValue);
         convertEWAttackDefendingRecordList(source.EWAttacksDefending(), EWAttacksDefending);
         (*destination)["EWAttackDefending"] = EWAttacksDefending;

         (*destination)["ResupplyType"] = source.resupplyMode().c_str();

         Json::Value suppliesOffered(Json::arrayValue);
         convertTypedRateRecordList(source.suppliesOffered(), suppliesOffered);
         (*destination)["SuppliesOffered"] = suppliesOffered;

         (*destination)["AutoResupplyPeriod"] = (DtFloat64)source.autoResupplyPeriod();
      }

      void DtVrfAggregateTranslator::addAdditionalDataValue( const DtString& name,
         const std::string& tag, const Json::Value& source )
      {
         Json::Value v = myAdditionalDataMap[name];
         v[tag] = source;
         myAdditionalDataMap[name] = v;

         // if it is then this message beat the object update and
         // the data can hang out until the discovery
         std::map<DtString,DtString>::iterator i = myNameLookup.find( name );
         if ( i != myNameLookup.end() )
         {
            // otherwise mark the entity for updating to the clients
            myLock.writeLock();

            std::map<void*, std::set<DtString> >::iterator u = this->myLvcUpdateSet.begin();
            for ( ; u != this->myLvcUpdateSet.end(); ++u )
            {
               u->second.insert( i->second );
            }

            myLock.unlock();
         }
      }

      void DtVrfAggregateTranslator::removePortalObject( const DtPortalReflectedVrfAggregate& obj )
      {
         myLock.writeLock();

         myAdditionalDataMap.erase( obj.sr()->markingText() );
         myNameLookup.erase( obj.sr()->markingText() );

         myLock.unlock();

         ParentClass::removePortalObject( obj );
      }

   }
}
