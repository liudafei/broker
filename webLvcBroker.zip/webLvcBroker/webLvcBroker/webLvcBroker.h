/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file webLvcBroker.h
//! \brief Contains the DtWebLvcBroker class declaration.
//! \ingroup webLvcBroker

#pragma once

#include <broker/broker.h>
#include <broker/translatorFactory.h>

#include <webLvcBroker/reliableConnectionServer.h>
#include <webLvcBroker/webLvcBrokerInitializer.h>
#include <webLvcBroker/lockingReflectedObjMgr.h>

#include <portal/pReflectedObjectManagerTypes.h>
#include <portal/pReflectedObjectTypes.h>

#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/WebSocket.h>
#include <Poco/RWLock.h>

#include <json/json.h>

namespace MAKVrExchange
{

   class DtPortalObjectPublisher;

   namespace DtWebLvcBroker
   {

      class DtClient;
      class DtWebLvcBroker;
      class DtTcpConnectionServer;
      class DtBaseWebLvcObjectTranslator;
      class DtBaseWebLvcInteractionTranslator;

      //! \brief Enumeration for WebLVC Broker Object Data field(s).
      enum WebLvcBrokerObjectDataField
      {
         ClientPtrData = 0
      };

      //! \brief Class DtWebLvcBroker is a class that enables clients
      //! to receive entity state updates from VR-Exchange via a TCP or
      //! web socket connection.  The choice of connection type is specified via
      //! command line argument.  By default, the server uses web socket connections.
      //! It responds to requests from clients to create a reliable connection
      //! through which it sends entity state updates from the DIS/HLA exercise.
      //! It acts as a bridge between DIS/HLA simulations and web-based applications
      //! (or a Kaazing server, in the case of TCP).
      //! \ingroup webLvcBroker
      class DT_DLL_WEBLVCBROKER DtWebLvcBroker : public MAKVrExchange::DtBroker
      {
      public:

         typedef std::map<const DtString,DtInteractionTranslator*> NamedInteractionTranslatorMap;
         typedef std::map<const DtString,DtObjectTranslator*> NamedObjectTranslatorMap;

      public:

         //! \brief Creator function. This returns a pointer to an instance of a DtWebLvcBroker
         //! Calls DtWebLvcBroker::initialize( DtWebLvcBrokerInitializer* )
         static DtBroker* create( DtBrokerInitializer* init );

         //! \brief Virtual DTOR.
         virtual ~DtWebLvcBroker();

         // process incoming and outgoing messages
         virtual void tick();

         //! \brief Get the broker initializer to catch configuration options
         virtual DtWebLvcBrokerInitializer* webLvcInitializer();

         //! \brief Open a TCP connection to the given host on the given port.
         virtual void initiateTcpConnection( const DtString& hostname, int port );

         virtual DtClient* manualTcpClient() { return myManualTcpClient; }

         //! \brief Returns the list of clients.
         //! Appropriate locks must be obtained before modifying clients or the list itself.
         virtual std::list<DtClient*>& clientList() { return theClientList; }

         //! \brief Send a message to the clients.
         //! Queues a message to be sent to clients. The given client is the client that
         //! triggered the message to be sent (where the message originated from), and will
         //! not receive the message when sent. This is to avoid sending object updates
         //! back to the client that sent the update.
         virtual void queueToSend( std::string& msg, DtClient* client );

         // Add a new client. (We would need to re-send all the LVC data.
         virtual bool addClient( DtClient* );

         // Access the lists of translators
         virtual const NamedInteractionTranslatorMap& interactionTranslators() { return myInteractionTranslatorMap; }
         virtual const NamedObjectTranslatorMap& objectTranslators() { return myObjectTranslatorMap; }

         virtual void addAttributeUpdateCB( const std::string& s, DtBaseWebLvcObjectTranslator* trans );
         virtual void removeAttributeUpdateCB( const std::string& s );
         virtual void addInteractionCB( const std::string& s, DtBaseWebLvcInteractionTranslator* trans );
         virtual void removeInteractionCB( const std::string& s );

         //! Adds an additional data value to all interested translators.
         virtual void addAdditionalDataValue( const DtString& name, const std::string& tag, const Json::Value& source );

         //! Adds an additional data value to the additional data map in the template translator.
         template<typename T>
         void addAdditionalDataValue( const DtString& name, const std::string& tag, const Json::Value& source );

         // Depreciated, handled by clients now
         virtual int processObjectUpdateSets( void* id );

         // statistics accessors
         virtual DtTime startTime() { return myStartTime; };
         virtual int clientsSinceStart() { return numClientsSinceStart; }
         virtual void setAvgFrameTime( DtTime t) { myAvgFrameTime = t; }
         virtual DtTime avgFrameTime() { return myAvgFrameTime; }

      protected:

         //! \brief Default CTOR.
         //! Protected - use create method.
         DtWebLvcBroker();

         //! \brief Initializes the WebLVC Broker.
         //! Must be called after the broker is instantiated.
         //! Calls the following methods:
         //!    DtWebLvcBroker::setupTranslators()
         //!    DtBroker::initialize( DtBrokerInitializer* )
         //!    DtWebLvcBroker::startBroker()
         virtual void initialize( DtWebLvcBrokerInitializer* init );

         //! \brief Add the default set of translators to the factories.
         virtual void setupTranslators( DtWebLvcBrokerInitializer* init );

         //! \brief Shut down the broker.
         //! Overridden to save persistent Entity IDs and destroy the ID mappers.
         virtual void shutdown();

         // load the translators defined in the factories.  Plugins will initialize after this so they
         // can modify the translators loaded.
         virtual void loadTranslators();

         // process gui events
         virtual void processEvents();

         //! \brief Starts the broker.
         virtual void startBroker();

         //! send a message to all clients
         virtual void sendToWebClients( std::string buffer );

         //! check the receive queues of the clients and process the messages
         virtual void receiveFromWebClients();

         //! determines what to do with messages inbound from clients
         virtual void processInboundMessage( std::string &msg, DtClient* client );

         //! processes attribute update messages from clients
         virtual void processAttributeUpdateMessage( Json::Value*, DtClient* client );

         //! processes interaction messages from clients
         virtual void processInteractionMessage( Json::Value*, DtClient* client );

         //! processes object deletion messages from clients
         virtual void processObjectDeletionMessage( Json::Value*, DtClient* client );

         //! forwarded the stored messages on to the clients
         virtual void sendQueue();

      private:

         //! Copy Constructor not implemented -- Copy Not Allowed
         DtWebLvcBroker( const DtWebLvcBroker& other );

         //! Assignment Operator Not implemented -- Assignment Not Allowed
         DtWebLvcBroker& operator = ( const DtWebLvcBroker& other );

      public:

         static Poco::RWLock theRWLock;
         static DtWebLvcBroker* theWebLvcBroker;

      protected:

         //! \brief Portal Connection Callback, registered during initialize
         static void processConnectCb(const DtBrokerConnectingMessage& msg, void* usr);

         //! HTTP server that handles web socket requests.
         std::vector<DtReliableConnectionServer*> myServers;

         //! HTTP server that handles tcp socket requests.
         DtReliableConnectionServer* myTcpServer;

         //! Amount of time we sleep each tick in seconds.
         double mySleepInterval;

         //! @name Statistics variables.
         //! @{

         int myNumClients;
         DtTime myStartTime;
         int numClientsSinceStart;
         DtTime myAvgFrameTime;
         bool myUpdateClients;

         //! @}

         //! Web Clients that are connected
         std::list<DtClient*> theClientList;

         //! Storage for manually created TCP client.
         DtClient* myManualTcpClient;

         //! message queue that is forwarded to clients
         typedef std::pair<DtClient*,std::string> ClientMessagePair;
         typedef std::list<ClientMessagePair> SendQueue;
         SendQueue mySendQueue;

         std::map<std::string,DtBaseWebLvcObjectTranslator*> myAttributeUpdateTranslatorCBs;
         std::map<std::string,DtBaseWebLvcInteractionTranslator*> myInteractionTranslatorCBs;

      };

   }
}
