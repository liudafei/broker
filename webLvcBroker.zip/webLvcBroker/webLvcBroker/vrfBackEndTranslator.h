/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file vrfBackEndTranslator.h
//! \brief Contains the DtVrfBackEndTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#if ! _WIN64
#  ifndef _WIN32_WINNT
#     define _WIN32_WINNT 0x400
#  endif
#endif

#include <portal/pVrfBackEnd.h>
#include <broker/brokerObject.h>
#include <webLvcBroker/lvcObjectTranslator.h>

#define VRF_BACKEND_TEMPLATE_ARGS \
   DtPortalVrfBackEndObject, DtPortalReflectedVrfBackEndObject

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtVrfBackEndTranslator are responsible for translating DtPortalVrfBackEndObject to MAK:VRFBackEnd.
      class DT_DLL_WEBLVCBROKER DtVrfBackEndTranslator
         : public DtLvcObjectTranslator<VRF_BACKEND_TEMPLATE_ARGS>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "MAK:VRFBackEnd" );

         //! \brief CTOR.
         DtVrfBackEndTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtVrfBackEndTranslator();

         virtual void translate( const Json::Value& source, DtPortalVrfBackEndObject* destination );
         virtual void translate( const DtPortalVrfBackEndObject& source, Json::Value* destination );

      };

   }
}
