/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file environmentalTranslator.h
//! \brief Contains the DtEnvironmentalTranslator class declaration.
//! \ingroup webLvcBroker

#pragma once

#if ! _WIN64
#  ifndef _WIN32_WINNT
#     define _WIN32_WINNT 0x400
#  endif
#endif

#include <broker/brokerObject.h>
#include <portal/pEnvironmentProcessObject.h>
#include <webLvcBroker/lvcObjectTranslator.h>
#include <omtReader/datatypeManager.h>
#include <omtReader/omtTree.h>

#define ENVOBJ_TEMPLATE_ARGS \
   DtPortalEnvironmentProcessObject, DtPortalReflectedEnvironmentProcessObject

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      //! \brief DtEnvironmentalTranslator are responsible for translating DtPortalEnvironmentProcessObject to WebLVC:EnvironmentalEntity.
      class DT_DLL_WEBLVCBROKER DtEnvironmentalTranslator
         : public DtLvcObjectTranslator<ENVOBJ_TEMPLATE_ARGS>
      {
      public:

         //! \brief Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "WebLVC:EnvironmentalEntity" );

         //! \brief CTOR.
         DtEnvironmentalTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtEnvironmentalTranslator();

         virtual void translate( const Json::Value& source, DtPortalEnvironmentProcessObject* destination );
         virtual void translate( const DtPortalEnvironmentProcessObject& source, Json::Value* destination );

      };

   }
}
