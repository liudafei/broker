/*********************************************************************
** Copyright (c) 1992-2010 VT MAK
** All rights reserved.
*********************************************************************/

#include "beamAntennaPatternRecord.h"

#include <stdlib.h>
#include <vlpi/parseEnum.h>
#include <vlutil/vlPrint.h>
#include <vlutil/vlPrintUtil.h>

DtBeamAntennaPatternRecord::DtBeamAntennaPatternRecord() :
   myBeamDirection(),
   myAzimuthBandwidth((DtFloat32)0.),
   myElevationBeamwidth((DtFloat32)0.),
   myReferenceSystem(DtReferenceSysWorldCoordinates),
   myEz((DtFloat32)0.),
   myEx((DtFloat32)0.),
   myPhase((DtFloat32)0.)
{
}

DtBeamAntennaPatternRecord::~DtBeamAntennaPatternRecord()
{
}

DtBeamAntennaPatternRecord::DtBeamAntennaPatternRecord(
   const DtBeamAntennaPatternRecord& orig) :
   myBeamDirection(orig.myBeamDirection),
   myAzimuthBandwidth(orig.myAzimuthBandwidth),
   myElevationBeamwidth(orig.myElevationBeamwidth),
   myReferenceSystem(orig.myReferenceSystem),
   myEz(orig.myEz),
   myEx(orig.myEx),
   myPhase(orig.myPhase)
{
}

DtBeamAntennaPatternRecord::DtBeamAntennaPatternRecord(
   const void* net, int size)
{
   setFromNet(net, size);
}

// assignment operator
DtBeamAntennaPatternRecord& DtBeamAntennaPatternRecord::operator=(
   const DtBeamAntennaPatternRecord& orig)
{
   // Guard against assignment to yourself.
   if (this == &orig)
   {
      return *this;
   }

   myBeamDirection = orig.myBeamDirection;
   myAzimuthBandwidth = orig.myAzimuthBandwidth;
   myElevationBeamwidth = orig.myElevationBeamwidth;
   myReferenceSystem = orig.myReferenceSystem;
   myEz = orig.myEz;
   myEx = orig.myEx;
   myPhase = orig.myPhase;

   return *this;
}

void DtBeamAntennaPatternRecord::setFromNet(const void* net, int size)
{
  if (net)
    {
     setFromNetBeam(*(DtNetBeamAntennaPatternRecord*) net);
    }
}

int DtBeamAntennaPatternRecord::netSize() const
{
   return sizeof(DtNetBeamAntennaPatternRecord);
}

const void* DtBeamAntennaPatternRecord::netRep(int* size) const
{
   if (size)
   {
      *size = sizeof(DtNetBeamAntennaPatternRecord);
   }
   return &netBeam();
}

void DtBeamAntennaPatternRecord::setFromNetBeam(
   const DtNetBeamAntennaPatternRecord& net)
{
   myBeamDirection = (DtTaitBryan) net.angles;
   myAzimuthBandwidth = net.azimuthWidth;
   myElevationBeamwidth = net.elevationWidth;
   myReferenceSystem = (DtReferenceSys) net.refSystem;
   myEz = net.ez;
   myEx = net.ex;
   myPhase = net.phase;
}

const DtNetBeamAntennaPatternRecord& 
   DtBeamAntennaPatternRecord::netBeam() const
{
   // myNetBeam is simply a place for copying the beam info;
   ((DtBeamAntennaPatternRecord*) this)->myNetBeam.angles = myBeamDirection;
   ((DtBeamAntennaPatternRecord*) this)->myNetBeam.azimuthWidth = myAzimuthBandwidth;
   ((DtBeamAntennaPatternRecord*) this)->myNetBeam.elevationWidth = myElevationBeamwidth;
   ((DtBeamAntennaPatternRecord*) this)->myNetBeam.refSystem = myReferenceSystem;
   ((DtBeamAntennaPatternRecord*) this)->myNetBeam.ez = myEz;
   ((DtBeamAntennaPatternRecord*) this)->myNetBeam.ex = myEx;
   ((DtBeamAntennaPatternRecord*) this)->myNetBeam.phase = myPhase;

   return myNetBeam;
}

void DtBeamAntennaPatternRecord::setAngles(const DtTaitBryan &angles)
{
   myBeamDirection = angles;
}

const DtTaitBryan& DtBeamAntennaPatternRecord::angles() const
{
   return myBeamDirection;
}

// Set/Get the azimuth bandwidth and elevation
void DtBeamAntennaPatternRecord::setBeamwidth(DtFloat32 azimuth, 
   DtFloat32 elevation)
{
   myAzimuthBandwidth = azimuth;
   myElevationBeamwidth = elevation;
}

// Get the azimuth beam bandwidth
DtFloat32 DtBeamAntennaPatternRecord::azimuthBeamwidth() const
{
   return myAzimuthBandwidth;
}

// Get the elevation beam width
DtFloat32 DtBeamAntennaPatternRecord::elevationBeamwidth() const
{
   return myElevationBeamwidth;
}

// Set/Get the beam reference system
void DtBeamAntennaPatternRecord::setReferenceSystem(const DtReferenceSys sys)
{
   myReferenceSystem = sys;
}

DtReferenceSys DtBeamAntennaPatternRecord::referenceSystem() const
{
   return myReferenceSystem;
}

// Set electric field
void DtBeamAntennaPatternRecord::setElectricField(DtFloat32 z, 
                                           DtFloat32 x)
{
   myEz = z;
   myEx = x;
}

// Get electric field Z
DtFloat32 DtBeamAntennaPatternRecord::electricFieldZ() const
{
   return myEz;
}

// Get electric field X
DtFloat32 DtBeamAntennaPatternRecord::electricFieldX() const
{
   return myEx;
}
   
// Set/Get the phase
void DtBeamAntennaPatternRecord::setPhase(DtFloat32 phase)
{
   myPhase = phase;
}

DtFloat32 DtBeamAntennaPatternRecord::phase() const
{
   return myPhase;
}
