/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioSignalTranslator.cxx
//! \brief Contains the DtRadioSignalTranslator class definition.
//! \ingroup webLvcBroker

#include <webLvcBroker/radioSignalTranslator.h>
#include <Poco/Base64Encoder.h>
#include <Poco/Base64Decoder.h>
#include <json/json.h>
#include <vector>

namespace MAKVrExchange
{

   namespace DtWebLvcBroker
   {

      DtRadioSignalTranslator::DtRadioSignalTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtRadioSignalInteractionKind )
      {
      }

      DtRadioSignalTranslator::~DtRadioSignalTranslator()
      {
      }

      void DtRadioSignalTranslator::translate( const Json::Value& source,
         DtPortalRadioSignalInteraction* destination )
      {
         destination->setHostRadioId(source["RadioIdentifier"].asCString());
         destination->setEncodingClass(source["EncodingClass"].asUInt());
         destination->setEncodingType(source["EncodingType"].asUInt());
         destination->setTacticalDataLinkType(source["TDLType"].asUInt());
         destination->setDataRate(source["SampleRate"].asUInt());
         destination->setSamples(source["SampleCount"].asUInt());
         destination->setUserProtocolID(source["UserProtocolID"].asUInt());
         destination->setDatabaseIndex(source["DatabaseIndex"].asUInt());

         std::stringstream ss;
         ss << source["SampleData"].asCString();
         Poco::Base64Decoder decoder(ss);
         std::vector<char> dataArray;
         while (decoder.good() == true && decoder.eof() == false)
         {
            dataArray.push_back(decoder.get());
         }
         DtVariableLengthData data;
         data.setDataArray(dataArray);
         destination->setSignalData(data);
      }

      void DtRadioSignalTranslator::translate( const DtPortalRadioSignalInteraction& source,
         Json::Value* destination )
      {
         (*destination)["RadioIdentifier"]=source.hostRadioId().c_str();
         (*destination)["EncodingClass"]=(unsigned int)source.encodingClass();
         (*destination)["EncodingType"]=(unsigned int)source.encodingType();
         (*destination)["TDLType"]=(unsigned int)source.tacticalDataLinkType();
         (*destination)["SampleRate"]=(unsigned int)source.dataRate();
         (*destination)["SampleCount"]=(unsigned int)source.samples();
         (*destination)["UserProtocolID"]=(unsigned int)source.userProtocolID();
         (*destination)["DatabaseIndex"]=(unsigned int)source.databaseIndex();

         std::stringstream ss;
         Poco::Base64Encoder encoder( ss );
         encoder.write( source.signalData().data(), source.signalData().size() );
         encoder.close();
         (*destination)["SampleData"] = ss.str();
      }

   }
}
