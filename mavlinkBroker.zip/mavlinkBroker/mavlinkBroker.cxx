/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

#include "mavlinkBroker.h"
#include "mavlinkBrokerInitializer.h"
#include "entityTranslator.h"
#include "mavlinkIdMapper.h"

#include <broker/statisticsManager.h>

#include "MAVSDKWrapper.h"
#include "Logger.h"


namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        DtBroker* DtMavlinkBroker::create(DtBrokerInitializer* init)
        {
            DtMavlinkBroker* broker = new DtMavlinkBroker();
            broker->initialize(dynamic_cast<DtMavlinkBrokerInitializer*>(init));
            return broker;
        }

        DtMavlinkBroker::~DtMavlinkBroker()
        {
            DtInfo << "Broker(" << brokerName() << "): Shutting down." << std::endl;
        }

        DtMavlinkBroker::DtMavlinkBroker()
            : DtBroker()
            , myMavlinkWrapper(nullptr)
            , myIdMapper(nullptr)
        {
        }

        void DtMavlinkBroker::tick()
        {
            // 仿照 disBroker::tick 的逻辑结构

            // 1. 网络处理阶段 (带统计和异常捕获)
            try
            {
                // 开始统计
                if (myStatisticsManager)
                {
                    myStatisticsManager->startSection(DtFrameTimer::MESSAGE_PROC);
                }

                // MAVLink 数据处理：
                // disBroker 在这里调用 drainInput 读取 socket。
                // MAVSDK 使用内部线程接收数据，放入缓冲区。
                // 这里我们可以留空，或者添加一个 poll() 调用（如果需要）。
                // 数据实际上已经在 MavsdkWrapper 回调中缓存了。

                // 结束统计
                if (myStatisticsManager)
                {
                    myStatisticsManager->endSection(DtFrameTimer::MESSAGE_PROC);
                }
            }
            DtCATCH_AND_WARN(DtWarn); // 使用 VR-Link 标准异常捕获宏

            // 2. 驱动转换器
            // 调用基类 tick，基类会遍历 myObjectTranslatorMap/myInteractionTranslatorMap
            // 并调用每个转换器的 tick() 方法。
            DtBroker::tick();
        }

        DtMavlinkBrokerInitializer* DtMavlinkBroker::mavlinkInitializer()
        {
            return dynamic_cast<DtMavlinkBrokerInitializer*>(myBrokerInitializer);
        }
        DtMavlinkIdMapper* DtMavlinkBroker::idMapper()
        {
            return myIdMapper;
        }
        MavsdkWrapper* DtMavlinkBroker::wrapper()
        {
            return myMavlinkWrapper;
        }

        void DtMavlinkBroker::initialize(DtMavlinkBrokerInitializer* init)
        {
            // 1. Setup Translators (仿照 disBroker::setupTranslators)
            setupTranslators(init);

            // 2. Call Parent Initialize (Initializes Portal Connection)
            // 注意：基类 initialize 接收基类指针
            DtBroker::initialize(init);
        }

        void DtMavlinkBroker::setupTranslators(DtMavlinkBrokerInitializer* init)
        {
            myObjectTranslatorFactory.addCreator<DtEntityTranslator>();

            DtInfo << "Broker(" << brokerName() << "): MAVLink Translators registered." << std::endl;
        }

        void DtMavlinkBroker::logBrokerSettings(DtBrokerInitializer * init)
        {
            DtBroker::logBrokerSettings(init);

            DtMavlinkBrokerInitializer* mavInit = mavlinkInitializer();

            if (mavInit)
            {
                DtInfo << "Broker(" << brokerName() << "): MAVLink URL: " << mavInit->mavlinkConnectionUrl() << std::endl;
            }
        }

        void DtMavlinkBroker::shutdown()
        {
            DtBroker::shutdown();

            DtDELETE(myMavlinkWrapper);
            DtDELETE(myIdMapper      );
        }

        void DtMavlinkBroker::initMavlinkConnection(DtMavlinkBrokerInitializer & init)
        {
            DtInfo << "Broker(" << brokerName() << "): Initializing MAVLink Connection..." << std::endl;

            myMavlinkWrapper = new MavsdkWrapper();
            DtString connUrl = init.mavlinkConnectionUrl();

            if (!myMavlinkWrapper->add_any_connection(connUrl.c_str()))
            {
                DtWarn << "Broker(" << brokerName() << "): Failed to connect to " << connUrl << std::endl;
            }
        }

        void DtMavlinkBroker::startBroker()
        {
            // 1. Create ID Mapper (对应 DisBroker 创建 GlobalIdMapper)
            myIdMapper = new DtMavlinkIdMapper();

            // 2. Initialize MAVLink Connection
            initMavlinkConnection(*mavlinkInitializer());

            // 3. Call Parent Start
            // DtBroker::startBroker 会调用 loadTranslators()，从而实例化上面注册的转换器
            DtBroker::startBroker();
        }
    }
}
