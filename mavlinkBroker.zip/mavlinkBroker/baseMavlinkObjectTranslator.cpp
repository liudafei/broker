/**************************************************************************** * Copyright (c) 2023 MAK * All rights reserved. ****************************************************************************/
//! \file baseMavlinkObjectTranslator.cxx
//! \brief Contains the DtBaseMavlinkObjectTranslator class definition.
//! \ingroup mavlinkBroker

#include "baseMavlinkObjectTranslator.h"
#include "mavlinkBroker.h"

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        // ----------------------------------------------------------------------------
        // Construction
        // ----------------------------------------------------------------------------

        DtBaseMavlinkObjectTranslator::DtBaseMavlinkObjectTranslator(
            DtBroker* broker,
            const DtString& name,
            DtPortalMessageKind kind
        )
            : DtObjectTranslator(broker, name, kind)
        {
            // 基础初始化逻辑
        }

        DtBaseMavlinkObjectTranslator::~DtBaseMavlinkObjectTranslator()
        {
            // 基础清理逻辑
        }

        // ----------------------------------------------------------------------------
        // Accessors
        // ----------------------------------------------------------------------------

        DtMavlinkBroker* DtBaseMavlinkObjectTranslator::mavlinkBroker()
        {
            // 将基类 myBroker 指针转换为具体的 DtMavlinkBroker 指针
            return static_cast<DtMavlinkBroker*>(myBroker);
        }

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
