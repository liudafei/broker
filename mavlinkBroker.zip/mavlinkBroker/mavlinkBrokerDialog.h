// mavlinkBrokerDialog.h
#pragma once

#include <widgets/brokerDialog.h>
#include <string>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        class DtMavlinkBroker;
        class DtMavlinkBrokerInitializer;

        class DtMavlinkBrokerDialog : public DtBrokerDialog
        {
            Q_OBJECT
        public:
            static DtBrokerDialog* create(DtBroker* broker, DtBrokerInitializer* init, QWidget* parent = 0);

        protected:
            DtMavlinkBrokerDialog(DtMavlinkBroker* broker, DtMavlinkBrokerInitializer* init, QWidget* parent = 0);
            virtual ~DtMavlinkBrokerDialog();

            virtual DtMavlinkBrokerInitializer* mavlinkInitializer();

            // 重写以自定义界面标签
            virtual void initObjectListViewHeaders();

            // 重写以创建自定义设置面板 (可选)
            // virtual DtConnectionSettingsWidget* instantiateConnectionSettingsWidget();
        };

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
