/****************************************************************************
 * Copyright (c) 2013 VT MAK
 * All rights reserved.
 ****************************************************************************/

#pragma once

#include <broker/broker.h>
#include <broker/translatorFactory.h>
#include <string>

class MavsdkWrapper;

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        class DtMavlinkBrokerInitializer;
        class DtMavlinkIdMapper;

        // A mavlink broker class that implements DtBroker for the mavlink protocol.
        // All broker applications must have a DtBrokerInstance. The DtBroker class
        // manages the application by listening for control messages from the
        // dataExchange.
        class DtMavlinkBroker : public DtBroker
        {
        public:

            // Create method - instantiates a new DtMavlinkBroker.
            static DtBroker* create(DtBrokerInitializer* init);

            // Virtual DTOR.
            virtual ~DtMavlinkBroker();

        protected:
            // Protected CTOR (use ::create()).
            DtMavlinkBroker();

        protected:
            // Must provide a Tick Function. This is called periodically.
            virtual void tick();

            //! \brief Get the broker initializer to catch configuration options
            virtual DtMavlinkBrokerInitializer* mavlinkInitializer();

            //! \brief Get the ID Mapper.
            virtual DtMavlinkIdMapper* idMapper();

            //! \brief Get the MAVLink Wrapper (Connection).
            virtual MavsdkWrapper* wrapper();

        public:
            // Initialization function - called from ::create().
            virtual void initialize(DtMavlinkBrokerInitializer* init);

            //! \brief Add the default set of translators to the factories.
            virtual void setupTranslators(DtMavlinkBrokerInitializer* init);

            //! \brief Logs settings (simulating logBrokerSettings).
            virtual void logBrokerSettings(DtBrokerInitializer* init);

            //! \brief Shut down the broker.
            //! Overridden to save persistent Entity IDs and destroy the ID mappers.
            virtual void shutdown();

            //! \brief Initializes the MAVLink Connection (MavsdkWrapper).
            virtual void initMavlinkConnection(DtMavlinkBrokerInitializer& init);

            //! \brief Initializes the broker.
            virtual void startBroker();

        private:
            DtMavlinkBroker(const DtMavlinkBroker&);
            DtMavlinkBroker& operator=(const DtMavlinkBroker&);

        protected:
            MavsdkWrapper* myMavlinkWrapper;

            // The ID Mapper (simulating DtGlobalIdMapper)
            DtMavlinkIdMapper* myIdMapper;
        };
    }
}
