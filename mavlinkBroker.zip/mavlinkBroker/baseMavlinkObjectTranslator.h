#pragma once

#include <broker/baseObjectTranslator.h>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        class DtMavlinkBroker;

        //! \brief Base class for MAVLink object translators.
        //! Provides common infrastructure similar to DtBaseWebLvcObjectTranslator.
        class DtBaseMavlinkObjectTranslator : public DtObjectTranslator
        {
        public:
            DtBaseMavlinkObjectTranslator(DtBroker* broker, const DtString& name, DtPortalMessageKind kind);
            virtual ~DtBaseMavlinkObjectTranslator();

            //! Helper to cast the broker.
            virtual DtMavlinkBroker* mavlinkBroker();
        };

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
