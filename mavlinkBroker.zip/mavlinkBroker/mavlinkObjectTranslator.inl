#include "mavlinkObjectTranslator.h"
#include "mavlinkBroker.h"
#include "MAVSDKWrapper.h"
#include <portal/pObjectPublisher.h>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        MAVLINK_OBJ_TRANS_TEMPLATE_ARGS
            DtMavlinkObjectTranslator<MAVLINK_OBJ_TRANS_TEMPLATE_FUNC>::DtMavlinkObjectTranslator(DtBroker* broker, const DtString& name, DtPortalMessageKind kind)
            : DtBaseObjectTranslator(broker, name, kind)
        {
            // --- Critical: Subscribe to MAVSDK ---
            // Ideally, mavlinkBroker()->wrapper() returns a valid wrapper at this point.
            if (mavlinkBroker() && mavlinkBroker()->wrapper())
            {
                auto* wrapper = mavlinkBroker()->wrapper();

                // Capture 'this' to call our buffer method
                wrapper->subscribe_on_new_system(
                    [this](uint8_t sysId)
                    {
                        // Trigger discovery logic implicitly when data arrives
                    }
                );

                wrapper->subscribe_raw_gps(
                    [this](uint8_t sysId, const std::vector<double>& data)
                    {
                        this->bufferMavlinkData(sysId, "GPS", data);
                    }
                );

                wrapper->subscribe_attitude_euler(
                    [this](uint8_t sysId, const std::vector<double>& data)
                    {
                        this->bufferMavlinkData(sysId, "ATT", data);
                    }
                );
            }
        }

        MAVLINK_OBJ_TRANS_TEMPLATE_ARGS
            void DtMavlinkObjectTranslator<MAVLINK_OBJ_TRANS_TEMPLATE_FUNC>::tick()
        {
            // 1. Process Portal side (Base class)
            ParentClass::tick();

            // 2. Drain MAVLink buffer (Thread-safe swap)
            std::vector<MavlinkBufferItem> localBuffer;
            {
                std::lock_guard<std::mutex> lock(myBufferMutex);
                localBuffer.swap(myMessageBuffer);
            }

            // 3. Update StateRepos
            for (const auto& item : localBuffer)
            {
                DtBrokerObject* brokerObj = findOrCreateBrokerObject(item.sysId);
                MavlinkStateRepository* sr = (MavlinkStateRepository*)brokerObj->brokerDataPtr(STATE_REPO_SLOT);

                if (item.type == "GPS" && item.values.size() >= 3)
                {
                    sr->setPosition(item.values[0], item.values[1], item.values[2]);
                }
                else if (item.type == "ATT" && item.values.size() >= 3)
                {
                    sr->setAttitude(item.values[0], item.values[1], item.values[2]);
                }
            }

            // 4. Publish Loop
            for (auto& pair : myBrokerObjectMap)
            {
                DtBrokerObject* brokerObj = pair.second;
                MavlinkStateRepository* mavlinkSr = (MavlinkStateRepository*)brokerObj->brokerDataPtr(STATE_REPO_SLOT);

                // Only publish if we have data
                if (mavlinkSr->isDirty())
                {
                    // Ensure Publisher exists (Lazy Creation)
                    if (!brokerObj->publisherPtr())
                    {
                        publishObject(brokerObj);
                    }

                    // Get Portal SR
                    T_PortalObject* portalSr = (T_PortalObject*)((DtPortalObjectPublisher*)brokerObj->publisherPtr())->baseSr();

                    // --- CALL DERIVED CLASS TRANSLATE ---
                    translate(*mavlinkSr, portalSr);

                    // Send
                    ((DtPortalObjectPublisher*)brokerObj->publisherPtr())->tick();

                    // Reset dirty flag
                    mavlinkSr->clearDirty();
                }
            }
        }

        MAVLINK_OBJ_TRANS_TEMPLATE_ARGS
            void DtMavlinkObjectTranslator<MAVLINK_OBJ_TRANS_TEMPLATE_FUNC>::bufferMavlinkData(uint8_t sysId, const std::string& type, const std::vector<double>& values)
        {
            std::lock_guard<std::mutex> lock(myBufferMutex);
            myMessageBuffer.push_back({ sysId, type, values });
        }

        MAVLINK_OBJ_TRANS_TEMPLATE_ARGS
            DtBrokerObject* DtMavlinkObjectTranslator<MAVLINK_OBJ_TRANS_TEMPLATE_FUNC>::findOrCreateBrokerObject(uint8_t sysId)
        {
            auto it = myBrokerObjectMap.find(sysId);
            if (it != myBrokerObjectMap.end()) return it->second;

            // Create BrokerObject
            DtBrokerObject* obj = new DtBrokerObject(false, this->name());
            obj->setObjectName(DtString::format("MAV_%d", sysId));

            // Create MavlinkStateRepository
            MavlinkStateRepository* sr = new MavlinkStateRepository();
            sr->setSysId(sysId);
            obj->setBrokerDataPtr(STATE_REPO_SLOT, sr);

            myBrokerObjectMap[sysId] = obj;
            return obj;
        }

        MAVLINK_OBJ_TRANS_TEMPLATE_ARGS
            void DtMavlinkObjectTranslator<MAVLINK_OBJ_TRANS_TEMPLATE_FUNC>::publishObject(DtBrokerObject* brokerObj)
        {
            MavlinkStateRepository* sr = (MavlinkStateRepository*)brokerObj->brokerDataPtr(STATE_REPO_SLOT);

            // Create Publisher
            DtPortalObjectPublisher* pub = new DtPortalObjectPublisherTemplate<T_PortalObject>(this->broker()->portalConnection());

            // Set initial ID
            DtEntityIdentifier portalId(1, 1, sr->sysId()); // Simple mapping 1:1
            pub->sr()->setEntityId(portalId.string());

            brokerObj->setPublisherPtr(pub);
        }

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
