#include "mavlinkBrokerInitializer.h"


namespace MAKVrExchange
{

    namespace DtMavlinkBroker
    {
        DtMavlinkBrokerInitializer::DtMavlinkBrokerInitializer(int argc, char** argv, const char* versionString)
            : DtBrokerInitializer(argc, argv, versionString)
            , myMavlinkConnectionUrl(mySettings, "mavlinkUrl"       , "udp://:14540", "MAVLink Connection URL", DtBaseConfigVariable::DtScopeBoth      )
            , myHeartbeatInterval   (mySettings, "heartbeatInterval", 1.0           , "Heartbeat Interval"    , DtBaseConfigVariable::DtScopeConfigFile)
        {
            setPluginDirectory("../plugins/mavlinkBroker");
            setLogFileName("mavlinkBroker.log");
        }

        DtMavlinkBrokerInitializer::DtMavlinkBrokerInitializer(const DtMavlinkBrokerInitializer& other)
            : DtBrokerInitializer(other)
            , myMavlinkConnectionUrl(mySettings, "mavlinkUrl"       , "udp://:14540", "MAVLink Connection URL", DtBaseConfigVariable::DtScopeBoth      )
            , myHeartbeatInterval   (mySettings, "heartbeatInterval", 1.0           , "Heartbeat Interval"    , DtBaseConfigVariable::DtScopeConfigFile)
        {
            myMavlinkConnectionUrl = other.myMavlinkConnectionUrl;
            myHeartbeatInterval    = other.myHeartbeatInterval   ;
        }

        DtMavlinkBrokerInitializer::~DtMavlinkBrokerInitializer()
        {}

        DtMavlinkBrokerInitializer& DtMavlinkBrokerInitializer::operator=(const DtMavlinkBrokerInitializer & other)
        {
            // Avoid assinment to self.
            if (this == &other)
            {
                return *this;
            }

            DtBrokerInitializer::operator = (other);
        }

        DtBrokerInitializer* DtMavlinkBrokerInitializer::clone() const
        {
            return new DtMavlinkBrokerInitializer(*this);
        }

        DtString DtMavlinkBrokerInitializer::mavlinkConnectionUrl() const
        {
            return myMavlinkConnectionUrl.value();
        }

        void DtMavlinkBrokerInitializer::setMavlinkConnectionUrl(const DtString& url)
        {
            myMavlinkConnectionUrl.setValue(url);
        }

        DtTime DtMavlinkBrokerInitializer::heartbeatInterval() const
        {
            return myHeartbeatInterval.value();
        }

        void DtMavlinkBrokerInitializer::setHeartbeatInterval(DtTime t)
        {
            myHeartbeatInterval.setValue(t);
        }


    }
}
