#include "mavlinkIdMapper.h"
#include <vlutil/vlPrint.h>
#include <iostream>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        // Static initialization
        DtMavlinkIdMapper::PortalId DtMavlinkIdMapper::theEmptyPortalId;
        DtMavlinkIdMapper::MavlinkId DtMavlinkIdMapper::theEmptyMavlinkId;

        DtMavlinkIdMapper::DtMavlinkIdMapper()
            : myDebugFlag(false)
        {}

        DtMavlinkIdMapper::~DtMavlinkIdMapper()
        {}

        bool DtMavlinkIdMapper::add(const MavlinkId& mavId, const PortalId& portalId)
        {
            if (myDebugFlag)
            {
                DtInfo << "MavlinkIdMapper: Adding Map MAV(" << (int)mavId.sysId << ":" << (int)mavId.compId
                    << ") <-> Portal(" << portalId.string() << ")" << std::endl;
            }

            // Check for existing
            if (myMavToPortalMap.find(mavId) != myMavToPortalMap.end() ||
                myPortalToMavMap.find(portalId) != myPortalToMavMap.end())
            {
                DtWarn << "MavlinkIdMapper: ID Collision detected!" << std::endl;
                return false;
            }

            myMavToPortalMap[mavId] = portalId;
            myPortalToMavMap[portalId] = mavId;
            return true;
        }

        void DtMavlinkIdMapper::removeByPortalId(const PortalId& portalId)
        {
            auto it = myPortalToMavMap.find(portalId);
            if (it != myPortalToMavMap.end())
            {
                MavlinkId mavId = it->second;
                myPortalToMavMap.erase(it);
                myMavToPortalMap.erase(mavId);

                if (myDebugFlag)
                    DtInfo << "MavlinkIdMapper: Removed mapping for Portal " << portalId.string() << std::endl;
            }
        }

        void DtMavlinkIdMapper::removeByMavlinkId(const MavlinkId& mavId)
        {
            auto it = myMavToPortalMap.find(mavId);
            if (it != myMavToPortalMap.end())
            {
                PortalId portalId = it->second;
                myMavToPortalMap.erase(it);
                myPortalToMavMap.erase(portalId);
            }
        }

        const DtMavlinkIdMapper::PortalId& DtMavlinkIdMapper::mavlinkToPortal(const MavlinkId& mavId) const
        {
            auto it = myMavToPortalMap.find(mavId);
            if (it != myMavToPortalMap.end())
                return it->second;
            return theEmptyPortalId;
        }

        const DtMavlinkIdMapper::MavlinkId& DtMavlinkIdMapper::portalToMavlink(const PortalId& portalId) const
        {
            auto it = myPortalToMavMap.find(portalId);
            if (it != myPortalToMavMap.end())
                return it->second;
            return theEmptyMavlinkId;
        }

        void DtMavlinkIdMapper::setDebug(bool on) { myDebugFlag = on; }
        bool DtMavlinkIdMapper::debug() const { return myDebugFlag; }

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
