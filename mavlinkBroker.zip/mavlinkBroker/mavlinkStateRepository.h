/**************************************************************************** * Copyright (c) 2023 MAK * All rights reserved. ****************************************************************************/
//! \file mavlinkStateRepository.h
//! \brief Contains the MavlinkStateRepository class declaration.
//! \ingroup mavlinkBroker

#pragma once

#include <vlutil/vlString.h>
#include <vlutil/vlTime.h>
#include <matrix/vlVector.h>
#include <cstdint>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        //! \brief Instances of MavlinkStateRepository are used to maintain attributes
        //! and state of MAVLink objects in a protocol-specific way.
        //! It stores raw MAVLink data (Lat, Lon, Alt, Attitude) and provides
        //! a clean interface for Translators to access.
        class MavlinkStateRepository
        {
        public:
            //! \brief Default CTOR.
            MavlinkStateRepository();

            //! \brief Virtual DTOR.
            virtual ~MavlinkStateRepository();

            //! @name System Identification
            //! @{
            inline void setSysId(uint8_t id) { mySysId = id; }
            inline uint8_t sysId() const { return mySysId; }

            inline void setCompId(uint8_t id) { myCompId = id; }
            inline uint8_t compId() const { return myCompId; }
            //! @}

            //! @name Position (Geodetic WGS84)
            //! @{
            //! \brief Set position in degrees and meters.
            virtual void setPosition(double lat, double lon, double alt);

            inline double lat() const { return myLat; }
            inline double lon() const { return myLon; }
            inline double alt() const { return myAlt; }

            inline bool hasPosition() const { return myHasPosition; }
            //! @}

            //! @name Attitude (Euler Angles: Yaw, Pitch, Roll)
            //! @{
            //! \brief Set attitude in radians.
            virtual void setAttitude(double yaw, double pitch, double roll);

            inline double yaw() const { return myYaw; }
            inline double pitch() const { return myPitch; }
            inline double roll() const { return myRoll; }

            inline bool hasAttitude() const { return myHasAttitude; }
            //! @}

            //! @name Velocity (NED)
            //! @{
            inline void setVelocity(const DtVector32& vel) { myVelocity = vel; myHasVelocity = true; }
            inline const DtVector32& velocity() const { return myVelocity; }
            inline bool hasVelocity() const { return myHasVelocity; }
            //! @}

            //! @name State Management
            //! @{
            //! \brief Returns true if the state has changed since the last publish.
            inline bool isDirty() const { return myIsDirty; }

            //! \brief Clears the dirty flag (called after publish).
            inline void clearDirty() { myIsDirty = false; }

            //! \brief Sets the time this state was last updated.
            inline void setTimeStamp(DtTime t) { myTimeStamp = t; }
            inline DtTime timeStamp() const { return myTimeStamp; }
            //! @}

            //! \brief Print data for debugging.
            virtual void printData() const;

        protected:
            uint8_t mySysId;
            uint8_t myCompId;

            // Position
            double myLat;
            double myLon;
            double myAlt;
            bool myHasPosition;

            // Attitude
            double myYaw;
            double myPitch;
            double myRoll;
            bool myHasAttitude;

            // Velocity
            DtVector32 myVelocity;
            bool myHasVelocity;

            // State
            bool myIsDirty;
            DtTime myTimeStamp;
        };

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
