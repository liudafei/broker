/**************************************************************************** * Copyright (c) 2023 MAK * All rights reserved. ****************************************************************************/
//! \file entityTranslator.h
//! \brief Contains the DtEntityTranslator class declaration.
//! \ingroup mavlinkBroker

#pragma once

#include "mavlinkObjectTranslator.h"
#include <portal/pEntity.h>
#include <broker/brokerObject.h>
#include <portal/pReflectedObjectTypes.h>


namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        //! \brief Concrete translator for MAVLink Entities.
        //! Inherits from DtMavlinkObjectTranslator to handle MAVLink specific logic
        //! while mapping to DtPortalEntity.
        class DtEntityTranslator : public DtMavlinkObjectTranslator<DtPortalEntity, DtPortalReflectedEntity>
        {
        public:
            //! \brief Static translator name definition.
            Dt_DEF_TRANSLATOR_NAME("Entity State");

            //! \brief Constructor.
            DtEntityTranslator(DtBroker* broker);

            //! \brief Destructor.
            virtual ~DtEntityTranslator();

            //! @name Translation Interface Implementation
            //! @{

            //! \brief MAVLink -> Portal Translation.
            //! Called by parent class tick() when MAVLink data is aggregated and ready.
            virtual void translate(const MavlinkStateRepository& source, DtPortalEntity* destination);

            //! \brief Portal -> MAVLink Translation.
            //! Interface defined, implementation is empty.
            virtual void translate(const DtPortalEntity& source, MavlinkStateRepository* destination);

            //! @}
        };

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
