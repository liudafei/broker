#pragma once

#include "baseMavlinkObjectTranslator.h"
#include "mavlinkStateRepository.h"
#include <broker/brokerObject.h>
#include <map>
#include <mutex>
#include <vector>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        // Template macros matching webLvcBroker style
#define MAVLINK_OBJ_TRANS_TEMPLATE_ARGS \
    template < class T_PortalObject, class T_PortalReflectedObject >

#define MAVLINK_OBJ_TRANS_TEMPLATE_FUNC \
    T_PortalObject, T_PortalReflectedObject

        MAVLINK_OBJ_TRANS_TEMPLATE_ARGS
        class DtMavlinkObjectTranslator : public DtBaseObjectTranslator<MAVLINK_OBJ_TRANS_TEMPLATE_FUNC, DtBaseMavlinkObjectTranslator>
        {
        public:
            typedef DtMavlinkObjectTranslator<MAVLINK_OBJ_TRANS_TEMPLATE_FUNC> ParentClass;

            DtMavlinkObjectTranslator(DtBroker* broker, const DtString& name, DtPortalMessageKind kind);
            virtual ~DtMavlinkObjectTranslator();

            virtual void tick();

        protected:
            //! @name MAVLink Data Interface (Buffered)
            //! @{

            //! \brief Callback entry point for MAVSDK (executed in background thread).
            //! Stores data in a buffer for later processing in tick().
            void bufferMavlinkData(uint8_t sysId, const std::string& dataType, const std::vector<double>& values);

            //! \brief Processes buffered messages and updates StateRepos (executed in main thread).
            virtual void processBufferedMessages();

            //! @}

            //! @name Object Management
            //! @{

            //! \brief Finds or creates a BrokerObject and its StateRepo for a given SysId.
            virtual DtBrokerObject* findOrCreateBrokerObject(uint8_t sysId);

            //! \brief Creates the Portal Publisher for the object.
            virtual void publishObject(DtBrokerObject* brokerObj);

            //! @}

            //! @name Translation Interface (Must be implemented by derived class)
            //! @{

            //! \brief Convert MAVLink state to Portal state.
            virtual void translate(const MavlinkStateRepository& source, T_PortalObject* destination) = 0;

            //! \brief Convert Portal state to MAVLink state (for reverse control).
            virtual void translate(const T_PortalObject& source, MavlinkStateRepository* destination) = 0;

            //! @}

        protected:
            // Map: SysID -> DtBrokerObject
            // DtBrokerObject contains:
            //   1. publisherPtr (T_PortalObject Publisher)
            //   2. brokerDataPtr(SLOT 0) -> MavlinkStateRepository
            std::map<uint8_t, DtBrokerObject*> myBrokerObjectMap;

            // Thread safety
            std::mutex myBufferMutex;

            struct MavlinkBufferItem
            {
                uint8_t sysId;
                std::string type;
                std::vector<double> values;
            };
            std::vector<MavlinkBufferItem> myMessageBuffer;

            static const int STATE_REPO_SLOT = 0;
        };

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange

#include "mavlinkObjectTranslator.inl"
