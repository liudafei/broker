#pragma once


#include <broker/brokerInitializer.h>
#include <mtl/mtlEnvironment.h>
#include <vlutil/vlUtil.h>


namespace MAKVrExchange
{

    namespace DtMavlinkBroker
    {

        //! \brief Provides initialization parameters to the
        //! \ref DtMavlinkBroker "MAVLink Broker"
        //! \ingroup mavlinkBroker
        class DtMavlinkBrokerInitializer : public DtBrokerInitializer
        {
            public:
                //! \brief Constructor initializes command line arguments and MTL parameters.
                DtMavlinkBrokerInitializer(int argc = 0, char** argv = 0, const char* versionString = "1.0");

                //! \brief Copy CTOR.
                DtMavlinkBrokerInitializer( const DtMavlinkBrokerInitializer& other );
                
                //! \brief Virtual DTOR.
                virtual ~DtMavlinkBrokerInitializer();

                //! \brief Assignment operator.
                DtMavlinkBrokerInitializer& operator = ( const DtMavlinkBrokerInitializer& other );

                //! \brief Clone method.
                //! Creates a copy of this initializer - caller is responsible for deletion.
                virtual DtBrokerInitializer* clone() const;

                // 配置项
            public:
                virtual DtString mavlinkConnectionUrl() const;
                virtual void setMavlinkConnectionUrl(const DtString& url);

                virtual DtTime heartbeatInterval() const;
                virtual void setHeartbeatInterval(DtTime t);

            protected:
                DtConfigVariable<DtString> myMavlinkConnectionUrl;
                DtConfigVariable<DtTime> myHeartbeatInterval;
        };
    }
}
