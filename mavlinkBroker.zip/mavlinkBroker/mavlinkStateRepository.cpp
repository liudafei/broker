/**************************************************************************** * Copyright (c) 2023 MAK * All rights reserved. ****************************************************************************/
//! \file mavlinkStateRepository.cxx
//! \brief Contains the MavlinkStateRepository class definition.
//! \ingroup mavlinkBroker

#include "mavlinkStateRepository.h"
#include <vlutil/vlPrint.h>
#include <iostream>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        // ----------------------------------------------------------------------------
        // Construction
        // ----------------------------------------------------------------------------

        MavlinkStateRepository::MavlinkStateRepository()
            : mySysId(0)
            , myCompId(0)
            , myLat(0.0)
            , myLon(0.0)
            , myAlt(0.0)
            , myHasPosition(false)
            , myYaw(0.0)
            , myPitch(0.0)
            , myRoll(0.0)
            , myHasAttitude(false)
            , myVelocity(0.0, 0.0, 0.0)
            , myHasVelocity(false)
            , myIsDirty(false)
            , myTimeStamp(0.0)
        {}

        MavlinkStateRepository::~MavlinkStateRepository()
        {}

        // ----------------------------------------------------------------------------
        // Position Logic
        // ----------------------------------------------------------------------------

        void MavlinkStateRepository::setPosition(double lat, double lon, double alt)
        {
            // 简单的变化检测，避免无意义的脏标记设置
            if (myLat != lat || myLon != lon || myAlt != alt)
            {
                myLat = lat;
                myLon = lon;
                myAlt = alt;
                myHasPosition = true;
                myIsDirty = true; // 标记状态已改变，需要发布
            }
        }

        // ----------------------------------------------------------------------------
        // Attitude Logic
        // ----------------------------------------------------------------------------

        void MavlinkStateRepository::setAttitude(double yaw, double pitch, double roll)
        {
            // 简单的变化检测
            if (myYaw != yaw || myPitch != pitch || myRoll != roll)
            {
                myYaw = yaw;
                myPitch = pitch;
                myRoll = roll;
                myHasAttitude = true;
                myIsDirty = true; // 标记状态已改变
            }
        }

        // ----------------------------------------------------------------------------
        // Debug
        // ----------------------------------------------------------------------------

        void MavlinkStateRepository::printData() const
        {
            DtInfo << "MAVLink StateRepo [SysID: " << (int)mySysId << "]" << std::endl;
            if (myHasPosition)
            {
                DtInfo << "  Pos (Lat/Lon/Alt): " << myLat << ", " << myLon << ", " << myAlt << std::endl;
            }
            if (myHasAttitude)
            {
                DtInfo << "  Att (Y/P/R): " << myYaw << ", " << myPitch << ", " << myRoll << std::endl;
            }
            DtInfo << "  Dirty: " << (myIsDirty ? "Yes" : "No") << std::endl;
        }

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
