#pragma once

#include <string>
#include <map>
#include <vlpi/entityIdentifier.h>
#include <vlutil/vlString.h>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        //! \brief Structure to represent a MAVLink Address (System ID + Component ID).
        struct DtMavlinkAddress
        {
            uint8_t sysId;
            uint8_t compId;

            DtMavlinkAddress(uint8_t sys = 0, uint8_t comp = 0) : sysId(sys), compId(comp) {}

            // Needed for use as map key
            bool operator<(const DtMavlinkAddress& rhs) const
            {
                if (sysId != rhs.sysId) return sysId < rhs.sysId;
                return compId < rhs.compId;
            }
        };

        //! \brief Handles mapping between MAVLink System/Component IDs and Portal Entity IDs.
        //! Similar to DtGlobalIdMapper but simplified for MAVLink addressing.
        class DtMavlinkIdMapper
        {
        public:
            typedef DtEntityIdentifier PortalId;
            typedef DtMavlinkAddress MavlinkId;

            DtMavlinkIdMapper();
            virtual ~DtMavlinkIdMapper();

            //! \brief Adds a mapping between a MAVLink ID and a Portal ID.
            virtual bool add(const MavlinkId& mavId, const PortalId& portalId);

            //! \brief Removes mapping by Portal ID.
            virtual void removeByPortalId(const PortalId& portalId);

            //! \brief Removes mapping by MAVLink ID.
            virtual void removeByMavlinkId(const MavlinkId& mavId);

            //! \brief Converts MAVLink ID to Portal ID. Returns empty/null if not found.
            virtual const PortalId& mavlinkToPortal(const MavlinkId& mavId) const;

            //! \brief Converts Portal ID to MAVLink ID. Returns (0,0) if not found.
            virtual const MavlinkId& portalToMavlink(const PortalId& portalId) const;

            //! \brief Sets debug output.
            void setDebug(bool on);
            bool debug() const;

        protected:
            typedef std::map<MavlinkId, PortalId> MavToPortalMap;
            typedef std::map<PortalId, MavlinkId> PortalToMavMap;

            MavToPortalMap myMavToPortalMap;
            PortalToMavMap myPortalToMavMap;

            bool myDebugFlag;

            // Static empty returns for failed lookups
            static PortalId theEmptyPortalId;
            static MavlinkId theEmptyMavlinkId;
        };

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
