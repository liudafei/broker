#include <iostream>
#include <chrono>
#include <thread>
#include <future>
#include <map>
#include <set>

#include "MAVSDKWrapper.h"

#include <mavsdk/mavsdk.h>
#include <mavsdk/plugins/action/action.h>
#include <mavsdk/plugins/telemetry/telemetry.h>
#include <mavsdk/plugins/manual_control/manual_control.h>


class MavsdkWrapper::Impl
{
public:
    Impl()
    {
        mavsdk_ = std::make_shared<mavsdk::Mavsdk>(mavsdk::Mavsdk::Configuration{ mavsdk::Mavsdk::ComponentType::GroundStation });
    }

    bool add_any_connection(const std::string& connection_url)
    {
        auto result = mavsdk_->add_any_connection(connection_url);

        if (result != mavsdk::ConnectionResult::Success)
        {
            std::cerr << "[Wrapper] Connection failed: " << result << std::endl;
            return false;
        }
        return true;
    }

    void subscribe_on_new_system(Wrapper_OnNewSystem callback)
    {
        onNewSystemCb_ = callback;

        mavsdk_->subscribe_on_new_system([this]()
            {
                auto systems = mavsdk_->systems();
                for (auto& sys : systems)
                {
                    uint8_t id = sys->get_system_id();

                    // 如果是新系统
                    if (processed_sys_ids_.find(id) == processed_sys_ids_.end())
                    {
                        processed_sys_ids_.insert(id);
                        std::cout << "[Wrapper] Discovered system ID: " << (int)id << std::endl;

                        // 初始化该系统的 Telemetry 插件
                        auto telemetry = std::make_shared<mavsdk::Telemetry>(sys);
                        telemetry_map_[id] = telemetry;

                        // 设置数据回调桥接
                        setup_telemetry_callbacks(id, telemetry);

                        // 触发外部回调
                        if (onNewSystemCb_)
                        {
                            onNewSystemCb_(id);
                        }
                    }
                }
            });
    }

    void setup_telemetry_callbacks(uint8_t sysId, std::shared_ptr<mavsdk::Telemetry> telemetry)
    {
        // 1. 位置回调
        telemetry->subscribe_raw_gps([this, sysId](const mavsdk::Telemetry::RawGps& gpsData)
            {
                if (rawGpsCb_)
                {
                    std::vector<double> pos = {
                        gpsData.latitude_deg,
                        gpsData.longitude_deg,
                        gpsData.absolute_altitude_m
                    };
                    rawGpsCb_(sysId, pos);
                }
            });

        // 2. 姿态回调
        telemetry->subscribe_attitude_euler([this, sysId](const mavsdk::Telemetry::EulerAngle& attData)
            {
                if (attEulerCb_)
                {
                    // 顺序: yaw, pitch, roll
                    std::vector<double> att = {
                        attData.yaw_deg,
                        attData.pitch_deg,
                        attData.roll_deg
                    };
                    attEulerCb_(sysId, att);
                }
            });
    }

    void stop()
    {
        
    }


    void subscribe_raw_gps(Wrapper_RawGpsCallback callback)
    {
        rawGpsCb_ = callback;
    }

    void subscribe_position_velocity_ned(Wrapper_PositionVelocityNedCallback callback)
    {

    }

    void subscribe_attitude_euler(Wrapper_AttitudeEulerCallback callback)
    {
        attEulerCb_ = callback;
    }

    void subscribe_attitude_angular_velocity_body(Wrapper_AttitudeAngularVelocityBodyCallback callback)
    {

    }

    void subscribe_raw_imu(Wrapper_RawImuCallback callback)
    {

    }


    uint8_t get_system_id()
    {
        return 0;
    }


    void sendTakeoffCommand(float altitude)
    {
        //while (telemetry_->health_all_ok() != true)
        //{
        //    std::cout << "Vehicle is getting ready to arm";
        //    std::this_thread::sleep_for(std::chrono::seconds(1));
        //}

        //std::cout << "Arming..." << std::endl;
        //const mavsdk::Action::Result arm_result = action_->arm();

        //if (arm_result != mavsdk::Action::Result::Success)
        //{
        //    std::cerr << "Arming failed: " << arm_result;
        //    return;
        //}

        //std::cout << "Taking off..." << std::endl;
        //const mavsdk::Action::Result takeoff_result = action_->takeoff();
        //if (takeoff_result != mavsdk::Action::Result::Success)
        //{
        //    std::cerr << "Takeoff failed: " << takeoff_result << std::endl;
        //    return;
        //}

        //std::this_thread::sleep_for(std::chrono::seconds(10));
    }

    void sendLandCommand()
    {
        //std::cout << "Landing...";
        //const mavsdk::Action::Result land_result = action_->land();
        //if (land_result != mavsdk::Action::Result::Success)
        //{
        //    std::cerr << "Land failed: " << land_result;
        //    return;
        //}

        //while (telemetry_->in_air())
        //{
        //    std::cout << "Vehicle is landing...";
        //    std::this_thread::sleep_for(std::chrono::seconds(1));
        //}
        //std::cout << "Landed!";
    }

    void startManualControlInputMode()
    {
        //while (!telemetry_->health_all_ok())
        //{
        //    std::cout << "Waiting for system to be ready\n";
        //    std::this_thread::sleep_for(std::chrono::seconds(1));
        //}
        //std::cout << "System is ready\n";

        //for (unsigned i = 0; i < 10; ++i)
        //{
        //    manualControl_->set_manual_control_input(0.f, 0.f, 0.5f, 0.f);
        //}

        //auto action_result = action_->arm();
        //if (action_result != mavsdk::Action::Result::Success)
        //{
        //    std::cerr << "Arming failed: " << action_result << '\n';
        //    return;
        //}
        //else
        //{
        //    std::cout << "Armed: " << action_result << '\n';
        //}

        //for (unsigned i = 0; i < 10; ++i)
        //{
        //    manualControl_->set_manual_control_input(0.f, 0.f, 0.5f, 0.f);
        //}

        //auto manual_control_result = manualControl_->start_altitude_control();
        //if (manual_control_result != mavsdk::ManualControl::Result::Success)
        //{
        //    std::cerr << "Position control start failed: " << manual_control_result << '\n';
        //    return;
        //}
        //else
        //{
        //    std::cerr << "Position control start successed: " << manual_control_result << '\n';
        //}
    }

    void sendManualControlInput(float x, float y, float z, float r)
    {
        //manualControl_->set_manual_control_input(x, y, z / 2.0f + 0.5f, r);

        //std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }

private:
    std::shared_ptr<mavsdk::Mavsdk> mavsdk_;

    // 存储回调
    Wrapper_OnNewSystem           onNewSystemCb_;
    Wrapper_RawGpsCallback        rawGpsCb_     ;
    Wrapper_AttitudeEulerCallback attEulerCb_   ;

    // 管理已发现的系统
    std::set<uint8_t> processed_sys_ids_;
    std::map<uint8_t, std::shared_ptr<mavsdk::Telemetry>> telemetry_map_;
};


MavsdkWrapper::MavsdkWrapper() : pimpl_(std::make_unique<Impl>()) {}

MavsdkWrapper::~MavsdkWrapper() = default;


bool MavsdkWrapper::add_any_connection(const std::string& connection_url)
{
    return pimpl_->add_any_connection(connection_url);
}

void MavsdkWrapper::subscribe_on_new_system(Wrapper_OnNewSystem callback)
{
    pimpl_->subscribe_on_new_system(callback);
}

void MavsdkWrapper::stop()
{
    pimpl_->stop();
}


uint8_t MavsdkWrapper::get_system_id()
{
    return pimpl_->get_system_id();
}


void MavsdkWrapper::subscribe_raw_gps(Wrapper_RawGpsCallback callback)
{
    pimpl_->subscribe_raw_gps(callback);
}

void MavsdkWrapper::subscribe_position_velocity_ned(Wrapper_PositionVelocityNedCallback callback)
{
    pimpl_->subscribe_position_velocity_ned(callback);
}

void MavsdkWrapper::subscribe_attitude_euler(Wrapper_AttitudeEulerCallback callback)
{
    pimpl_->subscribe_attitude_euler(callback);
}

void MavsdkWrapper::subscribe_attitude_angular_velocity_body(Wrapper_AttitudeAngularVelocityBodyCallback callback)
{
    pimpl_->subscribe_attitude_angular_velocity_body(callback);
}

void MavsdkWrapper::subscribe_raw_imu(Wrapper_RawImuCallback callback)
{
    pimpl_->subscribe_raw_imu(callback);
}


void MavsdkWrapper::sendTakeoffCommand(float altitude)
{
    pimpl_->sendTakeoffCommand(altitude);
}

void MavsdkWrapper::sendLandCommand()
{
    pimpl_->sendLandCommand();
}

void MavsdkWrapper::startManualControlInputMode()
{
    pimpl_->startManualControlInputMode();
}

void MavsdkWrapper::sendManualControlInput(float x, float y, float z, float r)
{
    pimpl_->sendManualControlInput(x, y, z, r);
}

