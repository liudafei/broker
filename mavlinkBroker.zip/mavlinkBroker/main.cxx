/****************************************************************************
 * Copyright (c) 2014 VT MAK
 * All rights reserved.
 ****************************************************************************/

 //! \file simple.cxx
 //! \brief Contains the application entry point for the simple broker.
 //! \ingroup examples

#include "mavlinkBrokerInitializer.h"
#include "mavlinkBrokerDialog.h"
#include "mavlinkBroker.h"
#include <widgets/brokerApp.h>
#include <vlutil/vlExceptions.h>
#include <vlutil/vlMiniDumper.h>
#include <iostream>

using namespace MAKVrExchange;

int main(int argc, char* argv[])
{
    DtINIT_MINIDUMPER("Mavlink Broker");

    try
    {
        using namespace MAKVrExchange;
        using namespace MAKVrExchange::DtMavlinkBroker;

        const std::string version = "1.0";

        // Load the configuration options
        DtMavlinkBrokerInitializer* mavlinkInit = new DtMavlinkBrokerInitializer(argc, argv, DtPortalConnection::version().c_str());
        mavlinkInit->parseCmdLine();

        DtBrokerApp::setBrokerCreator      (MAKVrExchange::DtMavlinkBroker::DtMavlinkBroker::create);
        DtBrokerApp::setBrokerDialogCreator(DtMavlinkBrokerDialog::create);
        DtBrokerApp* brokerApp = new DtBrokerApp(mavlinkInit);

        if (!mavlinkInit->showConnectionInfoDialog())
        {
            DtWarn << "Broker initialization failed, exiting." << std::endl;
            return 1;
        }

        // Run the broker.
        brokerApp->setDarkModeEnabled(mavlinkInit->darkModeEnabled());
        brokerApp->run(mavlinkInit->showConnectionInfoDialog());

        DtDELETE(brokerApp);
    }
    catch (DtException& es)
    {
        std::cerr << "MAVLink Broker exiting with DtException: " << es << std::endl;
        DtFatal << "MAVLink Broker exiting with DtException: " << es << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cerr << "MAVLink Broker exiting with std::exception: " << ex.what() << std::endl;
        DtFatal << "MAVLink Broker exiting with std::exception: " << ex.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "MAVLink Broker exiting with unknown exception." << std::endl;
        DtFatal << "MAVLink Broker exiting with unknown exception." << std::endl;
    }

    return 0;
}
