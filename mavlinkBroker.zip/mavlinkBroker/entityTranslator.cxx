/**************************************************************************** * Copyright (c) 2023 MAK * All rights reserved. ****************************************************************************/
//! \file entityTranslator.cxx
//! \brief Contains the DtEntityTranslator class definition.
//! \ingroup mavlinkBroker

#include "entityTranslator.h"
#include "mavlinkBroker.h"
#include "mavlinkStateRepository.h"

#include <vl/topoView.h>
#include <matrix/topoCoord.h>
#include <vlutil/vlPrint.h>
#include <vlutil/vlTime.h>

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        // ----------------------------------------------------------------------------
        // Construction
        // ----------------------------------------------------------------------------

        DtEntityTranslator::DtEntityTranslator(DtBroker* broker)
            : ParentClass(broker, translatorName(), DtPortalEntity::theKind)
        {
            // Constructor logic (if any)
        }

        DtEntityTranslator::~DtEntityTranslator()
        {
            // Destructor logic (if any)
        }

        // ----------------------------------------------------------------------------
        // MAVLink -> Portal Translation
        // ----------------------------------------------------------------------------

        void DtEntityTranslator::translate(const MavlinkStateRepository& source, DtPortalEntity* destination)
        {
            // 1. Coordinate Conversion (Geodetic -> Geocentric)
            if (source.hasPosition())
            {
                DtGeodeticCoord geo;
                geo.setLat(source.lat());
                geo.setLon(source.lon());
                geo.setAlt(source.alt());

                DtVector geoc = geo.geocentric();

                destination->setLocation(geoc);
            }

            // 2. Attitude Conversion (Euler Angles)
            if (source.hasAttitude())
            {
                // Assuming MAVLink provides Yaw, Pitch, Roll in radians
                destination->setOrientation(DtTaitBryan(source.yaw(), source.pitch(), source.roll()));
            }

            // 3. Velocity
            if (source.hasVelocity())
            {
                destination->setVelocity(source.velocity());
            }

            // 4. Time Stamp
            destination->setTimeReceived(mavlinkBroker()->simTime());
        }

        // ----------------------------------------------------------------------------
        // Portal -> MAVLink Translation
        // ----------------------------------------------------------------------------

        void DtEntityTranslator::translate(const DtPortalEntity& source, MavlinkStateRepository* destination)
        {
            // Empty implementation as requested.
            // Logic for controlling UAVs from Portal would go here.
        }

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
