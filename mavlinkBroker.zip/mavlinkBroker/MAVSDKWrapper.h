#pragma once


#include <memory>
#include <string>
#include <vector>
#include <functional>


using Wrapper_OnNewSystem                         = std::function<void(uint8_t sysId)>;
using Wrapper_RawGpsCallback                      = std::function<void(uint8_t sysId, const std::vector<double>& gpsData     )>;
using Wrapper_PositionVelocityNedCallback         = std::function<void(uint8_t sysId, const std::vector<double>& nedData     , const std::vector<double>& nedVData)>;
using Wrapper_AttitudeEulerCallback               = std::function<void(uint8_t sysId, const std::vector<double>& attitudeData)>;
using Wrapper_AttitudeAngularVelocityBodyCallback = std::function<void(uint8_t sysId, const std::vector<double>& attitudeData)>;
using Wrapper_RawImuCallback                      = std::function<void(uint8_t sysId, const std::vector<double>& rawIMUData  )>;


class MavsdkWrapper
{
public:
    MavsdkWrapper();
    ~MavsdkWrapper();

    MavsdkWrapper(const MavsdkWrapper&) = delete;
    MavsdkWrapper& operator=(const MavsdkWrapper&) = delete;

    // mavsdk::Mavsdk 
public:
    bool add_any_connection(const std::string& connection_url);
    void subscribe_on_new_system(Wrapper_OnNewSystem callback);
    void stop();

    // mavsdk::System
public:
    uint8_t get_system_id();
    
    // mavsdk::Telemetry
public:
    void subscribe_raw_gps                       (Wrapper_RawGpsCallback                      callback);
    void subscribe_position_velocity_ned         (Wrapper_PositionVelocityNedCallback         callback);
    void subscribe_attitude_euler                (Wrapper_AttitudeEulerCallback               callback);
    void subscribe_attitude_angular_velocity_body(Wrapper_AttitudeAngularVelocityBodyCallback callback);
    void subscribe_raw_imu                       (Wrapper_RawImuCallback                      callback);

    // mavsdk::Action
public:
    void sendTakeoffCommand    (float altitude);
    void sendLandCommand       (              );
    void startManualControlInputMode();
    void sendManualControlInput(float x, float y, float z, float r);//pitch, roll, throttle, yaw

private:
    class Impl;
    std::unique_ptr<Impl> pimpl_;
};
