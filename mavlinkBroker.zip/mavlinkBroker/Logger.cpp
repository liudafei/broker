#include "Logger.h"

#include <iomanip>


LogStream::LogStream(boost::log::trivial::severity_level level)
    : level_(level)
{

}

LogStream::~LogStream()
{
    switch (level_)
    {
    case boost::log::trivial::severity_level::trace:
        BOOST_LOG_TRIVIAL(trace) << stream_.str();
        break;
    case boost::log::trivial::severity_level::debug:
        BOOST_LOG_TRIVIAL(debug) << stream_.str();
        break;
    case boost::log::trivial::severity_level::info:
        BOOST_LOG_TRIVIAL(info) << stream_.str();
        break;
    case boost::log::trivial::severity_level::warning:
        BOOST_LOG_TRIVIAL(warning) << stream_.str();
        break;
    case boost::log::trivial::severity_level::error:
        BOOST_LOG_TRIVIAL(error) << stream_.str();
        break;
    case boost::log::trivial::severity_level::fatal:
        BOOST_LOG_TRIVIAL(fatal) << stream_.str();
        break;
    default:
        break;
    }
}

LogStream& LogStream::setPrecision(int precision)
{
    stream_ << std::fixed << std::setprecision(precision);
    return *this;
}

//template<typename T>
//LogStream& LogStream::operator<<(const T& value)
//{
//    stream_ << value;
//    return *this;
//}

void Logging::initLog(int logLevel)
{
    boost::log::register_simple_formatter_factory<boost::log::trivial::severity_level, char>("Severity");

    boost::log::add_console_log(std::cout,
        boost::log::keywords::format =
        "VRFEntitySimulator: >>>> [%TimeStamp%] [%Severity%] [%ThreadID%] %Message%");

    boost::log::core::get()->set_filter(
        boost::log::trivial::severity >= boost::log::trivial::severity_level(logLevel)
    );

    boost::log::add_common_attributes();
}

LogStream Logging::logTrace()
{
    return LogStream(boost::log::trivial::trace);
}

LogStream Logging::logDebug()
{
    return LogStream(boost::log::trivial::debug);
}

LogStream Logging::logInfo()
{
    return LogStream(boost::log::trivial::info);
}

LogStream Logging::logWarning()
{
    return LogStream(boost::log::trivial::warning);
}

LogStream Logging::logError()
{
    return LogStream(boost::log::trivial::error);
}

LogStream Logging::logFatal()
{
    return LogStream(boost::log::trivial::fatal);
}
