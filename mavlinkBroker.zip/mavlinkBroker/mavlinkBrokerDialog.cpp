// mavlinkBrokerDialog.cpp
#include "mavlinkBrokerDialog.h"
#include "mavlinkBroker.h"
#include "mavlinkBrokerInitializer.h"

namespace MAKVrExchange
{
    namespace DtMavlinkBroker
    {

        DtBrokerDialog* DtMavlinkBrokerDialog::create(DtBroker* broker, DtBrokerInitializer* init, QWidget* parent)
        {
            return new DtMavlinkBrokerDialog(static_cast<DtMavlinkBroker*>(broker), static_cast<DtMavlinkBrokerInitializer*>(init), parent);
        }

        DtMavlinkBrokerDialog::DtMavlinkBrokerDialog(DtMavlinkBroker* broker, DtMavlinkBrokerInitializer* init, QWidget* parent)
            : DtBrokerDialog(broker, init, parent)
        {}

        DtMavlinkBrokerDialog::~DtMavlinkBrokerDialog()
        {}

        DtMavlinkBrokerInitializer* DtMavlinkBrokerDialog::mavlinkInitializer()
        {
            return static_cast<DtMavlinkBrokerInitializer*>(myBrokerInitializer);
        }

        void DtMavlinkBrokerDialog::initObjectListViewHeaders()
        {
            DtBrokerDialog::initObjectListViewHeaders();

            // 自定义列头名称
            QStringList headers;
            headers << tr("Type") << tr("Name") << tr("MAVLink ID") << tr("Marking Text");

            // 注意：需要确保 widget 已经初始化，这里假设基类已经处理
            // 实际项目中可能需要访问 myPublishedObjectsWidget 等
            // 这里仅展示逻辑
            DtInfo << "Initialized MAVLink Dialog Headers." << std::endl;
        }

    } // namespace DtMavlinkBroker
} // namespace MAKVrExchange
