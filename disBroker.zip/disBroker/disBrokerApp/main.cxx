/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file main.cxx
//! \brief Contains the application entry point for the DIS Broker.
//! \ingroup disBrokerApp

#include <disBroker/disBrokerInitializer.h>
#include <disBroker/disBrokerDialog.h>
#include <disBroker/disBroker.h>
#include <vlutil/vlExceptions.h>
#include <vlutil/vlMiniDumper.h>
#include <portal/pConnection.h>
#include <widgets/brokerApp.h>
#include <broker/vrlBroker.h>
#include <iostream>

#ifdef main
#undef main
#endif

#ifdef _WIN32
#include <windows.h>
#include <fcntl.h>
#include <io.h>
#endif

#ifdef __fedora7__
#include <string.h>
#include <errno.h>
#include <stdio.h>
#endif

// Add a console out if necessary (for windows help)
void allocateConsole()
{
#if _WIN32
   int hConInHandle;
   long lStdInHandle;
   FILE* fp;

   AllocConsole();

   freopen( "CON", "w", stdout );
   freopen( "CON", "w", stderr );

   lStdInHandle= (long) GetStdHandle( STD_INPUT_HANDLE );
   hConInHandle = _open_osfhandle( lStdInHandle, _O_TEXT );
   fp = _fdopen( hConInHandle, "r" );
   *stdin = *fp;
#endif
}

int main( int argc, char* argv[] )
{
   DtINIT_MINIDUMPER( "DIS Broker" );

#ifdef __fedora7__
   // On some Linux distributions, the SESSION_MANAGER variable is set
   // incorrectly when the user is running in certain environments such
   // as GNOME or possibly KDE. This causes strange behavior with Qt
   // if the variable is found at at application startup as Qt attempts
   // to make an SmcOpenConnection call using the information from
   // SESSION_MANAGER, but the SmcOpenConnection call will silently
   // fail for the child brokers started from VRX as the environment
   // of VRX is passed to the children.

   // Session management via XSMP/DBUS is for allowing a session
   // manager application like gnome-session to manage the state of
   // applications, and is unnecessary for VRX operation.

   // An alternative to unsetting this SESSION_MANAGER variable would
   // be to modify the variable so that it correctly points to the
   // local hostname for its ICE socket, as Fedora Core incorrectly
   // sets the hostname in the variable to 'unix'
   if ( unsetenv("SESSION_MANAGER") == 0 )
   {
      DtInfo << "Unset SESSION_MANAGER environment variable\n";
      std::cout << "Unset SESSION_MANAGER environment variable\n";

   }
   else
   {
      DtWarn << "Could not unset the SESSION_MANAGER environment variable: "
         << strerror( errno ) << std::endl;
      std::cout << "Could not unset the SESSION_MANAGER environment variable: "
         << strerror( errno ) << std::endl;
   }
#endif

   try
   {
      using namespace MAKVrExchange;
      using namespace MAKVrExchange::DtDisBroker;

      int argCount = 1;
      while ( argCount < argc )
      {
         if ( strstr(argv[argCount],"-h") || strstr(argv[argCount],"--help")
            || strstr(argv[argCount],"-v") || strstr(argv[argCount],"--version") )
         {
            allocateConsole();
            break;
         }
         argCount++;
      }

      // Load the configuration options
      DtDisBrokerInitializer* disInit =
         new DtDisBrokerInitializer( argc, argv, DtPortalConnection::version().c_str() );
      disInit->parseCmdLine(); // Automatically loads the file specified by the CmdLine

      DtBrokerApp::setBrokerCreator( MAKVrExchange::DtDisBroker::DtDisBroker::create );
      DtBrokerApp::setBrokerDialogCreator( DtDisBrokerDialog::create );
      DtBrokerApp* brokerApp = new DtBrokerApp( disInit );
      if ( ! ((DtVrlBroker<DtExerciseConn>*)brokerApp->broker())->connection()
         && ! disInit->showConnectionInfoDialog() )
      {
         DtWarn << "Broker initialization failed, exiting." << std::endl;
         return 1;
      }
 
      // Run the broker.
      brokerApp->setDarkModeEnabled(disInit->darkModeEnabled());
      brokerApp->run( disInit->showConnectionInfoDialog() );

      DtDELETE( brokerApp );
   }
   catch ( DtException& es )
   {
      std::cerr << "DIS Broker exiting with DtException: " << es << std::endl;
      DtFatal << "DIS Broker exiting with DtException: " << es << std::endl;
   }
   catch ( const std::exception& ex )
   {
      std::cerr << "DIS Broker exiting with std::exception: " << ex.what() << std::endl;
      DtFatal << "DIS Broker exiting with std::exception: " << ex.what() << std::endl;
   }
   catch ( ... )
   {
       std::cerr << "DIS Broker exiting with unknown exception." << std::endl;
       DtFatal << "DIS Broker exiting with unknown exception." << std::endl;
   }

   return 0;
}
