/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disBrokerInitializer.cxx
//! \brief Contains the DtDisBrokerInitializer class definition.
//! \ingroup disBroker

#include <disBroker/disBrokerInitializer.h>
#include <mtl/mtlEnvironment.h>
#include <vlutil/vlUtil.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtDisBrokerInitializer::DtDisBrokerInitializer( int argc, char* argv[],
            const char* versionString )
         : DtBrokerInitializer( argc, argv, versionString )
         , myDisPort( mySettings, "dis&Port", 3000, "DIS Port",
            DtBaseConfigVariable::DtScopeBoth )
         , myExerciseId( mySettings, "e&xerciseId", 1, "Exercise ID",
            DtBaseConfigVariable::DtScopeBoth )
         , myDestinationAddress( mySettings, "destination&Address",
            "0.0.0.0", "Destination Address", DtBaseConfigVariable::DtScopeBoth )
         , myDeviceAddress( mySettings, "deviceAddress", "0.0.0.0",
            "Network Device Address", DtBaseConfigVariable::DtScopeBoth, false, "D" )
         , mySubnetMask( mySettings, "subnetMask", "", "Subnet Mask",
            DtBaseConfigVariable::DtScopeBoth )
         , myMcastSubscriptionSet( mySettings, "multicastSubscriptionSet",
            "multicastAddress", "Multicast Subscription Set",
            DtBaseConfigVariable::DtScopeConfigFile )
         , mySocketSendBufferSize( mySettings, "socketSendBufferSize", 0,
            "Socket Send Buffer Size", DtBaseConfigVariable::DtScopeConfigFile )
         , mySocketReceiveBufferSize( mySettings, "socketReceiveBufferSize", 0,
            "Socket Receive Buffer Size", DtBaseConfigVariable::DtScopeConfigFile )
         , myMulticastTimeToLive( mySettings, "multicastTimeToLive", -1,
            "Multicast Time to Live", DtBaseConfigVariable::DtScopeConfigFile )
         , myParseUnknownIdsFlag( mySettings, "parseUnknownIds", 1,
            "Parse Unknown IDs", DtBaseConfigVariable::DtScopeConfigFile )
         , myRemapDisIds( mySettings, "renameDisObjects", 0,
            "Rename DIS Objects", DtBaseConfigVariable::DtScopeConfigFile )
         , myUsePersistentEntityIds( mySettings, "usePersistentEntityIds", 0,
            "Use Persistent Entity IDs", DtBaseConfigVariable::DtScopeConfigFile )
         , myInteractionWaitListTimeout( mySettings, "interactionWaitListTimeout", 1.0,
            "Timeout for wait-listed incomplete interactions", DtBaseConfigVariable::DtScopeConfigFile )
         , mySendExpiredWaitListInteractions( mySettings, "sendExpiredWaitListInteractions", false,
            "Send expired wait-listed incomplete interactions", DtBaseConfigVariable::DtScopeConfigFile )
         , myApplicationNumber( mySettings, "&applicationNumber", 27,
            "Application Number", DtBaseConfigVariable::DtScopeBoth )
         , mySiteId( mySettings, "&siteId", 1, "Site ID",
            DtBaseConfigVariable::DtScopeBoth )
         , myUseAbsoluteTimeStamping( mySettings, "timeStampAbsolute", 0,
            "Use Absolute Timestamping", DtBaseConfigVariable::DtScopeConfigFile )
         , myLocationThreshold( mySettings, "locationThreshold", 1.0,
            "Location Threshold", DtBaseConfigVariable::DtScopeConfigFile )
         , myRotationThreshold( mySettings, "rotationThreshold", DtDeg2Rad(3.0),
            "Rotation Threshold", DtBaseConfigVariable::DtScopeConfigFile )
         , myProtocolVersionToSend( mySettings, "protocolVersionToSend", 7,
            "Protocol Version To Send", DtBaseConfigVariable::DtScopeConfigFile )
         , myProtocolVersionToRecvMin( mySettings, "protocolVersionToRecvMin", 4,
            "Minimum Protocol Version To Receive", DtBaseConfigVariable::DtScopeConfigFile )
         , myProtocolVersionToRecvMax( mySettings, "protocolVersionToRecvMax", 7,
            "Maximum Protocol Version To Receive", DtBaseConfigVariable::DtScopeConfigFile )
         , myDisableArticulatedParts( mySettings, "disableArticulatedParts", 0,
            "Disable Articulated Part Translating", DtBaseConfigVariable::DtScopeConfigFile )
         , mySplitUnderwaterAcousticPdus( mySettings, "splitUnderwaterAcousticPdus", 0,
            "Split Underwater Acoustic PDUs", DtBaseConfigVariable::DtScopeConfigFile )
         , mySendDiGuyPdus( mySettings, "sendDiGuyPdus", false,
            "Send DI-Guy PDUs", DtBaseConfigVariable::DtScopeConfigFile )
         , mySendSeesPdus( mySettings, "sendSeesPdus", false,
            "Send SEES PDUs", DtBaseConfigVariable::DtScopeConfigFile )
         , mySendRelativeLocationPdus( mySettings, "sendRelativeLocationPdus", true,
            "Send Relative Location PDUs", DtBaseConfigVariable::DtScopeConfigFile )
         , myDebugGlobalIdMapping( mySettings, "debugGlobalIdMapping", 0,
            "Debug Global ID Mapping", DtBaseConfigVariable::DtScopeConfigFile )
         , myDebugEntityIdMapping( mySettings, "debugEntityIdMapping", 0,
            "Debug Entity ID Mapping", DtBaseConfigVariable::DtScopeConfigFile )
         , myDebugEventIdMapping( mySettings, "debugEventIdMapping", 0,
            "Debug Event ID Mapping", DtBaseConfigVariable::DtScopeConfigFile )
         , myDumpGuiToText( mySettings, "dumpGuiToText", 0, "Dump GUI to Text",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myHeartbeatInterval( mySettings, "heartbeatInterval", 5.0,
            "Heartbeat Interval", DtBaseConfigVariable::DtScopeConfigFile )
         , myTimeoutInterval( mySettings, "timeoutInterval", 10.0,
            "Timeout Interval", DtBaseConfigVariable::DtScopeConfigFile )
         , myDrainTimeout( mySettings, "drainTimeout", -1.0, "Drain Timeout",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myNumPdusReadPerTimeCheck( mySettings, "numPdusToReadPerTimeCheck", 100,
            "Num PDUs Read Per Time Check", DtBaseConfigVariable::DtScopeConfigFile )
         , myDiscoverableCriteriaGroup( &mySettings, "publicationCriteria" )
      {
         myDiscoverableCriteria = new DtDisDiscoverableCriteria( &myDiscoverableCriteriaGroup );
         setPluginDirectory( "../plugins/disBroker" );
         setLogFileName( "disBroker.log" );
      }

      DtDisBrokerInitializer::DtDisBrokerInitializer( const DtDisBrokerInitializer& other )
         : DtBrokerInitializer( other )
         , myDisPort( mySettings, "dis&Port", 3000, "DIS Port",
            DtBaseConfigVariable::DtScopeBoth )
         , myExerciseId( mySettings, "e&xerciseId", 1, "Exercise ID",
            DtBaseConfigVariable::DtScopeBoth )
         , myDestinationAddress( mySettings, "destination&Address",
            "0.0.0.0", "Destination Address", DtBaseConfigVariable::DtScopeBoth )
         , myDeviceAddress( mySettings, "deviceAddress", "0.0.0.0",
            "Network Device Address", DtBaseConfigVariable::DtScopeBoth, false, "D" )
         , mySubnetMask( mySettings, "subnetMask", "", "Subnet Mask",
            DtBaseConfigVariable::DtScopeBoth )
         , myMcastSubscriptionSet( mySettings, "multicastSubscriptionSet",
            "multicastAddress", "Multicast Subscription Set",
            DtBaseConfigVariable::DtScopeConfigFile )
         , mySocketSendBufferSize( mySettings, "socketSendBufferSize", 0,
            "Socket Send Buffer Size", DtBaseConfigVariable::DtScopeConfigFile )
         , mySocketReceiveBufferSize( mySettings, "socketReceiveBufferSize", 0,
            "Socket Receive Buffer Size", DtBaseConfigVariable::DtScopeConfigFile )
         , myMulticastTimeToLive( mySettings, "multicastTimeToLive", 0,
            "Multicast Time to Live", DtBaseConfigVariable::DtScopeConfigFile )
         , myParseUnknownIdsFlag( mySettings, "parseUnknownIds", 1,
            "Parse Unknown IDs", DtBaseConfigVariable::DtScopeConfigFile )
         , myRemapDisIds( mySettings, "renameDisObjects", 0,
            "Rename DIS Objects", DtBaseConfigVariable::DtScopeConfigFile )
         , myUsePersistentEntityIds( mySettings, "usePersistentEntityIds", 0,
            "Use Persistent Entity IDs", DtBaseConfigVariable::DtScopeConfigFile )
         , myInteractionWaitListTimeout( mySettings, "interactionWaitListTimeout", 1.0,
            "Timeout for wait-listed incomplete interactions", DtBaseConfigVariable::DtScopeConfigFile )
         , mySendExpiredWaitListInteractions( mySettings, "sendExpiredWaitListInteractions", false,
            "Send expired wait-listed incomplete interactions", DtBaseConfigVariable::DtScopeConfigFile )
         , myApplicationNumber( mySettings, "&applicationNumber", 27,
            "Application Number", DtBaseConfigVariable::DtScopeBoth )
         , mySiteId( mySettings, "&siteId", 1, "Site ID",
            DtBaseConfigVariable::DtScopeBoth )
         , myUseAbsoluteTimeStamping( mySettings, "timeStampAbsolute", 0,
            "Use Absolute Timestamping", DtBaseConfigVariable::DtScopeConfigFile )
         , myLocationThreshold( mySettings, "locationThreshold", 1.0,
            "Location Threshold", DtBaseConfigVariable::DtScopeConfigFile )
         , myRotationThreshold( mySettings, "rotationThreshold", DtDeg2Rad(3.0),
            "Rotation Threshold", DtBaseConfigVariable::DtScopeConfigFile )
         , myProtocolVersionToSend( mySettings, "protocolVersionToSend", 7,
            "Protocol Version To Send", DtBaseConfigVariable::DtScopeConfigFile )
         , myProtocolVersionToRecvMin( mySettings, "protocolVersionToRecvMin", 4,
            "Minimum Protocol Version To Receive", DtBaseConfigVariable::DtScopeConfigFile )
         , myProtocolVersionToRecvMax( mySettings, "protocolVersionToRecvMax", 6,
            "Maximum Protocol Version To Receive", DtBaseConfigVariable::DtScopeConfigFile )
         , myDisableArticulatedParts( mySettings, "disableArticulatedParts", 0,
            "Disable Articulated Part Translating", DtBaseConfigVariable::DtScopeConfigFile )
         , mySplitUnderwaterAcousticPdus( mySettings, "splitUnderwaterAcousticPdus", 0,
            "Split Underwater Acoustic PDUs", DtBaseConfigVariable::DtScopeConfigFile )
         , mySendDiGuyPdus( mySettings, "sendDiGuyPdus", false,
            "Send DI-Guy PDUs", DtBaseConfigVariable::DtScopeConfigFile )
         , mySendSeesPdus( mySettings, "sendSeesPdus", false,
            "Send SEES PDUs", DtBaseConfigVariable::DtScopeConfigFile )
         , mySendRelativeLocationPdus( mySettings, "sendRelativeLocationPdus", true,
            "Send Relative Location PDUs", DtBaseConfigVariable::DtScopeConfigFile )
         , myDebugGlobalIdMapping( mySettings, "debugGlobalIdMapping", 0,
            "Debug Global ID Mapping", DtBaseConfigVariable::DtScopeConfigFile )
         , myDebugEntityIdMapping( mySettings, "debugEntityIdMapping", 0,
            "Debug Entity ID Mapping", DtBaseConfigVariable::DtScopeConfigFile )
         , myDebugEventIdMapping( mySettings, "debugEventIdMapping", 0,
            "Debug Event ID Mapping", DtBaseConfigVariable::DtScopeConfigFile )
         , myDumpGuiToText( mySettings, "dumpGuiToText", 0, "Dump GUI to Text",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myHeartbeatInterval( mySettings, "heartbeatInterval", 5.0,
            "Heartbeat Interval", DtBaseConfigVariable::DtScopeConfigFile )
         , myTimeoutInterval( mySettings, "timeoutInterval", 10.0,
            "Timeout Interval", DtBaseConfigVariable::DtScopeConfigFile )
         , myDrainTimeout( mySettings, "drainTimeout", -1.0, "Drain Timeout",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myNumPdusReadPerTimeCheck( mySettings, "numPdusToReadPerTimeCheck", 100,
            "Num PDUs Read Per Time Check", DtBaseConfigVariable::DtScopeConfigFile )
         , myDiscoverableCriteriaGroup( &mySettings, "publicationCriteria" )
      {
         // Connection Settings.
         myDisPort = other.myDisPort;
         myExerciseId = other.myExerciseId;
         myDestinationAddress = other.myDestinationAddress;
         myDeviceAddress = other.myDeviceAddress;
         mySubnetMask = other.mySubnetMask;
         myMcastSubscriptionSet = other.myMcastSubscriptionSet;
         mySocketSendBufferSize = other.mySocketSendBufferSize;
         mySocketReceiveBufferSize = other.mySocketReceiveBufferSize;
         myMulticastTimeToLive = other.myMulticastTimeToLive;

         // Translation Settings.
         myParseUnknownIdsFlag = other.myParseUnknownIdsFlag;
         myRemapDisIds = other.myRemapDisIds;
         myUsePersistentEntityIds = other.myUsePersistentEntityIds;
         myInteractionWaitListTimeout = other.myInteractionWaitListTimeout;
         mySendExpiredWaitListInteractions = other.mySendExpiredWaitListInteractions;
         myApplicationNumber = other.myApplicationNumber;
         mySiteId = other.mySiteId;
         myUseAbsoluteTimeStamping = other.myUseAbsoluteTimeStamping;
         myLocationThreshold = other.myLocationThreshold;
         myRotationThreshold = other.myRotationThreshold;
         myProtocolVersionToSend = other.myProtocolVersionToSend;
         myProtocolVersionToRecvMin = other.myProtocolVersionToRecvMin;
         myProtocolVersionToRecvMax = other.myProtocolVersionToRecvMax;
         myDisableArticulatedParts = other.myDisableArticulatedParts;
         mySplitUnderwaterAcousticPdus = other.mySplitUnderwaterAcousticPdus;
         mySendDiGuyPdus = other.mySendDiGuyPdus;
         mySendSeesPdus = other.mySendSeesPdus;
         mySendRelativeLocationPdus = other.mySendRelativeLocationPdus;

         // Debug Settings.
         myDebugGlobalIdMapping = other.myDebugGlobalIdMapping;
         myDebugEntityIdMapping = other.myDebugEntityIdMapping;
         myDebugEventIdMapping = other.myDebugEventIdMapping;
         myDumpGuiToText = other.myDumpGuiToText;

         // Timing Settings.
         myHeartbeatInterval = other.myHeartbeatInterval;
         myTimeoutInterval = other.myTimeoutInterval;
         myDrainTimeout = other.myDrainTimeout;
         myNumPdusReadPerTimeCheck = other.myNumPdusReadPerTimeCheck;

         // Discovery Criteria.
         myDiscoverableCriteria = new DtDisDiscoverableCriteria( &myDiscoverableCriteriaGroup );
         *myDiscoverableCriteria = *other.myDiscoverableCriteria;
      }

      DtDisBrokerInitializer::~DtDisBrokerInitializer()
      {
         DtDELETE( myDiscoverableCriteria );
      }

      DtDisBrokerInitializer& DtDisBrokerInitializer::operator = (
         const DtDisBrokerInitializer& other )
      {
         // Avoid assinment to self.
         if ( this == &other )
         {
            return *this;
         }

         DtBrokerInitializer::operator = ( other );

         // Connection Settings.
         myDisPort = other.myDisPort;
         myExerciseId = other.myExerciseId;
         myDestinationAddress = other.myDestinationAddress;
         myDeviceAddress = other.myDeviceAddress;
         mySubnetMask = other.mySubnetMask;
         myMcastSubscriptionSet = other.myMcastSubscriptionSet;
         mySocketSendBufferSize = other.mySocketSendBufferSize;
         mySocketReceiveBufferSize = other.mySocketReceiveBufferSize;
         myMulticastTimeToLive = other.myMulticastTimeToLive;

         // Translation Settings.
         myParseUnknownIdsFlag = other.myParseUnknownIdsFlag;
         myRemapDisIds = other.myRemapDisIds;
         myUsePersistentEntityIds = other.myUsePersistentEntityIds;
         myInteractionWaitListTimeout = other.myInteractionWaitListTimeout;
         mySendExpiredWaitListInteractions = other.mySendExpiredWaitListInteractions;
         myApplicationNumber = other.myApplicationNumber;
         mySiteId = other.mySiteId;
         myUseAbsoluteTimeStamping = other.myUseAbsoluteTimeStamping;
         myLocationThreshold = other.myLocationThreshold;
         myRotationThreshold = other.myRotationThreshold;
         myProtocolVersionToSend = other.myProtocolVersionToSend;
         myProtocolVersionToRecvMin = other.myProtocolVersionToRecvMin;
         myProtocolVersionToRecvMax = other.myProtocolVersionToRecvMax;
         myDisableArticulatedParts = other.myDisableArticulatedParts;
         mySplitUnderwaterAcousticPdus = other.mySplitUnderwaterAcousticPdus;
         mySendDiGuyPdus = other.mySendDiGuyPdus;
         mySendSeesPdus = other.mySendSeesPdus;
         mySendRelativeLocationPdus = other.mySendRelativeLocationPdus;

         // Debug Settings.
         myDebugGlobalIdMapping = other.myDebugGlobalIdMapping;
         myDebugEntityIdMapping = other.myDebugEntityIdMapping;
         myDebugEventIdMapping = other.myDebugEventIdMapping;
         myDumpGuiToText = other.myDumpGuiToText;

         // Timing Settings.
         myHeartbeatInterval = other.myHeartbeatInterval;
         myTimeoutInterval = other.myTimeoutInterval;
         myDrainTimeout = other.myDrainTimeout;
         myNumPdusReadPerTimeCheck = other.myNumPdusReadPerTimeCheck;

         // Discovery Criteria.
         *myDiscoverableCriteria = *other.myDiscoverableCriteria;

         return *this;
      }

      DtDisBrokerInitializer* DtDisBrokerInitializer::clone() const
      {
         return new DtDisBrokerInitializer( *this );
      }

      DtDisDiscoverableCriteria* DtDisBrokerInitializer::discoveryCriteria()
      {
         return myDiscoverableCriteria;
      }

      //
      // Connection Settings.
      //

      int DtDisBrokerInitializer::disPort() const
      {
         return myDisPort.value();
      }

      void DtDisBrokerInitializer::setDisPort( int port )
      {
         myDisPort.setValue( port );
      }

      int DtDisBrokerInitializer::exerciseId() const
      {
         return myExerciseId.value();
      }

      void DtDisBrokerInitializer::setExerciseId( int exid )
      {
         myExerciseId.setValue( exid );
      }

      DtString DtDisBrokerInitializer::destinationAddress() const
      {
         return myDestinationAddress.value();
      }

      void DtDisBrokerInitializer::setDestinationAddress( const DtString& addr )
      {
         myDestinationAddress.setValue( addr );
      }

      DtString DtDisBrokerInitializer::deviceAddress() const
      {
         return myDeviceAddress.value();
      }

      void DtDisBrokerInitializer::setDeviceAddress( const DtString& addr )
      {
         myDeviceAddress.setValue( addr );
      }

      DtString DtDisBrokerInitializer::subnetMask() const
      {
         return mySubnetMask.value();
      }

      void DtDisBrokerInitializer::setSubnetMask( const DtString& mask )
      {
         mySubnetMask.setValue( mask );
      }

      const std::vector<DtString>& DtDisBrokerInitializer::mcastSubscriptionSet() const
      {
         return myMcastSubscriptionSet.values();
      }

      void DtDisBrokerInitializer::setMcastSubscriptionSet( const std::vector<DtString>& val )
      {
         myMcastSubscriptionSet.setValues( val );
      }

      void DtDisBrokerInitializer::addMcastSubscriptionAddr( const DtString& addr )
      {
         myMcastSubscriptionSet.addValue( addr );
      }

      int DtDisBrokerInitializer::socketSendBufferSize() const
      {
         return mySocketSendBufferSize.value();
      }

      void DtDisBrokerInitializer::setSocketSendBufferSize( int value )
      {
         mySocketSendBufferSize.setValue( value );
      }

      int DtDisBrokerInitializer::socketReceiveBufferSize() const
      {
         return mySocketReceiveBufferSize.value();
      }

      void DtDisBrokerInitializer::setSocketReceiveBufferSize( int value )
      {
         mySocketReceiveBufferSize.setValue( value );
      }

      int DtDisBrokerInitializer::multicastTimeToLive() const
      {
         return myMulticastTimeToLive.value();
      }

      void DtDisBrokerInitializer::setMulticastTimeToLive( int num )
      {
         myMulticastTimeToLive.setValue( num );
      }

      //
      // Translation Settings.
      //

      bool DtDisBrokerInitializer::parseUnknownIds() const
      {
         return myParseUnknownIdsFlag.value();
      }

      void DtDisBrokerInitializer::setParseUnknownIds( bool pui )
      {
         myParseUnknownIdsFlag.setValue( pui );
      }

      bool DtDisBrokerInitializer::remapDisIds() const
      {
         return myRemapDisIds.value();
      }

      void DtDisBrokerInitializer::setRemapDisIds( bool yesno )
      {
         myRemapDisIds.setValue( yesno );
      }

      bool DtDisBrokerInitializer::usePersistentEntityIds() const
      {
         return myUsePersistentEntityIds.value();
      }

      void DtDisBrokerInitializer::setUsePersistentEntityIds( bool yesno )
      {
         myUsePersistentEntityIds.setValue( yesno );
      }

      DtTime DtDisBrokerInitializer::interactionWaitListTimeout() const
      {
         return myInteractionWaitListTimeout.value();
      }

      void DtDisBrokerInitializer::setInteractionWaitListTimeout( DtTime val )
      {
         myInteractionWaitListTimeout.setValue( val );
      }

      bool DtDisBrokerInitializer::sendExpiredWaitListInteractions() const
      {
         return mySendExpiredWaitListInteractions.value();
      }

      void DtDisBrokerInitializer::setSendExpiredWaitListInteractions( bool val )
      {
         mySendExpiredWaitListInteractions.setValue( val );
      }

      int DtDisBrokerInitializer::applicationNumber() const
      {
         return myApplicationNumber.value();
      }

      void DtDisBrokerInitializer::setApplicationNumber( int exid )
      {
         myApplicationNumber.setValue( exid );
      }

      int DtDisBrokerInitializer::siteId() const
      {
         return mySiteId.value();
      }

      void DtDisBrokerInitializer::setSiteId( int exid )
      {
         mySiteId.setValue( exid );
      }

      bool DtDisBrokerInitializer::useAbsoluteTimeStamping() const
      {
         return myUseAbsoluteTimeStamping.value();
      }

      void DtDisBrokerInitializer::setUseAbsoluteTimeStamping( bool yesno )
      {
         myUseAbsoluteTimeStamping.setValue( yesno );
      }

      double DtDisBrokerInitializer::locationThreshold() const
      {
         return myLocationThreshold.value();
      }

      void DtDisBrokerInitializer::setLocationThreshold( double thresh )
      {
         myLocationThreshold.setValue( thresh );
      }

      double DtDisBrokerInitializer::rotationThreshold() const
      {
         return myRotationThreshold.value();
      }

      void DtDisBrokerInitializer::setRotationThreshold( double thresh )
      {
         myRotationThreshold.setValue( thresh );
      }

      int DtDisBrokerInitializer::protocolVersionToSend() const
      {
         return myProtocolVersionToSend.value();
      }

      void DtDisBrokerInitializer::setProtocolVersionToSend( int num )
      {
         myProtocolVersionToSend.setValue( num );
      }

      int DtDisBrokerInitializer::protocolVersionToRecvMin() const
      {
         return myProtocolVersionToRecvMin.value();
      }

      void DtDisBrokerInitializer::setProtocolVersionToRecvMin( int num )
      {
         myProtocolVersionToRecvMin.setValue( num );
      }

      int DtDisBrokerInitializer::protocolVersionToRecvMax() const
      {
         return myProtocolVersionToRecvMax.value();
      }

      void DtDisBrokerInitializer::setProtocolVersionToRecvMax( int num )
      {
         myProtocolVersionToRecvMax.setValue( num );
      }

      bool DtDisBrokerInitializer::disableArticulatedParts() const
      {
         return myDisableArticulatedParts.value();
      }

      void DtDisBrokerInitializer::setDisableArticulatedParts( bool yesno )
      {
         myDisableArticulatedParts.setValue( yesno );
      }

      bool DtDisBrokerInitializer::splitUnderwaterAcousticPdus() const
      {
         return mySplitUnderwaterAcousticPdus.value();
      }

      void DtDisBrokerInitializer::setSplitUnderwaterAcousticPdus( bool val )
      {
         mySplitUnderwaterAcousticPdus.setValue( val );
      }

      bool DtDisBrokerInitializer::sendDiGuyPdus() const
      {
         return mySendDiGuyPdus.value();
      }

      void DtDisBrokerInitializer::setSendDiGuyPdus( bool val )
      {
         mySendDiGuyPdus.setValue( val );
      }

      bool DtDisBrokerInitializer::sendSeesPdus() const
      {
         return mySendSeesPdus.value();
      }

      void DtDisBrokerInitializer::setSendSeesPdus( bool val )
      {
         mySendSeesPdus.setValue( val );
      }

      bool DtDisBrokerInitializer::sendRelativeLocationPdus() const
      {
         return mySendRelativeLocationPdus.value();
      }

      void DtDisBrokerInitializer::setSendRelativeLocationPdus( bool val )
      {
         mySendRelativeLocationPdus.setValue( val );
      }

      //
      // Debug Settings.
      //

      bool DtDisBrokerInitializer::debugGlobalIdMapping() const
      {
         return myDebugGlobalIdMapping.value();
      }

      void DtDisBrokerInitializer::setDebugGlobalIdMapping( bool debug )
      {
         myDebugGlobalIdMapping.setValue( debug );
      }

      bool DtDisBrokerInitializer::debugEntityIdMapping() const
      {
         return myDebugEntityIdMapping.value();
      }

      void DtDisBrokerInitializer::setDebugEntityIdMapping( bool debug )
      {
         myDebugEntityIdMapping.setValue( debug );
      }

      bool DtDisBrokerInitializer::debugEventIdMapping() const
      {
         return myDebugEventIdMapping.value();
      }

      void DtDisBrokerInitializer::setDebugEventIdMapping( bool debug )
      {
         myDebugEventIdMapping.setValue( debug );
      }

      bool DtDisBrokerInitializer::dumpGuiToText() const
      {
         return myDumpGuiToText.value();
      }

      void DtDisBrokerInitializer::setDumpGuiToText( bool val )
      {
         myDumpGuiToText.setValue( val );
      }

      //
      // Timing Settings.
      //

      DtTime DtDisBrokerInitializer::heartbeatInterval() const
      {
         return myHeartbeatInterval.value();
      }

      void DtDisBrokerInitializer::setHeartbeatInterval( DtTime hrt )
      {
         myHeartbeatInterval.setValue( hrt );
      }

      DtTime DtDisBrokerInitializer::timeoutInterval() const
      {
         return myTimeoutInterval.value();
      }

      void DtDisBrokerInitializer::setTimeoutInterval( DtTime hrt )
      {
         myTimeoutInterval.setValue( hrt );
      }

      DtTime DtDisBrokerInitializer::drainTimeout() const
      {
         return myDrainTimeout.value();
      }

      void DtDisBrokerInitializer::setDrainTimeout( DtTime timeout )
      {
         myDrainTimeout.setValue( timeout );
      }

      int DtDisBrokerInitializer::numPdusReadPerTimeCheck() const
      {
         return myNumPdusReadPerTimeCheck.value();
      }

      void DtDisBrokerInitializer::setNumPdusReadPerTimeCheck( int num )
      {
         myNumPdusReadPerTimeCheck.setValue( num );
      }

   }
}

