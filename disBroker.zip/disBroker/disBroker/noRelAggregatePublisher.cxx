/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file noRelAggregatePublisher.cxx
//! \brief Contains the DtNoRelAggregatePublisher class declaration.
//! \ingroup disBroker

#if DtDIS

#include <disBroker/noRelAggregatePublisher.h>

DtNoRelAggregatePublisher::DtNoRelAggregatePublisher( DtAggregateStateRepository* stateRepToUse, DtExerciseConn* conn, const DtObjectId& id )
   : DtAggregatePublisher( stateRepToUse, conn, id )
{
}

DtNoRelAggregatePublisher::DtNoRelAggregatePublisher( DtExerciseConn* conn, const DtObjectId& id )
   : DtAggregatePublisher( conn, id )
{
}

DtNoRelAggregatePublisher::DtNoRelAggregatePublisher( const DtEntityType& type, DtExerciseConn* conn, const DtObjectId& id )
   : DtAggregatePublisher( type, conn, id )
{
}

DtNoRelAggregatePublisher::DtNoRelAggregatePublisher( const DtEntityType& type, DtExerciseConn* conn,
      DtDeadReckonTypes algorithm, DtForceType forceId, const DtObjectId& id )
   : DtAggregatePublisher( type, conn, algorithm, forceId, id )
{
}

DtNoRelAggregatePublisher::~DtNoRelAggregatePublisher()
{
}


void DtNoRelAggregatePublisher::tick()
{
   // If the user has specified to use their own, just keep
   // the myTimeThreshold value
   if ( ! useCustomThreshold() )
   {
      //Verify Time Threshold
      if(theStationaryDfltIsSetFlag && aggregateStateRep()->velocity() == DtVector32())
      {
         myTimeThreshold = theStationaryDfltTimeThreshold;
      }
      else
      {
         DtEntityType entType = aggregateStateRep()->entityType();
         myTimeThreshold = entityTypeHeartbeat(entType.kind(),entType.domain());
      }
   }

   DtClock* theClock = myExConn->clock();
   if (theClock->absRealTime() > lastTimeUpdated() + timeThreshold())
   {
      myAggregateEncoder->setSendNeeded();
   }

   DtAggregateStatePdu* pdu = myAggregateEncoder->stateMsg( *asr(), *(static_cast<DtAggregateStateRepository*>(approximateRemoteStateRep())) );
   if ( pdu )
   {
      send(pdu);
      myAggregateDecoder->decode( *pdu, (DtAggregateStateRepository*)approximateRemoteStateRep() );
   }
}

#endif
