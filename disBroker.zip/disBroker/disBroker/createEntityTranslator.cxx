/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file createEntityTranslator.cxx
//! \brief Contains the DtCreateEntityTranslator class definition.
//! \ingroup disBroker

#include <disBroker/createEntityTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtCreateEntityTranslator::DtCreateEntityTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalCreateEntityInteraction::theKind )
      {
      }

      DtCreateEntityTranslator::~DtCreateEntityTranslator()
      {
      }

      bool DtCreateEntityTranslator::isPortalDiscoverable(
         const DtPortalCreateEntityInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.originatingId())
            && testGlobalIdMapping("Receiver ID",inter.receiverId()) );
      }

      DtPortalCreateEntityInteraction* DtCreateEntityTranslator::translate(
         DtPortalCreateEntityInteraction* destination, const DtCreateEntityInteraction& source )
      {
         destination->setOriginatingId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setRequestId( source.requestId() );
         return destination;
      }

      DtCreateEntityInteraction* DtCreateEntityTranslator::translate(
         DtCreateEntityInteraction* destination, const DtPortalCreateEntityInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId(source.originatingId()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setRequestId( source.requestId() );
         return destination;
      }

   }
}
