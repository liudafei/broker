/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file serviceRequestTranslator.cxx
//! \brief Contains the DtServiceRequestTranslator class definition.
//! \ingroup disBroker

#include <disBroker/serviceRequestTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtServiceRequestTranslator::DtServiceRequestTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalServiceRequestInteraction::theKind )
      {
      }

      DtServiceRequestTranslator::~DtServiceRequestTranslator()
      {
      }

      bool DtServiceRequestTranslator::isPortalDiscoverable(
         const DtPortalServiceRequestInteraction& inter )
      {
         return ( testGlobalIdMapping("Requesting ID",inter.receivingId())
            && testGlobalIdMapping("Servicing ID",inter.supplyingId()) );
      }

      DtPortalServiceRequestInteraction* DtServiceRequestTranslator::translate(
         DtPortalServiceRequestInteraction* destination, const DtServiceRequestInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.requestingId()) );
         destination->setSupplyingId( disBroker()->convertGlobalId(source.servicingId()) );
         destination->setNumSupplyTypes( source.numSupplyTypes() );
         destination->setServiceType( source.serviceType() );

         int numSupplyTypes = source.numSupplyTypes();
         for ( int i = 0; i < numSupplyTypes; ++i )
         {
            float quantity = 0;
            int retCode = 0;
            DtEntityType supplyType = source.nthSupply( i, &quantity, &retCode );
            if ( DtSUPPLY_VALID == retCode )
            {
               retCode = destination->setNthSupply( i, supplyType, &quantity );
            }

            if ( DtSUPPLY_VALID != retCode )
            {
               DtWarn << name() << " problem translating supply.\n"
                  << "  Mismatch between stated num supplies and encoded num supplies.\n";
               break;
            }
         }

         return destination;
      }

      DtServiceRequestInteraction* DtServiceRequestTranslator::translate(
         DtServiceRequestInteraction* destination, const DtPortalServiceRequestInteraction& source )
      {
         destination->setRequestingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setServicingId( disBroker()->convertGlobalId(source.supplyingId()) );
         destination->setNumSupplyTypes( source.numSupplyTypes() );
         destination->setServiceType( (DtServiceType) source.serviceType() );

         int retCode = DtSUPPLY_VALID;
         int numSupplyTypes = source.numSupplyTypes();
         for ( int i = 0; ((DtSUPPLY_VALID == retCode) && (i < numSupplyTypes)); ++i )
         {
            float quantity = 0;
            DtNetEntityType supplyType;
            retCode = source.nthSupply( i, supplyType, &quantity );
            if ( DtSUPPLY_VALID == retCode )
            {
               destination->setNthSupply( i, supplyType, quantity, &retCode );
            }

            if ( DtSUPPLY_VALID != retCode )
            {
               DtWarn << name() << " problem translating supply.\n"
                  << "  Mismatch between stated num supplies and encoded num supplies.\n";
               break;
            }
         }
         return destination;
      }

   }
}
