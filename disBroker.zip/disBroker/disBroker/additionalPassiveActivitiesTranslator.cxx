/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file additionalPassiveActivitiesTranslator.cxx
//! \brief Contains the DtAdditionalPassiveActivitiesTranslator class definition.
//! \ingroup disBroker

#include <disBroker/additionalPassiveActivitiesTranslator.h>
#include <disBroker/disBrokerInitializer.h>
#include <disBroker/eventIdMapper.h>

#include <vl/underwaterAcousticsPublisher.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtAdditionalPassiveActivitiesTranslator::DtAdditionalPassiveActivitiesTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalAdditionalPassiveActivitiesObject::theKind )
      {
      }

      DtAdditionalPassiveActivitiesTranslator::~DtAdditionalPassiveActivitiesTranslator()
      {
      }

      DtObjectPublisher* DtAdditionalPassiveActivitiesTranslator::instantiateDisPublisher(
         const DtPortalReflectedAdditionalPassiveActivitiesObject* refObj,
         const DtEntityIdentifier& objectId )
      {
         DtObjectPublisher* objectPublisher = NULL;
         if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
         {
            objectPublisher = new DtAdditionalPassiveActivitiesPublisher(
               disBroker()->connection(), objectId );
         }
         else
         {
            DtUnderwaterAcousticsPublisherManager* mgr =
               disBroker()->underwaterAcousticsPublisherManager();
            DtString hostId = refObj->sr()->hostObjectIdentifier();
            DtUnderwaterAcousticsPublisher* publisher =
               mgr->findPublisher( hostId );
            if ( ! publisher )
            {
               publisher = new DtUnderwaterAcousticsPublisher(
                  disBroker()->connection(), objectId );
               mgr->registerPublisher( hostId, publisher );
            }
            mgr->checkoutPublisher( publisher );
            objectPublisher = publisher;
         }
         return objectPublisher;
      }

      void DtAdditionalPassiveActivitiesTranslator::createDisPublisher( DtBrokerObject* brokerObj )
      {
         try
         {
            // Get the reflected object and make sure it exists.
            const DtPortalReflectedAdditionalPassiveActivitiesObject* refObj =
               static_cast<const DtPortalReflectedAdditionalPassiveActivitiesObject*>(
                  brokerObj->reflectedObjPtr() );
            assert( refObj );

            // Get and convert the identifier and create the publisher.
            DtString objectName = disObjectName( refObj );
            DtGlobalIdMapper::DisId newId = mapIdentifier( refObj, objectName );

            // Workaround for OTD #58282:
            // Null and Default IDs should be treated the same during publisher instantiation.
            newId = ( newId == DtEntityIdentifier::nullId() ? DtEntityIdentifier::defaultId() : newId );

            DtObjectPublisher* publisher = instantiateDisPublisher( refObj, newId );

            // Abort if no publisher was instantiated.
            if ( ! publisher )
            {
               brokerObj->setDropReason( "Publisher instantiation failed" );
               DtWarn << name() << " translator dropping object: " <<
                  refObj->sr()->identifier() << std::endl;
               brokerObj->setPublisherPtr( NULL );
               brokerObj->setIsDropped( true );
               return;
            }

            // Set up the global ID Mapping
            if ( ! performDisGlobalIdMapping(publisher,*refObj,
               DtGlobalIdMapper::AdditionalPassiveActivitesType,refObj->sr()->activityCode()) )
            {
               // Object dropped, publisher no longer needed and will be deleted with the release.
               DtUnderwaterAcousticsPublisherManager* mgr = disBroker()->underwaterAcousticsPublisherManager();
               mgr->releasePublisher( refObj->sr()->hostObjectIdentifier() );

               // Note that the object is being dropped in the log file.
               DtWarn << this->name() << " translator dropping object: " << refObj->sr()->identifier() << std::endl;

               // Abort if the name is invalid and destroy the publisher.
               brokerObj->setDropReason( "Name collision" );
               brokerObj->setPublisherPtr( NULL );
               brokerObj->setIsDropped( true );
               return;
            }

            brokerObj->setPublisherPtr( publisher );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      DtString DtAdditionalPassiveActivitiesTranslator::portalObjectName(
         const DtReflectedAdditionalPassiveActivities* refObj ) const
      {
         DtString newApaName( refObj->globalId().string() );
         newApaName += "-";
         newApaName += refObj->asr()->activityCode();
         newApaName += "APAvrx";
         return newApaName;
      }

      bool DtAdditionalPassiveActivitiesTranslator::performPortalGlobalIdMapping(
         const DtPortalAdditionalPassiveActivitiesObjectPublisher* publisher,
         const DtReflectedAdditionalPassiveActivities& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performPortalGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::AdditionalPassiveActivitesType, refObj.asr()->activityCode() );
      }

      void DtAdditionalPassiveActivitiesTranslator::receivePortalUpdate(
         const DtPortalReflectedAdditionalPassiveActivitiesObject& object )
      {
         try
         {
            DtBrokerObject* brokerObject = findBrokerObject( &object );
            if ( ! brokerObject )
            {
               DtWarn << "Received update call for deleted portal emitter system: "
                  << object.sr()->hostObjectIdentifier() << std::endl;
               return;
            }
            assert( brokerObject );

            const DtPortalAdditionalPassiveActivitiesObject& portalAddPassAct = *(object.sr());

            updatePortalBrokerObject( brokerObject, portalAddPassAct );

            callObjectUpdateCallbacks( brokerObject );

            // Abort if the object has been dropped.
            if ( brokerObject->isDropped() )
            {
               return;
            }

            DtObjectPublisher* objectPublisher = NULL;
            DtAdditionalPassiveActivitiesRepository* disAddPassAct = NULL;
            if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
            {
               DtAdditionalPassiveActivitiesPublisher* publisher =
                  static_cast<DtAdditionalPassiveActivitiesPublisher*>(
                     brokerObject->publisherPtr() );
               assert( publisher );

               disAddPassAct = publisher->asr();
               objectPublisher = publisher;
            }
            else
            {
               DtUnderwaterAcousticsPublisher* publisher =
                  static_cast<DtUnderwaterAcousticsPublisher*>(
                     brokerObject->publisherPtr() );
               assert( publisher );

               DtApaRetCode retcode;
               disAddPassAct = publisher->usr()->apaSRById(
                  portalAddPassAct.activityCode(), &retcode );
               if ( retcode != DtApaSuccess )
               {
                  disAddPassAct = publisher->usr()->addApa(
                     portalAddPassAct.activityCode() );
               }
               objectPublisher = publisher;
            }

            translate( disAddPassAct, portalAddPassAct, object );

            if ( myBroker->brokerInitializer()->oneToOneMapping() )
            {
               objectPublisher->forceUpdate();
            }

            if ( myBroker->isTranslatorDebuggingOn(name()) )
            {
               printIncomingOutgoingStateReps( portalAddPassAct, *disAddPassAct );
            }

            if ( isPublishEnabled() )
            {
               objectPublisher->tick();
            }

            performPortalDebugging( portalAddPassAct, *disAddPassAct );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      bool DtAdditionalPassiveActivitiesTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedAdditionalPassiveActivitiesObject* refObj )
      {
         DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->underwaterAcousticsNeedsEntityId() )
         {
            int activityCode = refObj->sr()->activityCode();
            DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::AdditionalPassiveActivitesType;
            DtEntityIdentifier newId = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
               refObj->sr()->identifier(), &objType, &activityCode );
            if ( newId == DtEntityIdentifier::nullId() )
            {
               newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
                  refObj->sr()->entityIdentifier() );
            }
            if ( newId == DtEntityIdentifier::nullId() )
            {
               DtInfo << "DtAdditionalPassiveActivitiesTranslator: " << brokerObj->objectName()
                  << ": Entity Id not present, object incomplete" << std::endl;
               brokerObj->setDropReason( "Missing Entity ID" );
               return false;
            }
         }
         if ( discoveryCriteria->underwaterAcousticsNeedsHostId() &&
            refObj->sr()->hostObjectIdentifier().isEmpty() )
         {
            DtInfo << "DtAdditionalPassiveActivitiesTranslator: " << brokerObj->objectName()
               << ": Host Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Host ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      void DtAdditionalPassiveActivitiesTranslator::deleteDisPublisher( DtBrokerObject* brokerObject )
      {
         DtObjectPublisher* publisher =
            static_cast<DtObjectPublisher*>( brokerObject->publisherPtr() );
         const DtPortalReflectedAdditionalPassiveActivitiesObject* reflectedObj =
            static_cast<const DtPortalReflectedAdditionalPassiveActivitiesObject*>(
               brokerObject->reflectedObjPtr() );
         if ( ! disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
         {
            DtUnderwaterAcousticsPublisherManager* mgr =
               disBroker()->underwaterAcousticsPublisherManager();
            mgr->releasePublisher( reflectedObj->sr()->hostObjectIdentifier() );
         }

         if ( publisher && reflectedObj )
         {
            DtU16 activityCode = reflectedObj->sr()->activityCode();
            disBroker()->globalIdMapper()->remove( reflectedObj->sr()->entityIdentifier(),
               DtGlobalIdMapper::AdditionalPassiveActivitesType, activityCode );
            brokerObject->setPublisherPtr( 0 );
            if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
            {
               DtDELETE( publisher );
            }
         }
      }

      DtPortalAdditionalPassiveActivitiesObject* DtAdditionalPassiveActivitiesTranslator::translate(
         DtPortalAdditionalPassiveActivitiesObject* destination,
         const DtAdditionalPassiveActivitiesRepository& source,
         const DtReflectedAdditionalPassiveActivities& refObj )
      {
         // Translate underwater acoustics attributes.
         ParentClass::translate( destination, source, refObj );

         // Attribute Translation.
         destination->setActivityCode( source.activityCode() );
         destination->setActivityParameter( source.activityParameter() );
         destination->setIsSilent( source.isSilent() );

         return destination;
      }

      DtAdditionalPassiveActivitiesRepository* DtAdditionalPassiveActivitiesTranslator::translate(
         DtAdditionalPassiveActivitiesRepository* destination,
         const DtPortalAdditionalPassiveActivitiesObject& source,
         const DtPortalReflectedAdditionalPassiveActivitiesObject& refObj )
      {
         // Translate underwater acoustics attributes.
         ParentClass::translate( destination, source, refObj );

         // Attribute Translation.
         destination->setActivityCode( (DtUnderwaterAcousticPassiveParmIndex) source.activityCode() );
         destination->setActivityParameter( source.activityParameter() );

         return destination;
      }
   }
}
