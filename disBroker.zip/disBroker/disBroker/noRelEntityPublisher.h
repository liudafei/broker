/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file noRelEntityPublisher.h
//! \brief Contains the DtNoRelEntityPublisher class declaration.
//! \ingroup disBroker

#pragma once

#if DtDIS

#include <disBroker/dllExport.h>
#include <vl/entityPublisherDIS.h>

//! \brief Overridden version of the DtNoRelEntityPublisher that does not send relative location PDUs.
//! \ingroup disBroker
class DT_DLL_DISBROKER DtNoRelEntityPublisher : public DtEntityPublisher
{
public:

   DtNoRelEntityPublisher( DtEntityStateRepository* stateRepToUse, DtExerciseConn* conn, const DtObjectId& id = DtObjectId::defaultId() );

   DtNoRelEntityPublisher( const DtEntityType& type, DtExerciseConn* conn, const DtObjectId& id = DtObjectId::defaultId() );

   DtNoRelEntityPublisher( DtExerciseConn* conn, const DtObjectId& id = DtObjectId::defaultId() );

   DtNoRelEntityPublisher( const DtEntityType& type, DtExerciseConn* conn, DtDeadReckonTypes algorithm, DtForceType forceId,
      const DtEntityType& guise = guiseSameAsType(), const DtObjectId& id = DtObjectId::defaultId() );

   virtual ~DtNoRelEntityPublisher();

   //! This function should be called once per frame for each entity.
   //! It determines if any data needs to be sent to the other
   //! exercise participants, and sends that data.
   virtual void tick();

private:

   //! copy constructor - Not Implemented
   DtNoRelEntityPublisher( const DtNoRelEntityPublisher& orig );

   //! assignment operator - Not Implemented
   DtNoRelEntityPublisher& operator = ( const DtNoRelEntityPublisher& orig );

};

#endif // DtDIS
