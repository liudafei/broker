/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file arealObjectTranslator.cxx
//! \brief Contains the DtArealObjectTranslator class definition.
//! \ingroup disBroker

#include <disBroker/arealObjectTranslator.h>
#include <disBroker/disBrokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtArealObjectTranslator::DtArealObjectTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalArealObject::theKind )
      {
         DtArealObjectPublisher::setDfltTimeThreshold( ((DtDisBroker*)broker)->heartbeatInterval() );
      }

      DtArealObjectTranslator::~DtArealObjectTranslator()
      {
      }

      bool DtArealObjectTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedPointObject& refObj ) const
      {
         if ( refObj.sr()->objectIdentifier() == DtEntityIdentifier() )
         {
            DtInfo << "DtArealObjectTranslator: " << brokerObj->objectName()
               << ": Object Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Object ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<AREAL_OBJECT_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedArealObject* refObj, const DtString& identifier )
      {
         return mapObjectId( DtEntityIdentifier(identifier) );
      }

      DtString DtArealObjectTranslator::disObjectName(
         const DtPortalReflectedArealObject* refObj ) const
      {
         return refObj->sr()->objectIdentifier().string();
      }

      void DtArealObjectTranslator::updateDisBrokerObject( DtBrokerObject* brokerObj,
         const DtArealObjectRepository& sr )
      {
         ParentClass::updateDisBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.objectId().string() );
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<AREAL_OBJECT_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedArealObject* refObj, const DtEntityIdentifier& name )
      {
         DtArealObjectPublisher* publisher = NULL;
         try
         {
            // Instantiate the publisher.
            publisher = new DtArealObjectPublisher( refObj->sr()->objectType(),
               disBroker()->connection(), name );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      DtString DtArealObjectTranslator::portalObjectName(
         const DtReflectedArealObject* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "AOvrx";
      }

      void DtArealObjectTranslator::updatePortalBrokerObject( DtBrokerObject* brokerObj,
         const DtPortalArealObject& sr )
      {
         ParentClass::updatePortalBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.objectIdentifier().string() );
      }

      DtPortalArealObject* DtArealObjectTranslator::translate(
         DtPortalArealObject* dest, const DtArealObjectRepository& src,
         const DtReflectedArealObject& refObj )
      {
         // env. object attributes.
         dest->setObjectIdentifier( *disBroker()->entityIdMapper()
            ->convertDisEidToPortalEid(src.objectId()) );
         dest->setReferencedObjectId( disBroker()->entityIdMapper()
            ->convertDisEidToPortalEid(src.referencedObjectId())->string() );
         dest->setUpdateNumber( src.updateNumber() );
         dest->setForceId( src.forceId() );
         dest->setRequestorId( src.requesterSimId() );
         dest->setReceivingId( src.receivingSimId() );

         // env. object type.
         dest->setObjectType( src.objectType() );

         // areal object attributes.
         dest->setModifications( src.modifications() );
         dest->setGeneralAppearance( src.generalAppearance() );
         dest->setSpecificAppearance( src.specificAppearance() );

         // areal point data.
         std::vector<DtVector> points;
         int numPoints = src.numberOfPoints();
         dest->setNumPoints( src.numberOfPoints() );
         for ( int i = 0; i < numPoints; ++i )
         {
            DtVector loc;
            src.getPointLocation( i, loc );
            points.push_back( loc );
         }
         dest->setPoints( points );

         return dest;
      }

      DtArealObjectRepository* DtArealObjectTranslator::translate(
         DtArealObjectRepository* dest, const DtPortalArealObject& src,
         const DtPortalReflectedArealObject& refObj )
      {
         // env. object attributes.
         dest->setObjectId( *disBroker()->entityIdMapper()
            ->convertPortalEidToDisEid(src.objectIdentifier()) );
         dest->setReferencedObjectId( *disBroker()->entityIdMapper()
            ->convertPortalEidToDisEid(DtEntityIdentifier(src.referencedObjectId())) );
         dest->setUpdateNumber( src.updateNumber() );
         dest->setForceId( (DtForceType) src.forceId() );
         dest->setRequesterSimId( src.requestorId() );
         dest->setReceivingSimId( src.receivingId() );

         // env. object type.
         dest->setObjectType( src.objectType() );

         // areal object attributes.
         dest->setModifications( src.modifications() );
         dest->setGeneralAppearance( src.generalAppearance() );
         dest->setSpecificAppearance( src.specificAppearance() );

         // areal point data.
         int numPoints = src.numPoints();
         dest->setNumberOfPoints( src.numPoints() );
         for ( int i = 0; i < numPoints; ++i )
         {
            dest->setPointLocation( i, src.points()[i] );
         }

         return dest;
      }

   }
}
