/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioTransmitterTranslator.h
//! \brief Contains the DtRadioTransmitterTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/embeddedSystemTranslator.h>
#include <vl/reflectedRadioTransmitterList.h>
#include <vl/radioTransmitterPublisher.h>

class DtReflectedRadioTransmitter;
class DtRadioTransmitterRepository;

#define RADIO_XMIT_TEMPLATE_ARGS \
   DtPortalRadioTransmitterObject, DtPortalReflectedRadioTransmitterObject, \
   DtReflectedRadioTransmitter, DtReflectedRadioTransmitterList, \
   DtRadioTransmitterRepository, DtRadioTransmitterPublisher

namespace MAKVrExchange
{

   class DtPortalRadioTransmitterObject;

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<RADIO_XMIT_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedRadioTransmitterObject* refObj,
         const DtString& identifier );

      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<RADIO_XMIT_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedRadioTransmitterObject* refObj,
         const DtEntityIdentifier& name );


      //! \brief Provides Radio Transmitter object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtRadioTransmitterTranslator
         : public DtEmbeddedSystemTranslator<RADIO_XMIT_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Radio Transmitter" );

         //! \brief CTOR.
         DtRadioTransmitterTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtRadioTransmitterTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedRadioTransmitterObject* refObj );

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Overridden to use the radio receiver object type.
         virtual bool performDisGlobalIdMapping( const DtObjectPublisher* publisher,
            const DtPortalReflectedRadioTransmitterObject& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Construct the portal object name.
         //! Overridden to construct a radio transmitter name.
         virtual DtString portalObjectName( const DtReflectedRadioTransmitter* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Overridden to use the radio transmitter object type.
         virtual bool performPortalGlobalIdMapping(
            const DtPortalRadioTransmitterObjectPublisher* publisher,
            const DtReflectedRadioTransmitter& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Destroy the brokerObject's publisher.
         //! Overridden to correctly unmap the publisher's id.
         virtual void deleteDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Translates a Radio Transmitter object into the portal.
         virtual DtPortalRadioTransmitterObject* translate( DtPortalRadioTransmitterObject* destination,
            const DtRadioTransmitterRepository& source, const DtReflectedRadioTransmitter& refObj );

         //! \brief Translates a Radio Transmitter object from the portal.
         virtual DtRadioTransmitterRepository* translate( DtRadioTransmitterRepository* destination,
            const DtPortalRadioTransmitterObject& source, const DtPortalReflectedRadioTransmitterObject& refObj );

      };

   }
}

