/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioSignalTranslator.cxx
//! \brief Contains the DtRadioSignalTranslator class definition.
//! \ingroup disBroker

#include <disBroker/radioSignalTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtRadioSignalTranslator::DtRadioSignalTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalRadioSignalInteraction::theKind )
      {
      }

      DtRadioSignalTranslator::~DtRadioSignalTranslator()
      {
      }

      DtPortalRadioSignalInteraction* DtRadioSignalTranslator::translate(
         DtPortalRadioSignalInteraction* destination, const DtSignalInteraction& source )
      {
         destination->setHostRadioId( disBroker()->globalIdMapper()->convertDisGidToPortalGid(
            source.entityId(), DtGlobalIdMapper::RadioTransmitterType, source.radioId()) );

         destination->setDataRate( source.sampleRate() );
         destination->setSamples( source.numSamples() );
         if ( source.numDataBytes() >= 0 )
         {
            destination->setSignalData( DtVariableLengthData(
               (const char*)source.data(),source.numDataBytes()) );
         }
         else
         {
            DtWarn << "DIS Broker: received invalid number of data bytes in signal interaction" << std::endl;
            DtWarn << "DIS Broker: setting number of data bytes to zero in portal signal interaction" << std::endl;
         }
         destination->setUserProtocolID( source.encodingType() );
         destination->setTacticalDataLinkType( source.tdlType() );
         destination->setEncodingClass( source.encodingClass() );
         destination->setEncodingType( source.encodingType() );

         // Set Protocol ID if encoding is application specific.
         if ( source.encodingClass() == DtSignalClassApplicationSpecific )
         {
            if ( source.numDataBytes() < 4 )
            {
               DtWarn << "DisBroker: " << name() << " received Application"
                  " Specific encoding; but the data sent was less than the"
                  " required minimum of 4 bytes." << std::endl;
            }

            destination->setUserProtocolID( *(DtU32*)source.data() );
         }

         return destination;
      }

      DtSignalInteraction* DtRadioSignalTranslator::translate(
         DtSignalInteraction* destination, const DtPortalRadioSignalInteraction& source )
      {
         int id = DtGlobalIdMapper::NoSystemId;
         DtGlobalIdMapper::ObjectType aType = DtGlobalIdMapper::NoType;

         destination->setEntityId( disBroker()->globalIdMapper()->convertPortalGidToDisGid(
            source.hostRadioId(), &aType, &id) );

         if ( aType == DtGlobalIdMapper::RadioTransmitterType )
         {
            destination->setRadioId( id );
         }
         else
         {
            DtWarn << "Broker(DisBroker): DtSignalInteractionTranslator got"
               " Portal radio id(" << source.hostRadioId() << ") which does"
                  " not map  to a radioTransmitter. type=(" << aType
                  << ")" << std::endl;
         }

         destination->setEncodingClass( (DtEncodingClass)source.encodingClass() );
         destination->setEncodingType( (DtEncodingType)source.encodingType() );
         destination->setSampleRate( source.dataRate() );
         destination->setNumSamples( source.samples() );
         destination->setTdlType( source.tacticalDataLinkType() );
         destination->setNumDataBytes( source.signalData().size());
         destination->setData( (unsigned char*)source.signalData().data(),
            source.signalData().size() );

         return destination;
      }

   }
}
