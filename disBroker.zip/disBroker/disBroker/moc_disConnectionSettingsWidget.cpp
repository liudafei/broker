/****************************************************************************
** Meta object code from reading C++ file 'disConnectionSettingsWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "disConnectionSettingsWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'disConnectionSettingsWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MAKVrExchange__DtDisBroker__DtDisConnectionSettingsWidget_t {
    QByteArrayData data[20];
    char stringdata0[530];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MAKVrExchange__DtDisBroker__DtDisConnectionSettingsWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MAKVrExchange__DtDisBroker__DtDisConnectionSettingsWidget_t qt_meta_stringdata_MAKVrExchange__DtDisBroker__DtDisConnectionSettingsWidget = {
    {
QT_MOC_LITERAL(0, 0, 57), // "MAKVrExchange::DtDisBroker::D..."
QT_MOC_LITERAL(1, 58, 27), // "on_portSpinBox_valueChanged"
QT_MOC_LITERAL(2, 86, 0), // ""
QT_MOC_LITERAL(3, 87, 7), // "newPort"
QT_MOC_LITERAL(4, 95, 33), // "on_exerciseIdSpinBox_valueCha..."
QT_MOC_LITERAL(5, 129, 5), // "newId"
QT_MOC_LITERAL(6, 135, 41), // "on_nicAddressComboBox_current..."
QT_MOC_LITERAL(7, 177, 10), // "newNicAddr"
QT_MOC_LITERAL(8, 188, 25), // "on_advancedButton_toggled"
QT_MOC_LITERAL(9, 214, 7), // "enabled"
QT_MOC_LITERAL(10, 222, 41), // "on_destinationAddressEdit_edi..."
QT_MOC_LITERAL(11, 264, 41), // "on_multicastAddressesEdit_edi..."
QT_MOC_LITERAL(12, 306, 38), // "on_multicastAddressEditButton..."
QT_MOC_LITERAL(13, 345, 37), // "on_sendBufferSizeSpinBox_valu..."
QT_MOC_LITERAL(14, 383, 14), // "sendBufferSize"
QT_MOC_LITERAL(15, 398, 37), // "on_recvBufferSizeSpinBox_valu..."
QT_MOC_LITERAL(16, 436, 14), // "recvBufferSize"
QT_MOC_LITERAL(17, 451, 35), // "on_multicastTtlSpinBox_valueC..."
QT_MOC_LITERAL(18, 487, 8), // "mcastTtl"
QT_MOC_LITERAL(19, 496, 33) // "on_subnetMaskEdit_editingFini..."

    },
    "MAKVrExchange::DtDisBroker::DtDisConnectionSettingsWidget\0"
    "on_portSpinBox_valueChanged\0\0newPort\0"
    "on_exerciseIdSpinBox_valueChanged\0"
    "newId\0on_nicAddressComboBox_currentIndexChanged\0"
    "newNicAddr\0on_advancedButton_toggled\0"
    "enabled\0on_destinationAddressEdit_editingFinished\0"
    "on_multicastAddressesEdit_editingFinished\0"
    "on_multicastAddressEditButton_released\0"
    "on_sendBufferSizeSpinBox_valueChanged\0"
    "sendBufferSize\0on_recvBufferSizeSpinBox_valueChanged\0"
    "recvBufferSize\0on_multicastTtlSpinBox_valueChanged\0"
    "mcastTtl\0on_subnetMaskEdit_editingFinished"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MAKVrExchange__DtDisBroker__DtDisConnectionSettingsWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   69,    2, 0x09 /* Protected */,
       4,    1,   72,    2, 0x09 /* Protected */,
       6,    1,   75,    2, 0x09 /* Protected */,
       8,    1,   78,    2, 0x09 /* Protected */,
      10,    0,   81,    2, 0x09 /* Protected */,
      11,    0,   82,    2, 0x09 /* Protected */,
      12,    0,   83,    2, 0x09 /* Protected */,
      13,    1,   84,    2, 0x09 /* Protected */,
      15,    1,   87,    2, 0x09 /* Protected */,
      17,    1,   90,    2, 0x09 /* Protected */,
      19,    0,   93,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   18,
    QMetaType::Void,

       0        // eod
};

void MAKVrExchange::DtDisBroker::DtDisConnectionSettingsWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DtDisConnectionSettingsWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_portSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->on_exerciseIdSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_nicAddressComboBox_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->on_advancedButton_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->on_destinationAddressEdit_editingFinished(); break;
        case 5: _t->on_multicastAddressesEdit_editingFinished(); break;
        case 6: _t->on_multicastAddressEditButton_released(); break;
        case 7: _t->on_sendBufferSizeSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_recvBufferSizeSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_multicastTtlSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->on_subnetMaskEdit_editingFinished(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MAKVrExchange::DtDisBroker::DtDisConnectionSettingsWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<DtConnectionSettingsWidget::staticMetaObject>(),
    qt_meta_stringdata_MAKVrExchange__DtDisBroker__DtDisConnectionSettingsWidget.data,
    qt_meta_data_MAKVrExchange__DtDisBroker__DtDisConnectionSettingsWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MAKVrExchange::DtDisBroker::DtDisConnectionSettingsWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MAKVrExchange::DtDisBroker::DtDisConnectionSettingsWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MAKVrExchange__DtDisBroker__DtDisConnectionSettingsWidget.stringdata0))
        return static_cast<void*>(this);
    return DtConnectionSettingsWidget::qt_metacast(_clname);
}

int MAKVrExchange::DtDisBroker::DtDisConnectionSettingsWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = DtConnectionSettingsWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
