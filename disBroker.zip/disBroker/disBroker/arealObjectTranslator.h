/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file arealObjectTranslator.h
//! \brief Contains the DtArealObjectTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/arealObjectPublisher.h>
#include <vl/reflectedArealObjectList.h>

class DtReflectedArealObject;
class DtArealObjectRepository;

#define AREAL_OBJECT_TEMPLATE_ARGS \
   DtPortalArealObject, DtPortalReflectedArealObject, \
   DtReflectedArealObject, DtReflectedArealObjectList, \
   DtArealObjectRepository, DtArealObjectPublisher

namespace MAKVrExchange
{

   class DtPortalArealObject;

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<AREAL_OBJECT_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedArealObject* refObj, const DtString& identifier );

      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<AREAL_OBJECT_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedArealObject* refObj, const DtEntityIdentifier& name );


      //! \brief Provides Areal Object translation between DIS and the Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtArealObjectTranslator
         : public DtDisObjectTranslator<AREAL_OBJECT_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Areal Object" );

         //! \brief CTOR.
         DtArealObjectTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtArealObjectTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be published.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedPointObject& refObj ) const;

         //! \brief Gets the reflected object's entity id for publisher creation.
         virtual DtString disObjectName( const DtPortalReflectedArealObject* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const DtArealObjectRepository& sr );

         //! \brief Construct the portal object name.
         //! Overridden to construct a point object name.
         virtual DtString portalObjectName( const DtReflectedArealObject* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj,
            const DtPortalArealObject& sr );

         // Translate from PDU to Portal.
         virtual DtPortalArealObject* translate( DtPortalArealObject* dest,
            const DtArealObjectRepository& src, const DtReflectedArealObject& refObj );

         // Translate from Portal to PDU.
         virtual DtArealObjectRepository* translate( DtArealObjectRepository* dest,
            const DtPortalArealObject& src, const DtPortalReflectedArealObject& refObj );

      };

   }
}
