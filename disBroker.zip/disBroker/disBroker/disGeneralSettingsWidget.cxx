/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disGeneralSettingsWidget.cxx
//! \brief Contains the DtDisGeneralSettingsWidget class definition.
//! \ingroup disBroker

#include <disBroker/disGeneralSettingsWidget.h>

#include <commonWidgets/propertyEditorWidget.h>
#include <commonWidgets/propertyListViewItem.h>
#include <commonWidgets/propertyTypeFactory.h>
#include <commonWidgets/collectionEditor.h>

using namespace MAKCommonWidgets;

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      // Default Translation Settings.
      bool DtDisGeneralSettingsWidget::theDefaultParseUnknownIDs = true;
      bool DtDisGeneralSettingsWidget::theDefaultRemapDisIDs = false;
      bool DtDisGeneralSettingsWidget::theDefaultUsePersistentEntityIDs = false;
      DtTime DtDisGeneralSettingsWidget::theDefaultInteractionWaitListTimeout = 1.0;
      bool DtDisGeneralSettingsWidget::theDefaultSendExpiredWaitListInteractions = false;
      int DtDisGeneralSettingsWidget::theDefaultAppNumber = 2;
      int DtDisGeneralSettingsWidget::theDefaultSiteID = 1;
      bool DtDisGeneralSettingsWidget::theDefaultUseAbsoluteTimeStamp = false;
      double DtDisGeneralSettingsWidget::theDefaultLocationThreshold = 1.0;
      double DtDisGeneralSettingsWidget::theDefaultRotationThreshold = 0.5236; // 3 deg
      int DtDisGeneralSettingsWidget::theDefaultProtocolVersionToSend = 5;
      int DtDisGeneralSettingsWidget::theDefaultProtocolVersionToRecvMin = 4;
      int DtDisGeneralSettingsWidget::theDefaultProtocolVersionToRecvMax = 6;
      bool DtDisGeneralSettingsWidget::theDefaultDisableArticulatedParts = false;
      bool DtDisGeneralSettingsWidget::theDefaultSplitUnderwaterAcousticPdus = false;
      bool DtDisGeneralSettingsWidget::theDefaultSendDiGuyPdus = false;
      bool DtDisGeneralSettingsWidget::theDefaultSendSeesPdus = false;
      bool DtDisGeneralSettingsWidget::theDefaultSendRelativeLocationPdus = true;

      // Default Debug Settings.
      bool DtDisGeneralSettingsWidget::theDefaultDebugGlobalIdMapping = false;
      bool DtDisGeneralSettingsWidget::theDefaultDebugEventIdMapping = false;
      bool DtDisGeneralSettingsWidget::theDefaultDebugEntityIdMapping = false;
      bool DtDisGeneralSettingsWidget::theDefaultDumpGuiToText = false;

      // Default Timing Settings.
      DtTime DtDisGeneralSettingsWidget::theDefaultHeartbeatInterval = 5.0;
      DtTime DtDisGeneralSettingsWidget::theDefaultTimeoutInterval = 10.0;
      DtTime DtDisGeneralSettingsWidget::theDefaultDrainTimeout = -1.0;
      int DtDisGeneralSettingsWidget::theDefaultNumPdusReadPerTimeCheck = 100;

      // Default Discovery Settings.
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryAggregateEntityId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryAggregateLocation = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryAggregateEntityType = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryDesignatorEntityId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryDesignatorHostId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryEmitterSystemEntityId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryEmitterSystemHostId = false;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryEntityLocation = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryEntityEntityType = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryEnvironmentProcessId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryGriddedDataGridId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryIFFEntityId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryIFFHostId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryRadioRecvEntityId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryRadioRecvHostId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryRadioTransEntityId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryRadioTransHostId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryUndwaAcousticsAcousticId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryUndwaAcousticsEntityId = true;
      bool DtDisGeneralSettingsWidget::theDefaultDiscoveryUndwaAcousticsHostId = true;


      DtDisGeneralSettingsWidget::DtDisGeneralSettingsWidget( QWidget* parent /* = 0 */ )
         : DtGeneralSettingsWidget( parent )
         , myObjCollectionEditor( new DtCollectionEditor(this) )
      {
      }

      DtDisGeneralSettingsWidget::~DtDisGeneralSettingsWidget()
      {
      }

      DtDisBrokerInitializer* DtDisGeneralSettingsWidget::disInitializer()
      {
         return (DtDisBrokerInitializer*) myInitializer;
      }

      void DtDisGeneralSettingsWidget::initializeQtStrings()
      {
         // Common Broker Settings.
         DtGeneralSettingsWidget::initializeQtStrings();

         // Translation Settings.
         translationSettingsProperty = tr("DIS Translation Settings");
         parseUnknownIDsProperty = tr("Parse Unknown IDs");
         remapDisIDsProperty = tr("Remap DIS IDs");
         usePersistentEntityIDsProperty = tr("Use Persistent Entity IDs");
         interactionWaitListTimeoutProperty = tr("Interaction Wait-List Timeout");
         sendExpiredWaitListInteractionsProperty = tr("Send Expired Wait-List Interactions");
         applicationNumberProperty = tr("Application Number");
         siteIDProperty = tr("Site ID");
         useAbsoluteTimeStampProperty = tr("Use Absolute Timestamps");
         locationThresholdProperty = tr("Location Threshold");
         rotationThresholdProperty = tr("Rotation Threshold");
         protocolVersionToSendProperty = tr("DIS Protocol Version To Send");
         protocolVersionToRecvMinProperty = tr("DIS Minimum Protocol Version To Receive");
         protocolVersionToRecvMaxProperty = tr("DIS Maximum Protocol Version To Receive");
         disableArticulatedPartsProperty = tr("Disable Articulated Parts Translation");
         splitUnderwaterAcousticPdusProperty = tr("Split Underwater Acoustic PDUs");
         sendDiGuyPdusProperty = tr("Send DI-Guy PDUs");
         sendSeesPdusProperty = tr("Send SEES PDUs");
         sendRelativeLocationPdusProperty = tr("Send Relative Location PDUs");

         // Debug Settings.
         debugSettingsProperty = tr("Debug Settings");
         debugGlobalIdMappingProperty = tr("Debug Global ID Mappings");
         debugEntityIdMappingProperty = tr("Debug Entity ID Mappings");
         debugEventIdMappingProperty = tr("Debug Event ID Mappings");
         dumpGuiToTextProperty = tr("Dump GUI to Text");

         // Timing Settings.
         timingSettingsProperty = tr("Timing Settings");
         heartbeatIntervalProperty = tr("Heartbeat Interval");
         timeoutIntervalProperty = tr("Timeout Interval");
         drainTimeoutProperty = tr("Drain Timeout");
         numPdusReadPerTimeCheckProperty = tr("Number of PDUs Read Per Tick");

         // Discovery Settings.
         discoveryConditionsProperty = tr("Publication Conditions");
         discoveryAggregateEntityIdProperty = tr("Aggregate needs valid Entity ID");
         discoveryAggregateLocationProperty = tr("Aggregate needs valid Location");
         discoveryAggregateEntityTypeProperty = tr("Aggregate needs valid Type");
         discoveryDesignatorEntityIdProperty = tr("Designator needs valid Entity ID");
         discoveryDesignatorHostIdProperty = tr("Designator needs valid Host ID");
         discoveryEmitterSystemEntityIdProperty = tr("Emitter System needs valid Entity ID");
         discoveryEmitterSystemHostIdProperty = tr("Emitter System needs valid Host ID");
         discoveryEntityLocationProperty = tr("Entity needs valid Location");
         discoveryEntityEntityTypeProperty = tr("Entity needs valid Type");
         discoveryEnvironmentProcessIdProperty = tr("Environment Process needs valid Process ID");
         discoveryGriddedDataGridIdProperty = tr("Gridded Data needs valid Grid ID");
         discoveryIFFEntityIdProperty = tr("IFF needs valid Entity ID");
         discoveryIFFHostIdProperty = tr("IFF needs valid Host ID");
         discoveryRadioRecvEntityIdProperty = tr("Radio Receiver needs valid Entity ID");
         discoveryRadioRecvHostIdProperty = tr("Radio Receiver needs valid Host ID");
         discoveryRadioTransEntityIdProperty = tr("Radio Transmitter needs valid Entity ID");
         discoveryRadioTransHostIdProperty = tr("Radio Transmitter needs valid Host ID");
         discoveryUndwaAcousticsAcousticIdProperty = tr("Underwater Acoustics need valid Acoustic ID");
         discoveryUndwaAcousticsEntityIdProperty = tr("Underwater Acoustics need valid Entity ID");
         discoveryUndwaAcousticsHostIdProperty = tr("Underwater Acoustics need valid Host ID");
      }

      void DtDisGeneralSettingsWidget::initializeProperties()
      {
         // Initialize Common Settings.
         DtGeneralSettingsWidget::initializeProperties();

         DtPropertyTypeFactory* types = DtPropertyTypeFactory::create();
         DtPropertyListViewItem* propItem;

         QTreeWidgetItem* translationSettings = new QTreeWidgetItem( this, QStringList(translationSettingsProperty) );
         QTreeWidgetItem* debugSettings = new QTreeWidgetItem( this, QStringList(debugSettingsProperty) );
         QTreeWidgetItem* timingSettings = new QTreeWidgetItem( this, QStringList(timingSettingsProperty) );
         QTreeWidgetItem* discoveryConditionsSettings = new QTreeWidgetItem( this, QStringList(discoveryConditionsProperty) );

         // Translation Settings //

         propItem = addProperty(DtProperty((parseUnknownIDsProperty), types->boolType(),
            theDefaultParseUnknownIDs), translationSettings );
         propItem->setToolTip( 0, tr("Try to parse unknown string IDs into valid Entity IDs.") );

         propItem = addProperty(DtProperty((remapDisIDsProperty), types->boolType(), theDefaultRemapDisIDs), translationSettings );
         propItem->setToolTip( 0, tr("Causes broker to changes Entity Identifiers so that DIS PDUs are shown as sent from the broker itself") );

         propItem = addProperty(DtProperty((usePersistentEntityIDsProperty), types->boolType(),
            theDefaultUsePersistentEntityIDs), translationSettings );
         propItem->setToolTip( 0, tr("Persist Entity IDs even if the broker is re-started. Remap DIS IDs must also be enabled.") );

         propItem = addProperty(DtProperty((interactionWaitListTimeoutProperty), types->doubleType(),
            theDefaultInteractionWaitListTimeout), translationSettings );
         propItem->setToolTip( 0, tr("Each DIS object will be ticked every x number of seconds if no changes on the object have occured") );

         propItem = addProperty(DtProperty((sendExpiredWaitListInteractionsProperty), types->boolType(),
            theDefaultSendExpiredWaitListInteractions), translationSettings );
         propItem->setToolTip( 0, tr("Whether to send expired wait-listed interactions. If false, interactions will be dropped.") );

         propItem = addProperty(DtProperty((applicationNumberProperty), types->intType(), theDefaultAppNumber), translationSettings );
         propItem->setToolTip( 0, tr("DIS Application Number. Typically uniqe for each application at a site.") );

         propItem = addProperty(DtProperty((siteIDProperty), types->intType(), theDefaultSiteID), translationSettings );
         propItem->setToolTip( 0, tr("DIS Site Identifier. A unique number for a specifc lab, city, or other site. ") );

         propItem = addProperty(DtProperty((useAbsoluteTimeStampProperty), types->boolType(), theDefaultUseAbsoluteTimeStamp), translationSettings );
         propItem->setToolTip( 0, tr("Use absolute time stamping. Setting this to false will use relative time stamping.") );

         propItem = addProperty(DtProperty((locationThresholdProperty), types->doubleType(), theDefaultLocationThreshold), translationSettings );
         propItem->setToolTip( 0, tr("The threshold to use when checking location changes to determine whether to send an update or not (in meters).") );

         propItem = addProperty(DtProperty((rotationThresholdProperty), types->doubleType(), theDefaultRotationThreshold), translationSettings );
         propItem->setToolTip( 0, tr("The threshold to use when checking rotation changes to determine whether to send an update or not (in radians).") );

         propItem = addProperty(DtProperty((protocolVersionToSendProperty), types->intType(), theDefaultProtocolVersionToSend), translationSettings );
         propItem->setToolTip( 0, tr("Version of the DIS Protocol to send on outgoing PDUs. Possible values: 4-7") );

         propItem = addProperty(DtProperty((protocolVersionToRecvMinProperty), types->intType(), theDefaultProtocolVersionToRecvMin), translationSettings );
         propItem->setToolTip( 0, tr("Minimum Version of the DIS Protocol to accept on receive. Possible values: 4-7") );

         propItem = addProperty(DtProperty((protocolVersionToRecvMaxProperty), types->intType(), theDefaultProtocolVersionToRecvMax), translationSettings );
         propItem->setToolTip( 0, tr("Maximum Version of the DIS Protocol to accept on receive. Possible values: 4-7") );

         propItem = addProperty(DtProperty((disableArticulatedPartsProperty), types->boolType(), theDefaultDisableArticulatedParts), translationSettings );
         propItem->setToolTip( 0, tr("Disable translation of Articulated Parts. Enable this if you find circular dependencies but want to translate anyway.") );

         propItem = addProperty(DtProperty((splitUnderwaterAcousticPdusProperty), types->boolType(), theDefaultSplitUnderwaterAcousticPdus), translationSettings );
         propItem->setToolTip( 0, tr("Split PDUs of different UA object types into separate PDUs.") );

         propItem = addProperty(DtProperty((sendDiGuyPdusProperty), types->boolType(), theDefaultSendDiGuyPdus), translationSettings );
         propItem->setToolTip( 0, tr("Send DI-Guy PDUs containing additional entity information.") );

         propItem = addProperty(DtProperty((sendSeesPdusProperty), types->boolType(), theDefaultSendSeesPdus), translationSettings );
         propItem->setToolTip( 0, tr("Send SEES PDUs containing additional entity emissions information.") );

         propItem = addProperty(DtProperty((sendRelativeLocationPdusProperty), types->boolType(), theDefaultSendRelativeLocationPdus), translationSettings );
         propItem->setToolTip( 0, tr("Send Relative Location PDUs for embarked entities.") );

         // Debug Settings //

         propItem = addProperty(DtProperty((debugGlobalIdMappingProperty), types->boolType(), theDefaultDebugGlobalIdMapping), debugSettings);
         propItem->setToolTip( 0, tr("Print debugging information on how objects are named globaly in VR-Exchange") );

         propItem = addProperty(DtProperty((debugEntityIdMappingProperty), types->boolType(), theDefaultDebugEntityIdMapping), debugSettings);
         propItem->setToolTip( 0, tr("Print debugging information on the Entity Identifiers are mapped") );

         propItem = addProperty(DtProperty((debugEventIdMappingProperty), types->boolType(), theDefaultDebugEventIdMapping), debugSettings);
         propItem->setToolTip( 0, tr("Print debugging information on how Event Identifiers are mapped") );

         propItem = addProperty(DtProperty((dumpGuiToTextProperty), types->boolType(), theDefaultDumpGuiToText), debugSettings);
         propItem->setToolTip( 0, tr("Print a line to the log file for every object update, creation and destruction. Setting this field slows things down but makes it easier to figure out whats wrong if there is a problem") );

         // Timing Settings //

         propItem = addProperty(DtProperty((heartbeatIntervalProperty), types->doubleType(), theDefaultHeartbeatInterval), timingSettings);
         propItem->setToolTip( 0, tr("Each DIS object will be ticked every x number of seconds if no changes on the object have occured") );

         propItem = addProperty(DtProperty((timeoutIntervalProperty), types->doubleType(), theDefaultTimeoutInterval), timingSettings);
         propItem->setToolTip( 0, tr("DIS objects that have not been heard from in this many seconds will be considered removed. This is typically set to 2-3 times the heartbeat interval") );

         propItem = addProperty(DtProperty((drainTimeoutProperty), types->doubleType(), theDefaultDrainTimeout), timingSettings);
         propItem->setToolTip( 0, tr("The maximum amount of time to wait for PDUs every tick (in seconds)") );

         propItem = addProperty(DtProperty((numPdusReadPerTimeCheckProperty), types->intType(),
            theDefaultNumPdusReadPerTimeCheck), timingSettings);
         propItem->setToolTip( 0, tr("Maximum number of PDUs to read every tick") );

         // Discovery Settings //

         QTreeWidgetItem* aggregateSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Aggregate") );
         QTreeWidgetItem* designatorSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Designator") );
         QTreeWidgetItem* emitterSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Emitter System") );
         QTreeWidgetItem* entitySettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Entity State") );
         QTreeWidgetItem* envProcessSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Environment Process") );
         QTreeWidgetItem* griddedDataSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Gridded Data") );
         QTreeWidgetItem* iffSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("IFF") );
         QTreeWidgetItem* radioRecvSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Radio Receiver") );
         QTreeWidgetItem* radioTransSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Radio Transmitter") );
         QTreeWidgetItem* undwaAcousticsSettings = new QTreeWidgetItem( discoveryConditionsSettings, QStringList("Underwater Acoustics") );

         propItem = addProperty(DtProperty((discoveryAggregateEntityIdProperty), types->boolType(),
            theDefaultDiscoveryAggregateEntityId), aggregateSettings);
         propItem->setToolTip( 0, tr("Aggregates will not publish unless a valid entity ID is provided.") );

         propItem = addProperty(DtProperty((discoveryAggregateLocationProperty), types->boolType(),
            theDefaultDiscoveryAggregateLocation), aggregateSettings);
         propItem->setToolTip( 0, tr("Aggregates will not publish unless a valid Location is provided.") );

         propItem = addProperty(DtProperty((discoveryAggregateEntityTypeProperty), types->boolType(),
            theDefaultDiscoveryAggregateEntityType), aggregateSettings);
         propItem->setToolTip( 0, tr("Aggregates will not publish unless a valid Type is provided.") );


         propItem = addProperty(DtProperty((discoveryDesignatorEntityIdProperty), types->boolType(),
            theDefaultDiscoveryDesignatorEntityId), designatorSettings);
         propItem->setToolTip( 0, tr("Designators will not publish unless a valid entity ID is provided.") );

         propItem = addProperty(DtProperty((discoveryDesignatorHostIdProperty), types->boolType(),
            theDefaultDiscoveryDesignatorHostId), designatorSettings);
         propItem->setToolTip( 0, tr("Designators will not publish unless a valid host ID is provided.") );


         propItem = addProperty(DtProperty((discoveryEmitterSystemEntityIdProperty), types->boolType(),
            theDefaultDiscoveryEmitterSystemEntityId), emitterSettings);
         propItem->setToolTip( 0, tr("Emitter Systems will not publish unless a valid entity ID is provided.") );

         propItem = addProperty(DtProperty((discoveryEmitterSystemHostIdProperty), types->boolType(),
            theDefaultDiscoveryEmitterSystemHostId), emitterSettings);
         propItem->setToolTip( 0, tr("Emitter Systems will not publish unless a valid host ID is provided.") );


         propItem = addProperty(DtProperty((discoveryEntityLocationProperty), types->boolType(),
            theDefaultDiscoveryEntityLocation), entitySettings);
         propItem->setToolTip( 0, tr("Entities will not publish unless a valid Location is provided.") );

         propItem = addProperty(DtProperty((discoveryEntityEntityTypeProperty), types->boolType(),
            theDefaultDiscoveryEntityEntityType), entitySettings);
         propItem->setToolTip( 0, tr("Entities will not publish unless a valid Type is provided.") );


         propItem = addProperty(DtProperty((discoveryEnvironmentProcessIdProperty), types->boolType(),
            theDefaultDiscoveryEnvironmentProcessId), envProcessSettings);
         propItem->setToolTip( 0, tr("Environment Processes will not publish unless a valid process ID is provided.") );


         propItem = addProperty(DtProperty((discoveryGriddedDataGridIdProperty), types->boolType(),
            theDefaultDiscoveryGriddedDataGridId), griddedDataSettings);
         propItem->setToolTip( 0, tr("Gridded Data will not publish unless a valid grid ID is provided.") );


         propItem = addProperty(DtProperty((discoveryIFFEntityIdProperty), types->boolType(),
            theDefaultDiscoveryIFFEntityId), iffSettings);
         propItem->setToolTip( 0, tr("IFF will not publish unless a valid entity ID is provided.") );

         propItem = addProperty(DtProperty((discoveryIFFHostIdProperty), types->boolType(),
            theDefaultDiscoveryIFFHostId), iffSettings);
         propItem->setToolTip( 0, tr("IFF will not publish unless a valid host ID is provided.") );


         propItem = addProperty(DtProperty((discoveryRadioRecvEntityIdProperty), types->boolType(),
            theDefaultDiscoveryRadioRecvEntityId), radioRecvSettings);
         propItem->setToolTip( 0, tr("Radio Receivers will not publish unless a valid entity ID is provided.") );

         propItem = addProperty(DtProperty((discoveryRadioRecvHostIdProperty), types->boolType(),
            theDefaultDiscoveryRadioRecvHostId), radioRecvSettings);
         propItem->setToolTip( 0, tr("Radio Receivers will not publish unless a valid host ID is provided.") );


         propItem = addProperty(DtProperty((discoveryRadioTransEntityIdProperty), types->boolType(),
            theDefaultDiscoveryRadioTransEntityId), radioTransSettings);
         propItem->setToolTip( 0, tr("Radio Transmitters will not publish unless a valid entity ID is provided.") );

         propItem = addProperty(DtProperty((discoveryRadioTransHostIdProperty), types->boolType(),
            theDefaultDiscoveryRadioTransHostId), radioTransSettings);
         propItem->setToolTip( 0, tr("Radio Transmitters will not publish unless a valid host ID is provided.") );


         propItem = addProperty(DtProperty((discoveryUndwaAcousticsAcousticIdProperty), types->boolType(),
            theDefaultDiscoveryUndwaAcousticsAcousticId), undwaAcousticsSettings);
         propItem->setToolTip( 0, tr("Underwater Acoustics will not publish unless a valid Acoustic ID is provided.") );

         propItem = addProperty(DtProperty((discoveryUndwaAcousticsEntityIdProperty), types->boolType(),
            theDefaultDiscoveryUndwaAcousticsEntityId), undwaAcousticsSettings);
         propItem->setToolTip( 0, tr("Underwater Acoustics will not publish unless a valid Entity ID is provided.") );

         propItem = addProperty(DtProperty((discoveryUndwaAcousticsHostIdProperty), types->boolType(),
            theDefaultDiscoveryUndwaAcousticsHostId), undwaAcousticsSettings);
         propItem->setToolTip( 0, tr("Underwater Acoustics will not publish unless a valid Host ID is provided.") );

         delete types;
      }

      void DtDisGeneralSettingsWidget::updateConfiguration()
      {
         // Common Broker Settings.
         DtGeneralSettingsWidget::updateConfiguration();

         // Translation Settings.
         disInitializer()->setParseUnknownIds( parseUnknownIDs() );
         disInitializer()->setRemapDisIds( remapDisIDs() );
         disInitializer()->setUsePersistentEntityIds( usePersistentEntityIds() );
         disInitializer()->setInteractionWaitListTimeout( interactionWaitListTimeout() );
         disInitializer()->setSendExpiredWaitListInteractions( sendExpiredWaitListInteractions() );
         disInitializer()->setApplicationNumber( appNum() );
         disInitializer()->setSiteId( siteID() );
         disInitializer()->setUseAbsoluteTimeStamping( useAbsoluteTimeStamp() );
         disInitializer()->setLocationThreshold( locationThreshold() );
         disInitializer()->setRotationThreshold( rotationThreshold() );
         disInitializer()->setProtocolVersionToSend( protocolVersionToSend() );
         disInitializer()->setProtocolVersionToRecvMax( protocolVersionToRecvMax() );
         disInitializer()->setProtocolVersionToRecvMin( protocolVersionToRecvMin() );
         disInitializer()->setDisableArticulatedParts( disableArticulatedParts() );
         disInitializer()->setSplitUnderwaterAcousticPdus( splitUnderwaterAcousticPdus() );
         disInitializer()->setSendDiGuyPdus( sendDiGuyPdus() );
         disInitializer()->setSendSeesPdus( sendSeesPdus() );
         disInitializer()->setSendRelativeLocationPdus( sendRelativeLocationPdus() );

         // Debug Settings.
         disInitializer()->setDebugGlobalIdMapping( debugGlobalIdMapping() );
         disInitializer()->setDebugEntityIdMapping( debugEntityIdMapping() );
         disInitializer()->setDebugEventIdMapping( debugEventIdMapping() );
         disInitializer()->setDumpGuiToText( dumpGuiToText() );

         // Timing Settings.
         disInitializer()->setHeartbeatInterval( heartbeatInterval() );
         disInitializer()->setTimeoutInterval( timeoutInterval() );
         disInitializer()->setDrainTimeout( drainTimeout() );
         disInitializer()->setNumPdusReadPerTimeCheck( numPdusReadPerTimeCheck() );

         // Discovery Settings.
         disInitializer()->discoveryCriteria()->setAggregateNeedsEntityId( discoveryAggregateEntityId() );
         disInitializer()->discoveryCriteria()->setAggregateNeedsLocation( discoveryAggregateLocation() );
         disInitializer()->discoveryCriteria()->setAggregateNeedsEntityType( discoveryAggregateEntityType() );
         disInitializer()->discoveryCriteria()->setDesignatorNeedsEntityId( discoveryDesignatorEntityId() );
         disInitializer()->discoveryCriteria()->setDesignatorNeedsHostId( discoveryDesignatorHostId() );
         disInitializer()->discoveryCriteria()->setEmitterSystemNeedsEntityId( discoveryEmitterSystemEntityId() );
         disInitializer()->discoveryCriteria()->setEmitterSystemNeedsHostId( discoveryEmitterSystemHostId() );
         disInitializer()->discoveryCriteria()->setEntityNeedsLocation( discoveryEntityLocation() );
         disInitializer()->discoveryCriteria()->setEntityNeedsEntityType( discoveryEntityEntityType() );
         disInitializer()->discoveryCriteria()->setEnvironmentProcessNeedsProcessId( discoveryEnvironmentProcessId() );
         disInitializer()->discoveryCriteria()->setGriddedDataNeedsGridId( discoveryGriddedDataGridId() );
         disInitializer()->discoveryCriteria()->setIffNeedsEntityId( discoveryIFFEntityId() );
         disInitializer()->discoveryCriteria()->setIffNeedsHostId( discoveryIFFHostId() );
         disInitializer()->discoveryCriteria()->setRadioReceiverNeedsEntityId( discoveryRadioRecvEntityId() );
         disInitializer()->discoveryCriteria()->setRadioReceiverNeedsHostId( discoveryRadioRecvHostId() );
         disInitializer()->discoveryCriteria()->setRadioTransmitterNeedsEntityId( discoveryRadioTransEntityId() );
         disInitializer()->discoveryCriteria()->setRadioTransmitterNeedsHostId( discoveryRadioTransHostId() );
         disInitializer()->discoveryCriteria()->setUnderwaterAcousticsNeedsAcousticId( discoveryUndwaAcousticsAcousticId() );
         disInitializer()->discoveryCriteria()->setUnderwaterAcousticsNeedsEntityId( discoveryUndwaAcousticsEntityId() );
         disInitializer()->discoveryCriteria()->setUnderwaterAcousticsNeedsHostId( discoveryUndwaAcousticsHostId() );
      }

      void DtDisGeneralSettingsWidget::revertConfiguration()
      {
         // Common Broker Settings.
         DtGeneralSettingsWidget::revertConfiguration();

         // Translation Settings.
         setParseUnknownIDs( disInitializer()->parseUnknownIds() );
         setRemapDisIDs( disInitializer()->remapDisIds() );
         setUsePersistentEntityIds( disInitializer()->usePersistentEntityIds() );
         setInteractionWaitListTimeout( disInitializer()->interactionWaitListTimeout() );
         setSendExpiredWaitListInteractions( disInitializer()->sendExpiredWaitListInteractions() );
         setAppNum( disInitializer()->applicationNumber() );
         setSiteID( disInitializer()->siteId() );
         setUseAbsoluteTimeStamp( disInitializer()->useAbsoluteTimeStamping() );
         setLocationThreshold( disInitializer()->locationThreshold() );
         setRotationThreshold( disInitializer()->rotationThreshold() );
         setProtocolVersionToSend( disInitializer()->protocolVersionToSend() );
         setProtocolVersionToRecvMin( disInitializer()->protocolVersionToRecvMin() );
         setProtocolVersionToRecvMax( disInitializer()->protocolVersionToRecvMax() );
         setDisableArticulatedParts( disInitializer()->disableArticulatedParts() );
         setSplitUnderwaterAcousticPdus( disInitializer()->splitUnderwaterAcousticPdus() );
         setSendDiGuyPdus( disInitializer()->sendDiGuyPdus() );
         setSendSeesPdus( disInitializer()->sendSeesPdus() );
         setSendRelativeLocationPdus( disInitializer()->sendRelativeLocationPdus() );

         // Debug Settings.
         setDebugGlobalIdMapping( disInitializer()->debugGlobalIdMapping() );
         setDebugEntityIdMapping( disInitializer()->debugEntityIdMapping() );
         setDebugEventIdMapping( disInitializer()->debugEventIdMapping() );
         setDumpGuiToText( disInitializer()->dumpGuiToText() );

         // Timing Settings.
         setHeartbeatInterval( disInitializer()->heartbeatInterval() );
         setTimeoutInterval( disInitializer()->timeoutInterval() );
         setDrainTimeout( disInitializer()->drainTimeout() );
         setNumPdusReadPerTimeCheck( disInitializer()->numPdusReadPerTimeCheck() );

         // Discovery Settings.
         setDiscoveryAggregateEntityId( disInitializer()->discoveryCriteria()->aggregateNeedsEntityId() );
         setDiscoveryAggregateLocation( disInitializer()->discoveryCriteria()->aggregateNeedsLocation() );
         setDiscoveryAggregateEntityType( disInitializer()->discoveryCriteria()->aggregateNeedsEntityType() );
         setDiscoveryDesignatorEntityId( disInitializer()->discoveryCriteria()->designatorNeedsEntityId() );
         setDiscoveryDesignatorHostId( disInitializer()->discoveryCriteria()->designatorNeedsHostId() );
         setDiscoveryEmitterSystemEntityId( disInitializer()->discoveryCriteria()->emitterSystemNeedsEntityId() );
         setDiscoveryEmitterSystemHostId( disInitializer()->discoveryCriteria()->emitterSystemNeedsHostId() );
         setDiscoveryEntityLocation( disInitializer()->discoveryCriteria()->entityNeedsLocation() );
         setDiscoveryEntityEntityType( disInitializer()->discoveryCriteria()->entityNeedsEntityType() );
         setDiscoveryEnvironmentProcessId( disInitializer()->discoveryCriteria()->environmentProcessNeedsProcessId() );
         setDiscoveryGriddedDataGridId( disInitializer()->discoveryCriteria()->griddedDataNeedsGridId() );
         setDiscoveryIFFEntityId( disInitializer()->discoveryCriteria()->iffNeedsEntityId() );
         setDiscoveryIFFHostId( disInitializer()->discoveryCriteria()->iffNeedsHostId() );
         setDiscoveryRadioRecvEntityId( disInitializer()->discoveryCriteria()->radioReceiverNeedsEntityId() );
         setDiscoveryRadioRecvHostId( disInitializer()->discoveryCriteria()->radioReceiverNeedsHostId() );
         setDiscoveryRadioTransEntityId( disInitializer()->discoveryCriteria()->radioTransmitterNeedsEntityId() );
         setDiscoveryRadioTransHostId( disInitializer()->discoveryCriteria()->radioTransmitterNeedsHostId() );
         setDiscoveryUndwaAcousticsAcousticId( disInitializer()->discoveryCriteria()->underwaterAcousticsNeedsAcousticId() );
         setDiscoveryUndwaAcousticsEntityId( disInitializer()->discoveryCriteria()->underwaterAcousticsNeedsEntityId() );
         setDiscoveryUndwaAcousticsHostId( disInitializer()->discoveryCriteria()->underwaterAcousticsNeedsHostId() );
      }


      //
      // Translation Settings Setters/Getters.
      //

      void DtDisGeneralSettingsWidget::setParseUnknownIDs( bool val )
      {
         setProperty( translationSettingsProperty, parseUnknownIDsProperty, val );
      }

      bool DtDisGeneralSettingsWidget::parseUnknownIDs() const
      {
         const DtProperty* aProperty = property( translationSettingsProperty, parseUnknownIDsProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setRemapDisIDs( bool val )
      {
         setProperty( translationSettingsProperty, remapDisIDsProperty, val );
      }

      bool DtDisGeneralSettingsWidget::remapDisIDs() const
      {
         const DtProperty* aProperty = property( translationSettingsProperty, remapDisIDsProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setUsePersistentEntityIds( bool val )
      {
         setProperty( translationSettingsProperty, usePersistentEntityIDsProperty, val );
      }

      bool DtDisGeneralSettingsWidget::usePersistentEntityIds() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, usePersistentEntityIDsProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setInteractionWaitListTimeout( DtTime val )
      {
         setProperty( translationSettingsProperty, interactionWaitListTimeoutProperty, val );
      }

      DtTime DtDisGeneralSettingsWidget::interactionWaitListTimeout() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, interactionWaitListTimeoutProperty );
         if ( aProperty->value().type() == QVariant::Double )
         {
            return aProperty->value().toDouble();
         }
         return 0.0;
      }

      void DtDisGeneralSettingsWidget::setSendExpiredWaitListInteractions( bool val )
      {
         setProperty( translationSettingsProperty, sendExpiredWaitListInteractionsProperty, val );
      }

      bool DtDisGeneralSettingsWidget::sendExpiredWaitListInteractions() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, sendExpiredWaitListInteractionsProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setAppNum( int id )
      {
         setProperty( translationSettingsProperty, applicationNumberProperty, id );
      }

      int DtDisGeneralSettingsWidget::appNum() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, applicationNumberProperty );
         if ( aProperty->value().type() == QVariant::Int )
         {
            return aProperty->value().toInt();
         }
         return 0;
      }

      void DtDisGeneralSettingsWidget::setSiteID( int id )
      {
         setProperty( translationSettingsProperty, siteIDProperty, id );
      }

      int DtDisGeneralSettingsWidget::siteID() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, siteIDProperty );
         if ( aProperty->value().type() == QVariant::Int )
         {
            return aProperty->value().toInt();
         }
         return 0;
      }

      void DtDisGeneralSettingsWidget::setUseAbsoluteTimeStamp( bool val )
      {
         setProperty( translationSettingsProperty, useAbsoluteTimeStampProperty, val );
      }

      bool DtDisGeneralSettingsWidget::useAbsoluteTimeStamp() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, useAbsoluteTimeStampProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setLocationThreshold( double val )
      {
         setProperty( translationSettingsProperty, locationThresholdProperty, val );
      }

      double DtDisGeneralSettingsWidget::locationThreshold() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, locationThresholdProperty );
         if ( aProperty->value().type() == QVariant::Double )
         {
            return aProperty->value().toDouble();
         }
         return 0.0;
      }

      void DtDisGeneralSettingsWidget::setRotationThreshold( double val )
      {
         setProperty( translationSettingsProperty, rotationThresholdProperty, val );
      }

      double DtDisGeneralSettingsWidget::rotationThreshold() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, rotationThresholdProperty );
         if ( aProperty->value().type() == QVariant::Double )
         {
            return aProperty->value().toDouble();
         }
         return 0.0;
      }

      void DtDisGeneralSettingsWidget::setProtocolVersionToSend( int val )
      {
         setProperty( translationSettingsProperty, protocolVersionToSendProperty, val );
      }

      int DtDisGeneralSettingsWidget::protocolVersionToSend() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, protocolVersionToSendProperty );
         if ( aProperty->value().type() == QVariant::Int )
         {
            return aProperty->value().toInt();
         }
         return 0;
      }

      void DtDisGeneralSettingsWidget::setProtocolVersionToRecvMin( int val )
      {
         setProperty( translationSettingsProperty, protocolVersionToRecvMinProperty, val );
      }

      int DtDisGeneralSettingsWidget::protocolVersionToRecvMin() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, protocolVersionToRecvMinProperty );
         if ( aProperty->value().type() == QVariant::Int )
         {
            return aProperty->value().toInt();
         }
         return 0;
      }

      void DtDisGeneralSettingsWidget::setProtocolVersionToRecvMax( int val )
      {
         setProperty( translationSettingsProperty, protocolVersionToRecvMaxProperty, val );
      }

      int DtDisGeneralSettingsWidget::protocolVersionToRecvMax() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, protocolVersionToRecvMaxProperty );
         if ( aProperty->value().type() == QVariant::Int )
         {
            return aProperty->value().toInt();
         }
         return 0;
      }

      void DtDisGeneralSettingsWidget::setDisableArticulatedParts( bool val )
      {
         setProperty( translationSettingsProperty, disableArticulatedPartsProperty, val );
      }

      bool DtDisGeneralSettingsWidget::disableArticulatedParts() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, disableArticulatedPartsProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setSplitUnderwaterAcousticPdus( bool val )
      {
         setProperty( translationSettingsProperty, splitUnderwaterAcousticPdusProperty, val );
      }

      bool DtDisGeneralSettingsWidget::splitUnderwaterAcousticPdus() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, splitUnderwaterAcousticPdusProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setSendDiGuyPdus( bool val )
      {
         setProperty( translationSettingsProperty, sendDiGuyPdusProperty, val );
      }

      bool DtDisGeneralSettingsWidget::sendDiGuyPdus() const
      {
         const DtProperty* aProperty =
            property( translationSettingsProperty, sendDiGuyPdusProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setSendSeesPdus( bool val )
      {
         setProperty( translationSettingsProperty, sendSeesPdusProperty, val );
      }

      bool DtDisGeneralSettingsWidget::sendSeesPdus() const
      {
         const DtProperty* aProperty = property( translationSettingsProperty, sendSeesPdusProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setSendRelativeLocationPdus( bool val )
      {
         setProperty( translationSettingsProperty, sendRelativeLocationPdusProperty, val );
      }

      bool DtDisGeneralSettingsWidget::sendRelativeLocationPdus() const
      {
         const DtProperty* aProperty = property( translationSettingsProperty, sendRelativeLocationPdusProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      //
      // Debug Settings Setters/Getters.
      //

      void DtDisGeneralSettingsWidget::setDebugGlobalIdMapping( bool val )
      {
         setProperty( debugSettingsProperty, debugGlobalIdMappingProperty, val );
      }

      bool DtDisGeneralSettingsWidget::debugGlobalIdMapping() const
      {
         const DtProperty* aProperty =
            property( debugSettingsProperty, debugGlobalIdMappingProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDebugEntityIdMapping( bool val )
      {
         setProperty( debugSettingsProperty, debugEntityIdMappingProperty,val );
      }

      bool DtDisGeneralSettingsWidget::debugEntityIdMapping() const
      {
         const DtProperty* aProperty =
            property( debugSettingsProperty, debugEntityIdMappingProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDebugEventIdMapping( bool val )
      {
         setProperty( debugSettingsProperty, debugEventIdMappingProperty, val );
      }

      bool DtDisGeneralSettingsWidget::debugEventIdMapping() const
      {
         const DtProperty* aProperty =
            property( debugSettingsProperty, debugEventIdMappingProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDumpGuiToText( bool val )
      {
         setProperty( debugSettingsProperty, dumpGuiToTextProperty, val );
      }

      bool DtDisGeneralSettingsWidget::dumpGuiToText() const
      {
         const DtProperty* aProperty =
            property( debugSettingsProperty, dumpGuiToTextProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }


      //
      // Timing Settings Setters/Getters.
      //

      void DtDisGeneralSettingsWidget::setHeartbeatInterval( DtTime time )
      {
         setProperty( timingSettingsProperty, heartbeatIntervalProperty, time );
      }

      DtTime DtDisGeneralSettingsWidget::heartbeatInterval() const
      {
         const DtProperty* aProperty =
            property( timingSettingsProperty, heartbeatIntervalProperty );
         if ( aProperty->value().type() == QVariant::Double )
         {
            return aProperty->value().toDouble();
         }
         return 0.0;
      }

      void DtDisGeneralSettingsWidget::setTimeoutInterval( DtTime time )
      {
         setProperty( timingSettingsProperty, timeoutIntervalProperty, time );
      }

      DtTime DtDisGeneralSettingsWidget::timeoutInterval() const
      {
         const DtProperty* aProperty =
            property( timingSettingsProperty, timeoutIntervalProperty );
         if ( aProperty->value().type() == QVariant::Double )
         {
            return aProperty->value().toDouble();
         }
         return 0.0;
      }

      void DtDisGeneralSettingsWidget::setDrainTimeout( DtTime val )
      {
         setProperty( timingSettingsProperty, drainTimeoutProperty, val );
      }

      DtTime DtDisGeneralSettingsWidget::drainTimeout() const
      {
         const DtProperty* aProperty =
            property( timingSettingsProperty, drainTimeoutProperty );
         if ( aProperty->value().type() == QVariant::Double )
         {
            return aProperty->value().toDouble();
         }
         return 0.0;
      }

      void DtDisGeneralSettingsWidget::setNumPdusReadPerTimeCheck( int val )
      {
         setProperty( timingSettingsProperty, numPdusReadPerTimeCheckProperty, val );
      }

      int DtDisGeneralSettingsWidget::numPdusReadPerTimeCheck() const
      {
         const DtProperty* aProperty =
            property( timingSettingsProperty, numPdusReadPerTimeCheckProperty );
         if ( aProperty->value().type() == QVariant::Int )
         {
            return aProperty->value().toInt();
         }
         return 0;
      }


      //
      // Publication Condition Settings Setters/Getters.
      //

      void DtDisGeneralSettingsWidget::setDiscoveryAggregateEntityId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Aggregate",
            discoveryAggregateEntityIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryAggregateEntityId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Aggregate", discoveryAggregateEntityIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryAggregateLocation( bool val )
      {
         setProperty( discoveryConditionsProperty, "Aggregate",
            discoveryAggregateLocationProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryAggregateLocation() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Aggregate", discoveryAggregateLocationProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryAggregateEntityType( bool val )
      {
         setProperty( discoveryConditionsProperty, "Aggregate",
            discoveryAggregateEntityTypeProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryAggregateEntityType() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Aggregate", discoveryAggregateEntityTypeProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryDesignatorEntityId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Designator",
            discoveryDesignatorEntityIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryDesignatorEntityId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Designator", discoveryDesignatorEntityIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryDesignatorHostId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Designator",
            discoveryDesignatorHostIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryDesignatorHostId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Designator", discoveryDesignatorHostIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryEmitterSystemEntityId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Emitter System",
            discoveryEmitterSystemEntityIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryEmitterSystemEntityId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Emitter System", discoveryEmitterSystemEntityIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryEmitterSystemHostId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Emitter System",
            discoveryEmitterSystemHostIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryEmitterSystemHostId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Emitter System", discoveryEmitterSystemHostIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryEntityLocation( bool val )
      {
         setProperty( discoveryConditionsProperty, "Entity State",
            discoveryEntityLocationProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryEntityLocation() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Entity State", discoveryEntityLocationProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryEntityEntityType( bool val )
      {
         setProperty( discoveryConditionsProperty, "Entity State",
            discoveryEntityEntityTypeProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryEntityEntityType() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Entity State", discoveryEntityEntityTypeProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryEnvironmentProcessId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Environment Process",
            discoveryEnvironmentProcessIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryEnvironmentProcessId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Environment Process", discoveryEnvironmentProcessIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryGriddedDataGridId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Gridded Data",
            discoveryGriddedDataGridIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryGriddedDataGridId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Gridded Data", discoveryGriddedDataGridIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryIFFEntityId( bool val )
      {
         setProperty( discoveryConditionsProperty, "IFF",
            discoveryIFFEntityIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryIFFEntityId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "IFF", discoveryIFFEntityIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryIFFHostId( bool val )
      {
         setProperty( discoveryConditionsProperty, "IFF",
            discoveryIFFHostIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryIFFHostId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "IFF", discoveryIFFHostIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryRadioRecvEntityId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Radio Receiver",
            discoveryRadioRecvEntityIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryRadioRecvEntityId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Radio Receiver", discoveryRadioRecvEntityIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryRadioRecvHostId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Radio Receiver",
            discoveryRadioRecvHostIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryRadioRecvHostId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Radio Receiver", discoveryRadioRecvHostIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryRadioTransEntityId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Radio Transmitter",
            discoveryRadioTransEntityIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryRadioTransEntityId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Radio Transmitter", discoveryRadioTransEntityIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryRadioTransHostId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Radio Transmitter",
            discoveryRadioTransHostIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryRadioTransHostId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Radio Transmitter", discoveryRadioTransHostIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryUndwaAcousticsAcousticId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Underwater Acoustics",
            discoveryUndwaAcousticsAcousticIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryUndwaAcousticsAcousticId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Underwater Acoustics", discoveryUndwaAcousticsAcousticIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryUndwaAcousticsEntityId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Underwater Acoustics",
            discoveryUndwaAcousticsEntityIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryUndwaAcousticsEntityId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Underwater Acoustics", discoveryUndwaAcousticsEntityIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

      void DtDisGeneralSettingsWidget::setDiscoveryUndwaAcousticsHostId( bool val )
      {
         setProperty( discoveryConditionsProperty, "Underwater Acoustics",
            discoveryUndwaAcousticsHostIdProperty, val );
      }

      bool DtDisGeneralSettingsWidget::discoveryUndwaAcousticsHostId() const
      {
         const DtProperty* aProperty = property( discoveryConditionsProperty,
            "Underwater Acoustics", discoveryUndwaAcousticsHostIdProperty );
         if ( aProperty->value().type() == QVariant::Bool )
         {
            return aProperty->value().toBool();
         }
         return false;
      }

   }
}
