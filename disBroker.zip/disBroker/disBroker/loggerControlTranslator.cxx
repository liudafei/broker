/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file loggerControlTranslator.cxx
//! \brief Contains the logger control toolkit translator class definition.
//! \ingroup disBroker

#include <disBroker/loggerControlTranslator.h>
#include <disBroker/eventIdMapper.h>
#include <disBroker/disBroker.h>

// Logger Control Toolkit Includes
#include <loggerControlToolkit/lcPdu.h>
#include <loggerControlToolkit/lcConnect.h>
#include <loggerControlToolkit/lcDelFile.h>
#include <loggerControlToolkit/lcEmpty.h>
#include <loggerControlToolkit/lcEnd.h>
#include <loggerControlToolkit/lcEofAction.h>
#include <loggerControlToolkit/lcHeartbeat.h>
#include <loggerControlToolkit/lcPause.h>
#include <loggerControlToolkit/lcPlayAction.h>
#include <loggerControlToolkit/lcPlayFile.h>
#include <loggerControlToolkit/lcPlay.h>
#include <loggerControlToolkit/lcQuit.h>
#include <loggerControlToolkit/lcRecAction.h>
#include <loggerControlToolkit/lcRecFile.h>
#include <loggerControlToolkit/lcRecord.h>
#include <loggerControlToolkit/lcSetTime.h>
#include <loggerControlToolkit/lcSkipTime.h>
#include <loggerControlToolkit/lcStart.h>
#include <loggerControlToolkit/lcStateFlag.h>
#include <loggerControlToolkit/lcStop.h>
#include <loggerControlToolkit/lcTimeout.h>
#include <loggerControlToolkit/lcTimeScale.h>
#include <loggerControlToolkit/lcTotalState.h>

// Portal Includes
#include <portal/pLoggerControlInteraction.h>
#include <portal/pLoggerConnectInteraction.h>
#include <portal/pLoggerDeleteFileInteraction.h>
#include <portal/pLoggerEmptyInteraction.h>
#include <portal/pLoggerStopInteraction.h>
#include <portal/pLoggerEndInteraction.h>
#include <portal/pLoggerEndOfActionInteraction.h>
#include <portal/pLoggerHeartbeatInteraction.h>
#include <portal/pLoggerPauseInteraction.h>
#include <portal/pLoggerPlayActionInteraction.h>
#include <portal/pLoggerPlayFileInteraction.h>
#include <portal/pLoggerPlayInteraction.h>
#include <portal/pLoggerQuitInteraction.h>
#include <portal/pLoggerRecordActionInteraction.h>
#include <portal/pLoggerRecordFileInteraction.h>
#include <portal/pLoggerRecordInteraction.h>
#include <portal/pLoggerSetTimeInteraction.h>
#include <portal/pLoggerSkipTimeInteraction.h>
#include <portal/pLoggerStartInteraction.h>
#include <portal/pLoggerStateFlagInteraction.h>
#include <portal/pLoggerTimeoutInteraction.h>
#include <portal/pLoggerTimeScaleInteraction.h>
#include <portal/pLoggerTotalStateInteraction.h>

#include <portal/pConnection.h>

#include <vl/exerciseConn.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtLoggerControlTranslator::DtLoggerControlTranslator( DtBroker* broker )
         : DtInteractionTranslator( broker, translatorName(), DtPortalLoggerControlInteraction::theKind )
      {
      }

      DtLoggerControlTranslator::~DtLoggerControlTranslator()
      {
      }

      DtDisBroker* DtLoggerControlTranslator::disBroker()
      {
         return (DtDisBroker*) myBroker;
      }

      const DtDisBroker* DtLoggerControlTranslator::disBroker() const
      {
         return (DtDisBroker*) myBroker;
      }

      void DtLoggerControlTranslator::enableReflectTranslator( bool enabled )
      {
         if ( myReflectEnabled != enabled )
         {
            if ( enabled )
            {
               initializeDisCallbacks();
            }
            else
            {
               removeDisCallbacks();
            }
            myReflectEnabled = enabled;
         }
      }

      void DtLoggerControlTranslator::enablePublishTranslator( bool enabled )
      {
         if ( myPublishEnabled != enabled )
         {
            if ( enabled )
            {
               initializePortalCallbacks();
            }
            else
            {
               removePortalCallbacks();
            }
            myPublishEnabled = enabled;
         }
      }

      void DtLoggerControlTranslator::initializeDisCallbacks()
      {
         DtLgrControlInteraction::addCallback(
            disBroker()->connection(), receiveDisInteraction, this );
      }

      void DtLoggerControlTranslator::removeDisCallbacks()
      {
         DtLgrControlInteraction::removeCallback(
            disBroker()->connection(), receiveDisInteraction, this );
      }

      void DtLoggerControlTranslator::initializePortalCallbacks()
      {
         DtPortalLoggerConnectInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerEmptyInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerStopInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerEndInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerEndOfActionInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerHeartbeatInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerPauseInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerPlayActionInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerPlayFileInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerPlayInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerQuitInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerRecordActionInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerRecordFileInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerRecordInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerSetTimeInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerSkipTimeInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerStartInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerStateFlagInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerTimeoutInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerTimeScaleInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
         DtPortalLoggerTotalStateInteraction::addCallback(
            myBroker->portalConnection(), receivePortalInteraction, this );
      }

      void DtLoggerControlTranslator::removePortalCallbacks()
      {
         if ( this->myPublishEnabled )
         {
            DtPortalLoggerConnectInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this);
            DtPortalLoggerDeleteFileInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerEmptyInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerStopInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerEndInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerEndOfActionInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerHeartbeatInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerPauseInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerPlayActionInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerPlayFileInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerPlayInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerQuitInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerRecordActionInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerRecordFileInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerRecordInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerSetTimeInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerSkipTimeInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerStartInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerStateFlagInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerTimeoutInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerTimeScaleInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
            DtPortalLoggerTotalStateInteraction::removeCallback(
               myBroker->portalConnection(), receivePortalInteraction, this );
         }
      }

      void DtLoggerControlTranslator::shutdown()
      {
         removePortalCallbacks();
         removeDisCallbacks();
      }

      void DtLoggerControlTranslator::printIncomingOutgoingInteractions(
         const DtPortalInteraction& incoming, const DtInteraction& outgoing ) const
      {
         DtInfo << "======== ORIG (Portal) - " << name() << " ========" << std::endl;
         DtInfo << incoming;
         DtInfo << "======== NEW (DIS) - " << name() << " ========" << std::endl;
         outgoing.printData();
         DtInfo << "------------------------------------------------" << std::endl;
      }

      void DtLoggerControlTranslator::printIncomingOutgoingInteractions(
         const DtInteraction& incoming, const DtPortalInteraction& outgoing ) const
      {
         DtInfo << "======== ORIG (DIS) - " << name() << " ========" << std::endl;
         incoming.printData();
         DtInfo << "======== NEW (Portal) - " << name() << " ========" << std::endl;
         DtInfo << outgoing;
         DtInfo << "------------------------------------------------" << std::endl;
      }

      void DtLoggerControlTranslator::receiveDisInteraction(
         DtLgrControlInteraction* loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createPortalInteraction( *loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerConnectInteraction& loggerControl, void* usr)
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*)usr;
         trans->createInteraction(loggerControl);
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerDeleteFileInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerEmptyInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerStopInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerEndInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerEndOfActionInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerHeartbeatInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerPauseInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerPlayActionInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerPlayFileInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerPlayInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerQuitInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerRecordActionInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerRecordFileInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerRecordInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerSetTimeInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerSkipTimeInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerStartInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerStateFlagInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerTimeoutInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerTimeScaleInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }

      void DtLoggerControlTranslator::receivePortalInteraction(
         const DtPortalLoggerTotalStateInteraction& loggerControl, void* usr )
      {
         DtLoggerControlTranslator* trans =
            (DtLoggerControlTranslator*) usr;
         trans->createInteraction( loggerControl );
      }


      void DtLoggerControlTranslator::createPortalInteraction(
         const DtLgrControlInteraction& incoming )
      {
         try
         {
            DtString debugString;
            DtPortalLoggerControlInteraction* out = 0;
            switch ( incoming.lgrCommand() )
            {
            case DtLgrConnect:
            {
               out = new DtPortalLoggerConnectInteraction;
               DtPortalLoggerConnectInteraction* actualPduType =
                  dynamic_cast<DtPortalLoggerConnectInteraction*>(out);
               translate(actualPduType, incoming);
               debugString = "Logger Connect Interaction";
               break;
            }
            case DtLgrDelFile:
               {
                  out = new DtPortalLoggerDeleteFileInteraction;
                  DtPortalLoggerDeleteFileInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerDeleteFileInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Delete File Interaction";
                  break;
               }
            case DtLgrEmpty:
               {
                  out = new DtPortalLoggerEmptyInteraction;
                  DtPortalLoggerEmptyInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerEmptyInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Empty Interaction";
                  break;
               }
            case DtLgrPbFile:
               {
                  out = new DtPortalLoggerPlayFileInteraction;
                  DtPortalLoggerPlayFileInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerPlayFileInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Play File Interaction";
                  break;
               }
            case DtLgrRecFile:
               {
                  out = new DtPortalLoggerRecordFileInteraction;
                  DtPortalLoggerRecordFileInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerRecordFileInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger RecordFile Interaction";
                  break;
               }
            case DtLgrQuit:
               {
                  out = new DtPortalLoggerQuitInteraction;
                  DtPortalLoggerQuitInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerQuitInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Quit Interaction";
                  break;
               }
            case DtLgrStart:
               {
                  out = new DtPortalLoggerStartInteraction;
                  DtPortalLoggerStartInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerStartInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Start Interaction";
                  break;
               }
            case DtLgrEnd:
               {
                  out = new DtPortalLoggerEndInteraction;
                  DtPortalLoggerEndInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerEndInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger End Interaction";
                  break;
               }
            case DtLgrPlay:
               {
                  out = new DtPortalLoggerPlayInteraction;
                  DtPortalLoggerPlayInteraction* actualPduType  =
                     dynamic_cast<DtPortalLoggerPlayInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Play Interaction";
                  break;
               }
            case DtLgrPause:
               {
                  out = new DtPortalLoggerPauseInteraction;
                  DtPortalLoggerPauseInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerPauseInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Pause Interaction";
                  break;
               }
            case DtLgrStop:
               {
                  out = new DtPortalLoggerStopInteraction;
                  DtPortalLoggerStopInteraction* actualPduType  =
                     dynamic_cast<DtPortalLoggerStopInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Stop Interaction";
                  break;
               }
            case DtLgrRecord:
               {
                  out = new DtPortalLoggerRecordInteraction;
                  DtPortalLoggerRecordInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerRecordInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Record Interaction";
                  break;
               }
            case DtLgrSetTime:
               {
                  out = new DtPortalLoggerSetTimeInteraction;
                  DtPortalLoggerSetTimeInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerSetTimeInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Set Time Interaction";
                  break;
               }
            case DtLgrSkipTime:
               {
                  out = new DtPortalLoggerSkipTimeInteraction;
                  DtPortalLoggerSkipTimeInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerSkipTimeInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Skip Time Interaction";
                  break;
               }
            case DtLgrTimeScale:
               {
                  out = new DtPortalLoggerTimeScaleInteraction;
                  DtPortalLoggerTimeScaleInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerTimeScaleInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Time Scale Interaction";
                  break;
               }
            case DtLgrPlayAction:
               {
                  out = new DtPortalLoggerPlayActionInteraction;
                  DtPortalLoggerPlayActionInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerPlayActionInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Play Action Interaction";
                  break;
               }
            case DtLgrRecordAction:
               {
                  out = new DtPortalLoggerRecordActionInteraction;
                  DtPortalLoggerRecordActionInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerRecordActionInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Record Action Interaction";
                  break;
               }
            case DtLgrEofAction:
               {
                  out = new DtPortalLoggerEndOfActionInteraction;
                  DtPortalLoggerEndOfActionInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerEndOfActionInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger End of File Action Interaction";
                  break;
               }
            case DtLgrHeartbeat:
               {
                  out = new DtPortalLoggerHeartbeatInteraction;
                  DtPortalLoggerHeartbeatInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerHeartbeatInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Heartbeat Interaction";
                  break;
               }
            case DtLgrTimeout:
               {
                  out = new DtPortalLoggerTimeoutInteraction;
                  DtPortalLoggerTimeoutInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerTimeoutInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Timeout Interaction";
                  break;
               }
            case DtLgrStateFlag:
               {
                  out = new DtPortalLoggerStateFlagInteraction;
                  DtPortalLoggerStateFlagInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerStateFlagInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger State Interaction";
                  break;
               }
            case DtLgrTotalState:
               {
                  out = new DtPortalLoggerTotalStateInteraction;
                  DtPortalLoggerTotalStateInteraction* actualPduType =
                     dynamic_cast<DtPortalLoggerTotalStateInteraction*>(out);
                  translate( actualPduType, incoming );
                  debugString = "Logger Total State Interaction";
                  break;
               }
            default:
               {
                  break;
               }
            }

            // Abort if a portal interaction could not be instantiated.
            if ( ! out )
            {
               return;
            }

            if ( myBroker->isTranslatorDebuggingOn(name()) )
            {
               printIncomingOutgoingInteractions( incoming, *out );
            }

            myBroker->portalConnection()->send( *out );
            ++myNumInteractions;
            DtDELETE( out );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      void DtLoggerControlTranslator::createInteraction(
         const DtPortalLoggerControlInteraction& incoming )
      {
         try
         {
            DtLgrControlInteraction* out = NULL;
            switch ( incoming.loggerCommandType() )
            {
            case DtLgrConnect:
            {
               out = new DtLgrConnectPdu;
               const DtPortalLoggerConnectInteraction* actualPortalType =
                  dynamic_cast<const DtPortalLoggerConnectInteraction*>(&incoming);
               translate(out, *actualPortalType);
               break;
            }
            case DtLgrDelFile:
               {
                  out = new DtLgrDelFilePdu;
                  const DtPortalLoggerDeleteFileInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerDeleteFileInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrEmpty:
               {
                  out = new DtLgrEmptyPdu;
                  const DtPortalLoggerEmptyInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerEmptyInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrEnd:
               {
                  out = new DtLgrEndPdu;
                  const DtPortalLoggerEndInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerEndInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrEofAction:
               {
                  out = new DtLgrEofActionPdu;
                  const DtPortalLoggerEndOfActionInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerEndOfActionInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrHeartbeat:
               {
                  out = new DtLgrHeartbeatPdu;
                  const DtPortalLoggerHeartbeatInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerHeartbeatInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrPause:
               {
                  out = new DtLgrPausePdu;
                  const DtPortalLoggerPauseInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerPauseInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrPbFile:
               {
                  out = new DtLgrPbFilePdu;
                  const DtPortalLoggerPlayFileInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerPlayFileInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrPlayAction:
               {
                  out = new DtLgrPlayActionPdu;
                  const DtPortalLoggerPlayActionInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerPlayActionInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrPlay:
               {
                  out = new DtLgrPlayPdu;
                  const DtPortalLoggerPlayInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerPlayInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrQuit:
               {
                  out = new DtLgrQuitPdu;
                  const DtPortalLoggerQuitInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerQuitInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrRecFile:
               {
                  out = new DtLgrRecFilePdu;
                  const DtPortalLoggerRecordFileInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerRecordFileInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrRecordAction:
               {
                  out = new DtLgrRecordActionPdu;
                  const DtPortalLoggerRecordActionInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerRecordActionInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrRecord:
               {
                  out = new DtLgrRecordPdu;
                  const DtPortalLoggerRecordInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerRecordInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrSetTime:
               {
                  out = new DtLgrSetTimePdu;
                  const DtPortalLoggerSetTimeInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerSetTimeInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrSkipTime:
               {
                  out = new DtLgrSkipTimePdu;
                  const DtPortalLoggerSkipTimeInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerSkipTimeInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrStart:
               {
                  out = new DtLgrStartPdu;
                  const DtPortalLoggerStartInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerStartInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrStateFlag:
               {
                  out = new DtLgrStateFlagPdu;
                  const DtPortalLoggerStateFlagInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerStateFlagInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrTimeout:
               {
                  out = new DtLgrTimeoutPdu;
                  const DtPortalLoggerTimeoutInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerTimeoutInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrTimeScale:
               {
                  out = new DtLgrTimeScalePdu;
                  const DtPortalLoggerTimeScaleInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerTimeScaleInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            case DtLgrTotalState:
               {
                  out = new DtLgrTotalStatePdu;
                  const DtPortalLoggerTotalStateInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerTotalStateInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }

            case DtLgrStop:
               {
                  out = new DtLgrStopPdu;
                  const DtPortalLoggerStopInteraction* actualPortalType =
                     dynamic_cast<const DtPortalLoggerStopInteraction*>(&incoming);
                  translate( out, *actualPortalType );
                  break;
               }
            default:
               {
                  break;
               }
            }


            if ( out )
            {
               ++myNumInteractions;
               disBroker()->connection()->sendStamped( *out );

               if ( myBroker->isTranslatorDebuggingOn(name()) )
               {
                  printIncomingOutgoingInteractions( incoming, *out );
               }
               DtDELETE( out );
            }
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerConnectInteraction* destination, const DtLgrControlInteraction& source)
      {
         destination->setReceiverId(disBroker()->convertGlobalId(source.receiverId()));
         destination->setSenderId(disBroker()->convertGlobalId(source.senderId()));
         destination->setLoggerCommandType(source.lgrCommand());

         const DtLgrConnectPdu* actual = dynamic_cast<const DtLgrConnectPdu*>(&source);
         destination->setLoggerName(actual->loggerName());

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerDeleteFileInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setLoggerCommandType( source.lgrCommand() );

         const DtLgrDelFilePdu* actual = dynamic_cast<const DtLgrDelFilePdu*>( &source );
         destination->setFilename( actual->filename() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerEmptyInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setLoggerCommandType( source.lgrCommand() );

         const DtLgrEmptyPdu* actual = dynamic_cast<const DtLgrEmptyPdu*>( &source );
         //empty pdu.

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerStopInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setLoggerCommandType( source.lgrCommand() );

         const DtLgrStopPdu* actual = dynamic_cast<const DtLgrStopPdu*>( &source );
         // empty pdu.

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerStartInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrStartPdu* actualPdu = dynamic_cast<DtLgrStartPdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerRecordInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrRecordPdu* actualPdu = dynamic_cast<const DtLgrRecordPdu*>( &source );
         // empty pdu.

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerTimeoutInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrTimeoutPdu* actualPdu = dynamic_cast<const DtLgrTimeoutPdu*>( &source );
         destination->setTimeout( actualPdu->timeout() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerSkipTimeInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrSkipTimePdu* actualPdu = dynamic_cast<const DtLgrSkipTimePdu*>( &source );
         destination->setSkipTime( actualPdu->time() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerPlayFileInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrPbFilePdu* actualPdu = dynamic_cast<const DtLgrPbFilePdu*>( &source );
         destination->setFilename( actualPdu->filename() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerPlayActionInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrPlayActionPdu* actualPdu = dynamic_cast<const DtLgrPlayActionPdu*>( &source );
         destination->setAction( actualPdu->action() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerRecordFileInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrRecFilePdu* actualPdu = dynamic_cast<const DtLgrRecFilePdu*>( &source );
         destination->setFilename( actualPdu->filename() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerSetTimeInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrSetTimePdu* actualPdu = dynamic_cast<const DtLgrSetTimePdu*>( &source );
         destination->setSetTime( actualPdu->time() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerEndInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrEndPdu* actualPdu = dynamic_cast<const DtLgrEndPdu*>( &source );
         // empty pdu.

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerEndOfActionInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrEofActionPdu* actualPdu = dynamic_cast<const DtLgrEofActionPdu*>( &source );
         destination->setAction( actualPdu->action() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerPlayInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrPlayPdu* actualPdu = dynamic_cast<const DtLgrPlayPdu*>( &source );
         // empty pdu.

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerStateFlagInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrStateFlagPdu* actualPdu = dynamic_cast<const DtLgrStateFlagPdu*>( &source );
         destination->setStateFlag( actualPdu->flag() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerTimeScaleInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrTimeScalePdu* actualPdu = dynamic_cast<const DtLgrTimeScalePdu*>( &source );
         destination->setTimeScale( actualPdu->timeScale() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerQuitInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrQuitPdu* actualPdu = dynamic_cast<const DtLgrQuitPdu*>( &source );
         // empty pdu.

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerRecordActionInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrRecordActionPdu* actualPdu = dynamic_cast<const DtLgrRecordActionPdu*>( &source );
         destination->setAction( actualPdu->action() );

         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerPauseInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrPausePdu* actualPdu = dynamic_cast<const DtLgrPausePdu*>( &source );
         // empty pdu.

         return destination;
      }


      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerTotalStateInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrTotalStatePdu* actualPdu = dynamic_cast<const DtLgrTotalStatePdu*>( &source );
         destination->setTime( actualPdu->time() );
         destination->setIdealTime( actualPdu->idealTime() );
         destination->setScale( actualPdu->scale() );
         destination->setFileLength( actualPdu->fileLength() );
         destination->setHeartbeat( actualPdu->heartbeat() );
         destination->setTimeout( actualPdu->timeout() );
         destination->setDataScaling( actualPdu->dataScaling() );
         destination->setFilePos( actualPdu->filePos() );
         destination->setMode( actualPdu->mode() );
         destination->setPlayAction( actualPdu->playAction() );
         destination->setRecordAction( actualPdu->recordAction() );
         destination->setEndOfAction( actualPdu->eofAction() );
         destination->setTimeConstrained( actualPdu->timeConstrained() );
         destination->setTimeRegulating( actualPdu->timeRegulated() );
         destination->setUsingOwnFedAmb( actualPdu->usingOwnFedAmb() );
         destination->setLoggerFile( actualPdu->lgrFile() );
         destination->setAnnotationsFile( actualPdu->annotationsFile() );
         return destination;
      }

      DtPortalLoggerControlInteraction* DtLoggerControlTranslator::translate(
         DtPortalLoggerHeartbeatInteraction* destination, const DtLgrControlInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         const DtLgrHeartbeatPdu* actualPdu = dynamic_cast<const DtLgrHeartbeatPdu*>( &source );
         destination->setHeartbeat( actualPdu->heartbeat() );

         return destination;
      }


      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerConnectInteraction& source)
      {
         destination->setReceiverId(disBroker()->convertGlobalId(source.receiverId()));
         destination->setSenderId(disBroker()->convertGlobalId(source.senderId()));

         DtLgrConnectPdu* actualPdu = dynamic_cast<DtLgrConnectPdu*>(destination);
         actualPdu->setLoggerName(source.loggerName());

         return destination;
      }


      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerDeleteFileInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrDelFilePdu* actualPdu = dynamic_cast<DtLgrDelFilePdu*>( destination );
         actualPdu->setFilename( source.filename() );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerEmptyInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrEmptyPdu* actualPdu = dynamic_cast<DtLgrEmptyPdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerStopInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrStopPdu* actualPdu = dynamic_cast<DtLgrStopPdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerStartInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrStartPdu* actualPdu = dynamic_cast<DtLgrStartPdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerPlayActionInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrPlayActionPdu* actualPdu = dynamic_cast<DtLgrPlayActionPdu*>( destination );
         actualPdu->setAction( DtLgrMode(source.action()) );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerHeartbeatInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrHeartbeatPdu* actualPdu = dynamic_cast<DtLgrHeartbeatPdu*>( destination );
         actualPdu->setHeartbeat( source.heartbeat() );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerTimeoutInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrTimeoutPdu* actualPdu = dynamic_cast<DtLgrTimeoutPdu*>( destination );
         actualPdu->setTimeout( source.timeout() );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerEndOfActionInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrEofActionPdu* actualPdu = dynamic_cast<DtLgrEofActionPdu*>( destination );
         actualPdu->setAction( DtLgrMode(source.action()) );
         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerRecordInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrRecordPdu* actualPdu = dynamic_cast<DtLgrRecordPdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerPlayInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrPlayPdu* actualPdu = dynamic_cast<DtLgrPlayPdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerEndInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrEndPdu* actualPdu = dynamic_cast<DtLgrEndPdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerSetTimeInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrSetTimePdu* actualPdu = dynamic_cast<DtLgrSetTimePdu*>( destination );
         actualPdu->setTime( source.setTime() );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerQuitInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrQuitPdu* actualPdu = dynamic_cast<DtLgrQuitPdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerSkipTimeInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrSkipTimePdu* actualPdu = dynamic_cast<DtLgrSkipTimePdu*>( destination );
         actualPdu->setTime( source.skipTime() );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerRecordActionInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrRecordActionPdu* actualPdu = dynamic_cast<DtLgrRecordActionPdu*>( destination );
         actualPdu->setAction( DtLgrMode(source.action()) );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerPauseInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrPausePdu* actualPdu = dynamic_cast<DtLgrPausePdu*>( destination );
         // empty pdu.

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerStateFlagInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrStateFlagPdu* actualPdu = dynamic_cast<DtLgrStateFlagPdu*>( destination );
         actualPdu->setFlag( DtLgrCtrlFlagStates(source.stateFlag()) );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerRecordFileInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrRecFilePdu* actualPdu = dynamic_cast<DtLgrRecFilePdu*>( destination );
         actualPdu->setFilename( source.filename() );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerPlayFileInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrPbFilePdu* actualPdu = dynamic_cast<DtLgrPbFilePdu*>( destination );
         actualPdu->setFilename( source.filename() );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerTotalStateInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrTotalStatePdu* actualPdu = dynamic_cast<DtLgrTotalStatePdu*>( destination );
         actualPdu->setTime( source.time() );
         actualPdu->setIdealTime( source.idealTime() );
         actualPdu->setScale( source.scale() );
         actualPdu->setFileLength( source.fileLength() );
         actualPdu->setHeartbeat( source.heartbeat() );
         actualPdu->setTimeout( source.timeout() );
         actualPdu->setDataScaling( source.dataScaling() );
         actualPdu->setFilePos( DtLgrFilePosition(source.filePos()) );
         actualPdu->setMode( DtLgrMode(source.mode()) );
         actualPdu->setPlayAction( DtLgrMode(source.playAction()) );
         actualPdu->setRecordAction( DtLgrMode(source.recordAction()) );
         actualPdu->setEofAction( DtLgrMode(source.endOfAction()) );
         actualPdu->setTimeConstrained( source.timeConstrained() );
         actualPdu->setTimeRegulated( source.timeRegulating() );
         actualPdu->setUsingOwnFedAmb( source.usingOwnFedAmb() );
         actualPdu->setLgrFile( source.loggerFile() );
         actualPdu->setAnnotationsFile( source.annotationsFile() );

         return destination;
      }

      DtLgrControlInteraction* DtLoggerControlTranslator::translate(
         DtLgrControlInteraction* destination, const DtPortalLoggerTimeScaleInteraction& source )
      {
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );

         DtLgrTimeScalePdu* actualPdu = dynamic_cast<DtLgrTimeScalePdu*>( destination );
         actualPdu->setTimeScale( source.timeScale() );

         return destination;
      }

   }
}
