/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disGeneralSettingsWidget.h
//! \brief Contains the DtDisGeneralSettingsWidget class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/dllExport.h>
#include <disBroker/disBrokerInitializer.h>
#include <widgets/generalSettingsWidget.h>

namespace MAKCommonWidgets
{
   class DtCollectionEditor;
}

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //! \brief Provides an interface for configuring general DIS settings.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDisGeneralSettingsWidget
         : public DtGeneralSettingsWidget
      {  Q_OBJECT;
      public:

         //! \brief CTOR.
         //! \throw DtQAppStartingUp is thrown if the qApp is not started up yet.
         DtDisGeneralSettingsWidget( QWidget* parent = 0 );

         //! \brief Virtual DTOR.
         virtual ~DtDisGeneralSettingsWidget();

         //! \brief Accessor for casted DIS Initializer.
         virtual DtDisBrokerInitializer* disInitializer();

         //! @name Translation Settings Setters/Getters
         //! @{

         //! \brief Set Parse Unknown IDs flag.
         virtual void setParseUnknownIDs( bool );
         //! \brief Get Parse Unknown IDs flag.
         virtual bool parseUnknownIDs() const;

         //! \brief Set remap Dis IDs.
         virtual void setRemapDisIDs( bool );
         //! \brief Get remap Dis IDs.
         virtual bool remapDisIDs() const;

         //! \brief Set Use Persistent Entity IDs.
         virtual void setUsePersistentEntityIds( bool );
         //! \brief Get Use Persistent Entity IDs.
         virtual bool usePersistentEntityIds() const;

         //! \brief Set Timeout for wait-listed incomplete interactions.
         virtual void setInteractionWaitListTimeout( DtTime );
         //! \brief Get Timeout for wait-listed incomplete interactions.
         virtual DtTime interactionWaitListTimeout() const;

         //! \brief Set whether to send wait-listed incomplete interactions.
         virtual void setSendExpiredWaitListInteractions( bool );
         //! \brief Get whether to send wait-listed incomplete interactions.
         virtual bool sendExpiredWaitListInteractions() const;

         //! \brief Set application number.
         virtual void setAppNum( int );
         //! \brief Get application number.
         virtual int appNum() const;

         //! \brief Set site id.
         virtual void setSiteID( int );
         //! \brief Get site id.
         virtual int siteID() const;

         //! \brief Set whether to use absolute time stamps.
         virtual void setUseAbsoluteTimeStamp( bool );
         //! \brief Get whether to use absolute time stamps.
         virtual bool useAbsoluteTimeStamp() const;

         //! \brief Set the location threshold.
         virtual void setLocationThreshold( double );
         //! \brief Get the location threshold.
         virtual double locationThreshold() const;

         //! \brief Set the rotation threshold.
         virtual void setRotationThreshold( double );
         //! \brief Get the rotation threshold.
         virtual double rotationThreshold() const;

         //! \brief Set the protocol version to send.
         virtual void setProtocolVersionToSend( int );
         //! \brief Get the protocol version to send.
         virtual int protocolVersionToSend() const;

         //! \brief Set the min protocol version to receive.
         virtual void setProtocolVersionToRecvMin( int );
         //! \brief Get the min protocol version to receive.
         virtual int protocolVersionToRecvMin() const;

         //! \brief Set the max protocol version to receive.
         virtual void setProtocolVersionToRecvMax( int );
         //! \brief Get the max protocol version to receive.
         virtual int protocolVersionToRecvMax() const;

         //! \brief Set whether to disable art part processing.
         virtual void setDisableArticulatedParts( bool );
         //! \brief Get whether to disable art part processing.
         virtual bool disableArticulatedParts() const;

         //! \brief Set whether to split underwater acoustic PDUs.
         virtual void setSplitUnderwaterAcousticPdus( bool );
         //! \brief Get whether to split underwater acoustic PDUs.
         virtual bool splitUnderwaterAcousticPdus() const;

         //! \brief Set whether to publish DI-Guy PDUs.
         virtual void setSendDiGuyPdus( bool );
         //! \brief Get whether to publish DI-Guy PDUs.
         virtual bool sendDiGuyPdus() const;

         //! \brief Set whether to publish SEES PDUs.
         virtual void setSendSeesPdus( bool );
         //! \brief Get whether to publish SEES PDUs.
         virtual bool sendSeesPdus() const;

         //! \brief Set whether to publish Relative Location PDUs.
         virtual void setSendRelativeLocationPdus( bool );
         //! \brief Get whether to publish Relative Location PDUs.
         virtual bool sendRelativeLocationPdus() const;

         //! @}

         //! @name Debug Settings Setters/Getters
         //! @{

         //! \brief Set whether to debug global id mapping.
         virtual void setDebugGlobalIdMapping( bool );
         //! \brief Get whether to debug global id mapping.
         virtual bool debugGlobalIdMapping() const;

         //! \brief Set whether to debug entity id mapping.
         virtual void setDebugEntityIdMapping( bool );
         //! \brief Get whether to debug entity id mapping.
         virtual bool debugEntityIdMapping() const;

         //! \brief Set whether to debug event id mapping.
         virtual void setDebugEventIdMapping( bool );
         //! \brief Get whether to debug event id mapping.
         virtual bool debugEventIdMapping() const;

         //! \brief Set Dump Gui to Text Flag.
         virtual void setDumpGuiToText( bool );
         //! \brief Get Dump Gui to Text Flag.
         virtual bool dumpGuiToText() const;

         //! @}

         //! @name Timing Settings Setters/Getters
         //! @{

         //! \brief Set heartbeat interval.
         virtual void setHeartbeatInterval( DtTime );
         //! \brief Get heartbeat interval.
         virtual DtTime heartbeatInterval() const;

         //! \brief Set timeout Interval.
         virtual void setTimeoutInterval( DtTime );
         //! \brief Get timeout Interval.
         virtual DtTime timeoutInterval() const;

         //! \brief Set Dump Gui to Text Flag.
         virtual void setDrainTimeout( DtTime );
         //! \brief Get Dump Gui to Text Flag
         virtual DtTime drainTimeout() const;

         //! \brief Set the number of PDUs to read per time check.
         virtual void setNumPdusReadPerTimeCheck( int );
         //! \brief Get the number of PDUs to read per time check.
         virtual int numPdusReadPerTimeCheck() const;

         //! @}

         //! @name Publication Condition Settings Setters/Getters
         //! @{

         virtual void setDiscoveryAggregateEntityId( bool );
         virtual bool discoveryAggregateEntityId() const;
         virtual void setDiscoveryAggregateLocation( bool );
         virtual bool discoveryAggregateLocation() const;
         virtual void setDiscoveryAggregateEntityType( bool );
         virtual bool discoveryAggregateEntityType() const;

         virtual void setDiscoveryDesignatorEntityId( bool );
         virtual bool discoveryDesignatorEntityId() const;
         virtual void setDiscoveryDesignatorHostId( bool );
         virtual bool discoveryDesignatorHostId() const;

         virtual void setDiscoveryEmitterSystemEntityId( bool );
         virtual bool discoveryEmitterSystemEntityId() const;
         virtual void setDiscoveryEmitterSystemHostId( bool );
         virtual bool discoveryEmitterSystemHostId() const;

         virtual void setDiscoveryEntityLocation( bool );
         virtual bool discoveryEntityLocation() const;
         virtual void setDiscoveryEntityEntityType( bool );
         virtual bool discoveryEntityEntityType() const;

         virtual void setDiscoveryEnvironmentProcessId( bool );
         virtual bool discoveryEnvironmentProcessId() const;

         virtual void setDiscoveryGriddedDataGridId( bool );
         virtual bool discoveryGriddedDataGridId() const;

         virtual void setDiscoveryIFFEntityId( bool );
         virtual bool discoveryIFFEntityId() const;
         virtual void setDiscoveryIFFHostId( bool );
         virtual bool discoveryIFFHostId() const;

         virtual void setDiscoveryRadioRecvEntityId( bool );
         virtual bool discoveryRadioRecvEntityId() const;
         virtual void setDiscoveryRadioRecvHostId( bool );
         virtual bool discoveryRadioRecvHostId() const;

         virtual void setDiscoveryRadioTransEntityId( bool );
         virtual bool discoveryRadioTransEntityId() const;
         virtual void setDiscoveryRadioTransHostId( bool );
         virtual bool discoveryRadioTransHostId() const;

         virtual void setDiscoveryUndwaAcousticsAcousticId( bool );
         virtual bool discoveryUndwaAcousticsAcousticId() const;
         virtual void setDiscoveryUndwaAcousticsEntityId( bool );
         virtual bool discoveryUndwaAcousticsEntityId() const;
         virtual void setDiscoveryUndwaAcousticsHostId( bool );
         virtual bool discoveryUndwaAcousticsHostId() const;

         //! @}

      protected:

         //! \brief Initialize translated Qt property names.
         //! Overridden to initialize DIS specific property names.
         virtual void initializeQtStrings();

         //! \brief Initialize the property entries for the settings.
         //! Overridden to initialize DIS specific properties.
         virtual void initializeProperties();

         //! \brief Update the initializer with the dialog's current settings.
         //! Overridden to update DIS specific configuration options.
         virtual void updateConfiguration();

         //! \brief Update the dialog with the initializer's current settings.
         //! Overridden to revert DIS specific configuration options.
         virtual void revertConfiguration();

      protected:

         // Translation Settings.
         QString translationSettingsProperty;
         QString parseUnknownIDsProperty;
         QString remapDisIDsProperty;
         QString usePersistentEntityIDsProperty;
         QString interactionWaitListTimeoutProperty;
         QString sendExpiredWaitListInteractionsProperty;
         QString applicationNumberProperty;
         QString siteIDProperty;
         QString useAbsoluteTimeStampProperty;
         QString locationThresholdProperty;
         QString rotationThresholdProperty;
         QString protocolVersionToSendProperty;
         QString protocolVersionToRecvMinProperty;
         QString protocolVersionToRecvMaxProperty;
         QString disableArticulatedPartsProperty;
         QString splitUnderwaterAcousticPdusProperty;
         QString sendDiGuyPdusProperty;
         QString sendSeesPdusProperty;
         QString sendRelativeLocationPdusProperty;

         // Debug Settings.
         QString debugSettingsProperty;
         QString debugGlobalIdMappingProperty;
         QString debugEntityIdMappingProperty;
         QString debugEventIdMappingProperty;
         QString dumpGuiToTextProperty;

         // Timing Settings.
         QString timingSettingsProperty;
         QString heartbeatIntervalProperty;
         QString timeoutIntervalProperty;
         QString drainTimeoutProperty;
         QString numPdusReadPerTimeCheckProperty;

         // Discovery Settings.
         QString discoveryConditionsProperty;
         QString discoveryAggregateEntityIdProperty;
         QString discoveryAggregateLocationProperty;
         QString discoveryAggregateEntityTypeProperty;
         QString discoveryDesignatorEntityIdProperty;
         QString discoveryDesignatorHostIdProperty;
         QString discoveryEmitterSystemEntityIdProperty;
         QString discoveryEmitterSystemHostIdProperty;
         QString discoveryEntityLocationProperty;
         QString discoveryEntityEntityTypeProperty;
         QString discoveryEnvironmentProcessIdProperty;
         QString discoveryGriddedDataGridIdProperty;
         QString discoveryIFFEntityIdProperty;
         QString discoveryIFFHostIdProperty;
         QString discoveryRadioRecvEntityIdProperty;
         QString discoveryRadioRecvHostIdProperty;
         QString discoveryRadioTransEntityIdProperty;
         QString discoveryRadioTransHostIdProperty;
         QString discoveryUndwaAcousticsAcousticIdProperty;
         QString discoveryUndwaAcousticsEntityIdProperty;
         QString discoveryUndwaAcousticsHostIdProperty;


         // Default Translation Settings.
         static bool theDefaultParseUnknownIDs;
         static bool theDefaultRemapDisIDs;
         static bool theDefaultUsePersistentEntityIDs;
         static DtTime theDefaultInteractionWaitListTimeout;
         static bool theDefaultSendExpiredWaitListInteractions;
         static int theDefaultAppNumber;
         static int theDefaultSiteID;
         static bool theDefaultUseAbsoluteTimeStamp;
         static double theDefaultLocationThreshold;
         static double theDefaultRotationThreshold;
         static int theDefaultProtocolVersionToSend;
         static int theDefaultProtocolVersionToRecvMin;
         static int theDefaultProtocolVersionToRecvMax;
         static bool theDefaultDisableArticulatedParts;
         static bool theDefaultSplitUnderwaterAcousticPdus;
         static bool theDefaultSendDiGuyPdus;
         static bool theDefaultSendSeesPdus;
         static bool theDefaultSendRelativeLocationPdus;

         // Default Debug Settings.
         static bool theDefaultDebugGlobalIdMapping;
         static bool theDefaultDebugEntityIdMapping;
         static bool theDefaultDebugEventIdMapping;
         static bool theDefaultDumpGuiToText;

         // Default Timing Settings.
         static DtTime theDefaultHeartbeatInterval;
         static DtTime theDefaultTimeoutInterval;
         static DtTime theDefaultDrainTimeout;
         static int theDefaultNumPdusReadPerTimeCheck;

         // Default Discovery Settings.
         static bool theDefaultDiscoveryAggregateEntityId;
         static bool theDefaultDiscoveryAggregateLocation;
         static bool theDefaultDiscoveryAggregateEntityType;
         static bool theDefaultDiscoveryDesignatorEntityId;
         static bool theDefaultDiscoveryDesignatorHostId;
         static bool theDefaultDiscoveryEmitterSystemEntityId;
         static bool theDefaultDiscoveryEmitterSystemHostId;
         static bool theDefaultDiscoveryEntityLocation;
         static bool theDefaultDiscoveryEntityEntityType;
         static bool theDefaultDiscoveryEnvironmentProcessId;
         static bool theDefaultDiscoveryGriddedDataGridId;
         static bool theDefaultDiscoveryIFFEntityId;
         static bool theDefaultDiscoveryIFFHostId;
         static bool theDefaultDiscoveryRadioRecvEntityId;
         static bool theDefaultDiscoveryRadioRecvHostId;
         static bool theDefaultDiscoveryRadioTransEntityId;
         static bool theDefaultDiscoveryRadioTransHostId;
         static bool theDefaultDiscoveryUndwaAcousticsAcousticId;
         static bool theDefaultDiscoveryUndwaAcousticsEntityId;
         static bool theDefaultDiscoveryUndwaAcousticsHostId;

         MAKCommonWidgets::DtCollectionEditor* myObjCollectionEditor;

      };

   }
}
