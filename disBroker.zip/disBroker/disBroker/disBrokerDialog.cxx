/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disBrokerDialog.cxx
//! \brief Contains the DtDisBrokerDialog class definition.
//! \ingroup disBroker

#include <disBroker/disBrokerDialog.h>
#include <disBroker/disBrokerInitializer.h>
#include <disBroker/disConnectionSettingsWidget.h>
#include <disBroker/disGeneralSettingsWidget.h>
#include <disBroker/disBroker.h>
#include <broker/brokerObject.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtBrokerDialog* DtDisBrokerDialog::create( DtBroker* broker,
         DtBrokerInitializer* init, QWidget* parent /* = 0 */ )
      {
         DtDisBrokerDialog* dialog = new DtDisBrokerDialog(
            (DtDisBroker*)broker, (DtDisBrokerInitializer*)init, parent );
         dialog->initialize();
         return dialog;
      }

      DtDisBrokerDialog::DtDisBrokerDialog( DtDisBroker* broker,
            DtDisBrokerInitializer* init, QWidget* parent /* = 0 */ )
         : DtBrokerDialog( broker, init, parent )
         , myDisBroker( broker )
      {
      }

      DtDisBrokerDialog::~DtDisBrokerDialog()
      {
      }

      DtDisBrokerInitializer* DtDisBrokerDialog::disInitializer()
      {
         return (DtDisBrokerInitializer*) myBrokerInitializer;
      }

      void DtDisBrokerDialog::initObjectListViewHeaders()
      {
         // Set up the default list view headers.
         DtBrokerDialog::initObjectListViewHeaders();

         // Rename ID columns to "DIS ID".
         QStringList columnHeaders;
         columnHeaders << tr("Type") << tr("Name") << tr("DIS ID") << tr("Marking Text") ;
         myPublishedObjectsWidget->listView()->setHeaderLabels( columnHeaders );
         myReflectedObjectsWidget->listView()->setHeaderLabels( columnHeaders );

         // Set titles to be more DIS specific.
         QString pubTitle = tr( "Objects published to DIS execution." );
         myPublishedObjectsWidget->titleLabel()->setText( pubTitle );
         QString subTitle = tr( "Objects discovered from DIS execution." );
         myReflectedObjectsWidget->titleLabel()->setText( subTitle );
      }

      DtConnectionSettingsWidget* DtDisBrokerDialog::instantiateConnectionSettingsWidget()
      {
         return new DtDisConnectionSettingsWidget();
      }

      DtGeneralSettingsWidget* DtDisBrokerDialog::instantiateGeneralSettingsWidget()
      {
         return new DtDisGeneralSettingsWidget();
      }

   }
}
