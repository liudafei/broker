/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file actionResponseTranslator.h
//! \brief Contains the DtActionResponseTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pActionResponseInter.h>
#include <vl/actionResponseInteraction.h>

namespace MAKVrExchange
{

   class DtPortalActionResponseInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Translates Action Response Interactions to/from the portal.
      class DT_DLL_DISBROKER DtActionResponseTranslator
         : public DtDisInteractionTranslator<DtPortalActionResponseInteraction,DtActionResponseInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Action Response" );

         //! \brief CTOR.
         DtActionResponseTranslator( DtBroker* broker );

         //! \brief Virtual CTOR.
         virtual ~DtActionResponseTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalActionResponseInteraction& inter );

         //! \brief Translates the action response interaction into the portal.
         virtual DtPortalActionResponseInteraction* translate(
            DtPortalActionResponseInteraction* destination,
            const DtActionResponseInteraction& source );

         //! \brief Translates the portal action response interaction from the portal.
         virtual DtActionResponseInteraction* translate(
            DtActionResponseInteraction* destination,
            const DtPortalActionResponseInteraction& source );

      };

   }
}
