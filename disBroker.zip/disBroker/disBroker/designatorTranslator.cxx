/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file designatorTranslator.cxx
//! \brief Contains the DtDesignatorTranslator class definition.
//! \ingroup disBroker

#include <disBroker/designatorTranslator.h>
#include <disBroker/disBrokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtDesignatorTranslator::DtDesignatorTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalDesignatorObject::theKind )
      {
      }

      DtDesignatorTranslator::~DtDesignatorTranslator()
      {
      }

      bool DtDesignatorTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedDesignatorObject* refObj )
      {
         DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->designatorNeedsEntityId() )
         {
            DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::DesignatorType;
            DtEntityIdentifier newId = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
               refObj->sr()->identifier(), &objType );
            if ( newId == DtEntityIdentifier::nullId() )
            {
               newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
                  refObj->sr()->entityIdentifier() );
            }
            if ( newId == DtEntityIdentifier::nullId() )
            {
               DtInfo << "DtDesignatorTranslator: " << brokerObj->objectName()
                  << ": Entity Id not present, object incomplete" << std::endl;
               brokerObj->setDropReason( "Missing Entity ID" );
               return false;
            }
         }
         if ( discoveryCriteria->designatorNeedsHostId()
            && refObj->sr()->hostObjectIdentifier() == "" )
         {
            DtInfo << "DtDesignatorTranslator: " << brokerObj->objectName()
               << ": Host Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Host ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      bool DtDesignatorTranslator::performDisGlobalIdMapping(
         const DtObjectPublisher* publisher, const DtPortalReflectedDesignatorObject& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performDisGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::DesignatorType );
      }

      DtString DtDesignatorTranslator::portalObjectName(
         const DtReflectedDesignator* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "Dvrx";
      }

      bool DtDesignatorTranslator::performPortalGlobalIdMapping(
         const DtPortalDesignatorObjectPublisher* publisher,
         const DtReflectedDesignator& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */)
      {
         return ParentClass::performPortalGlobalIdMapping(publisher,
            refObj, DtGlobalIdMapper::DesignatorType,
            refObj.dsr()->codeName(), beamId);
      }

      void DtDesignatorTranslator::deleteDisPublisher( DtBrokerObject* brokerObj )
      {
         DtDesignatorPublisher* publisher =
            static_cast<DtDesignatorPublisher*>( brokerObj->publisherPtr() );
         const DtPortalReflectedDesignatorObject* refObj =
            static_cast<const DtPortalReflectedDesignatorObject*>(
               brokerObj->reflectedObjPtr() );
         if ( publisher && refObj )
         {
            disBroker()->globalIdMapper()->remove( refObj->sr()->entityIdentifier(),
               DtGlobalIdMapper::DesignatorType );
            brokerObj->setPublisherPtr( 0 );
            DtDELETE( publisher );
         }
      }

      DtPortalDesignatorObject* DtDesignatorTranslator::translate(
         DtPortalDesignatorObject* destination,
         const DtDesignatorRepository& source,
         const DtReflectedDesignator& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         destination->setDesignatedObjectIdentifier( disBroker()
            ->convertGlobalId(source.designatedObject()) );

         destination->setCodeName( source.codeName() );
         destination->setDesignatorCode( source.designatorCode() );
         destination->setDesignatorOutputPower( source.designatorPower() );
         destination->setDesignatorSpotLocation( source.designatorSpotLocation() );
         destination->setDesignatorEmissionWavelength( source.designatorWavelength() );
         destination->setDeadReckoningAlgorithm( source.dRAlgorithm() );
         destination->setRelativeSpotLocation( source.relativeSpotLocation() );
         destination->setSpotLinearAccelerationVector( source.spotLinearAcceleration() );

         return destination;
      }

      DtDesignatorRepository* DtDesignatorTranslator::translate(
         DtDesignatorRepository* destination, const DtPortalDesignatorObject& source,
         const DtPortalReflectedDesignatorObject& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         destination->setDesignatedObject( disBroker()
            ->convertGlobalId(source.designatedObjectIdentifier()) );

         destination->setCodeName( (DtDesignatorCodeName)source.codeName() );
         destination->setDesignatorCode( (DtDesignatorCode)source.designatorCode() );
         destination->setDesignatorPower( source.designatorOutputPower() );
         destination->setDesignatorSpotLocation( source.designatorSpotLocation() );
         destination->setDesignatorWavelength( source.designatorEmissionWavelength() );
         destination->setDRAlgorithm( (DtDeadReckonTypes)source.deadReckoningAlgorithm() );
         destination->setRelativeSpotLocation( source.relativeSpotLocation() );
         destination->setSpotLinearAcceleration( source.spotLinearAccelerationVector() );

         return destination;
      }

   }
}
