/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file propulsionNoiseTranslator.h
//! \brief Contains the DtPropulsionNoiseTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/underwaterAcousticTranslator.h>
#include <vl/reflectedPropulsionNoiseList.h>
#include <vl/propulsionNoisePublisher.h>

class DtReflectedPropulsionNoise;
class DtPropulsionNoiseStateRepository;

#define PROP_NOISE_TEMPLATE_ARGS \
   DtPortalPropulsionNoiseObject, DtPortalReflectedPropulsionNoiseObject, \
   DtReflectedPropulsionNoise, DtReflectedPropulsionNoiseList, \
   DtPropulsionNoiseStateRepository, DtPropulsionNoisePublisher

namespace MAKVrExchange
{

   class DtPortalPropulsionNoiseObject;

   namespace DtDisBroker
   {

      //! \brief Provides Propulsion Noise translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtPropulsionNoiseTranslator
         : public DtUnderwaterAcousticTranslator<PROP_NOISE_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Propulsion Noise" );

         //! \brief CTOR.
         DtPropulsionNoiseTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtPropulsionNoiseTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedPropulsionNoiseObject* refObj );

         //! Instantiates the publisher for the given reflected object.
         //! This may be overridden to modify the constructor used to create
         //! the publisher or perform additional publisher initialization.
         //! Default implementation attempts to create the publisher using
         //! the given name (the value returned from ::disObjectName), then
         //! attempts to create the publisher again with no name if the first
         //! attempt fails.
         //! Called by ::createDisPublisher.
         virtual DtObjectPublisher* instantiateDisPublisher(
            const DtPortalReflectedPropulsionNoiseObject* refObj,
            const DtEntityIdentifier& name );

         //! \brief Creates a new publisher and handles identifier mapping.
         //! Overridden to perform propulsion noise specific mapping.
         virtual void createDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Construct the portal object name.
         //! Overridden to construct a propulsion noise object name.
         virtual DtString portalObjectName( const DtReflectedPropulsionNoise* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Overridden to use the propulsion noise object type.
         virtual bool performPortalGlobalIdMapping(
            const DtPortalPropulsionNoisePublisher* publisher,
            const DtReflectedPropulsionNoise& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Processes incoming portal updates.
         //! Overridden to properly cast publisher to get the state rep.
         virtual void receivePortalUpdate( const DtPortalReflectedPropulsionNoiseObject& object );

         //! \brief Destroy the brokerObject's publisher.
         //! Overridden to correctly destroy the instantiated publisher and
         //! remove it from the manager if underwater acoustic PDUs aren't split.
         virtual void deleteDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Translates a Propulsion Noise object into the portal.
         virtual DtPortalPropulsionNoiseObject* translate( DtPortalPropulsionNoiseObject* destination,
            const DtPropulsionNoiseStateRepository& source, const DtReflectedPropulsionNoise& refObj );

         //! \brief Translates a Propulsion Noise object from the portal.
         virtual DtPropulsionNoiseStateRepository* translate( DtPropulsionNoiseStateRepository* destination,
            const DtPortalPropulsionNoiseObject& source, const DtPortalReflectedPropulsionNoiseObject& refObj );

         //! \brief Translates shaft rate data into the portal.
         virtual DtShaftRateData* translate( DtShaftRateData* destination,
            const DtUnderwaterAcousticShaftSpeed& source );

         //! \brief Translates shaft rate data from the portal.
         virtual DtUnderwaterAcousticShaftSpeed* translate(
            DtUnderwaterAcousticShaftSpeed* destination,
            const DtShaftRateData& source );

      };

   }
}
