/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file resupplyReceivedTranslator.cxx
//! \brief Contains the DtResupplyReceivedTranslator class definition.
//! \ingroup disBroker

#include <disBroker/resupplyReceivedTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtResupplyReceivedTranslator::DtResupplyReceivedTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalResupplyReceivedInteraction::theKind )
      {
      }

      DtResupplyReceivedTranslator::~DtResupplyReceivedTranslator()
      {
      }

      bool DtResupplyReceivedTranslator::isPortalDiscoverable(
         const DtPortalResupplyReceivedInteraction& inter )
      {
         return ( testGlobalIdMapping("Receiving ID",inter.receivingId())
            && testGlobalIdMapping("Supplying ID",inter.supplyingId()) );
      }

      DtPortalResupplyReceivedInteraction* DtResupplyReceivedTranslator::translate(
         DtPortalResupplyReceivedInteraction* destination, const DtResupplyRecInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setSupplyingId( disBroker()->convertGlobalId(source.supplyingId()) );
         destination->setNumSupplyTypes( source.numSupplyTypes() );

         int numSupplyTypes = source.numSupplyTypes();
         for ( int i = 0; i < numSupplyTypes; ++i )
         {
            float quantity = 0;
            int retCode = 0;
            DtEntityType supplyType = source.nthSupply( i, &quantity, &retCode );
            if ( DtSUPPLY_VALID == retCode )
            {
               retCode = destination->setNthSupply( i, supplyType, &quantity );
            }

            if ( DtSUPPLY_VALID != retCode )
            {
               DtWarn << name() << " problem translating supply.\n"
                  << "  Mismatch between stated num supplies and encoded num supplies.\n";
               break;
            }
         }

         return destination;
      }

      DtResupplyRecInteraction* DtResupplyReceivedTranslator::translate(
         DtResupplyRecInteraction* destination, const DtPortalResupplyReceivedInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setSupplyingId( disBroker()->convertGlobalId(source.supplyingId()) );
         destination->setNumSupplyTypes( source.numSupplyTypes() );

         int retCode = DtSUPPLY_VALID;
         int numSupplyTypes = source.numSupplyTypes();
         for ( int i = 0; ((DtSUPPLY_VALID == retCode) && (i < numSupplyTypes)); ++i )
         {
            float quantity = 0;
            DtNetEntityType supplyType;
            retCode = source.nthSupply( i, supplyType, &quantity );
            if ( DtSUPPLY_VALID == retCode )
            {
               destination->setNthSupply( i, supplyType, quantity, &retCode );
            }

            if ( DtSUPPLY_VALID != retCode )
            {
               DtWarn << name() << " problem translating supply.\n"
                  << "  Mismatch between stated num supplies and encoded num supplies.\n";
               break;
            }
         }

         return destination;
      }

   }
}
