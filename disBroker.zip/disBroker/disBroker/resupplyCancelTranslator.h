/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file resupplyCancelTranslator.h
//! \brief Contains the DtResupplyCancelTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/resupplyCancelInteraction.h>
#include <portal/pResupplyCancelInteraction.h>

namespace MAKVrExchange
{

   class DtPortalResupplyCancelInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides DIS<->Portal ResupplyCancel interaction translation.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtResupplyCancelTranslator
         : public DtDisInteractionTranslator<DtPortalResupplyCancelInteraction,DtResupplyCancelInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Resupply Cancel" );

         //! \brief CTOR.
         DtResupplyCancelTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtResupplyCancelTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalResupplyCancelInteraction& inter );

         //! \brief Translates the resupply cancel interaction into the portal.
         virtual DtPortalResupplyCancelInteraction* translate(
            DtPortalResupplyCancelInteraction* destination,
            const DtResupplyCancelInteraction& source );

         //! \brief Translates the resupply cancel interaction from the portal.
         virtual DtResupplyCancelInteraction* translate( DtResupplyCancelInteraction* destination,
            const DtPortalResupplyCancelInteraction& source );

      };

   }
}
