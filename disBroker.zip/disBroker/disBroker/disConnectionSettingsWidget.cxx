/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disConnectionSettingsWidget.cxx
//! \brief Contains the DtDisConnectionSettingsWidget class definition.
//! \ingroup disBroker

#include <disBroker/disConnectionSettingsWidget.h>
#include <disBroker/disBrokerInitializer.h>

#include <vlutil/vlInetInterfaceUtils.h>

#include <commonWidgets/collectionEditor.h>

#include <QMessageBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QToolButton>
#include <QComboBox>
#include <QLineEdit>
#include <QSpinBox>
#include <QLabel>

#define MAXVAL(a,b) ((a)>(b))?(a):(b)

using namespace MAKCommonWidgets;

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtDisConnectionSettingsWidget::DtDisConnectionSettingsWidget( QWidget* parent /* = 0 */ )
         : DtConnectionSettingsWidget( parent )
         , myUserNicDestinationAddresses()
         , myPortSpinBox( 0 )
         , myExerciseIdSpinBox( 0 )
         , myNicAddressComboBox( 0 )
         , myAdvancedButton( 0 )
         , myAdvancedWidget( 0 )
         , myDestinationAddressEdit( 0 )
         , myMulticastAddressesEdit( 0 )
         , myMulticastAddressEditButton( 0 )
         , mySendBufferSizeSpinBox( 0 )
         , myRecvBufferSizeSpinBox( 0 )
         , myMulticastTtlSpinBox( 0 )
         , mySubnetMaskEdit( 0 )
      {
      }

      DtDisConnectionSettingsWidget::~DtDisConnectionSettingsWidget()
      {
      }

      void DtDisConnectionSettingsWidget::initialize( DtBrokerInitializer* init )
      {
         setupGui();
         connectToSignals();
         myInitializer = init;
         populateAvailableNicAddresses();
         loadCurrentSettings();
      }

      DtDisBrokerInitializer* DtDisConnectionSettingsWidget::disInitializer()
      {
         return (DtDisBrokerInitializer*) myInitializer;
      }

      QIcon DtDisConnectionSettingsWidget::icon()
      {
         return QIcon( "../data/images/DarkMode/NetworkConnectionDIS.svg" );
      }

      std::string DtDisConnectionSettingsWidget::iconFilepath()
      {
         return "../data/images/DarkMode/NetworkConnectionDIS.svg";
      }

      void DtDisConnectionSettingsWidget::setupGui()
      {
         QVBoxLayout* mainLayout = new QVBoxLayout();

         QHBoxLayout* settingsLayout = new QHBoxLayout();
         {
            // Create column layout for the labels.
            QVBoxLayout* labelsLayout = new QVBoxLayout();
            {
               // Create label for the dis port field.
               QLabel* portLabel = new QLabel();
               portLabel->setText( tr("Port") );
               portLabel->setToolTip( tr("The UDP port to use to "
                  "listen for and broadcast DIS traffic.") );
               labelsLayout->addWidget( portLabel );

               // Create label for the exercise id field.
               QLabel* exerciseIdLabel = new QLabel();
               exerciseIdLabel->setText( tr("Exercise ID") );
               exerciseIdLabel->setToolTip( tr("The DIS exercise ID to 'join'.") );
               labelsLayout->addWidget( exerciseIdLabel );

               // Create label for the NIC combo box.
               QLabel* nicLabel = new QLabel();
               nicLabel->setText( tr("Network Interface Address") );
               nicLabel->setToolTip( tr("The IP address of the network "
                  "device to which outgoing PDUs are sent.") );
               labelsLayout->addWidget( nicLabel );
            }
            settingsLayout->addLayout( labelsLayout );

            // Add some spacing between the columns.
            settingsLayout->addSpacing( 25 );

            // Create a column layout for the fields.
            QVBoxLayout* fieldsLayout = new QVBoxLayout();
            {
               // Create a spin box for the port field.
               myPortSpinBox = new QSpinBox();
               myPortSpinBox->setRange( 0, 65535 );
               myPortSpinBox->setToolTip( tr("The UDP port to use to "
                  "listen for and broadcast DIS traffic.") );
               fieldsLayout->addWidget( myPortSpinBox );

               // Create a spin box for the exercise id field.
               myExerciseIdSpinBox = new QSpinBox();
               myExerciseIdSpinBox->setRange( 0, INT_MAX );
               myExerciseIdSpinBox->setSpecialValueText( tr("All") );
               myExerciseIdSpinBox->setToolTip( tr("The DIS exercise ID to 'join'.") );
               fieldsLayout->addWidget( myExerciseIdSpinBox );

               // Create a combo box for the NIC address field.
               myNicAddressComboBox = new QComboBox();
               myNicAddressComboBox->setToolTip( tr("The IP address of "
                  "the network device to which outgoing PDUs are sent.") );
               fieldsLayout->addWidget( myNicAddressComboBox );
            }
            settingsLayout->addLayout( fieldsLayout );
         }
         mainLayout->addLayout( settingsLayout );

         // Create the button for showing/hiding advanced settings.
         myAdvancedButton = new QToolButton();
         myAdvancedButton->setCheckable( true );
         myAdvancedButton->setText( tr("Advanced") );
         myAdvancedButton->setToolButtonStyle( Qt::ToolButtonTextBesideIcon );
         myAdvancedButton->setIcon( QIcon("../data/images/DarkMode/UtilityExpand.svg") );
         mainLayout->addWidget( myAdvancedButton );

         // Create a widget and layout for the advanced settings fields.
         myAdvancedWidget = new QWidget();
         QVBoxLayout* advancedVertLayout = new QVBoxLayout();
         {
            // Add a horizontal splitter line.
            QFrame* hRule = new QFrame();
            hRule->setFrameShape( QFrame::HLine );
            hRule->setFrameShadow( QFrame::Sunken );
            advancedVertLayout->addWidget( hRule );

            QHBoxLayout* advancedLayout = new QHBoxLayout();
            {
               // Create a column layout for the field labels.
               QVBoxLayout* labelsLayout = new QVBoxLayout();
               {
                  // Create label for the destination address field.
                  QLabel* destAddrLabel = new QLabel();
                  destAddrLabel->setText( tr("Destination Address") );
                  destAddrLabel->setToolTip( tr("The default IP address to which "
                     "outgoing PDUs are sent.\nCan be a unicast, multicast, or "
                     "broadcast address.") );
                  labelsLayout->addWidget( destAddrLabel );

                  // Create label for the multicast addresses field.
                  QLabel* multicastAdressesLabel = new QLabel();
                  multicastAdressesLabel->setText( tr("Multicast Subscription Set") );
                  multicastAdressesLabel->setToolTip( tr("A semicolon "
                     "separated list of multicast addresses.\nThe broker "
                     "is subscribed to the specified multicast addresses.") );
                  labelsLayout->addWidget( multicastAdressesLabel );

                  // Create label for the send buffer size field.
                  QLabel* sendBufferSizeLabel = new QLabel();
                  sendBufferSizeLabel->setText( tr("Send Buffer Size") );
                  sendBufferSizeLabel->setToolTip( tr("The default network buffer size.") );
                  labelsLayout->addWidget( sendBufferSizeLabel );

                  // Create label for the receive buffer size field.
                  QLabel* recvBufferSizeLabel = new QLabel();
                  recvBufferSizeLabel->setText( tr("Receive Buffer Size") );
                  recvBufferSizeLabel->setToolTip( tr("The default receive buffer size.") );
                  labelsLayout->addWidget( recvBufferSizeLabel );

                  // Create label for the mcast ttl field.
                  QLabel* multicastTtlLabel = new QLabel();
                  multicastTtlLabel->setText( tr("Multicast TTL") );
                  multicastTtlLabel->setToolTip( tr("The multicast time-to-live, in seconds.") );
                  labelsLayout->addWidget( multicastTtlLabel );

                  // Create label for the subnet mask field.
                  QLabel* subnetMaskLabel = new QLabel();
                  subnetMaskLabel->setText( tr("Subnet Mask") );
                  subnetMaskLabel->setToolTip( tr("The subnet mask the "
                     "broker should use with all IP addresses. Only necessary\n"
                     "if your subnet mask cannot be determined automatically.") );
                  labelsLayout->addWidget( subnetMaskLabel );
               }
               advancedLayout->addLayout( labelsLayout );

               // Add some spacing between the columns.
               advancedLayout->addSpacing( 25 );

               // Create column layout for the field widgets.
               QVBoxLayout* fieldsLayout = new QVBoxLayout();
               {
                  // Create the destination address edit box.
                  myDestinationAddressEdit = new QLineEdit();
                  myDestinationAddressEdit->setToolTip( tr("The default IP "
                     "address to which outgoing PDUs are sent.\nCan be "
                     "a unicast, multicast, or broadcast address.") );
                  fieldsLayout->addWidget( myDestinationAddressEdit );

                  // Create layout for the multicast field (edit box and button).
                  QHBoxLayout* multicastLayout = new QHBoxLayout();
                  {
                     // Create the multicast addresses edit box.
                     myMulticastAddressesEdit = new QLineEdit();
                     myMulticastAddressesEdit->setToolTip( tr("A semicolon "
                        "separated list of multicast addresses.\nThe broker "
                        "is subscribed to the specified multicast addresses.") );
                     multicastLayout->addWidget( myMulticastAddressesEdit );

                     // Create the multicast addresses edit button.
                     myMulticastAddressEditButton = new QPushButton();
                     myMulticastAddressEditButton->setIcon( QIcon("../data/images/DarkMode/UtilitySettingsEdit.svg") );
                     myMulticastAddressEditButton->setIconSize( QSize(16,16) );
                     multicastLayout->addWidget( myMulticastAddressEditButton );
                  }
                  fieldsLayout->addLayout( multicastLayout );

                  // Create the send buffer size spin box.
                  mySendBufferSizeSpinBox = new QSpinBox();
                  mySendBufferSizeSpinBox->setRange( 0, 999999 );
                  mySendBufferSizeSpinBox->setSpecialValueText( tr("Default") );
                  mySendBufferSizeSpinBox->setToolTip( tr("The default network buffer size.") );
                  fieldsLayout->addWidget( mySendBufferSizeSpinBox );

                  // Create the receive buffer size spin box.
                  myRecvBufferSizeSpinBox = new QSpinBox();
                  myRecvBufferSizeSpinBox->setRange( 0, 999999 );
                  myRecvBufferSizeSpinBox->setSpecialValueText( tr("Default") );
                  myRecvBufferSizeSpinBox->setToolTip( tr("The default receive buffer size.") );
                  fieldsLayout->addWidget( myRecvBufferSizeSpinBox );

                  // Create the multicast time-to-live spin box.
                  myMulticastTtlSpinBox = new QSpinBox();
                  myMulticastTtlSpinBox->setMinimum( -1 );
                  myMulticastTtlSpinBox->setSpecialValueText( tr("Default") );
                  myMulticastTtlSpinBox->setToolTip( tr("The multicast time-to-live, in seconds.") );
                  fieldsLayout->addWidget( myMulticastTtlSpinBox );

                  // Create the subnet mask edit box.
                  mySubnetMaskEdit = new QLineEdit();
                  mySubnetMaskEdit->setToolTip( tr("The subnet mask the "
                     "broker should use with all IP addresses. Only necessary\n"
                     "if your subnet mask cannot be determined automatically.") );
                  fieldsLayout->addWidget( mySubnetMaskEdit );
               }
               advancedLayout->addLayout( fieldsLayout );
            }
            advancedVertLayout->addLayout( advancedLayout );
         }
         myAdvancedWidget->setLayout( advancedVertLayout );
         mainLayout->addWidget( myAdvancedWidget );
         myAdvancedWidget->hide();

         // Squish the widgets to the top.
         mainLayout->addStretch( 1 );

         setLayout( mainLayout );
      }

      void DtDisConnectionSettingsWidget::connectToSignals()
      {
         connect( myPortSpinBox, SIGNAL(valueChanged(int)),
            SLOT(on_portSpinBox_valueChanged(int)) );
         connect( myExerciseIdSpinBox, SIGNAL(valueChanged(int)),
            SLOT(on_exerciseIdSpinBox_valueChanged(int)) );
         connect( myNicAddressComboBox, SIGNAL(currentIndexChanged(const QString&)),
            SLOT(on_nicAddressComboBox_currentIndexChanged(const QString&)) );
         connect( myAdvancedButton, SIGNAL(toggled(bool)),
            SLOT(on_advancedButton_toggled(bool)) );
         connect( myDestinationAddressEdit, SIGNAL(editingFinished()),
            SLOT(on_destinationAddressEdit_editingFinished()) );
         connect( myMulticastAddressesEdit, SIGNAL(editingFinished()),
            SLOT(on_multicastAddressesEdit_editingFinished()) );
         connect( myMulticastAddressEditButton, SIGNAL(released()),
            SLOT(on_multicastAddressEditButton_released()) );
         connect( mySendBufferSizeSpinBox, SIGNAL(valueChanged(int)),
            SLOT(on_sendBufferSizeSpinBox_valueChanged(int)) );
         connect( myRecvBufferSizeSpinBox, SIGNAL(valueChanged(int)),
            SLOT(on_recvBufferSizeSpinBox_valueChanged(int)) );
         connect( myMulticastTtlSpinBox, SIGNAL(valueChanged(int)),
            SLOT(on_multicastTtlSpinBox_valueChanged(int)) );
         connect( mySubnetMaskEdit, SIGNAL(editingFinished()),
            SLOT(on_subnetMaskEdit_editingFinished()) );
      }

      void DtDisConnectionSettingsWidget::populateAvailableNicAddresses()
      {
         // Block signals while populating the combo box.
         bool blocked = myNicAddressComboBox->blockSignals( true );

         DtInetUtils::DtHostDeviceList deviceList;
         DtInetUtils::DtHostDeviceList::iterator deviceItr;
         DtInetUtils::DtHostDeviceList::iterator deviceEnd;

         // Add the default address if its valid.
         DtInetAddr defaultDeviceAddress;
         if ( ! defaultDeviceAddress.isAnyAddr() )
         {
            myNicAddressComboBox->addItem(
               defaultDeviceAddress.toDtString().string() );
         }

         // Get the supported IPv4 addresses.
         deviceList = DtInetUtils::scanInetDevices( true, false );
         deviceItr = deviceList.begin();
         deviceEnd = deviceList.end();
         for ( ; deviceItr != deviceEnd; ++deviceItr )
         {
            DtInetDeviceSP device = *deviceItr;
            if ( device && device->ipv4Addr() && *device->ipv4Addr() != defaultDeviceAddress )
            {
               myNicAddressComboBox->addItem( device->ipv4Addr()->toDtString().string() );
            }
         }

         // Get the supported IPv6 addresses.
         deviceList = DtInetUtils::scanIpv6Devices( true );
         deviceItr = deviceList.begin();
         deviceEnd = deviceList.end();
         for ( ; deviceItr != deviceEnd; ++deviceItr )
         {
            DtInetDeviceSP device = *deviceItr;
            if ( device && device->ipv6Addr() && *device->ipv6Addr() != defaultDeviceAddress )
            {
               myNicAddressComboBox->addItem( device->ipv6Addr()->toDtString().string() );
            }
         }

         // Enable signals for the combo box again, now that we're done.
         myNicAddressComboBox->blockSignals( blocked );
      }

      void DtDisConnectionSettingsWidget::applyCurrentSettings()
      {
         disInitializer()->setDisPort( port() );
         disInitializer()->setExerciseId( exerciseId() );
         disInitializer()->setDeviceAddress( deviceAddress().toLatin1().data() );
         disInitializer()->setDestinationAddress( destinationAddress().toLatin1().data() );
         disInitializer()->setSocketSendBufferSize( socketSendBufferSize() );
         disInitializer()->setSocketReceiveBufferSize( socketReceiveBufferSize() );
         disInitializer()->setMulticastTimeToLive( multicastTimeToLive() );
         disInitializer()->setSubnetMask( subnetMask().toLatin1().data() );

         std::vector<DtString> result;
         QStringList value = disMcastSubscriptionSet();
         QStringList::iterator itr = value.begin();
         QStringList::iterator end = value.end();
         for ( ; itr != end; ++itr )
         {
            result.push_back( (*itr).toLatin1().data() );
         }
         disInitializer()->setMcastSubscriptionSet( result );
      }

      void DtDisConnectionSettingsWidget::loadCurrentSettings()
      {
         setPort( disInitializer()->disPort() );
         setExerciseId( disInitializer()->exerciseId() );
         setDeviceAddress( disInitializer()->deviceAddress().c_str() );
         setDisMcastSubscriptionSet( disInitializer()->mcastSubscriptionSet() );
         setSocketSendBufferSize( disInitializer()->socketSendBufferSize() );
         setSocketReceiveBufferSize( disInitializer()->socketReceiveBufferSize() );
         setMulticastTimeToLive( disInitializer()->multicastTimeToLive() );
         setSubnetMask( disInitializer()->subnetMask().c_str() );

         // Only set the destination address if it's valid.
         DtString destAddr = disInitializer()->destinationAddress();
         if ( ! destAddr.isEmpty() && destAddr != "0.0.0.0" )
         {
            setDestinationAddress( destAddr.c_str() );
         }
      }

      void DtDisConnectionSettingsWidget::setPort( int port )
      {
         bool blocked = myPortSpinBox->blockSignals( true );
         myPortSpinBox->setValue( port );
         myPortSpinBox->blockSignals( blocked );
      }

      int DtDisConnectionSettingsWidget::port() const
      {
         return myPortSpinBox->value();
      }

      void DtDisConnectionSettingsWidget::setExerciseId( int id )
      {
         bool blocked = myExerciseIdSpinBox->blockSignals( true );
         myExerciseIdSpinBox->setValue( id );
         myExerciseIdSpinBox->blockSignals( blocked );
      }

      int DtDisConnectionSettingsWidget::exerciseId() const
      {
         return myExerciseIdSpinBox->value();
      }

      void DtDisConnectionSettingsWidget::setDeviceAddress( const QString& addr )
      {
         // Block signals then call the slot manually to ensure it is
         // called even if the value didn't change (but only once).
         bool previousFlag = myNicAddressComboBox->blockSignals( true );
         int index = myNicAddressComboBox->findText( addr );
         myNicAddressComboBox->setCurrentIndex( MAXVAL(index,0) );
         myNicAddressComboBox->blockSignals( previousFlag );

         // Update the destination address to the nic's default (doesn't count as edit).
         previousFlag = myIsEdited;
         on_nicAddressComboBox_currentIndexChanged( myNicAddressComboBox->currentText() );
         myIsEdited = previousFlag;
      }

      QString DtDisConnectionSettingsWidget::deviceAddress() const
      {
         return myNicAddressComboBox->currentText();
      }

      void DtDisConnectionSettingsWidget::setDestinationAddress( const QString& addr )
      {
         bool blocked = myDestinationAddressEdit->blockSignals( true );
         myDestinationAddressEdit->setText( addr );
         myDestinationAddressEdit->blockSignals( blocked );
      }

      QString DtDisConnectionSettingsWidget::destinationAddress() const
      {
         return myDestinationAddressEdit->text();
      }

      void DtDisConnectionSettingsWidget::setDisMcastSubscriptionSet(
         const std::vector<DtString>& mcastSet )
      {
         QStringList result;
         std::vector<DtString>::const_iterator itr = mcastSet.begin();
         std::vector<DtString>::const_iterator end = mcastSet.end();
         for ( ; itr != end; ++itr )
         {
            result << itr->string();
         }

         bool blocked = myMulticastAddressesEdit->blockSignals( true );
         myMulticastAddressesEdit->setText( result.join(";") );
         myMulticastAddressesEdit->blockSignals( blocked );
      }

      QStringList DtDisConnectionSettingsWidget::disMcastSubscriptionSet() const
      {
         return myMulticastAddressesEdit->text().split( ";", QString::SkipEmptyParts );
      }

      void DtDisConnectionSettingsWidget::setSocketSendBufferSize( int sendBufferSize )
      {
         bool blocked = mySendBufferSizeSpinBox->blockSignals( true );
         mySendBufferSizeSpinBox->setValue( sendBufferSize );
         mySendBufferSizeSpinBox->blockSignals( blocked );
      }

      int DtDisConnectionSettingsWidget::socketSendBufferSize() const
      {
         return mySendBufferSizeSpinBox->value();
      }

      void DtDisConnectionSettingsWidget::setSocketReceiveBufferSize( int recvBufferSize )
      {
         bool blocked = myRecvBufferSizeSpinBox->blockSignals( true );
         myRecvBufferSizeSpinBox->setValue( recvBufferSize );
         myRecvBufferSizeSpinBox->blockSignals( blocked );
      }

      int DtDisConnectionSettingsWidget::socketReceiveBufferSize() const
      {
         return myRecvBufferSizeSpinBox->value();
      }

      void DtDisConnectionSettingsWidget::setMulticastTimeToLive( int mcastTtl )
      {
         bool blocked = myMulticastTtlSpinBox->blockSignals( true );
         myMulticastTtlSpinBox->setValue( mcastTtl );
         myMulticastTtlSpinBox->blockSignals( blocked );
      }

      int DtDisConnectionSettingsWidget::multicastTimeToLive() const
      {
         return myMulticastTtlSpinBox->value();
      }

      void DtDisConnectionSettingsWidget::setSubnetMask( const QString& subnetMask )
      {
         bool blocked = mySubnetMaskEdit->blockSignals( true );
         mySubnetMaskEdit->setText( subnetMask );
         mySubnetMaskEdit->blockSignals( blocked );
      }

      QString DtDisConnectionSettingsWidget::subnetMask() const
      {
         return mySubnetMaskEdit->text();
      }

      void DtDisConnectionSettingsWidget::on_portSpinBox_valueChanged( int newPort )
      {
         myIsEdited = true;
      }

      void DtDisConnectionSettingsWidget::on_exerciseIdSpinBox_valueChanged( int newId )
      {
         myIsEdited = true;
      }

      void DtDisConnectionSettingsWidget::on_nicAddressComboBox_currentIndexChanged( const QString& newNicAddr )
      {
         // If user has set a destination address for this NIC, populate
         // the field with that. Otherwise, set the destination address
         // to the NIC's default.
         UserNicDestAddrs::iterator itr = myUserNicDestinationAddresses.find( newNicAddr );
         if ( itr == myUserNicDestinationAddresses.end() )
         {
            QString destAddr = defaultBroadcastAddr( newNicAddr );
            myIsEdited = ( destinationAddress() != destAddr );
            setDestinationAddress( destAddr );
         }
         else
         {
            myIsEdited = ( destinationAddress() != itr->second );
            setDestinationAddress( itr->second );
         }
      }

      void DtDisConnectionSettingsWidget::on_advancedButton_toggled( bool enabled )
      {
         if ( enabled )
         {
            myAdvancedButton->setIcon( QIcon("../data/images/DarkMode/UtilityCollapse.svg") );
         }
         else
         {
            myAdvancedButton->setIcon( QIcon("../data/images/DarkMode/UtilityExpand.svg") );
         }
         myAdvancedWidget->setVisible( enabled );
      }

      void DtDisConnectionSettingsWidget::on_destinationAddressEdit_editingFinished()
      {
         DtString newDestAddr = myDestinationAddressEdit->text().toLatin1().data();
         QString currentNicAddr = myNicAddressComboBox->currentText();

         // Validate the new destination address.
         if ( ! DtInetUtils::isIpv4AddrString(newDestAddr) &&
              ! DtInetUtils::isIpv6AddrString(newDestAddr) )
         {
            // Restore destination address to either user inputted value
            // (if available) or the NICs default broadcast address.
            UserNicDestAddrs::iterator itr =
               myUserNicDestinationAddresses.find( currentNicAddr );
            if ( newDestAddr.isEmpty() || itr == myUserNicDestinationAddresses.end() )
            {
               // If user cleared the field or there were no user addresses..

               // Use the default address for the current NIC.
               QString bcastAddr = defaultBroadcastAddr( currentNicAddr );
               setDestinationAddress( bcastAddr );

               // If ther user cleared the field, store the default as a user address.
               // This will override the previous address the user cleared.
               if ( newDestAddr.isEmpty() )
               {
                  myUserNicDestinationAddresses[currentNicAddr] = bcastAddr;
               }
            }
            else
            {
               // If user destination address was found, set it.
               setDestinationAddress( itr->second );
            }

            // Tell the user they input a bad destination address (not on clear).
            if ( ! newDestAddr.isEmpty() )
            {
               QMessageBox mb;
               mb.setText( tr("Destination address must be a valid IP Address") );
               mb.setWindowTitle( tr("Invalid IP Address") );
               mb.setIcon( QMessageBox::Warning );
               mb.exec();
            }

            // The value reverted to counts as a change.
            myIsEdited = true;

            return;
         }

         // Save user edited destination address in case of nic address changes.
         // This is so the user's destination address will be restored if the
         // NIC address is changed to something else then changed back.
         if ( ! newDestAddr.isEmpty() )
         {
            myUserNicDestinationAddresses[currentNicAddr] = newDestAddr;
         }
         else
         {
            setDestinationAddress( defaultBroadcastAddr(currentNicAddr) );
         }

         myIsEdited = true;
      }

      void DtDisConnectionSettingsWidget::on_multicastAddressesEdit_editingFinished()
      {
         // Validate the addresses in the multicast addresses field.
         QStringList mcastAddresses = disMcastSubscriptionSet();
         validateMulticastAddresses( mcastAddresses );

         // Set the field to the new set of addresses.
         QString newMcastAddrsString = mcastAddresses.join(";");
         if ( myMulticastAddressesEdit->text() != newMcastAddrsString )
         {
            myMulticastAddressesEdit->setText( newMcastAddrsString );
         }
         myIsEdited = true;
      }

      void DtDisConnectionSettingsWidget::on_multicastAddressEditButton_released()
      {
         // Display the editor dialog and abort if user cancelled.
         DtCollectionEditor editor( this );
         editor.setCollection( disMcastSubscriptionSet() );
         if ( editor.exec() == QDialog::Rejected )
         {
            return;
         }

         // Validate the addresses returned from the editing dialog.
         QStringList newMulticastAddresses = editor.collection();
         validateMulticastAddresses( newMulticastAddresses );

         // Set the field to the new set of addresses.
         QString newMcastAddrsString = newMulticastAddresses.join(";");
         if ( myMulticastAddressesEdit->text() != newMcastAddrsString )
         {
            myMulticastAddressesEdit->setText( newMcastAddrsString );
            myIsEdited = true;
         }
      }

      void DtDisConnectionSettingsWidget::on_sendBufferSizeSpinBox_valueChanged( int sendBufferSize )
      {
         myIsEdited = true;
      }

      void DtDisConnectionSettingsWidget::on_recvBufferSizeSpinBox_valueChanged( int recvBufferSize )
      {
         myIsEdited = true;
      }

      void DtDisConnectionSettingsWidget::on_multicastTtlSpinBox_valueChanged( int mcastTtl )
      {
         myIsEdited = true;
      }

      void DtDisConnectionSettingsWidget::on_subnetMaskEdit_editingFinished()
      {
         DtString newSubnetMask = mySubnetMaskEdit->text().toLatin1().data();

         // Only perform validation if the subnet mask isn't empty.
         if ( ! newSubnetMask.isEmpty() )
         {
            // Validate the new destination address.
            if ( ! DtInetUtils::isIpv4AddrString(newSubnetMask) &&
                 ! DtInetUtils::isIpv6AddrString(newSubnetMask) )
            {
               // Tell the user their subnet mask was bad.
               QMessageBox mb;
               mb.setText( tr("Subnet Mask must be a valid IP Address") );
               mb.setWindowTitle( tr("Invalid IP Address") );
               mb.setIcon( QMessageBox::Warning );
               mb.exec();

               // Restore the subnet mask to its previous state.
               setSubnetMask( disInitializer()->subnetMask().string() );

               // Abort.
               return;
            }
         }

         // If change was valid, set the edited flag.
         myIsEdited = true;
      }

      QString DtDisConnectionSettingsWidget::defaultBroadcastAddr( const QString& nicAddr )
      {
         DtInetAddr nicInetAddr( nicAddr.toLatin1().data() );
         return nicInetAddr.getBroadcastAddr()->toDtString().string();
      }

      bool DtDisConnectionSettingsWidget::validAddresses(
         const QStringList& mcastAddresses, QStringList& badAddresses )
      {
         bool valid = true;
         QStringList::const_iterator itr = mcastAddresses.begin();
         QStringList::const_iterator end = mcastAddresses.end();
         for ( ; itr != end; ++itr )
         {
            if ( ! DtInetUtils::isIpv4AddrString(itr->toLatin1().data()) &&
                 ! DtInetUtils::isIpv6AddrString(itr->toLatin1().data()) )
            {
               badAddresses.push_back( *itr );
               valid = false;
            }
         }

         return valid;
      }

      QStringList DtDisConnectionSettingsWidget::validateMulticastAddresses( QStringList& mcastAddrs )
      {
         QStringList badApples;
         if ( ! validAddresses(mcastAddrs,badApples) )
         {
            // Tell the user the multicast address was bad.
            QString error;
            QMessageBox mb;
            if ( badApples.size() == 1 )
            {
               mb.setWindowTitle( tr("Invalid IP Address") );
               error = tr("Invalid multicast address")+": ";
            }
            else
            {
               mb.setWindowTitle( tr("Invalid IP Addresses") );
               error = tr("Invalid multicast addresses")+": ";
            }

            // Iterate over the bad addresses, remove them
            // from the field, and add them to the error message.
            QStringList::iterator itr = badApples.begin();
            QStringList::iterator end = badApples.end();
            for ( ; itr != end; ++itr )
            {
               mcastAddrs.removeAll( *itr );
               if ( itr != badApples.begin() )
               {
                  error += ", ";
               }

               error += (*itr);
            }

            // Set the message box's icon and error string and show it.
            mb.setIcon( QMessageBox::Warning );
            mb.setText( error );
            mb.exec();
         }

         return badApples;
      }

   }
}
