/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file entityTranslator.cxx
//! \brief Contains the DtEntityTranslator class definition.
//! \ingroup disBroker

#include <disBroker/entityTranslator.h>
#include <disBroker/disBrokerInitializer.h>
#include <vlpi/deadReckoner.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtEntityTranslator::DtEntityTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalEntity::theKind )
         , myPortalReflectedDiGuyManager( 0 )
      {
         try
         {
            DtEntityPublisher::setDfltTimeThreshold( disBroker()->heartbeatInterval() );
         }
         DtCATCH_AND_PROPAGATE( DtException );
      }

      DtEntityTranslator::~DtEntityTranslator()
      {
      }

      void DtEntityTranslator::tick()
      {
         ParentClass::tick();

         DtBrokerObject* brokerObj;
         PortalDiGuyPublisherMap::iterator pdiItr = myPortalDiGuyPublisherMap.begin();
         PortalDiGuyPublisherMap::iterator pdiEnd = myPortalDiGuyPublisherMap.end();
         for ( ; pdiItr != pdiEnd; ++pdiItr )
         {
            EntityByEntityIdMap::iterator brokerObjItr =
               myDisEntityByEntityIdMap.find( pdiItr->first );
            if ( brokerObjItr != myDisEntityByEntityIdMap.end() )
            {
               brokerObj = brokerObjItr->second;
               if ( pdiItr->second && brokerObj->isPublishable() )
               {
                  try
                  {
                     pdiItr->second->tick();
                  }
                  DtCATCH_AND_PROPAGATE( DtException )
               }
            }
         }
      }

      void DtEntityTranslator::initializeDisCallbacks()
      {
         ParentClass::initializeDisCallbacks();
         myDisReflectedList->setProcessDiGuyPdus(true); //Allow processing of DI Guy PDUs
      }

      void DtEntityTranslator::initializePortalCallbacks()
      {
         DtDisObjectTranslator<ENTITY_TEMPLATE_ARGS>::initializePortalCallbacks();

         myPortalReflectedDiGuyManager = new DtPortalReflectedDiGuyManager( disBroker()->portalConnection() );
         myPortalReflectedDiGuyManager->addAdditionCallback( DtEntityTranslator::portalDiGuyAddedCb, this );
         myPortalReflectedDiGuyManager->addRemovalCallback( DtEntityTranslator::portalDiGuyDeletedCb, this );
         myPortalReflectedDiGuyManager->setDiscoveryCondition( DtEntityTranslator::portalDiGuyDiscoveryCriteria, this );
      }

      void DtEntityTranslator::removePortalCallbacks()
      {
         if ( myPublishEnabled && myPortalReflectedManager )
         {
            // Callbacks will be removed when the list is deleted. Also,
            // removal callbacks will need to be called on list deletion.
            DtDELETE( myPortalReflectedDiGuyManager );
         }

         DtDisObjectTranslator<ENTITY_TEMPLATE_ARGS>::removePortalCallbacks();
      }
      //
      // Static Object Discovery/Update/Delete Callbacks.
      //

      bool DtEntityTranslator::portalDiGuyDiscoveryCriteria(
         const DtPortalReflectedObject* object, void* usr )
      {
         if ( object )
         {
            // DI-Guys must have a valid entity ID.
            DtPortalReflectedDiGuy* refDiGuy = (DtPortalReflectedDiGuy*) object;
            return ( refDiGuy->sr()->entityId() != DtEntityIdentifier() );
         }
         return false;
      }

      void DtEntityTranslator::portalDiGuyAddedCb(
         const DtPortalReflectedDiGuy& reflectedObj, void* usr )
      {
         DtEntityTranslator* et = (DtEntityTranslator*) usr;
         et->discoverPortalDiGuy( reflectedObj );
      }

      void DtEntityTranslator::portalDiGuyUpdatedCb(
         const DtPortalReflectedDiGuy& reflectedObj, void* usr )
      {
         DtEntityTranslator* et = (DtEntityTranslator*) usr;
         et->receivePortalDiGuyUpdate( reflectedObj );
      }

      void DtEntityTranslator::portalDiGuyDeletedCb(
         const DtPortalReflectedDiGuy& reflectedObj, void* usr )
      {
         DtEntityTranslator* et = (DtEntityTranslator*) usr;
         et->removePortalDiGuy( &reflectedObj );
      }

      //
      // Virtual Object Discovery/Update/Delete Callbacks.
      //

      bool DtEntityTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedEntity* refObj )
      {
         // Entities need an Entity ID to be discovered.
         if ( refObj->sr()->entityId() == DtEntityIdentifier() )
         {
            DtInfo << "DtEntityTranslator: " << brokerObj->objectName() <<
               ": Entity Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Entity ID" );
            return false;
         }

         if ( disBroker()->disInitializer()->discoveryCriteria()->entityNeedsEntityType()
            && refObj->sr()->entityType() == DtEntityType::nullType() )
         {
            DtInfo << "DtEntityTranslator: " << brokerObj->objectName() <<
               ": Entity Type not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Entity Type" );
            return false;
         }
         if ( disBroker()->disInitializer()->discoveryCriteria()->entityNeedsLocation()
            && refObj->sr()->location() == DtVector() )
         {
            DtInfo << "DtEntityTranslator: " << brokerObj->objectName() <<
               ": Location not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Location" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      void DtEntityTranslator::discoverDisObject( DtReflectedEntity& reflectedObj )
      {
         // Make sure the broker object is instantiated.
         DtBrokerObject* brokerObject = findBrokerObject( &reflectedObj );
         if ( ! brokerObject )
         {
            brokerObject = createBrokerObject( &reflectedObj );
         }

         // Add the entity to the Entity ID map.
         DtEntityIdentifier entityId( reflectedObj.esr()->entityId() );
         myDisEntityByEntityIdMap.insert( std::make_pair(entityId,brokerObject) );

         // Call the base class implementation.
         ParentClass::discoverDisObject( reflectedObj );
      }

      void DtEntityTranslator::discoverPortalObject( const DtPortalReflectedEntity& reflectedObj )
      {
         // Create BrokerObjectStateRepository and store publisher in it.
         DtBrokerObject* brokerObject = findBrokerObject( &reflectedObj );
         if ( ! brokerObject )
         {
            brokerObject = createBrokerObject( &reflectedObj );
         }

         // Add the entity to the Entity ID map.
         DtEntityIdentifier entityId( reflectedObj.sr()->entityId() );
         myPortalEntityByEntityIdMap.insert( std::make_pair(entityId,brokerObject) );

         // Discover DI-Guy for entity from waitlist (if present).
         DiGuyWaitList::iterator itr = myDiGuyWaitList.find( entityId );
         if ( itr != myDiGuyWaitList.end() )
         {
            const DtPortalReflectedDiGuy* refDiGuy = itr->second;
            myDiGuyWaitList.erase( itr );
            discoverPortalDiGuy( *refDiGuy );
         }

         // Call the base class implementation.
         ParentClass::discoverPortalObject( reflectedObj );
      }

      void DtEntityTranslator::discoverPortalDiGuy( const DtPortalReflectedDiGuy& reflectedObj )
      {
         // Look up the entity for the discovered DI-Guy.
         DtEntityIdentifier entityId( reflectedObj.sr()->entityId() );
         EntityByEntityIdMap::iterator entityItr = myPortalEntityByEntityIdMap.find( entityId );
         if ( entityItr == myPortalEntityByEntityIdMap.end() )
         {
            // Add the DI-Guy to the wait list if he isn't there already.
            DiGuyWaitList::iterator diGuyItr = myDiGuyWaitList.find( entityId );
            if ( diGuyItr == myDiGuyWaitList.end() )
            {
               myDiGuyWaitList.insert( std::make_pair(entityId,&reflectedObj) );
            }

            // Abort.
            return;
         }

         // Update the entity with the info from the di-guy update.
         reflectedObj.addUpdateCallback( DtEntityTranslator::portalDiGuyUpdatedCb, this );
         receivePortalDiGuyUpdate( reflectedObj );
      }

      DtString DtEntityTranslator::disObjectName(
         const DtPortalReflectedEntity* refObj ) const
      {
         return refObj->sr()->entityId().string();
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<ENTITY_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedEntity* refObj, const DtString& identifier )
      {
         return mapObjectId( DtEntityIdentifier(identifier) );
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<ENTITY_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedEntity* refObj, const DtEntityIdentifier& name )
      {
         DtEntityPublisher* publisher = NULL;
         try
         {
            // Instantiate the publisher.
            publisher = new DtEntityPublisher( refObj->sr()->entityType(), disBroker()->connection(),
               (DtDeadReckonTypes) refObj->sr()->algorithm(), (DtForceType) refObj->sr()->forceId(),
               DtEntityType(refObj->sr()->guise().c_str()), name );
            publisher->setSendSeesPdus( disBroker()->disInitializer()->sendSeesPdus() );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      void DtEntityTranslator::createDisPublisher( DtBrokerObject* brokerObj )
      {
         ParentClass::createDisPublisher( brokerObj );

         DtEntityPublisher* publisher =
            static_cast<DtEntityPublisher*>( brokerObj->publisherPtr() );
         if ( ! publisher )
         {
            return;
         }

         // This is a dead reckoning hack. Basically there is no dead reckoning in the Portal,
         // none at all, not even for the reflected objects. So, since the Publisher
         // always needs to have the "real" value (and that means dead reckoned value) we
         // turn on dead reckoning in the publisher.
         //
         // Why does the publisher need to have the DR Value? Two fold.
         // 1) as we tick ALL the TIME, every tick the sr is compared to the ASB sr, which
         // is dead reckoned. And if the two are off then you get a packet flood.
         // 2) A late jointer might request an update for this object, and if all you have
         // is old position/vel/orientation data then the late jointer will not have
         // an accurate picture of the world.
         publisher->entityStateRep()->useDeadReckoner();
         publisher->entityStateRep()->useRelativeDeadReckoner();
         publisher->entityStateRep()->setClock( disBroker()->connection()->clock() );
      }

      void DtEntityTranslator::updateDisBrokerObject( DtBrokerObject* brokerObj,
         const DtEntityStateRepository& sr )
      {
         ParentClass::updateDisBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.entityId().string() );
         brokerObj->setMarkingText( sr.markingText() );
         brokerObj->setEntityType( sr.entityType() );
      }

      void DtEntityTranslator::updateFilteredState( DtBrokerObject* brokerObj,
         DtPortalEntityPublisher* publisher, DtReflectedEntity* refObj )
      {
         if ( publisher )
         {
            // Get the Entity ID then see if this has been marked as a filtered object.
            const DtVector loc = refObj->esr()->location();
            const DtString id = publisher->sr()->identifier();
            const DtString markingText = brokerObj->markingText();
            const DtEntityType entityType = refObj->esr()->entityType();
            const DtString entityId = refObj->esr()->entityId().string();
            const DtFilterManager& objectFilters = myBroker->objectFilters();
            const bool isFiltered = objectFilters.isTypeFiltered( entityType )
               || objectFilters.isMarkingTextFiltered( markingText )
               || objectFilters.isNameFiltered( entityId )
               || objectFilters.isNameFiltered( id )
               || filterLocation( *refObj, loc );
            publisher->sr()->setFiltered( isFiltered );
            brokerObj->setIsFiltered( isFiltered );
         }
      }

      void DtEntityTranslator::updateFilteredState( DtBrokerObject* brokerObj,
         const DtPortalReflectedEntity* refObj )
      {
         //Check against geoFilters.  Filter published entities that do not fall within
         //set geographic filters.
         const DtVector loc = refObj->sr()->location();
         const DtFilterManager& objectFilters = myBroker->objectFilters();
         const bool isFiltered = filterLocation( *refObj, loc );

         brokerObj->setIsFiltered( isFiltered );
      }

      void DtEntityTranslator::updatePortalBrokerObject(
         DtBrokerObject* brokerObj, const DtPortalEntity& sr )
      {
         ParentClass::updatePortalBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.entityId().string() );
         brokerObj->setMarkingText( sr.markingText() );
         brokerObj->setEntityType( sr.entityType() );
      }

      void DtEntityTranslator::receivePortalDiGuyUpdate( const DtPortalReflectedDiGuy& reflectedObj )
      {
         DtEntityIdentifier entityId( reflectedObj.sr()->entityId() );
         EntityByEntityIdMap::iterator itr = myPortalEntityByEntityIdMap.find( entityId );
         if ( itr == myPortalEntityByEntityIdMap.end() || ! itr->second )
         {
            DtWarn << "Received DI-Guy update for deleted entity: "
               << entityId << std::endl;
            return;
         }

         DtBrokerObject* brokerObj = itr->second;
         brokerObj->setLastUpdate( myBroker->simTime() );
         if ( ! brokerObj->isPublishable() )
         {
            DtPortalReflectedEntity* refObj =
               (DtPortalReflectedEntity*) brokerObj->reflectedObjPtr();
            brokerObj->setIsPublishable( isDisPublishable(brokerObj,refObj) );
         }

         callObjectUpdateCallbacks( brokerObj );

         // Bail out if the entity is dropped.
         if ( brokerObj->isDropped() )
         {
            return;
         }

         // Get and cast the publisher and assert that it exists.
         DtEntityPublisher* publisher = static_cast<DtEntityPublisher*>( brokerObj->publisherPtr() );
         assert( publisher );

         // Set whether the publisher should send DI-Guy PDUs.
         publisher->setSendDiGuyPdus( disBroker()->disInitializer()->sendDiGuyPdus() );

         DtEntityStateRepository& newSr = *(publisher->entityStateRep());
         const DtPortalDiGuy& sr = *reflectedObj.sr();

         // Only translate the DI-Guy attributes from the update.
         translate( &newSr, sr );

         if ( myBroker->brokerInitializer()->oneToOneMapping() )
         {
            publisher->forceUpdate();
         }

         if ( myBroker->isTranslatorDebuggingOn(name()) )
         {
            printIncomingOutgoingStateReps( sr, newSr );
         }

         if ( isPublishEnabled() )
         {
            publisher->tick();
         }

         performPortalDebugging( sr, newSr );
      }

      void DtEntityTranslator::removeDisObject(
         const DtReflectedObject& refObj )
      {
         DtReflectedEntity& entity = (DtReflectedEntity&) refObj;
         DtEntityIdentifier entityId( entity.esr()->entityId() );

         // Remove the entity from the Entity ID map.
         EntityByEntityIdMap::iterator eItr =
            myDisEntityByEntityIdMap.find( entityId );
         if ( eItr != myDisEntityByEntityIdMap.end() )
         {
            myDisEntityByEntityIdMap.erase( eItr );
         }

         // Delete the DI-Guy publisher for the entity.
         PortalDiGuyPublisherMap::iterator pItr =
            myPortalDiGuyPublisherMap.find( entityId );
         if ( pItr != myPortalDiGuyPublisherMap.end() )
         {
            DtPortalDiGuyPublisher* publisher = pItr->second;
            myPortalDiGuyPublisherMap.erase( pItr );
            DtDELETE( publisher );
         }

         // Call the default removeDisObject implementation.
         ParentClass::removeDisObject( refObj );
      }

      void DtEntityTranslator::removePortalObject(
         const DtPortalReflectedEntity& refObj )
      {
         // Remove the entity from the Entity ID map.
         DtEntityIdentifier entityId( refObj.sr()->entityId() );
         EntityByEntityIdMap::iterator itr = myPortalEntityByEntityIdMap.find( entityId );
         if ( itr != myPortalEntityByEntityIdMap.end() )
         {
            myPortalEntityByEntityIdMap.erase( itr );
         }

         // Call the default removePortalObject implementation.
         ParentClass::removePortalObject( refObj );
      }

      void DtEntityTranslator::removePortalDiGuy(
         const DtPortalReflectedDiGuy* diGuy )
      {
         // Remove the DI-Guy from the waitlist if he's there.
         DtEntityIdentifier entityId( diGuy->sr()->identifier() );
         DiGuyWaitList::iterator itr = myDiGuyWaitList.find( entityId );
         if ( itr != myDiGuyWaitList.end() )
         {
            myDiGuyWaitList.erase( itr );
         }
      }

      void DtEntityTranslator::deleteDisPublisher( DtBrokerObject* brokerObject )
      {
         DtEntityPublisher* publisher =
            static_cast<DtEntityPublisher*>( brokerObject->publisherPtr() );
         if ( publisher )
         {
            // Cache the dead reckoners for deletion.
            DtDeadReckoner* deadReckoner;
            DtDeadReckoner* relativeDeadReckoner;
            deadReckoner = publisher->entityStateRep()->usingDeadReckoner();
            relativeDeadReckoner = publisher->entityStateRep()->usingRelativeDeadReckoner();

            // Cache the as-seen-by dead reckoners for deletion.
            DtDeadReckoner* asbDeadReckoner;
            DtDeadReckoner* asbRelativeDeadReckoner;
            DtEntityStateRepository* asbEntityStateRep =
               static_cast<DtEntityStateRepository*>( publisher->approximateRemoteStateRep() );
            asbRelativeDeadReckoner = asbEntityStateRep->usingRelativeDeadReckoner();
            asbDeadReckoner = asbEntityStateRep->usingDeadReckoner();

            // Unmap the publisher's global ID, unset from broker, and delete.
            disBroker()->globalIdMapper()->remove( publisher->globalId() );
            brokerObject->setPublisherPtr( 0 );
            DtDELETE( publisher );
         }
      }

      //
      // Primary Translation Methods.
      //

      bool DtEntityTranslator::hasDiGuyAttributes( const DtEntityStateRepository& entity )
      {
         const DtString& nullStr = DtString::nullString();
         return ( entity.diGuyAppearance() != nullStr
            || entity.diGuyBodyAppearance() != nullStr
            || entity.diGuyHeadAppearance() != nullStr
            || entity.diGuyItemAppearance() != nullStr
            || entity.diGuyAction() != nullStr
            || entity.diGuyType() != nullStr
            || entity.diGuyArc().size()
            || entity.diGuyShapeVariations().size()
            || entity.diGuyAccessoryAppearanceCount()
            || entity.diGuyParent() != DtEntityIdentifier()
            || entity.diGuyCharacterScale() != DtVector() );
      }

      void DtEntityTranslator::syncDisDeadReckonedValues(
         DtEntityStateRepository* destination, const DtPortalEntity& source )
      {
         destination->setLocation( source.location() );
         destination->setVelocity( source.velocity() );
         destination->setAcceleration( source.acceleration() );
         destination->setOrientation( source.orientation() );
         destination->setRotationalVelocity( source.rotationalVelocity() );
         destination->setRelativeLocation( source.relativeLocation() );
         destination->setRelativeVelocity( source.relativeVelocity() );
         destination->setRelativeAcceleration( source.relativeAcceleration() );
         destination->setRelativeOrientation( source.relativeOrientation() );
         destination->setRelativeRotationalVelocity( source.relativeRotationalVelocity() );

         if ( ! disBroker()->disInitializer()->disableArticulatedParts() )
         {
            try
            {
               const DtArticulatedPartCollection& apList = source.articulatedPartList();
               DtArticulatedPartCollection* newApList = destination->artPartList();
               *newApList = apList;
            }
            catch (DtException &)
            {
               DtWarn << "Error Parsing Articulated Parts for " << source.entityId();
            }
         }
      }

      void DtEntityTranslator::syncPortalDeadReckonedValues(
         DtPortalEntity* destination, const DtEntityStateRepository& source )
      {
         destination->setLocation( source.location() );
         destination->setVelocity( source.velocity() );
         destination->setAcceleration( source.acceleration() );
         destination->setOrientation( source.orientation() );
         destination->setRotationalVelocity( source.rotationalVelocity() );
         destination->setRelativeLocation( source.relativeLocation() );
         destination->setRelativeVelocity( source.relativeVelocity() );
         destination->setRelativeAcceleration( source.relativeAcceleration() );
         destination->setRelativeOrientation( source.relativeOrientation() );
         destination->setRelativeRotationalVelocity( source.relativeRotationalVelocity() );

         if ( ! disBroker()->disInitializer()->disableArticulatedParts() )
         {
            try
            {
               const DtArticulatedPartCollection* apList = source.artPartList();
               destination->setArticulatedPartList( (DtArticulatedPartCollection)*apList );
            }
            catch ( DtException& )
            {
               DtWarn << "Error Parsing Articulated Parts for " << source.entityId();
            }
         }
      }

      DtPortalEntity* DtEntityTranslator::translate( DtPortalEntity* destination,
         const DtEntityStateRepository& source, const DtReflectedEntity& reflectedObject )
      {
         syncPortalDeadReckonedValues( destination, source );

         destination->setFrozen( source.frozen() );
         destination->setAlgorithm( source.algorithm() );
         destination->setRelativeFrozen( source.relativeFrozen() );
         destination->setRelativeAlgorithm( source.relativeAlgorithm() );
         destination->setNature( source.nature() );
         destination->setPartPosition( source.partPosition() );
         destination->setStationName( source.stationName() );
         destination->setStationNumber( source.stationNumber() );
         destination->setRelativePosition( source.relativePosition() );
         destination->setRange( source.range() );
         destination->setBearing( source.bearing() );
         destination->setHostId( disBroker()->convertGlobalId( source.hostGlobalId() ));
         destination->setEntityId( disBroker()->convertDisEntIdToPortalEntId( source.entityId() ));
         destination->setEntityType( source.entityType() );
         /// END BASE ENTITY COPY.

         // Entity SR Copy start
         destination->setForceId( (DtForceType) source.forceId() );
         destination->setGuise( source.guise().string() );
         destination->setMarkingCharSet( source.markingCharSet() );
         destination->setMarkingText( source.markingText() );
         destination->setPowerPlantOn( source.powerPlantOn() );
         destination->setDamageState( source.damageState() );
         destination->setEngineSmokeOn( source.engineSmokeOn() );
         destination->setFlamesPresent( source.flamesPresent() );
         destination->setHasFuelSupplyCap( source.hasFuelSupplyCap() );
         destination->setHasRecoveryCap( source.hasRecoveryCap() );
         destination->setHasRepairCap( source.hasRepairCap() );
         destination->setHatchState( source.hatchState() );
         destination->setImmobilized( source.immobilized() );
         destination->setLifeformState( source.lifeformState() );
         destination->setDensity( source.density() );
         destination->setRampDeployed( source.rampDeployed() );
         destination->setSmokePlumePresent( source.smokePlumePresent() );
         destination->setTentDeployed( source.tentDeployed() );
         destination->setTrailState( source.trailState() );
         destination->setCamouflageType( source.camouflageType() );
         destination->setFirePowerDisabled( source.firePowerDisabled() );
         destination->setIsConcealed( source.isConcealed() );
         destination->setAfterburnerOn( source.afterburnerOn() );
         destination->setHasAmmunitionSupplyCap( source.hasAmmunitionSupplyCap() );
         destination->setLauncherRaised( source.launcherRaised() );
         destination->setPrimaryWeaponState( source.primaryWeaponState() );
         destination->setSecondaryWeaponState( source.secondaryWeaponState() );
         destination->setComplianceState( source.complianceState() );
         destination->setAntennaRaised( source.antennaRaised() );
         destination->setMissionKill( source.missionKill() );

         {  // Translate SEES Attributes.
            destination->setInfraredSigRepIndex( source.infraRedSigRepIndex() );
            destination->setAcousticSigRepIndex( source.acousticSigRepIndex() );
            destination->setRadarSigRepIndex( source.radarSigRepIndex() );

            // Translate Propulsion System Data.
            DtPropulsionSystemDataList destPropulsionSystems;
            int numPropulsionSystems = source.numPropulsionSystems();
            for ( int itr = 0; itr < numPropulsionSystems; ++itr )
            {
               DtPropulsionSystem srcPropulsionSystem;
               DtPropulsionSystemData destPropulsionSystem;
               source.getPropulsionSystem( itr, srcPropulsionSystem );
               destPropulsionSystem.setPowerSetting( srcPropulsionSystem.powerSetting() );
               destPropulsionSystem.setEngineRpm( srcPropulsionSystem.engineRPM() );
               destPropulsionSystems.push_back( destPropulsionSystem );
            }
            destination->setPropulsionSystemData( destPropulsionSystems );

            // Translate Nozzle System Data.
            DtNozzleSystemDataList destNozzleSystems;
            int numNozzleSystems = source.numNozzleSystems();
            for ( int itr = 0; itr < numNozzleSystems; ++itr )
            {
               DtNozzleSystemData destNozzleSystem;
               DtVectoringNozzleSystem srcNozzleSystem;
               source.getNozzleSystem( itr, srcNozzleSystem );
               destNozzleSystem.setVerticalDeflectionAngle( srcNozzleSystem.vertDeflection() );
               destNozzleSystem.setHorizontalDeflectionAngle( srcNozzleSystem.horDeflection() );
               destNozzleSystems.push_back( destNozzleSystem );
            }
            destination->setNozzleSystemData( destNozzleSystems );
         }

         // Translate the various light state fields into one value and store in portal.
         DtU32 lightState = ( source.lightState( DtHeadLightsOn ) << DtHeadLightsOn );
         lightState |= ( source.lightState( DtTailLightsOn ) << DtTailLightsOn );
         lightState |= ( source.lightState( DtBrakeLightsOn ) << DtBrakeLightsOn );
         lightState |= ( source.lightState( DtBlackOutLightsOn ) << DtBlackOutLightsOn );
         lightState |= ( source.lightState( DtBlackOutBrakeLightsOn ) << DtBlackOutBrakeLightsOn );
         lightState |= ( source.lightState( DtSpotLightsOn ) << DtSpotLightsOn );
         lightState |= ( source.lightState( DtInteriorLightsOn ) << DtInteriorLightsOn );
         destination->setLightState( lightState );

         if ( ! disBroker()->disInitializer()->disableArticulatedParts() )
         {
            try
            {
               const DtArticulatedPartCollection* apList = source.artPartList();
               destination->setArticulatedPartList( (DtArticulatedPartCollection)*apList );
            }
            catch ( DtException& )
            {
               DtWarn << "Error Parsing Articulated Parts for " << source.entityId();
            }
            try
            {
               const DtAttachedPartCollection* attList = source.attPartList();
               DtAttachedPartCollection newAttList(*attList);
               destination->setAttachedPartList( newAttList );
            }
            catch (DtException &)
            {
               DtWarn << "Error Parsing Attached Parts for " << source.entityId();
            }
         }

         // If entity has DI-Guy attributes, translate them into a new PortalDiGuy publisher.
         PortalDiGuyPublisherMap::iterator itr =
            myPortalDiGuyPublisherMap.find( destination->entityId() );
         bool entityHasDiGuyAttrs = hasDiGuyAttributes( source );
         if ( entityHasDiGuyAttrs )
         {
            if ( itr == myPortalDiGuyPublisherMap.end() )
            {
               // Instantiate publisher and translate DI-Guy attributes into it.
               DtPortalDiGuyPublisher* publisher =
                  new DtPortalDiGuyPublisher( broker()->portalConnection() );
               itr = myPortalDiGuyPublisherMap.insert(
                  std::make_pair(destination->entityId(),publisher) ).first;
            }

            // Perform the translation.
            translate( itr->second->sr(), source );

            if ( myBroker->isTranslatorDebuggingOn(name()) )
            {
               printIncomingOutgoingStateReps( source, *itr->second->sr() );
            }
         }
         else if ( itr != myPortalDiGuyPublisherMap.end() )
         {
            DtPortalDiGuyPublisher* publisher = itr->second;
            myPortalDiGuyPublisherMap.erase( itr );
            DtDELETE( publisher );
         }

         return destination;
      }

      DtEntityStateRepository* DtEntityTranslator::translate(
         DtEntityStateRepository* destination, const DtPortalEntity& source,
         const DtPortalReflectedEntity& reflectedObject )
      {
         syncDisDeadReckonedValues( destination, source );

         destination->setHostGlobalId( disBroker()->convertGlobalId( source.hostId() ));
         destination->setNature( (DtNature)source.nature() );
         destination->setPartPosition( (DtPosition)source.partPosition() );
         destination->setStationName( (DtStationName)source.stationName() );
         destination->setStationNumber( source.stationNumber() );
         destination->setRelativePosition( source.relativePosition() );
         destination->setRange( source.range() );
         destination->setBearing( source.bearing() );
         destination->setAlgorithm( (DtDeadReckonTypes)source.algorithm() );
         destination->setRelativeFrozen( source.relativeFrozen() );
         destination->setRelativeAlgorithm( (DtDeadReckonTypes)source.relativeAlgorithm() );
         destination->setEntityId( disBroker()->convertPortalEntIdToDisEntId( source.entityId() ));
         if( destination->entityId() == DtEntityIdentifier::nullId() )
         {
            // Try to map it using the portal global ID instead
            destination->setEntityId(
               disBroker()->globalIdMapper()->convertPortalGidToDisGid( source.identifier() ) );
         }
         destination->setEntityType( source.entityType() );
         /// END BASE ENTITY COPY.

         // Entity SR Copy start
         destination->setForceId( (DtForceType) source.forceId() );
         destination->setGuise( source.guise().string() );
         destination->setFrozen( source.frozen() );
         destination->setMarkingCharSet( source.markingCharSet() );
         destination->setMarkingText( source.markingText() );
         destination->setPowerPlantOn( source.powerPlantOn() );
         destination->setDamageState( (DtDamageState) source.damageState() );
         destination->setEngineSmokeOn( source.engineSmokeOn() );
         destination->setFlamesPresent( source.flamesPresent() );
         destination->setHasFuelSupplyCap( source.hasFuelSupplyCap() );
         destination->setHasRecoveryCap( source.hasRecoveryCap() );
         destination->setHasRepairCap( source.hasRepairCap() );
         destination->setHatchState( (DtHatchState) source.hatchState() );
         destination->setImmobilized( source.immobilized() );
         destination->setLifeformState( (DtLifeformState) source.lifeformState() );
         destination->setDensity( (DtDensityType) source.density() );
         destination->setRampDeployed( source.rampDeployed() );
         destination->setSmokePlumePresent( source.smokePlumePresent() );
         destination->setTentDeployed( source.tentDeployed() );
         destination->setTrailState( (DtTrailState) source.trailState() );
         destination->setCamouflageType( (DtCamouflageType) source.camouflageType() );
         destination->setFirePowerDisabled( source.firePowerDisabled() );
         destination->setIsConcealed( source.isConcealed() );
         destination->setAfterburnerOn( source.afterburnerOn() );
         destination->setHasAmmunitionSupplyCap( source.hasAmmunitionSupplyCap() );
         destination->setLauncherRaised( source.launcherRaised() );
         destination->setPrimaryWeaponState( (DtWeaponState) source.primaryWeaponState() );
         destination->setSecondaryWeaponState( (DtWeaponState) source.secondaryWeaponState() );
         destination->setComplianceState( (DtComplianceState) source.complianceState() );
         destination->setAntennaRaised( source.antennaRaised() );
         destination->setMissionKill( source.missionKill() );

         {  // Translate SEES Attributes.
            destination->setInfraRedSigRepIndex( source.infraredSigRepIndex() );
            destination->setAcousticSigRepIndex( source.acousticSigRepIndex() );
            destination->setRadarSigRepIndex( source.radarSigRepIndex() );

            {  // Translate Propulsion System Data.
               DtPropulsionSystemDataList::const_iterator itr = source.propulsionSystemData().begin();
               DtPropulsionSystemDataList::const_iterator end = source.propulsionSystemData().end();
               destination->setNumPropulsionSystems( source.propulsionSystemData().size() );
               for ( int index = 0; itr != end; ++itr, ++index )
               {
                  DtPropulsionSystem propulsionSystem;
                  propulsionSystem.setEngineRPM( itr->engineRpm() );
                  propulsionSystem.setPowerSetting( itr->powerSetting() );
                  destination->setPropulsionSystem( index, propulsionSystem );
               }
            }

            {  // Translate Nozzle System Data.
               DtNozzleSystemDataList::const_iterator itr = source.nozzleSystemData().begin();
               DtNozzleSystemDataList::const_iterator end = source.nozzleSystemData().end();
               destination->setNumNozzleSystems( source.nozzleSystemData().size() );
               for ( int index = 0; itr != end; ++itr, ++index )
               {
                  DtVectoringNozzleSystem nozzleSystem;
                  nozzleSystem.setVertDeflection( itr->verticalDeflectionAngle() );
                  nozzleSystem.setHorDeflection( itr->horizontalDeflectionAngle() );
                  destination->setNozzleSystem( index, nozzleSystem );
               }
            }
         }

         // Translate the various light state fields from the portal into the esr.
         DtU32 lightState = source.lightState();
         destination->setLightState( DtHeadLightsOn, (lightState&(0x1<<DtHeadLightsOn))>>DtHeadLightsOn );
         destination->setLightState( DtTailLightsOn, (lightState&(0x1<<DtTailLightsOn))>>DtTailLightsOn );
         destination->setLightState( DtBrakeLightsOn, (lightState&(0x1<<DtBrakeLightsOn))>>DtBrakeLightsOn );
         destination->setLightState( DtBlackOutLightsOn, (lightState&(0x1<<DtBlackOutLightsOn))>>DtBlackOutLightsOn );
         destination->setLightState( DtBlackOutBrakeLightsOn, (lightState&(0x1<<DtBlackOutBrakeLightsOn))>>DtBlackOutBrakeLightsOn );
         destination->setLightState( DtSpotLightsOn, (lightState&(0x1<<DtSpotLightsOn))>>DtSpotLightsOn );
         destination->setLightState( DtInteriorLightsOn, (lightState&(0x1<<DtInteriorLightsOn))>>DtInteriorLightsOn );

         if ( ! disBroker()->disInitializer()->disableArticulatedParts() )
         {
            try
            {
               const DtArticulatedPartCollection& apList = source.articulatedPartList();
               DtArticulatedPartCollection* newApList = destination->artPartList();
               *newApList = apList;
            }
            catch ( DtException& )
            {
               DtWarn << "Error Parsing Articulated Parts for " << source.entityId();
            }
            try
            {
               const DtAttachedPartCollection& attList = source.attachedPartList();
               DtAttachedPartCollection* newAttList = destination->attPartList();
               *newAttList = attList;
            }
            catch (DtException &)
            {
               DtWarn << "Error Parsing Attached Parts for " << source.entityId();
            }
         }

         return destination;
      }

      DtPortalDiGuy* DtEntityTranslator::translate(
         DtPortalDiGuy* destination, const DtEntityStateRepository& source )
      {
         destination->setEntityId( source.entityId() );
         destination->setParent( source.diGuyParent() );
         destination->setObjectId( source.globalId().string() );
         destination->setIdentifier( source.entityId().string() );
         destination->setBodyAppearance( source.diGuyBodyAppearance() );
         destination->setHeadAppearance( source.diGuyHeadAppearance() );
         destination->setItemAppearance( source.diGuyItemAppearance() );
         destination->setType( source.diGuyType() );

         int numAccessories = source.diGuyAccessoryAppearanceCount();
         destination->setAccessoryAppearanceCount( numAccessories );
         for ( int i = 0; i < numAccessories; ++i )
         {
            destination->setAccessoryAppearance( i, source.diGuyAccessoryAppearance(i) );
         }

         destination->setAction( source.diGuyAction() );
         destination->setActionSpeed( source.diGuyActionSpeed() );
         destination->setActionPaused( source.isDiGuyActionPaused() );
         destination->setVisible( source.isDiGuyVisible() );
         destination->setShapeVariations( source.diGuyShapeVariations() );

         const DtDIGuyObjectStateRepository* dig = source.diGuyStateRepository();
         if (dig)
         {
             destination->setUseActionPositioningFlag(dig->useActionPositioning());
             destination->setActionOffset(dig->actionOffset());
             destination->setTransitionSpeed(dig->transitionSpeed());
             destination->setBodyWeight(dig->bodyWeight());
             destination->setUnit(dig->unit());
             destination->setPersonalUnit(dig->personalUnit());
             destination->setRank(dig->rank());
             destination->setName(dig->name());
         }

         destination->setIsUpdated(true);

         return destination;
      }

      DtEntityStateRepository* DtEntityTranslator::translate(
         DtEntityStateRepository* destination, const DtPortalDiGuy& source )
      {
         destination->enableDiGuyObject();
         destination->setDiGuyParent( source.parent() );
         destination->setDiGuyAppearance( source.bodyAppearance() );
         destination->setDiGuyBodyAppearance( source.bodyAppearance() );
         destination->setDiGuyHeadAppearance( source.headAppearance() );
         destination->setDiGuyItemAppearance( source.itemAppearance() );
         destination->setDiGuyType( source.type(), source.bodyAppearance() );

         unsigned int numAccessories = source.accessoryAppearanceCount();
         destination->setDiGuyAccessoryAppearanceCount( numAccessories );
         for ( unsigned int i = 0; i < numAccessories; ++i )
         {
            destination->setDiGuyAccessoryAppearance( i, source.accessoryAppearance(i) );
         }

         destination->setDiGuyAction( source.action(), source.actionPaused(), source.actionSpeed(), 
             source.useActionPositioningFlag(), source.actionOffset(), source.transitionSpeed() );
         destination->setDiGuyVisible( source.visible() );
         destination->setDiGuyShapeVariations( source.shapeVariations() );

         destination->setDiGuyBodyWeight(source.bodyWeight());
         destination->setDiGuyUnit(source.unit());
         destination->setDiGuyPersonalUnit(source.personalUnit());
         destination->setDiGuyRank(source.rank());
         destination->setDiGuyName(source.name());

         return destination;
      }

   }
}
