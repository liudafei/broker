/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioSignalTranslator.h
//! \brief Contains the DtRadioSignalTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pRadioSignalInter.h>
#include <vl/signalInteraction.h>

namespace MAKVrExchange
{

   class DtPortalRadioSignalInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides Radio Signal interaction translation between DIS and
      //! the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtRadioSignalTranslator
         : public DtDisInteractionTranslator<DtPortalRadioSignalInteraction,DtSignalInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Radio Signal" );

         //! \brief CTOR.
         DtRadioSignalTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtRadioSignalTranslator();

         //! \brief Translates the signal interaction into the portal.
         virtual DtPortalRadioSignalInteraction* translate(
            DtPortalRadioSignalInteraction* destination,
            const DtSignalInteraction& source );

         //! \brief Translates the signal interaction from the portal.
         virtual DtSignalInteraction* translate( DtSignalInteraction*  destination,
            const DtPortalRadioSignalInteraction& source );

      };

   }
}
