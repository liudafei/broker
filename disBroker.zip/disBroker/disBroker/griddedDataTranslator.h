/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file griddedDataTranslator.h
//! \brief Contains the DtGriddedDataObjectTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/griddedDataPublisher.h>
#include <vl/reflectedGriddedDataList.h>

class DtReflectedGriddedData;
class DtGriddedDataRepository;

#define GRIDDED_DATA_TEMPLATE_ARGS \
   DtPortalGriddedDataObject, DtPortalReflectedGriddedDataObject, \
   DtReflectedGriddedData, DtReflectedGriddedDataList, \
   DtGriddedDataRepository, DtGriddedDataPublisher

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<GRIDDED_DATA_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedGriddedDataObject* refObj,
         const DtString& identifier );


      //! \brief Provides gridded data object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtGriddedDataObjectTranslator
         : public DtDisObjectTranslator<GRIDDED_DATA_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Gridded Data" );

         //! \brief CTOR.
         DtGriddedDataObjectTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtGriddedDataObjectTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedGriddedDataObject* refObj );

         //! \brief Gets the reflected object's entity id for publisher creation.
         virtual DtString disObjectName( const DtPortalReflectedGriddedDataObject* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const DtGriddedDataRepository& sr );

         //! \brief Construct the portal object name.
         //! Overridden to construct a gridded data object name.
         virtual DtString portalObjectName( const DtReflectedGriddedData* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj,
            const DtPortalGriddedDataObject& sr );

         //! \brief Translates a Gridded Data object into the portal.
         virtual DtPortalGriddedDataObject* translate( DtPortalGriddedDataObject* destination,
            const DtGriddedDataRepository& source, const DtReflectedGriddedData& refObj );

         //! \brief Translates a Gridded Data object from the portal.
         virtual DtGriddedDataRepository* translate( DtGriddedDataRepository* destination,
            const DtPortalGriddedDataObject& source, const DtPortalReflectedGriddedDataObject& refObj );

      };

   }
}
