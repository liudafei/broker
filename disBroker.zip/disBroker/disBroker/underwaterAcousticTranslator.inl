/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file underwaterAcousticTranslator.inl
//! \brief Contains the DtUnderwaterAcousticTranslator class definition.
//! \ingroup rprBroker

#ifndef _underwaterAcousticTranslator_INL_
#error "Inline definitions file must be included from declaring header."
#endif

#include <disBroker/underwaterAcousticTranslator.h>
#include <vl/underwaterAcousticsEmissionRepository.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DIS_TEMPLATE_LIST
      DtUnderwaterAcousticTranslator<DIS_TEMPLATE_FUNCTION>::DtUnderwaterAcousticTranslator(
            DtBroker* broker, const DtString& name, DtPortalMessageKind kind )
         : DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>( broker, name, kind )
      {
      }

      DIS_TEMPLATE_LIST
      DtUnderwaterAcousticTranslator<DIS_TEMPLATE_FUNCTION>::~DtUnderwaterAcousticTranslator()
      {
      }

      DIS_TEMPLATE_LIST
      DtPortalUnderwaterAcousticObject* DtUnderwaterAcousticTranslator<DIS_TEMPLATE_FUNCTION>::translate(
         DtPortalUnderwaterAcousticObject* destination, const DtUnderwaterAcousticsEmissionRepository& source,
         const T_DisReflectedObject& refObj )
      {
         // Translate embedded system attributes.
         DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::translate( destination, source, refObj );

         // Underwater Acoustic Emission Attribute Translation.
         destination->setEventIdentifier( source.eventIdentifier().string() );

         return destination;
      }

      DIS_TEMPLATE_LIST
      DtUnderwaterAcousticsEmissionRepository* DtUnderwaterAcousticTranslator<DIS_TEMPLATE_FUNCTION>::translate(
         DtUnderwaterAcousticsEmissionRepository* destination, const DtPortalUnderwaterAcousticObject& source,
         const T_PortalReflectedObject& refObj )
      {
         // Translate embedded system attributes.
         DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::translate( destination, source, refObj );

         // Underwater Acoustic Emission Attribute Translation.
         destination->setEventIdentifier( this->disBroker()->eventIdMapper()
            ->convertEventId(source.eventIdentifier()) );

         return destination;
      }

   }
}
