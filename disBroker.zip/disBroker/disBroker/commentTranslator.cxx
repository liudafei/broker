/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file commentTranslator.cxx
//! \brief Contains the DtCommentTranslator class definition.
//! \ingroup disBroker

#include <disBroker/commentTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtCommentTranslator::DtCommentTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalCommentInteraction::theKind )
      {
      }

      DtCommentTranslator::~DtCommentTranslator()
      {
      }

      bool DtCommentTranslator::isPortalDiscoverable(
         const DtPortalCommentInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.senderId())
            && testGlobalIdMapping("Receiver ID",inter.receiverId()) );
      }

      DtPortalCommentInteraction* DtCommentTranslator::translate(
         DtPortalCommentInteraction* destination, const DtCommentInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setComment( source.comment() );

         {  // Copy fixed datum...
            DtFixedLengthDataArray* fixedDatums = &destination->fixedDatums();
            fixedDatums->resize( source.numFixedFields() );

            DtFixedLengthDataArray::iterator pos = fixedDatums->begin();
            for ( int vrlink_index = 1; pos != fixedDatums->end(); ++pos, ++vrlink_index )
            {
               (*pos).setId( source.fixedDatumId( vrlink_index ));
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtU32 fixedValue = source.datumValUnsigned32( DtFixed, vrlink_index, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  (*pos).setValue( fixedValue );
               }
            }
         }

         {  // Copy variable datum...
            DtAttributeValuePairList* variableDatumSet = &destination->variableDatumSet();
            variableDatumSet->resize( source.numVarFields() );

            DtAttributeValuePairList::iterator pos = variableDatumSet->begin();
            for ( int vrlink_index = 1; pos != variableDatumSet->end(); ++pos, ++vrlink_index )
            {
               (*pos).first = DtString( source.varDatumId( vrlink_index ));
               (*pos).second.setData( source.datumValByteArray( DtVar, vrlink_index ),
                  source.datumSizeBytes( DtVar, vrlink_index ));
            }
         }

         return destination;
      }

      DtCommentInteraction* DtCommentTranslator::translate(
         DtCommentInteraction* destination, const DtPortalCommentInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setComment( source.comment().c_str(), source.comment().size() );

         {  // Copy fixed datum...
            destination->setNumFixedFields( source.fixedDatums().size() );

            DtFixedLengthDataArray::const_iterator pos = source.fixedDatums().begin();
            for (int vrlink_index = 1; pos != source.fixedDatums().end(); ++pos, ++vrlink_index)
            {
               DtDatumRetCode  returnCode = DtDatumBadLength;
               DtDatumParam id = (DtDatumParam)(*pos).id();
               destination->setDatumParam( DtFixed, vrlink_index, id, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  DtU32 value = (*pos).value();
                  destination->setDatumValUnsigned32( DtFixed, vrlink_index, value, &returnCode );
               }
            }
         }

         {  // Copy variable datum...
            destination->setNumVarFields( source.variableDatumSet().size() );

            DtAttributeValuePairList::const_iterator pos = source.variableDatumSet().begin();
            for (int vrlink_index = 1; pos != source.variableDatumSet().end(); ++pos, ++vrlink_index)
            {
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtDatumParam varDatumId = (DtDatumParam)atol( (*pos).first );
               destination->setDatumParam( DtVar, vrlink_index, varDatumId, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  int length = (*pos).second.size();
                  destination->setVarDataBytes( vrlink_index, length, &returnCode );
                  const char* value = (*pos).second.data();
                  destination->setDatumValByteArray( DtVar, vrlink_index, value, &returnCode );
               }
            }
         }

         return destination;
      }

   }
}
