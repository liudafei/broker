/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file noRelEntityPublisher.cxx
//! \brief Contains the DtNoRelEntityPublisher class definition.
//! \ingroup disBroker

#if DtDIS

#include <disBroker/noRelEntityPublisher.h>

DtNoRelEntityPublisher::DtNoRelEntityPublisher( DtEntityStateRepository* stateRepToUse, DtExerciseConn* conn, const DtObjectId& id )
   : DtEntityPublisher( stateRepToUse, conn, id )
{
}


DtNoRelEntityPublisher::DtNoRelEntityPublisher( DtExerciseConn* conn, const DtObjectId& id )
   : DtEntityPublisher( conn, id )
{
}

DtNoRelEntityPublisher::DtNoRelEntityPublisher( const DtEntityType& type, DtExerciseConn* conn, const DtObjectId& id )
   : DtEntityPublisher( type, conn, id )
{
}

DtNoRelEntityPublisher::DtNoRelEntityPublisher( const DtEntityType& type, DtExerciseConn* conn, DtDeadReckonTypes algorithm,
      DtForceType forceId, const DtEntityType& guise, const DtObjectId& id )
   : DtEntityPublisher( type, conn, algorithm, forceId, guise, id )
{
}

DtNoRelEntityPublisher::~DtNoRelEntityPublisher()
{
}

void DtNoRelEntityPublisher::tick()
{
   // If the user has specified to use their own, just keep
   // the myTimeThreshold value
   if ( ! useCustomThreshold() )
   {
      // Verify Time Threshold
      if ( theStationaryDfltIsSetFlag && entityStateRep()->velocity() == DtVector32() )
      {
         myTimeThreshold = theStationaryDfltTimeThreshold;
      }
      else
      {
         DtEntityType entType = entityStateRep()->entityType();
         myTimeThreshold = entityTypeHeartbeat(entType.kind(),entType.domain());
      }
   }

   DtClock* theClock = exerciseConn()->clock();
   DtTime tt = lastTimeUpdated() + timeThreshold();
   DtTime rt = theClock->absRealTime();
   if (theClock->absRealTime() > lastTimeUpdated() + timeThreshold())
   {
      myEntityEncoder->setSendNeeded();
   }

   DtEntityStatePdu* pdu = myEntityEncoder->stateMsg( *entityStateRep(),
      *((DtEntityStateRepository*)approximateRemoteStateRep()) );
   if ( pdu )
   {
      send( pdu );
      myEntityDecoder->decode( *pdu, ((DtEntityStateRepository*) approximateRemoteStateRep()) );
   }

   if (mySendSeesPdus)
   {
      if (sendSeesNeeded() || theClock->absRealTime() > myLastSeesPdusUpdate + seesTimeThreshold())
      {
         createAndSendSeesPdu();
      }
   }

   if ( sendDiGuyAttributes() || sendDiGuyPdus() )
   {
      createAndSendDiGuy();
   }
}

#endif // DtDIS
