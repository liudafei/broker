/*********************************************************************
 ** Copyright (c) 1992-2010 VT MAK
** All rights reserved.
*********************************************************************/

#include "eventIdMapper.h"

#include <vl/eventId.h>
#include <vlutil/vlUtil.h>
#include <vlutil/vlPrint.h>

namespace MAKVrExchange { namespace DtDisBroker {

DtEventIdMapper::DtEventIdMapper( int siteId, int hostId, bool remapDisIds ) :
   myRemapDisIdsFlag(remapDisIds),
   mySiteId(siteId),
   myHostId(hostId),
   myNextIdCounter(0),
   myEventIdMap(),
   myDebugOutputOn(false)
{
}

DtEventIdMapper::~DtEventIdMapper()
{
}


const DtEventId& DtEventIdMapper::convertEventId(const DtString& portalId)
{
   static DtEventId retVal;

   // We need to try to parse the string to get an event number and "global ID"
   // from the string passed to us by the portal... This assumes an Portal event 
   // ID type...
   char* copy = DtStrdup(portalId.string());
   char* work = copy;
   char* numStr = strtok(work, ":");
   int num = (int) strtol(work, &work, 0);
   DtString name = strtok(0, ":");

   if (myRemapDisIdsFlag)
   {
      // see if we have already mapped this event to a number yet...
      StringULongMap::iterator pos = myEventIdMap.find(name);
      if (pos != myEventIdMap.end())
      {
         retVal.setEventNum(pos->second);
      }
      else
      {
         // we have never come across this event, lets make a new one...
         retVal.setEventNum(myNextIdCounter++);
         myEventIdMap[name] = retVal.eventNum();
      }
      retVal.setSite(mySiteId);
      retVal.setHost(myHostId);
   }
   else
   {
      DtString buffer = name;
      if (buffer.size() >= 4 &&
          buffer[0] == 'V' &&
          buffer[1] == 'R' &&
          buffer[2] == 'X' &&
          buffer[3] == 'D')
      {
         char *p = (char *) buffer.c_str();
         p += 4; 
         int s = (int) strtol(p, &p, 0); if (*p) p++;
         int h = (int) strtol(p, &p, 0); if (*p) p++;
         retVal.setSite(s);
         retVal.setHost(h);
      }
      else
      {
         if (myDebugOutputOn)
         {
            // Now we need to remap
            DtInfo << "DIS Broker got an Event ID which it can't pass through without remapping,"
               << " will maintain the eventNum\n";
         }
         retVal.setSite(mySiteId);
         retVal.setHost(myHostId);
      }
      retVal.setEventNum(num);
   }
   if(copy)
   {
      delete[] copy;
   }
   return retVal;
}

const DtString& DtEventIdMapper::convertEventId(const DtEventId& disId)
{
   static DtString retVal;

   if (myRemapDisIdsFlag)
   {
      char buffer[40];
      DtString key = DtString(disId.site()) + ":" + DtString(disId.host()) +
         ":" + DtString(disId.eventNum());
       // see if we have already mapped this event to a number yet...
       StringULongMap::iterator pos = myEventIdMap.find(key);
       if (pos != myEventIdMap.end())
       {
          sprintf(buffer, "%d:%s", pos->second, "VRXD");
          retVal = DtString(buffer);
       }
       else
       {
          // we have never come across this event, lets make a new one...
          sprintf(buffer, "%d:%s", myNextIdCounter, "VRXD");
          retVal = DtString(buffer);
          myEventIdMap[key] = myNextIdCounter;
          ++myNextIdCounter;
       }
   }
   else
   {
      static char buffer[40];
      sprintf(buffer,"VRXD%d.%d",disId.site(), disId.host());
      retVal = DtString(disId.eventNum()) + DtString(":") + DtString(buffer);
   }
   return retVal;
}

}}

