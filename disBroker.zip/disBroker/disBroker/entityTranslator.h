/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file entityTranslator.h
//! \brief Contains the DtEntityTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/reflectedEntityList.h>
#include <vl/entityPublisher.h>

class DtEntityStateRepository;

#define ENTITY_TEMPLATE_ARGS \
   DtPortalEntity, DtPortalReflectedEntity, \
   DtReflectedEntity, DtReflectedEntityList, \
   DtEntityStateRepository, DtEntityPublisher

namespace MAKVrExchange
{

   class DtPortalObject;

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<ENTITY_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedEntity* refObj, const DtString& identifier );

      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<ENTITY_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedEntity* refObj, const DtEntityIdentifier& name );


      //! \brief Provides Entity State object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtEntityTranslator
         : public DtDisObjectTranslator<ENTITY_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Entity State" );

         //! \brief CTOR.
         //! Instantiates DIS and Portal reflected entity lists and registers
         //! callbacks for processing entity discovery and updating.
         DtEntityTranslator( DtBroker* broker );

         //! \brief DTOR.
         virtual ~DtEntityTranslator();

         //! \brief Ticks all Portal and DIS publishers.
         virtual void tick();

         //! @name Portal Callback Initialization
         //! Overridden to initialize callbacks for DI-Guy objects.
         //! @{

         virtual void initializePortalCallbacks();
         virtual void removePortalCallbacks();

         //! @}

      protected:

         //! @name Static DI-Guy Discovery/Update/Delete Callbacks.
         //! @{

         //! \brief Static callback for testing whether the portal object should be discovered.
         static bool portalDiGuyDiscoveryCriteria( const DtPortalReflectedObject* obj, void* usr );

         //! \brief Static callback for processing newly discovered portal DI-Guy objects.
         //! Calls: DtEntityTranslator::discoverPortalObject( const DtPortalReflectedEntity& ).
         static void portalDiGuyAddedCb( const DtPortalReflectedDiGuy& obj, void* usr );

         //! \brief Static callback for processing portal DI-Guy object updates.
         //! Calls: DtEntityTranslator::receivePortalUpdate( const DtPortalReflectedEntity& ).
         static void portalDiGuyUpdatedCb( const DtPortalReflectedDiGuy& obj, void* usr );

         //! \brief Static callback for processing portal DI-Guy object destruction.
         //! Calls: DtEntityTranslator::removePortalObject( const DtPortalReflectedEntity& ).
         static void portalDiGuyDeletedCb( const DtPortalReflectedDiGuy& obj, void* usr );

         //! @}

         //! Overriding DIS Callbacks to add calling of DI-Guy PDUs as well as entities.
         virtual void initializeDisCallbacks();

         //! @name Virtual Object Discovery/Update/Delete Callbacks.
         //! @{

         //! Overridden to check for valid entity ID, type, location, and
         //! marking text (conditional).
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedEntity* refObj );

         //! \brief Creates and initializes a broker object and portal publisher.
         //! Overridden to add the entity/ID to the entityId map.
         virtual void discoverDisObject( DtReflectedEntity& obj );

         //! \brief Creates and initializes a broker object and DIS publisher.
         //! Overridden to add the entity/ID to the entityId map and perform
         //! waitlisted DI-Guy discovery if necessary.
         virtual void discoverPortalObject( const DtPortalReflectedEntity& obj );

         //! \brief Updates the associated entity or waits for it to be discovered.
         virtual void discoverPortalDiGuy( const DtPortalReflectedDiGuy& obj );

         //! \brief Gets the reflected object's entity id for publisher creation.
         virtual DtString disObjectName( const DtPortalReflectedEntity* refObj ) const;

         //! \brief Creates a new DtEntityPublisher and stores it in the broker object.
         //! Overridden to enable dead-reckoning on the entity state repository.
         virtual void createDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Updates the broker object with the latest entity information.
         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const DtEntityStateRepository& sr );

         //! \brief Performs the entity filtering logic.
         virtual void updateFilteredState( DtBrokerObject* brokerObj,
            DtPortalEntityPublisher* publisher, DtReflectedEntity* refObj );

         //! \\brief Performs the entity filtering logic.
         //! Overridden to test location against filters. Applied to portal objects.
         //! Checks the object against configured filters and sets the object's
         //! filtered state in the broker object.  Sets whether broker object is 
         //! publishable or not. Translators wishing to perform type, marking text,
         //! or other types of filtering  on Portal reflected objects must override this method.
         virtual void updateFilteredState( DtBrokerObject* brokerObj,
            const DtPortalReflectedEntity* refObj );

         //! \brief Updates the broker object with the latest entity information.
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj,
            const DtPortalEntity& sr );

         //! \brief Updates the entity's DIS publisher with the new state.
         //! Also updates the entity's broker object and prints
         //! debugging information if debugging is turned on.
         virtual void receivePortalDiGuyUpdate( const DtPortalReflectedDiGuy& obj );

         //! Overridden to remove the entity ID from the entity ID map.
         virtual void removeDisObject( const DtReflectedObject& refObj );

         //! \brief Removes the portal entity from the entity ID map.
         virtual void removePortalObject( const DtPortalReflectedEntity& refObj );

         //! \brief Removes the DI-Guy from the wait-list if he's still there.
         virtual void removePortalDiGuy( const DtPortalReflectedDiGuy* diGuy );

         //! \brief Destroys the broker object's DtEntityPublisher.
         virtual void deleteDisPublisher( DtBrokerObject* brokerObj );

         //! @}

         //! @name Primary Translation Methods.
         //! @{

         //! \brief Checks whether the entity has DI-Guy attributes.
         //! Used to determine whether to publish Portal DI-Guy object updates.
         virtual bool hasDiGuyAttributes( const DtEntityStateRepository& entity );

         //! \brief Syncs the DIS object's dead-reckoned values with the portal object's.
         virtual void syncDisDeadReckonedValues( DtEntityStateRepository* destination,
            const DtPortalEntity& source );

         //! \brief Syncs the portal object's dead-reckoned values with the DIS object's.
         virtual void syncPortalDeadReckonedValues( DtPortalEntity* destination,
            const DtEntityStateRepository& source );

         //! \brief Translates a DIS entity state rep into a portal entity.
         virtual DtPortalEntity* translate( DtPortalEntity* destination,
            const DtEntityStateRepository& source, const DtReflectedEntity& reflectedObject );

         //! \brief Translates a portal entity into a DIS entity state rep.
         virtual DtEntityStateRepository* translate(
            DtEntityStateRepository* destination, const DtPortalEntity& source,
            const DtPortalReflectedEntity& reflectedObject );

         //! \brief Translates DIS Entity DI-Guy attributes into a portal DI-Guy.
         virtual DtPortalDiGuy* translate( DtPortalDiGuy* destination,
            const DtEntityStateRepository& source );

         //! \brief Translates a portal DI-Guy into a DIS entity state rep.
         virtual DtEntityStateRepository* translate(
            DtEntityStateRepository* destination, const DtPortalDiGuy& source );

         //! @}

      private:

         //! Copy Constructor not implemented -- do not copy!
         DtEntityTranslator( const DtEntityTranslator& other );

         //! Assignment Operator not implemented -- do not copy!
         DtEntityTranslator& operator = ( const DtEntityTranslator& other );

      protected:

         typedef std::map<DtEntityIdentifier,DtBrokerObject*> EntityByEntityIdMap;
         EntityByEntityIdMap myPortalEntityByEntityIdMap;
         EntityByEntityIdMap myDisEntityByEntityIdMap;

         typedef std::map<DtEntityIdentifier,const DtPortalReflectedDiGuy*> DiGuyWaitList;
         DiGuyWaitList myDiGuyWaitList;

         typedef std::map<DtEntityIdentifier,DtPortalDiGuyPublisher*> PortalDiGuyPublisherMap;
         PortalDiGuyPublisherMap myPortalDiGuyPublisherMap;

         DtPortalReflectedDiGuyManager* myPortalReflectedDiGuyManager;

      };

   }
}
