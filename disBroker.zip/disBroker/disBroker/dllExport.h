/****************************************************************************
 * Copyright (c) 2013 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file dllExport.h
//! \brief Contains the DLL export macro.
//! \ingroup disBroker

#pragma once

// Get proper local export symbol
#ifdef _WIN32
#  ifdef libDisBroker_EXPORTS
#    define DT_DLL_DISBROKER __declspec ( dllexport )
#  else
#    define DT_DLL_DISBROKER __declspec ( dllimport )
#  endif
#else
#  define DT_DLL_DISBROKER
#endif
