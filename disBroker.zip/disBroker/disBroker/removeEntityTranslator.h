/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file removeEntityTranslator.h
//! \brief Contains the DtRemoveEntityTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pRemoveEntityInter.h>
#include <vl/removeEntityInteraction.h>

namespace MAKVrExchange
{

   class DtPortalRemoveEntityInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides RemoveEntity interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtRemoveEntityTranslator
         : public DtDisInteractionTranslator<DtPortalRemoveEntityInteraction,DtRemoveEntityInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Remove Entity" );

         //! \brief CTOR.
         DtRemoveEntityTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtRemoveEntityTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalRemoveEntityInteraction& inter );

         //! \brief Translates the remove entity interaction into the portal.
         virtual DtPortalRemoveEntityInteraction* translate(
            DtPortalRemoveEntityInteraction* destination,
            const DtRemoveEntityInteraction& source );

         //! \brief Translates the remove entity interaction from the portal.
         virtual DtRemoveEntityInteraction* translate( DtRemoveEntityInteraction* destination,
            const DtPortalRemoveEntityInteraction& source );

      };

   }
}
