/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file actionRequestTranslator.cxx
//! \brief Contains the DtActionRequestTranslator class definition.
//! \ingroup disBroker

#include <disBroker/actionRequestTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtActionRequestTranslator::DtActionRequestTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalActionRequestInteraction::theKind )
      {
      }

      DtActionRequestTranslator::~DtActionRequestTranslator()
      {
      }

      bool DtActionRequestTranslator::isPortalDiscoverable(
         const DtPortalActionRequestInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.originatingEntity())
            && testGlobalIdMapping("Receiver ID",inter.receivingEntity()) );
      }

      DtPortalActionRequestInteraction* DtActionRequestTranslator::translate(
         DtPortalActionRequestInteraction* destination, const DtActionRequestInteraction& source )
      {
         destination->setOriginatingEntity( disBroker()->convertGlobalId(source.senderId()) );
         destination->setReceivingEntity( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setRequestIdentifier( source.requestId() );
         destination->setActionIdentifier( source.actionId() );

         {  // Copy fixed datum...
            DtFixedLengthDataArray* fixedDatums = &destination->fixedDatums();
            fixedDatums->resize( source.numFixedFields() );

            DtFixedLengthDataArray::iterator pos = fixedDatums->begin();
            for ( int vrlink_index = 1; pos != fixedDatums->end(); ++pos, ++vrlink_index )
            {
               (*pos).setId( source.fixedDatumId( vrlink_index ));
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtU32 fixedValue = source.datumValUnsigned32( DtFixed, vrlink_index, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  (*pos).setValue( fixedValue );
               }
            }
         }

         {  // Copy variable datum...
            DtAttributeValuePairList* variableDatumSet = &destination->variableDatumSet();
            variableDatumSet->resize( source.numVarFields() );

            DtAttributeValuePairList::iterator pos = variableDatumSet->begin();
            for ( int vrlink_index = 1; pos != variableDatumSet->end(); ++pos, ++vrlink_index )
            {
               (*pos).first = DtString( source.varDatumId( vrlink_index ));
               (*pos).second.setData( source.datumValByteArray( DtVar, vrlink_index ),
                  source.datumSizeBytes( DtVar, vrlink_index ));
            }
         }

         return destination;
      }

      DtActionRequestInteraction* DtActionRequestTranslator::translate(
         DtActionRequestInteraction* destination, const DtPortalActionRequestInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId(source.originatingEntity()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receivingEntity()) );
         destination->setRequestId( source.requestIdentifier() );
         destination->setActionId( source.actionIdentifier() );

         {  // Copy fixed datum...
            destination->setNumFixedFields( source.fixedDatums().size() );

            DtFixedLengthDataArray::const_iterator pos = source.fixedDatums().begin();
            for ( int vrlink_index = 1; pos != source.fixedDatums().end(); ++pos, ++vrlink_index )
            {
               DtDatumRetCode  returnCode = DtDatumBadLength;
               DtDatumParam id = (DtDatumParam)(*pos).id();
               destination->setDatumParam( DtFixed, vrlink_index, id, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  DtU32 value = (*pos).value();
                  destination->setDatumValUnsigned32( DtFixed, vrlink_index, value, &returnCode );
               }
            }
         }

         {  // Copy variable datum...
            destination->setNumVarFields( source.variableDatumSet().size() );

            DtAttributeValuePairList::const_iterator pos = source.variableDatumSet().begin();
            for ( int vrlink_index = 1; pos != source.variableDatumSet().end(); ++pos, ++vrlink_index )
            {
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtDatumParam varDatumId = (DtDatumParam)atol( (*pos).first );
               destination->setDatumParam( DtVar, vrlink_index, varDatumId, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  int length = (*pos).second.size();
                  destination->setVarDataBytes( vrlink_index, length, &returnCode );
                  const char* value = (*pos).second.data();
                  destination->setDatumValByteArray( DtVar, vrlink_index, value, &returnCode );
               }
            }
         }

         return destination;
      }

   }
}
