/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disBroker.h
//! \brief Contains the DtDisBroker class declaration.
//! \ingroup disBroker

#pragma once

#include <broker/vrlBroker.h>
#include <broker/translatorFactory.h>
#include <disBroker/globalIdMapper.h>
#include <disBroker/underwaterAcousticsPublisherManager.h>
#include <vl/globalObjectDesignator.h>
#include <vl/exerciseConn.h>

namespace MAKVrExchange
{

   class DtBrokerObject;
   class DtPortalReflectedObject;

   namespace DtDisBroker
   {

      class DtEventIdMapper;
      class DtEntityIdMapper;
      class DtDisBrokerInitializer;

      //! \brief Implements a DtBroker for the DIS Protocol.
      //! Implementation is accomplished through DtTranslator classes. Each translator
      //! class represents a DtPortalObject or DtPortalInteraction class. DtDisBroker
      //! connects to the DtExerciseConnection and manages reflected lists, and object
      //! updates from both DIS and the Data Exchange.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDisBroker : public DtVrlBroker<DtExerciseConn>
      {
      public:

         //! \brief Creator function. This returns a pointer to an instance of a DtDisBroker
         //! Calls DtDisBroker::initialize( DtDisBrokerInitializer* )
         static DtBroker* create( DtBrokerInitializer* init );

         //! \brief Virtual DTOR.
         virtual ~DtDisBroker();

      protected:

         //! \brief Default CTOR.
         //! Protected - use create method.
         DtDisBroker();

      public:

         //! \brief Drains input from the exercise connection.
         virtual void tick();

         //! \brief Overridden to update sim time using absolute timestamps if specified.
         virtual void updateSimTime() const;

         //! \brief Get the broker initializer to catch configuration options
         virtual DtDisBrokerInitializer* disInitializer();

         //! @name Initializer Pass-through Methods.
         //! The following functions are passthroughs to the initializer.
         //! @{

         virtual DtUnderwaterAcousticsPublisherManager*
            underwaterAcousticsPublisherManager();
         virtual DtGlobalIdMapper* globalIdMapper();
         virtual DtEventIdMapper* eventIdMapper();
         virtual DtEntityIdMapper* entityIdMapper();
         virtual DtTime heartbeatInterval() const;
         virtual DtTime timeoutInterval() const;
         virtual bool remapDisIds() const;
         virtual bool usePersistentIds() const;
         virtual bool dumpGuiToText() const;

         //! @}

         DtGlobalObjectDesignator convertGlobalId( const DtString& id );
         DtString convertGlobalId( const DtGlobalObjectDesignator& id );
         DtEntityIdentifier convertPortalEntIdToDisEntId( const DtEntityIdentifier& portalId );
         DtEntityIdentifier convertDisEntIdToPortalEntId( const DtEntityIdentifier& disId );

         //! Sets a function to be called by the broker for use when creating
         //! an underwater acoustics publisher manager. Setting the function to
         //! NULL, the default, will result in DtDisBroker using the default
         //! implementation (DtUnderwaterAcousticsPublisherManager).
         static void setUnderwaterAcousticsPublisherManagerCreator(
            DtUnderwaterAcousticsPublisherManagerCreator func );

         //! Returns the function used to create an underwater acoustics
         //! publisher manager. May return null if no function is set.
         static DtUnderwaterAcousticsPublisherManagerCreator
            underwaterAcousticsPublisherManagerCreator();

         //! Sets a function to be called by DtDisBroker for use when creating
         //! a GlobalIdMapper. Setting the function to NULL, the default, will result
         //! in the broker using DtGlobalIdMapper.
         static void setGlobalIdMapperCreator( DtGlobalIdMapperCreator func );

         //! Returns the function used to create a globalIdMapper. May return null
         //! if no function is set.
         static DtGlobalIdMapperCreator globalIdMapperCreator();

      protected:

         //! \brief Initializes the DIS Broker.
         //! Must be called after the broker is instantiated.
         //! Calls the following methods:
         //!    DtDisBroker::setupTranslators()
         //!    DtVrlBroker::initialize( DtBrokerInitializer* )
         //!    DtDisBroker::startBroker()
         virtual void initialize( DtDisBrokerInitializer* init );

         //! \brief Add the default set of translators to the factories.
         virtual void setupTranslators( DtDisBrokerInitializer* init );

         //! \brief Output DIS Broker initialization settings to log file.
         virtual void logBrokerSettings( DtBrokerInitializer* init );

         //! \brief Shut down the broker.
         //! Overridden to save persistent Entity IDs and destroy the ID mappers.
         virtual void shutdown();

         //! \brief Initializes the DIS Connection
         virtual void initDisConnection( DtDisBrokerInitializer& init );

         //! \brief Scans available network devices and picks a new one to use.
         //! This is used if the configured device address is unavailable.
         virtual DtString chooseNewDeviceAddress() const;

         //! \brief Initializes the broker.
         virtual void startBroker();

      private:

         //! Class not copyable, not implemented.
         DtDisBroker( const DtDisBroker& other );

         //! Class not copyable, not implemented.
         DtDisBroker& operator = ( const DtDisBroker& other );

      protected:

         static DtUnderwaterAcousticsPublisherManagerCreator
            theUnderwaterAcousticsPublisherManagerCreator;

         static DtGlobalIdMapperCreator theGlobalIdMapperCreator;

         DtInetDevice* myDisMcastDevice;

         DtUnderwaterAcousticsPublisherManager* myUndwaAcPublisherManager;
         DtGlobalIdMapper* myGlobalIdMapper;
         DtEventIdMapper* myEventIdMapper;
         DtEntityIdMapper* myEntityIdMapper;

      };


      inline DtUnderwaterAcousticsPublisherManager*
         DtDisBroker::underwaterAcousticsPublisherManager()
      {
         return myUndwaAcPublisherManager;
      }

      inline DtGlobalIdMapper* DtDisBroker::globalIdMapper()
      {
         return myGlobalIdMapper;
      }

      inline DtEntityIdMapper* DtDisBroker::entityIdMapper()
      {
         return myEntityIdMapper;
      }

      inline DtEventIdMapper* DtDisBroker::eventIdMapper()
      {
         return myEventIdMapper;
      }

   }
}
