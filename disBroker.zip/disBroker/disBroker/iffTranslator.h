/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file iffTranslator.h
//! \brief Contains the DtIffTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/embeddedSystemTranslator.h>
#include <vl/reflectedIffList.h>
#include <vl/iffPublisher.h>

class DtReflectedIff;
class DtIffStateRepository;

#define IFF_TEMPLATE_ARGS \
   DtPortalIffObject, DtPortalReflectedIffObject, \
   DtReflectedIff, DtReflectedIffList, \
   DtIffStateRepository, DtIffPublisher

namespace MAKVrExchange
{

   class DtPortalIffObject;

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<IFF_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedIffObject* refObj,
         const DtString& identifier );

      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<IFF_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedIffObject* refObj,
         const DtEntityIdentifier& name );


      //! \brief Provides IFF object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtIffTranslator
         : public DtEmbeddedSystemTranslator<IFF_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "IFF" );

         //! \brief CTOR.
         DtIffTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtIffTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedIffObject* refObj );

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Overridden to use the IFF object type.
         virtual bool performDisGlobalIdMapping( const DtObjectPublisher* publisher,
            const DtPortalReflectedIffObject& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Construct the portal object name.
         //! Overridden to construct an active sonar name.
         virtual DtString portalObjectName( const DtReflectedIff* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! Overridden to pass IffType enumeration for object type.
         virtual bool performPortalGlobalIdMapping(
            const DtPortalIffObjectPublisher* publisher,
            const DtReflectedIff& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Deletes the DIS publisher.
         //! Overridden to avoid destroying Global ID mapping for host object.
         virtual void deleteDisPublisher( DtBrokerObject* object );

         //! \brief Translates an IFF object into the portal.
         virtual DtPortalIffObject* translate( DtPortalIffObject* destination,
            const DtIffStateRepository& source, const DtReflectedIff& refObj );

         //! \brief Translates an IFF object from the portal.
         virtual DtIffStateRepository* translate( DtIffStateRepository* destination,
            const DtPortalIffObject& source, const DtPortalReflectedIffObject& refObj );

      };

   }
}
