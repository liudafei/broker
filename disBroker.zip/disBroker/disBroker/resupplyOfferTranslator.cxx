/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file resupplyOfferTranslator.cxx
//! \brief Contains the DtResupplyOfferTranslator class definition.
//! \ingroup disBroker

#include <disBroker/resupplyOfferTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtResupplyOfferTranslator::DtResupplyOfferTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalResupplyOfferInteraction::theKind )
      {
      }

      DtResupplyOfferTranslator::~DtResupplyOfferTranslator()
      {
      }

      bool DtResupplyOfferTranslator::isPortalDiscoverable(
         const DtPortalResupplyOfferInteraction& inter )
      {
         return ( testGlobalIdMapping("Receiving ID",inter.receivingId())
            && testGlobalIdMapping("Supplying ID",inter.supplyingId()) );
      }

      DtPortalResupplyOfferInteraction* DtResupplyOfferTranslator::translate(
         DtPortalResupplyOfferInteraction* destination, const DtResupplyOfferInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setSupplyingId( disBroker()->convertGlobalId(source.supplyingId()) );
         destination->setNumSupplyTypes( source.numSupplyTypes() );

         int numSupplyTypes = source.numSupplyTypes();
         for ( int i = 0; i < numSupplyTypes; ++i )
         {
            float quantity = 0;
            int retCode = 0;
            DtEntityType supplyType = source.nthSupply( i, &quantity, &retCode );
            if ( DtSUPPLY_VALID == retCode )
            {
               retCode = destination->setNthSupply( i, supplyType, &quantity );
            }

            if ( DtSUPPLY_VALID != retCode )
            {
               DtWarn << name() << " problem translating supply.\n"
                  << "  Mismatch between stated num supplies and encoded num supplies.\n";
               break;
            }
         }

         return destination;
      }

      DtResupplyOfferInteraction* DtResupplyOfferTranslator::translate(
         DtResupplyOfferInteraction* destination, const DtPortalResupplyOfferInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setSupplyingId( disBroker()->convertGlobalId(source.supplyingId()) );
         destination->setNumSupplyTypes( source.numSupplyTypes() );

         int retCode = DtSUPPLY_VALID;
         int numSupplyTypes = source.numSupplyTypes();
         for ( int i = 0; ((DtSUPPLY_VALID == retCode) && (i < numSupplyTypes)); ++i )
         {
            float quantity = 0;
            DtNetEntityType supplyType;
            retCode = source.nthSupply( i, supplyType, &quantity );
            if ( DtSUPPLY_VALID == retCode )
            {
               destination->setNthSupply( i, supplyType, quantity, &retCode );
            }

            if ( DtSUPPLY_VALID != retCode )
            {
               DtWarn << name() << " problem translating supply.\n"
                  << "  Mismatch between stated num supplies and encoded num supplies.\n";
               break;
            }
         }

         return destination;
      }

   }
}
