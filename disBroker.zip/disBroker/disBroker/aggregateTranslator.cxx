/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file aggregateTranslator.cxx
//! \brief Contains the DtAggregateTranslator class definition.
//! \ingroup mrfBroker

#include <disBroker/aggregateTranslator.h>
#include <disBroker/disBrokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtAggregateTranslator::DtAggregateTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalAggregate::theKind )
      {
         DtAggregatePublisher::setDfltTimeThreshold( disBroker()->heartbeatInterval() );
      }

      DtAggregateTranslator::~DtAggregateTranslator()
      {
      }

      bool DtAggregateTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedAggregate* refObj )
      {
         DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->aggregateNeedsEntityId()
            && refObj->sr()->entityId() == DtEntityIdentifier() )
         {
            DtInfo << "DtAggregateTranslator: " << brokerObj->objectName()
               << ": Entity Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Entity ID" );
            return false;
         }

         if ( discoveryCriteria->aggregateNeedsEntityType()
            && refObj->sr()->entityType() == DtEntityType::nullType() )
         {
            DtInfo << "DtAggregateTranslator: " << brokerObj->objectName()
               << ": Entity Type not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Entity Type" );
            return false;
         }

         if ( discoveryCriteria->aggregateNeedsLocation()
            && refObj->sr()->location() == DtVector() )
         {
            DtInfo << "DtAggregateTranslator: " << brokerObj->objectName()
               << ": Location not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Location" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      DtString DtAggregateTranslator::disObjectName(
         const DtPortalReflectedAggregate* refObj ) const
      {
         return refObj->sr()->entityId().string();
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<AGGREGATE_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedAggregate* refObj, const DtString& identifier )
      {
         return mapObjectId( DtEntityIdentifier(identifier) );
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<AGGREGATE_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedAggregate* refObj, const DtEntityIdentifier& name )
      {
         DtObjectPublisher* publisher = NULL;
         try
         {
            // Instantiate the publisher.
            publisher = new DtAggregatePublisher(
               refObj->sr()->entityType(), disBroker()->connection(),
               (DtDeadReckonTypes) refObj->sr()->algorithm(),
               (DtForceType) refObj->sr()->forceId(), name );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      void DtAggregateTranslator::createDisPublisher( DtBrokerObject* brokerObj )
      {
         ParentClass::createDisPublisher( brokerObj );

         // Get the publisher.
         DtAggregatePublisher* publisher =
            static_cast<DtAggregatePublisher*>( brokerObj->publisherPtr() );
         if ( ! publisher )
         {
            return;
         }

         // This is a dead reckoning hack. Basically there is no dead reckoning in the Portal,
         // none at all, not even for the reflected objects. So, since the Publisher
         // always needs to have the "real" value (and that means dead reckoned value) we
         // turn on dead reckoning in the publisher.
         //
         // Why does the publisher need to have the DR Value? Two fold.
         // 1) as we tick ALL the TIME, every tick the sr is compared to the ASB sr, which
         // is dead reckoned. And if the two are off then you get a packet flood.
         // 2) A late jointer might request an update for this object, and if all you have
         // is old position/vel/orientation data then the late jointer will not have
         // an accurate picture of the world.
         publisher->asr()->useDeadReckoner();
         publisher->asr()->useRelativeDeadReckoner();
         publisher->asr()->setClock( disBroker()->connection()->clock() );
      }

      DtString DtAggregateTranslator::portalObjectName(
         const DtReflectedAggregate* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "Avrx";
      }

      void DtAggregateTranslator::updateDisBrokerObject( DtBrokerObject* brokerObj,
         const DtAggregateStateRepository& sr )
      {
         ParentClass::updateDisBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.entityId().string() );
         brokerObj->setMarkingText( sr.markingText() );
         brokerObj->setEntityType( sr.entityType() );
      }

      void DtAggregateTranslator::updatePortalBrokerObject( DtBrokerObject* brokerObj,
         const DtPortalAggregate& sr )
      {
         ParentClass::updatePortalBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.entityId().string() );
         brokerObj->setMarkingText( sr.markingText() );
         brokerObj->setEntityType( sr.entityType() );
      }

      void DtAggregateTranslator::updateFilteredState( DtBrokerObject* brokerObj,
         DtPortalAggregatePublisher* publisher, DtReflectedAggregate* refObj )
      {
         if ( publisher )
         {
            // Get the entity ID then see if this has been marked as a filtered object.
            const DtVector loc = refObj->asr()->location();
            const DtString id = publisher->sr()->identifier();
            const DtString markingText = brokerObj->markingText();
            const DtEntityType entityType = refObj->asr()->entityType();
            const DtString entityId = refObj->asr()->entityId().string();
            const DtFilterManager& objectFilters = myBroker->objectFilters();
            const bool isFiltered = objectFilters.isTypeFiltered( entityType )
               || objectFilters.isMarkingTextFiltered( markingText )
               || objectFilters.isNameFiltered( entityId )
               || objectFilters.isNameFiltered( id )
               || filterLocation( *refObj, loc );
            publisher->sr()->setFiltered( isFiltered );
            brokerObj->setIsFiltered( isFiltered );
         }
      }

      void DtAggregateTranslator::updateFilteredState(DtBrokerObject* brokerObj,
         const DtPortalReflectedAggregate* refObj)
      {
         //Check against geoFilters.  Filter published entities that do not fall within
         //set geographic filters.
         const DtVector loc = refObj->sr()->location();
         const DtFilterManager& objectFilters = myBroker->objectFilters();
         const bool isFiltered = filterLocation(*refObj, loc);

         brokerObj->setIsFiltered(isFiltered);
      }

      DtPortalAggregate* DtAggregateTranslator::translate(
         DtPortalAggregate* destination,
         const DtAggregateStateRepository& source,
         const DtReflectedAggregate& refObj )
      {
         syncPortalDeadReckonedValues( *destination, source );

         destination->setHostId(
            disBroker()->convertGlobalId(source.hostGlobalId()) );
         destination->setFrozen( source.frozen() );
         destination->setAlgorithm( source.algorithm() );
         destination->setRelativeFrozen( source.relativeFrozen() );
         destination->setRelativeAlgorithm( source.relativeAlgorithm() );
         destination->setNature( source.nature() );
         destination->setPartPosition( source.partPosition() );
         destination->setStationName( source.stationName() );
         destination->setStationNumber( source.stationNumber() );
         destination->setRelativePosition( source.relativePosition() );
         destination->setRange( source.range() );
         destination->setBearing( source.bearing() );
         destination->setEntityId( *(disBroker()->entityIdMapper()->convertDisEidToPortalEid(
               source.entityId().string() )));
         destination->setEntityType( source.entityType() );
         /// END BASE ENTITY COPY.

         destination->setForceId( source.forceId() );
         destination->setAggregateState( source.aggregateState() );
         destination->setAggregateType( source.aggregateType().string() );
         destination->setFormation( source.formation() );
         destination->setMarkingCharacterSet( source.markingCharacterSet() );
         destination->setMarkingText( source.markingText() );
         destination->setDimensions( source.dimensions() );

         {  // Variable Datums
            DtAggregateVariableDatumArray varDatums;
            varDatums.resize( source.numberOfDatumRecords() );

            for (int index = 0; index < source.numberOfDatumRecords(); ++index)
            {
               const DtVariableDatumRecord& vd = source.variableDatumRecordConstRef( index );

               varDatums[index].setDatumId( vd.datumID() );
               varDatums[index].datum().setData( vd.constDatumValPtr(),
                     (int) ceil( vd.datumBitLength()/8.0 ));
            }
            destination->setVariableDatums( varDatums );
         }

         {  // Fill in Entities:
            std::vector<DtString> sa;
            sa.resize( source.numberOfDIS_Entities() );

            for (unsigned int index = 0; index < sa.size(); ++index)
            {
               DtGlobalObjectDesignator id;
               source.getEntityID( index, id );
               sa[index] = disBroker()->convertGlobalId( id );
            }
            destination->setEntities( sa );
         }

         {  // Fill In SubAggregates
            std::vector<DtString> sa;
            sa.resize( source.numberOfDIS_Subaggregates() );

            for (unsigned int index = 0; index < sa.size(); ++index)
            {
               DtGlobalObjectDesignator id;
               source.getSubaggregateID( index, id );
               sa[index] = disBroker()->convertGlobalId( id );
            }
            destination->setSubaggregates( sa );
         }

         {  // Fill In Silent Entities
            DtSilentEntityArray sa;
            sa.resize( source.numberOfSilentEntities() );
            for (int index = 0; index < source.numberOfSilentEntities(); ++index)
            {
               DtSilentEntityList ent;
               source.getSilentEntityList( index, ent ); // Fills in the entity
               sa[index].setNumberOfEntities(ent.numberOfEntities() );
               sa[index].setNumberOfAppearanceRecords(ent.numberOfAppearanceRecords() );
               sa[index].setEntityType( ent.entityType() );
            }
            destination->setSilentEntities( sa );
         }

         {  // Fill In Silent Aggregates
            DtSilentAggregateArray sa;
            sa.resize( source.numberOfSilentSubaggregates() );
            for (int index = 0; index < source.numberOfSilentSubaggregates(); ++index)
            {
               DtSilentAggregateList agg;
               source.getSilentAggregateList( index, agg );
               sa[index].setEntityType( agg.aggregateType() );
               sa[index].setNumberOfAggregates(agg.numberOfAggregates() );
            }
            destination->setSilentAggregates( sa );
         }

         return destination;
      }

      DtAggregateStateRepository* DtAggregateTranslator::translate(
         DtAggregateStateRepository* destination, const DtPortalAggregate& source,
         const DtPortalReflectedAggregate& refObj )
      {
         syncDisDeadReckonedValues( *destination, source );

         destination->setFrozen( source.frozen() );
         destination->setAlgorithm( (DtDeadReckonTypes)source.algorithm() );
         destination->setRelativeFrozen( source.relativeFrozen() );
         destination->setRelativeAlgorithm( (DtDeadReckonTypes)source.relativeAlgorithm() );
         destination->setNature( (DtNature)source.nature() );
         destination->setPartPosition( (DtPosition)source.partPosition() );
         destination->setStationName( (DtStationName)source.stationName() );
         destination->setStationNumber( source.stationNumber() );
         destination->setRelativePosition( source.relativePosition() );
         destination->setRange( source.range() );
         destination->setBearing( source.bearing() );
         destination->setEntityId( disBroker()->convertPortalEntIdToDisEntId(source.entityId()) );
         destination->setEntityType( source.entityType() );
         /// END BASE ENTITY COPY.

         destination->setForceId( (DtForceType)source.forceId() );
         destination->setAggregateState( (DtAggregateState)source.aggregateState() );
         destination->setAggregateType( DtEntityType( source.aggregateType() ));
         destination->setFormation( (DtAggregateFormation)source.formation() );
         destination->setMarkingText( source.markingText() );
         destination->setDimensions( source.dimensions() );
         destination->setMarkingCharacterSet( (DtCharacterSet)source.markingCharacterSet() );

         {  // Variable Datums
            const DtAggregateVariableDatumArray& varDatums = source.variableDatums();
            destination->setNumberOfDatumRecords( varDatums.size() );

            for (unsigned int index = 0; index < varDatums.size(); ++index)
            {
               DtVariableDatumRecord& vd = destination->variableDatumRecordRef( index );

               vd.setDatumID( (DtDatumParam)varDatums[index].datumId() );
               vd.setDatumBitLength( varDatums[index].datum().size() * 8 );
               vd.setDatumValByteArray( (const DtU8*)varDatums[index].datum().data() );
            }
         }

         {  // Fill in Entities:
            destination->setNumberOfDIS_Entities( source.entities().size());
            for (unsigned int index = 0; index < source.entities().size(); ++index)
            {
               destination->setEntityID( index,
                  disBroker()->convertGlobalId(source.entities()[index]));
            }
         }

         {  // Fill In SubAggregates
            destination->setNumberOfDIS_Subaggregates( source.subaggregates().size());
            for (unsigned int index = 0; index < source.subaggregates().size(); ++index)
            {
               destination->setSubaggregateID( index,
                  disBroker()->convertGlobalId(source.subaggregates()[index]) );
            }
         }

         {  // Fill In Silent Entities
            destination->setNumberOfSilentEntities( source.silentEntities().size() );
            for (unsigned int index = 0; index < source.silentEntities().size(); ++index)
            {
               DtSilentEntityList ent;
               ent.setNumberOfEntities( source.silentEntities()[index].numberOfEntities() );
               ent.setNumberOfAppearanceRecords( source.silentEntities()[index].numberOfAppearanceRecords() );
               ent.setEntityType( source.silentEntities()[index].entityType() );
               destination->setSilentEntityList( index, ent );
            }
         }

         {  // Fill in Silent Aggregates
            destination->setNumberOfSilentSubaggregates( source.silentAggregates().size() );
            for (unsigned int index = 0; index < source.silentAggregates().size(); ++index)
            {
               DtSilentAggregateList agg;
               agg.setAggregateType( source.silentAggregates()[index].entityType() );
               agg.setNumberOfAggregates( source.silentAggregates()[index].numberOfAggregates() );
               destination->setSilentAggregateList( index, agg );
            }
         }

         return destination;
      }

      void DtAggregateTranslator::syncPortalDeadReckonedValues(
         DtPortalAggregate& destination, const DtAggregateStateRepository& source )
      {
         destination.setLocation( source.location() );
         destination.setVelocity( source.velocity() );
         destination.setAcceleration( source.acceleration() );
         destination.setOrientation( source.orientation() );
         destination.setRotationalVelocity( source.rotationalVelocity() );
         destination.setRelativeLocation( source.relativeLocation() );
         destination.setRelativeVelocity( source.relativeVelocity() );
         destination.setRelativeAcceleration( source.relativeAcceleration() );
         destination.setRelativeOrientation( source.relativeOrientation() );
         destination.setRelativeRotationalVelocity( source.relativeRotationalVelocity() );
      }

      void DtAggregateTranslator::syncDisDeadReckonedValues(
         DtAggregateStateRepository& destination, const DtPortalAggregate& source )
      {
         destination.setLocation( source.location() );
         destination.setVelocity( source.velocity() );
         destination.setAcceleration( source.acceleration() );
         destination.setOrientation( source.orientation() );
         destination.setRotationalVelocity( source.rotationalVelocity() );
         destination.setRelativeLocation( source.relativeLocation() );
         destination.setRelativeVelocity( source.relativeVelocity() );
         destination.setRelativeAcceleration( source.relativeAcceleration() );
         destination.setRelativeOrientation( source.relativeOrientation() );
         destination.setRelativeRotationalVelocity( source.relativeRotationalVelocity() );
      }

   }
}
