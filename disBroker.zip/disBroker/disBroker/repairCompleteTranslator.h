/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file repairCompleteTranslator.h
//! \brief Contains the DtRepairCompleteTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pRepairCompleteInteraction.h>
#include <vl/repairResponsePdu.h>

namespace MAKVrExchange
{

   class DtPortalRepairCompleteInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides RepairComplete interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtRepairCompleteTranslator
         : public DtDisInteractionTranslator<DtPortalRepairCompleteInteraction,DtRepairCompleteInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Repair Complete" );

         //! \brief CTOR.
         DtRepairCompleteTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtRepairCompleteTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalRepairCompleteInteraction& inter );

         //! \brief Translates the repair complete interaction into the portal.
         virtual DtPortalRepairCompleteInteraction* translate(
            DtPortalRepairCompleteInteraction* destination,
            const DtRepairCompleteInteraction& source );

         //! \brief Translates the repair complete interaction from the portal.
         virtual DtRepairCompleteInteraction* translate( DtRepairCompleteInteraction* destination,
            const DtPortalRepairCompleteInteraction& source );

      };

   }
}
