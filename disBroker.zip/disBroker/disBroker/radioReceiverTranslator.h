/*****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioReceiverTranslator.h
//! \brief Contains the DtRadioReceiverTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/embeddedSystemTranslator.h>
#include <vl/reflectedRadioReceiverList.h>
#include <vl/radioReceiverPublisher.h>

class DtReflectedRadioReceiver;
class DtRadioReceiverRepository;

#define RADIO_RECV_TEMPLATE_ARGS \
   DtPortalRadioReceiverObject, DtPortalReflectedRadioReceiverObject, \
   DtReflectedRadioReceiver, DtReflectedRadioReceiverList, \
   DtRadioReceiverRepository, DtRadioReceiverPublisher

namespace MAKVrExchange
{

   class DtPortalRadioReceiverObject;

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<RADIO_RECV_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedRadioReceiverObject* refObj,
         const DtString& identifier );

      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<RADIO_RECV_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedRadioReceiverObject* refObj,
         const DtEntityIdentifier& objectName );


      //! \brief Provides Radio Receiver object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtRadioReceiverTranslator
         : public DtEmbeddedSystemTranslator<RADIO_RECV_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Radio Receiver" );

         //! \brief CTOR.
         DtRadioReceiverTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtRadioReceiverTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedRadioReceiverObject* refObj );

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Overridden to use the radio receiver object type.
         virtual bool performDisGlobalIdMapping( const DtObjectPublisher* publisher,
            const DtPortalReflectedRadioReceiverObject& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Construct the portal object name.
         //! Overridden to construct a radio receiver name.
         virtual DtString portalObjectName( const DtReflectedRadioReceiver* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Overridden to use the radio receiver object type.
         virtual bool performPortalGlobalIdMapping(
            const DtPortalRadioReceiverObjectPublisher* publisher,
            const DtReflectedRadioReceiver& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Destroy the brokerObject's publisher.
         //! Overridden to correctly unmap the publisher's id.
         virtual void deleteDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Translates a Radio Receiver object into the portal.
         virtual DtPortalRadioReceiverObject* translate( DtPortalRadioReceiverObject* destination,
            const DtRadioReceiverRepository& source, const DtReflectedRadioReceiver& refObj );

         //! \brief Translates a Radio Receiver object from the portal.
         virtual DtRadioReceiverRepository* translate( DtRadioReceiverRepository* destination,
            const DtPortalRadioReceiverObject& source, const DtPortalReflectedRadioReceiverObject& refObj );

      };

   }
}
