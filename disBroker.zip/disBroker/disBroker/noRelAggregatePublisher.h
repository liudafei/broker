/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file noRelAggregatePublisher.cxx
//! \brief Contains the DtNoRelAggregatePublisher class declaration.
//! \ingroup disBroker

#pragma once

#if DtDIS

#include <disBroker/dllExport.h>
#include <vl/aggregatePublisherDIS.h>

class DtExerciseConn;

//! Instances of DtNoRelAggregatePublisher are used to take care of the details
//! associated with publishing the state of an aggregate.
//! \ingroup vl
class DT_DLL_DISBROKER DtNoRelAggregatePublisher : public DtAggregatePublisher
{
public:

   //! constructor
   DtNoRelAggregatePublisher( DtAggregateStateRepository *stateRepToUse,
      DtExerciseConn* conn, const DtObjectId& id = DtObjectId::nullId() );

   //! constructor
   DtNoRelAggregatePublisher( DtExerciseConn* conn, const DtObjectId& id = DtObjectId::nullId() );

   //! constructor
   //! The default is = (-1,-1,-1)
   DtNoRelAggregatePublisher( const DtEntityType& type, DtExerciseConn* conn,
      const DtObjectId& id = DtObjectId::defaultId() );

   //! constructor
   //! The default is = (-1,-1,-1)
   DtNoRelAggregatePublisher( const DtEntityType& type, DtExerciseConn* conn,
      DtDeadReckonTypes algorithm, DtForceType forceId, const DtObjectId& id = DtObjectId::defaultId() );

   //! destructor
   virtual ~DtNoRelAggregatePublisher();

   //! Tick the publisher.
   virtual void tick();

private:

   //! copy constructor -- Not Implemented
   DtNoRelAggregatePublisher( const DtNoRelAggregatePublisher& orig );

   //! assignment operator -- Not Implemented
   DtNoRelAggregatePublisher& operator = ( const DtNoRelAggregatePublisher& orig );


};

#endif
