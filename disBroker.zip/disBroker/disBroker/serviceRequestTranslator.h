/*****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file serviceRequestTranslator.h
//! \brief Contains the DtServiceRequestTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pServiceRequestInteraction.h>
#include <vl/serviceRequestPdu.h>

namespace MAKVrExchange
{

   class DtPortalServiceRequestInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides ServiceRequest interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtServiceRequestTranslator
         : public DtDisInteractionTranslator<DtPortalServiceRequestInteraction,DtServiceRequestInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Service Request" );

         //! \brief CTOR.
         DtServiceRequestTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtServiceRequestTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalServiceRequestInteraction& inter );

         //! \brief Translates the service request interaction into the portal.
         virtual DtPortalServiceRequestInteraction* translate(
            DtPortalServiceRequestInteraction* destination,
            const DtServiceRequestInteraction& source );

         //! \brief Translates the service request interaction from the portal.
         virtual DtServiceRequestInteraction* translate( DtServiceRequestInteraction* destination,
            const DtPortalServiceRequestInteraction& source );

      };

   }
}
