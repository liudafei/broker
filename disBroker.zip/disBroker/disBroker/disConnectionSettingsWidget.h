/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disConnectionSettingsWidget.h
//! \brief Contains the DtDisConnectionSettingsWidget class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/dllExport.h>
#include <widgets/connectionSettingsWidget.h>
#include <vlutil/vlString.h>
#include <map>

class QSpinBox;
class QComboBox;
class QLineEdit;
class QPushButton;
class QToolButton;

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      class DtDisBrokerInitializer;

      //! \brief Widget containing the connection settings for the DIS broker.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDisConnectionSettingsWidget
         : public DtConnectionSettingsWidget
      {  Q_OBJECT;
      public:

         //! \brief Default Constructor.
         DtDisConnectionSettingsWidget( QWidget* parent = 0 );

         //! \brief Destructor.
         virtual ~DtDisConnectionSettingsWidget();

         //! \brief Initializes the widget.
         //! Overridden to call populateAvailableNicAddresses().
         virtual void initialize( DtBrokerInitializer* init );

         //! \brief Accessor for casted DIS Initializer.
         virtual DtDisBrokerInitializer* disInitializer();

         //! \brief Returns the widget's icon.
         virtual QIcon icon();

         //! \brief Returns the widget's icon filepath.
         virtual std::string iconFilepath();

         //! @name Connection Settings Setters/Getters
         //! @{

         //! \brief Set DIS port value.
         virtual void setPort( int port );
         //! \brief Get DIS port value.
         virtual int port() const;

         //! \brief Set Exercise id.
         virtual void setExerciseId( int id );
         //! \brief Get Exercise id.
         virtual int exerciseId() const;

         //! \brief Set Destination address.
         virtual void setDestinationAddress( const QString& addr );
         //! \brief Get Destination address.
         virtual QString destinationAddress() const;

         //! \brief Set Multicast Interface Device.
         virtual void setDeviceAddress( const QString& addr );
         //! \brief Get Multicast Interface Device.
         virtual QString deviceAddress() const;

         //! \brief Set Multicast Device.
         virtual void setSubnetMask( const QString& mask );
         //! \brief Get Multicast Device.
         virtual QString subnetMask() const;

         //! \brief Set the multicast subscription set.
         virtual void setDisMcastSubscriptionSet( const std::vector<DtString>& mcastSet );
         //! \brief Get the multicast subscription set.
         virtual QStringList disMcastSubscriptionSet() const;

         virtual void setSocketSendBufferSize( int );
         //! \brief Get Scoket Send Buffer Size
         virtual int socketSendBufferSize() const;

         virtual void setSocketReceiveBufferSize( int );
         //! \brief Get Socket Receive Buffer Size
         virtual int socketReceiveBufferSize() const;

         //! \brief Set the multicast packet time-to-live.
         virtual void setMulticastTimeToLive( int );
         //! \brief Get the multicast packet time-to-live.
         virtual int multicastTimeToLive() const;

         //! @}

         //! \brief Updates the initializer with the dialog's current settings.
         virtual void applyCurrentSettings();

         //! \brief Updates the dialog with the initializer's current settings.
         virtual void loadCurrentSettings();

      protected slots:

         //! @name User input slots.
         //! These slots receive and process user input in the dialog.
         //! @{

         virtual void on_portSpinBox_valueChanged( int newPort );
         virtual void on_exerciseIdSpinBox_valueChanged( int newId );
         virtual void on_nicAddressComboBox_currentIndexChanged( const QString& newNicAddr );
         virtual void on_advancedButton_toggled( bool enabled );
         virtual void on_destinationAddressEdit_editingFinished();
         virtual void on_multicastAddressesEdit_editingFinished();
         virtual void on_multicastAddressEditButton_released();
         virtual void on_sendBufferSizeSpinBox_valueChanged( int sendBufferSize );
         virtual void on_recvBufferSizeSpinBox_valueChanged( int recvBufferSize );
         virtual void on_multicastTtlSpinBox_valueChanged( int mcastTtl );
         virtual void on_subnetMaskEdit_editingFinished();

         //! @}

      protected:

         //! Lays out the widget's fields.
         virtual void setupGui();

         //! Connects to signals from the input widgets.
         virtual void connectToSignals();

         //! Populates the network interface address combo box.
         virtual void populateAvailableNicAddresses();

         //! Looks up the default broadcast address for the given NIC address.
         virtual QString defaultBroadcastAddr( const QString& nicAddr );

         //! Checks to make sure the given strings are valid ip addresses.
         //! Any invalid addresses are added to the QStringList badAddresses.
         //! \returns true if all addresses are valid, false otherwise.
         virtual bool validAddresses( const QStringList& mcastAddresses,
            QStringList& badAddresses );

         //! Checks for bad addresses and reports and error if necessary.
         //! Bad addresses are detected using the validAddresses(..) method,
         //! and any bad addresses are removed from the input list and
         //! returned as a separate list.
         virtual QStringList validateMulticastAddresses( QStringList& mcastAddrs );

      protected:

         typedef std::map<QString,QString> UserNicDestAddrs;
         UserNicDestAddrs myUserNicDestinationAddresses;

         QSpinBox* myPortSpinBox;
         QSpinBox* myExerciseIdSpinBox;
         QComboBox* myNicAddressComboBox;
         QToolButton* myAdvancedButton;
         QWidget* myAdvancedWidget;
         QLineEdit* myDestinationAddressEdit;
         QLineEdit* myMulticastAddressesEdit;
         QPushButton* myMulticastAddressEditButton;
         QSpinBox* mySendBufferSizeSpinBox;
         QSpinBox* myRecvBufferSizeSpinBox;
         QSpinBox* myMulticastTtlSpinBox;
         QLineEdit* mySubnetMaskEdit;

      };

   }
}
