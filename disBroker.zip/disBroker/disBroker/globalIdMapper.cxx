/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file globalIdMapper.cxx
//! \brief Contains the DtGlobalIdMapper class definition.
//! \ingroup disBroker

#include <disBroker/globalIdMapper.h>

#include <vl/globalObjectDesignatorHashKey.h>

#include <vlutil/vlPrint.h>
#include <vlutil/vlUtil.h>

#include <iostream>
#include <assert.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //
      // DtGlobalIdMapper
      //

      DtGlobalIdMapper::DtGlobalIdMapper()
         : myDebugOutputOn( false )
         , myParseUnknownIds( false )
         , myPortalIdHashList( 0 )
         , myDisIdHashList( 0 )
         , myUnknownPortalIdHashList( 0 )
         , myUnknownDisIdHashList( 0 )
         , myEmptyPortalId()
         , myEmptyDisId()
      {
         myPortalIdHashList = new DtHashlist();
         myDisIdHashList = new DtHashlist();

         myUnknownPortalIdHashList = new DtHashlist();
         myUnknownDisIdHashList = new DtHashlist();

      }

      DtGlobalIdMapper::~DtGlobalIdMapper()
      {
         DtDELETE( myPortalIdHashList );
         DtDELETE( myDisIdHashList );

         DtDELETE( myUnknownPortalIdHashList );
         DtDELETE( myUnknownDisIdHashList );
      }

      bool DtGlobalIdMapper::add( const PortalId& portal_name, const DisId& dis_name,
         ObjectType oType /* = EntityType */,
         int systemId /* = NoSystemId */,
         int beamId /* = NoBeamId */ )
      {
         if ( myDebugOutputOn )
         {
            DtInfo << "Broker(DIS Simulation)[GlobalIdMapper]:  registering names Portal = ("
               << portal_name.string() << ")"
               << "<-> DIS"
               << "(" << dis_name.string() << ")"
               << " ObjectType("  << oType << ")"
               << " SystemId(" << systemId << ")"
               << " BeamId(" << beamId << ")"
               << std::endl;
         }

         DtStringHashKey disKey = createDisKey( dis_name, oType, systemId, beamId );
         DtStringHashKey  portalKey( portal_name );

         // see if we can add these names. If they are in there
         // we need to return false.
         if ( myPortalIdHashList->lookup(disKey)
            || myDisIdHashList->lookup(portalKey) )
         {
            return false;
         }

         // Now check unknown ID lists
         if ( myUnknownPortalIdHashList->lookup(disKey) )
         {
            if ( myDebugOutputOn )
            {
               DtInfo( "Broker(DIS Simulation)[GlobalIdMapper]: Found %s on the unknown"
                  " Portal Global ID list... removing\n", portal_name.string() );
            }

            PortalId* removeName = static_cast<PortalId*>(
               myUnknownPortalIdHashList->remove(disKey) );

            delete removeName;
         }

         if ( myUnknownDisIdHashList->lookup(portalKey) )
         {
            if ( myDebugOutputOn )
            {
               DtInfo( "Broker(DIS Simulation)[GlobalIdMapper]: Found %s on the unknown"
                  " DIS Global ID list... removing\n", dis_name.string() );
            }

            DtDisGlobalIdContainer* removeName = static_cast<DtDisGlobalIdContainer*>(
               myUnknownDisIdHashList->remove(portalKey) );

            delete removeName;
         }

         // It's OK TO Add...

         // Let's add the Portal ID to the DIS Hash List (we can look it up with the DIS key.
         myPortalIdHashList->add( disKey, new PortalId(portal_name) );

         // Let's add the DIS ID to the Portal hash List (we can look it up with the Portal key.
         myDisIdHashList->add( portalKey, new DtDisGlobalIdContainer(dis_name,oType,systemId,beamId) );

         return true;
      }

      DtStringHashKey DtGlobalIdMapper::createDisKey( const DisId& dis_name,
         ObjectType oType, int systemId, int beamId ) const
      {
         char buff30[30];
         sprintf( buff30, "%d%d%d", systemId, oType, beamId );
         DtStringHashKey disKey( dis_name.string() + DtString(buff30) );
         return disKey;
      }

      bool DtGlobalIdMapper::addUnknownIds( const PortalId& portal_name, const DisId& dis_name,
         ObjectType oType /* = EntityType */,
         int systemId /* = NoSystemId */,
         int beamId /* = NoBeamId */ )
      {
         DtStringHashKey disKey = createDisKey( dis_name, oType, systemId, beamId );
         DtStringHashKey  portalKey( portal_name );

         // see if we can add these names. If they are in there
         // we need to return false.
         if ( myUnknownPortalIdHashList->lookup(disKey) )
            // || myUnknownDisIdHashList->lookup(portalKey) )
         {
            return false;
         }

         // It's OK TO Add...

         // Let's add the Portal ID to the DIS Hash List (we can look it up with the DIS key.
         myUnknownPortalIdHashList->add( disKey, new PortalId(portal_name) );

         // Let's add the DIS ID to the Portal hash List (we can look it up with the Portal key.
         myUnknownDisIdHashList->add( portalKey, new DtDisGlobalIdContainer(dis_name,oType,systemId,beamId) );

         return true;
      }

      void DtGlobalIdMapper::setDebug( bool debugOn )
      {
         myDebugOutputOn = debugOn;
      }

      bool DtGlobalIdMapper::debug() const
      {
         return myDebugOutputOn;
      }

      void DtGlobalIdMapper::setParseUnknownIds( bool parseOn )
      {
         myParseUnknownIds = parseOn;
      }

      bool DtGlobalIdMapper::parseUnknownIds() const
      {
         return myParseUnknownIds;
      }

      bool DtGlobalIdMapper::unique( const PortalId& portal_name ) const
      {
         return ! myDisIdHashList->lookup( DtStringHashKey(portal_name) );
      }

      bool DtGlobalIdMapper::unique( const DisId& dis_name,
         ObjectType oType /* = EntityType */,
         int systemId /* = NoSystemId */,
         int beamId /* = NoBeamId */ ) const
      {
         DtStringHashKey disKey = createDisKey( dis_name, oType, systemId, beamId );
         return ! myPortalIdHashList->lookup( disKey );
      }

      const DtGlobalIdMapper::PortalId& DtGlobalIdMapper::convertDisGidToPortalGid(
         const DisId& dis_name, ObjectType oType /* = EntityType */,
         int systemId /* = NoSystemId */,
         int beamId /* = NoBeamId */ )
      {
         DtStringHashKey disKey = createDisKey( dis_name, oType, systemId, beamId );
         void* ptr = myPortalIdHashList->lookup( disKey );
         if ( ! ptr )
         {
            if ( myDebugOutputOn )
            {
               DtInfo << "Broker(DIS Simulation)[GlobalIdMapper]: failed to convert DIS->Portal -"
                  << " disId(" << dis_name.string() << ")"
                  << " ObjectType(" << oType << ")"
                  << " SystemId(" << systemId << ")"
                  << " BeamId(" << beamId << ")"
                  << std::endl;
            }

            // If we're parsing unknown ID's
            if ( parseUnknownIds() && dis_name != DisId::nullId() )
            {
               return parseAndCreatePortalId( dis_name, disKey, oType, systemId, beamId );
            }

            return myEmptyPortalId;
         }

         return *static_cast<PortalId*>(ptr);
      }

      const DtGlobalIdMapper::PortalId& DtGlobalIdMapper::parseAndCreatePortalId(
         const DisId& disName, const DtStringHashKey& disKey,
         ObjectType oType /* = EntityType */,
         int systemId /* = NoSystemId */,
         int beamId /* = NoBeamId */ )
      {
         // Check if it's already in our unknown list... If so, return it
         void* ptr = myUnknownPortalIdHashList->lookup( disKey );
         if ( ptr )
         {
            if ( myDebugOutputOn )
            {
               DtInfo << "Broker(DIS Simulation)[GlobalIdMapper]: Found "
                  << disName.string() << " on Unknown Global ID list" << std::endl;
            }
            return *static_cast<PortalId*>(ptr);
         }

         if ( myDebugOutputOn )
         {
            DtInfo << "Broker(DIS Simulation)[GlobalIdMapper]: Attempting to parse global DIS ID, "
               << disName.string() << ", to convert to Portal ID" << std::endl;
         }

         // Create new Portal Global object ID from DIS ID + 'vrx'
         DtString newPortalName( disName.string() );

         // Add -<sysId>Xvrx, because signal interactions will look for the system
         // ID and a radio transmitter...  Other object types should be added in
         // the future
         if ( oType == RadioTransmitterType )
         {
            newPortalName += DtString("-");
            newPortalName += DtString(systemId);
            newPortalName += DtString("X");
         }
         else if ( oType == RadioReceiverType )
         {
            newPortalName += DtString("-");
            newPortalName += DtString(systemId);
            newPortalName += DtString("R");
         }

         newPortalName += "vrx";

         // Add the name to our global ID hash list
         if ( ! addUnknownIds(newPortalName,disName,oType,systemId,beamId) )
         {
            // Display warning if we can't add it to the list
            if ( myDebugOutputOn )
            {
               DtWarn << "Broker(DIS Simulation)[GlobalIdMapper]: Add failed while parsing unknown ID." << std::endl;
               if ( ! unique(disName) )
               {
                  DtWarn << "Broker(DIS Simulation)[GlobalIdMapper]: Name Collision on DIS " << disName.string() << std::endl;
               }
               if ( ! unique(newPortalName) )
               {
                  DtWarn << "Broker(DIS Simulation)[GlobalIdMapper]: Name Collision On Portal " << newPortalName.string() << std::endl;
               }
               DtWarn << "Broker(DIS Simulation)[GlobalIdMapper]: Ignoring collision." << std::endl;
            }
         }

         // Get the name just added and return it... If name couldn't be added, return the
         // empty string
         void* idPtr = myUnknownPortalIdHashList->lookup( disKey );
         if ( idPtr )
         {
            return *static_cast<PortalId*>(idPtr);
         }

         return myEmptyPortalId;
      }

      const DtGlobalIdMapper::DisId &DtGlobalIdMapper::convertPortalGidToDisGid(
         const PortalId& portal_name, ObjectType* oType /* = 0 */,
         int* systemId /* = 0 */, int* beamId /* = 0 */ )
      {
         DtStringHashKey  portalKey( portal_name );

         DtDisGlobalIdContainer* ptr = static_cast<DtDisGlobalIdContainer*>(
            myDisIdHashList->lookup(portalKey) );
         if ( ! ptr )
         {
            if ( myDebugOutputOn )
            {
               DtInfo << "Broker(DIS Simulation)[GlobalIdMapper]: failed to convert Portal->DIS ID("
                  << portal_name << ")" << std::endl;
            }

            if ( parseUnknownIds() )
            {
               return parseAndCreateDisId( portal_name, portalKey, oType, systemId, beamId );
            }

            // Blank these out
            if ( oType )
            {
               *oType = NoType;
            }
            if ( systemId )
            {
               *systemId = NoSystemId;
            }
            if ( beamId )
            {
               *beamId = NoBeamId;
            }
            return myEmptyDisId;
         }

         if ( oType )
         {
            *oType = ptr->objectType();
         }
         if ( systemId )
         {
            *systemId = ptr->systemId();
         }
         if ( beamId )
         {
            *beamId = ptr->beamId();
         }
         return *ptr->gid();
      }

      const DtGlobalIdMapper::DisId& DtGlobalIdMapper::parseAndCreateDisId(
         const PortalId& portalName, const DtStringHashKey& portalKey,
         ObjectType* oType /* = 0 */,
         int* systemId /* = 0 */,
         int* beamId /* = 0 */ )
      {
         // MJI - This code needs to be cleaned up!
         DtDisGlobalIdContainer* ptr = static_cast<DtDisGlobalIdContainer*>(
            myUnknownDisIdHashList->lookup(portalKey) );
         if ( ptr )
         {
            if ( myDebugOutputOn )
            {
               DtInfo << "Broker(DIS Simulation)[GlobalIdMapper]: Found " << portalName.string()
                  << " on Unknown Global ID list. Looking up: " << portalName << std::endl;
            }

            if ( oType )
            {
               *oType = ptr->objectType();
            }
            if ( systemId )
            {
               *systemId = ptr->systemId();
            }
            if ( beamId )
            {
               *beamId = ptr->beamId();
            }
            return *ptr->gid();
         }

         if ( myDebugOutputOn )
         {
            DtInfo << "Broker(DIS Simulation)[GlobalIdMapper]: Attempting to parse global Portal ID ("
               << portalName << ") to convert to DIS ID" << std::endl;
         }

         // If we don't have a mapping, and parseUnknown ID's is set to 1
         // then try to parse the string
         char* p = (char*) portalName.c_str();

         // Get the site
         int site = (int) strtol( p, &p, 0 );
         if ( *p && *p == ':' )
         {
            ++p;
         }

         // Get the app
         int app = (int) strtol( p, &p, 0 );
         if ( *p && *p == ':' )
         {
            ++p;
         }

         // Get the entity
         int entityNumber = (int) strtol( p, &p, 0 );

         // Now check for a '-' in case of a radio ID...
         // This was added to allow signals to retain radio ID's, and the signal
         // interaction actually checks to determine if it is a radio transmitter
         // This should be extended for all types of objects
         if ( *p && *p == '-' )
         {
            ++p;

            if ( systemId )
            {
               *systemId = (int) strtol( p, &p, 0 );
            }

            if ( *p && *p == 'X' )
            {
               if ( oType )
               {
                  *oType = RadioTransmitterType;
               }
            }
         }

         ObjectType objectType = ( oType ? *oType : EntityType);
         int system = (systemId ? *systemId : NoSystemId);
         int beam = (beamId ? *beamId : NoBeamId);


         if (site && app)
         {
            // Create a new DIS global object designator with new s:a:e
            DisId disName(site, app, entityNumber);

            // Add it to our hash list
            if (!addUnknownIds(portalName, disName, objectType, system, beam))
            {
               if (myDebugOutputOn)
               {
                  DtWarn << "Broker(DIS Simulation)[GlobalIdMapper]: Add failed while parsing unknown ID.\n";
                  if (!unique(disName))
                  {
                     DtWarn << "Broker(DIS Simulation)[GlobalIdMapper]: Name Collision on DIS " << disName.string() << '\n';
                  }
                  if (!unique(portalName))
                  {
                     DtWarn << "Broker(DIS Simulation)[GlobalIdMapper]: Name Collision On Portal " << portalName.string() << '\n';
                  }
                  DtWarn << "Broker(DIS Simulation)[GlobalIdMapper]: Ignoring collision.\n";
               }
            }
            else if (myDebugOutputOn)
            {
               DtInfo
                  << "Broker(DIS Simulation)[GlobalIdMapper]:  Parse Successful("
                  << portalName << ") ->"
                  << disName.string() << std::endl;
            }

            ptr = static_cast<DtDisGlobalIdContainer *>(myUnknownDisIdHashList->lookup(portalKey));

            if(ptr)
            {
               if (oType) *oType = ptr->objectType();
               if (systemId) *systemId = ptr->systemId();
               if (beamId) *beamId = ptr->beamId();
               return (*(ptr->gid()));
            }
            else
            {
               return myEmptyDisId;
            }
         }
         else
         {
            return myEmptyDisId;
         }
      }

      void DtGlobalIdMapper::remove(const PortalId &portal_name)
      {
         int systemId = NoSystemId;
         int beamId = NoBeamId;
         ObjectType oType = EntityType;
         const DisId &disNamePtr = convertPortalGidToDisGid(portal_name, &oType, &systemId, &beamId);
         remove(portal_name, disNamePtr, oType, systemId, beamId);
      }

      void DtGlobalIdMapper::remove(const DisId &dis_name,
         ObjectType oType,
         int systemId,
         int beamId)
      {
         remove( convertDisGidToPortalGid(dis_name,oType,systemId,beamId), dis_name, oType, systemId, beamId);
      }

      void DtGlobalIdMapper::remove(const PortalId &portal_name,
         const DisId &dis_name,
         ObjectType oType,
         int systemId,
         int beamId)
      {
         if (myDebugOutputOn)
         {
            DtInfo("Broker(DIS Simulation)[GlobalIdMapper]: removed names Portal = (%s) DIS (%s)",
               portal_name.string(),
               dis_name.string());

            if (oType != EntityType)
            {
               DtInfo(" ObjectType(%d)", oType);
            }

            if (systemId != NoSystemId)
            {
               DtInfo(" System ID(%d)", systemId);
            }

            if (beamId != NoSystemId)
            {
               DtInfo(" Beam ID(%d)", beamId);
            }

            DtInfo("\n");
         }

         DtStringHashKey  portalKey(portal_name);
         DtStringHashKey disKey = createDisKey(dis_name, oType, systemId, beamId);

         PortalId *portalId =
            static_cast<PortalId*>(
            myPortalIdHashList->remove(disKey));


         DtDisGlobalIdContainer *disContainer =
            static_cast<DtDisGlobalIdContainer*>(
            myDisIdHashList->remove(portalKey));

         DtDELETE(disContainer);
         DtDELETE(portalId);


      }

      std::ostream& operator<<( std::ostream& os, const DtGlobalIdMapper::ObjectType &ut )
      {

         switch(ut)
         {

         case DtGlobalIdMapper::NoType:
            os << "NoType";
            break;
         case DtGlobalIdMapper::EntityType :
            os << "EntityType";
            break;
         case DtGlobalIdMapper::EmitterSystemType :
            os << "EmitterSystemType";
            break;
         case DtGlobalIdMapper::RadioTransmitterType :
            os << "RadioTransmitterType ";
            break;
         case DtGlobalIdMapper::RadioReceiverType:
            os << "RadioReceiverType";
            break;
         case DtGlobalIdMapper::EmitterBeamType:
            os << "EmitterBeamType";
            break;
         case DtGlobalIdMapper::EnvironmentProcess:
            os << "EnvironmentProcess";
            break;
         case DtGlobalIdMapper::GridData:
            os << "GridData";
            break;
         }
         return os;
      }


      //
      // DtDisGlobalIdContainer
      //

      DtDisGlobalIdContainer::DtDisGlobalIdContainer( const DtGlobalIdMapper::DisId& name,
            DtGlobalIdMapper::ObjectType oType, int sysId, int beamId )
         : myType( oType )
         , mySystemId( sysId )
         , myBeamId( beamId )
         , myGid( 0 )
      {
         myGid = new DtGlobalIdMapper::DisId( name );
         assert( myGid );
      }

      DtDisGlobalIdContainer::~DtDisGlobalIdContainer()
      {
         DtDELETE( myGid );
      }

      int DtDisGlobalIdContainer::systemId() const
      {
         return mySystemId;
      }

      int DtDisGlobalIdContainer::beamId() const
      {
         return myBeamId;
      }

      DtGlobalIdMapper::ObjectType DtDisGlobalIdContainer::objectType() const
      {
         return myType;
      }

      const DtGlobalIdMapper::DisId *DtDisGlobalIdContainer::gid() const
      {
         return myGid;
      }

   }
}
