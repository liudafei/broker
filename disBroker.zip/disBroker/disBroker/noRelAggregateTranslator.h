/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file aggTrans.h
//! \brief Contains the DtNoRelAggregateTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <disBroker/noRelAggregatePublisher.h>
#include <vl/reflectedAggregateList.h>

#define AGGREGATE_TEMPLATE_ARGS \
   DtPortalAggregate, DtPortalReflectedAggregate, \
   DtReflectedAggregate, DtReflectedAggregateList, \
   DtAggregateStateRepository, DtNoRelAggregatePublisher

class DtAggregateStateRepository;

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<AGGREGATE_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedAggregate* refObj, const DtString& identifier );

      //! Template specialization to avoid compilation errors
      //! resulting from aggregate publisher CTOR.
      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<AGGREGATE_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedAggregate* refObj, const DtEntityIdentifier& name );


      //! \brief Provides Aggregate object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtNoRelAggregateTranslator
         : public DtDisObjectTranslator<AGGREGATE_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Aggregate (No-RL)" );

         //! \brief CTOR.
         DtNoRelAggregateTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtNoRelAggregateTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( const DtBrokerObject* brokerObject,
            const DtPortalReflectedAggregate* refObj );

         //! \brief Gets the reflected object's entity id for publisher creation.
         virtual DtString disObjectName( const DtPortalReflectedAggregate* refObj ) const;

         //! \brief Creates a new publisher and stores it in the broker object.
         //! Overridden to enable dead-reckoning on the state repository.
         virtual void createDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Construct the portal object name.
         //! Overridden to construct an aggregate object name.
         virtual DtString portalObjectName( const DtReflectedAggregate* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         //! Overridden to update with the marking text and entity type.
         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const DtAggregateStateRepository& sr );

         //! \brief Updates the broker object with the latest information.
         //! Overridden to update with the marking text and entity type.
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj,
            const DtPortalAggregate& sr );

         //! \brief Performs the filtering logic.
         virtual void updateFilteredState( DtBrokerObject* brokerObj,
            DtPortalAggregatePublisher* publisher, DtReflectedAggregate* refObj );

         //! \brief Translates an Aggregate into the portal.
         virtual DtPortalAggregate* translate( DtPortalAggregate* destination,
            const DtAggregateStateRepository& source,
            const DtReflectedAggregate& refObj );

         //! \brief Translates an Aggregate from the portal.
         virtual DtAggregateStateRepository* translate(
            DtAggregateStateRepository* destination,
            const DtPortalAggregate& source,
            const DtPortalReflectedAggregate& refObj );

         //! \brief Synchronizes the Portal object's dead-reckoned values with the DIS object's.
         virtual void syncPortalDeadReckonedValues( DtPortalAggregate& destination,
            const DtAggregateStateRepository& source );

         //! \brief Synchronizes the DIS object's dead-reckoned values with the Portal object's.
         virtual void syncDisDeadReckonedValues( DtAggregateStateRepository& destination,
            const DtPortalAggregate& source );

      };

   }
}
