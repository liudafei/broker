/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file detonationTranslator.h
//! \brief Contains the DtDetonationTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pDetonationInter.h>
#include <vl/detonationInteraction.h>

namespace MAKVrExchange
{

   class DtPortalDetonationInteraction;

   namespace DtDisBroker
   {

      //! \brief Provides Detonation interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDetonationTranslator
         : public DtDisInteractionTranslator<DtPortalDetonationInteraction,DtDetonationInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Detonation" );

         //! \brief CTOR.
         DtDetonationTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtDetonationTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalDetonationInteraction& inter );

         //! \brief Translates the detonation interaction into the portal.
         virtual DtPortalDetonationInteraction* translate(
            DtPortalDetonationInteraction* destination,
            const DtDetonationInteraction& source );

         //! \brief Translates the portal detonation interaction from the portal.
         virtual DtDetonationInteraction* translate( DtDetonationInteraction* destination,
            const DtPortalDetonationInteraction& source );

      };

   }
}
