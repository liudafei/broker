/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file repairCompleteTranslator.cxx
//! \brief Contains the DtRepairCompleteTranslator class definition.
//! \ingroup disBroker

#include <disBroker/repairCompleteTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtRepairCompleteTranslator::DtRepairCompleteTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalRepairCompleteInteraction::theKind )
      {
      }

      DtRepairCompleteTranslator::~DtRepairCompleteTranslator()
      {
      }

      bool DtRepairCompleteTranslator::isPortalDiscoverable(
         const DtPortalRepairCompleteInteraction& inter )
      {
         return ( testGlobalIdMapping("Receiving ID",inter.receivingId())
            && testGlobalIdMapping("Repairing ID",inter.repairingId()) );
      }

      DtPortalRepairCompleteInteraction* DtRepairCompleteTranslator::translate(
         DtPortalRepairCompleteInteraction* destination, const DtRepairCompleteInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setRepairingId( disBroker()->convertGlobalId(source.repairingId()) );
         destination->setRepairType( source.repairType() );
         return destination;
      }

      DtRepairCompleteInteraction* DtRepairCompleteTranslator::translate(
         DtRepairCompleteInteraction* destination, const DtPortalRepairCompleteInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setRepairingId( disBroker()->convertGlobalId(source.repairingId()) );
         destination->setRepairType( (DtRepairType) source.repairType() );
         return destination;
      }

   }
}
