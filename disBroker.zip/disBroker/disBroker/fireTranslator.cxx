/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file fireTranslator.cxx
//! \brief Contains the DtFireTranslator class definition.
//! \ingroup disBroker

#include <disBroker/fireTranslator.h>
#include <disBroker/eventIdMapper.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtFireTranslator::DtFireTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalFireInteraction::theKind )
      {
      }

      DtFireTranslator::~DtFireTranslator()
      {
      }

      bool DtFireTranslator::isPortalDiscoverable(
         const DtPortalFireInteraction& inter )
      {
         return ( testGlobalIdMapping("Target ID",inter.targetId())
            && testGlobalIdMapping("Attacker ID",inter.attackerId())
            && testGlobalIdMapping("Munition ID",inter.munitionId()) );
      }

      DtPortalFireInteraction* DtFireTranslator::translate(
         DtPortalFireInteraction* destination, const DtFireInteraction& source )
      {
         destination->setAttackerId( disBroker()->convertGlobalId( source.attackerId() ));
         destination->setTargetId( disBroker()->convertGlobalId( source.targetId() ));
         destination->setMunitionId( disBroker()->convertGlobalId( source.munitionId() ));
         destination->setEventId( disBroker()->eventIdMapper()->convertEventId( source.eventId() ));
         destination->setFireMissionIndex( source.fireMissionIndex() );
         destination->setLocation( source.location() );
         destination->setVelocity( source.velocity() );
         destination->setRange( source.range() );
         destination->setFuseType( (DtDetonatorFuze)source.fuseType() );
         destination->setMunitionType( source.munitionType().string() );
         destination->setQuantity( source.quantity() );
         destination->setRate( source.rate() );
         destination->setWarheadType( (DtWarheadType)source.warheadType() );

         return destination;
      }

      DtFireInteraction* DtFireTranslator::translate(
         DtFireInteraction* destination, const DtPortalFireInteraction& source )
      {
         destination->setAttackerId( disBroker()->convertGlobalId(source.attackerId()) );
         destination->setTargetId( disBroker()->convertGlobalId( source.targetId() ));
         destination->setMunitionId( disBroker()->convertGlobalId( source.munitionId() ));
         destination->setEventId( disBroker()->eventIdMapper()->convertEventId( source.eventId() ));
         destination->setFireMissionIndex( source.fireMissionIndex() );
         destination->setLocation( source.location() );
         destination->setVelocity( source.velocity() );
         destination->setRange( source.range() );
         destination->setFuseType( (DtDetonatorFuze)source.fuseType() );
         destination->setMunitionType( source.munitionType().string() );
         destination->setQuantity( source.quantity() );
         destination->setRate( source.rate() );
         destination->setWarheadType( (DtWarheadType)source.warheadType() );

         return destination;
      }

   }
}
