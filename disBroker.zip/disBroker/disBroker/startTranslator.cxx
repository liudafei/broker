/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file startTranslator.cxx
//! \brief Contains the DtStartTranslator class definition.
//! \ingroup disBroker

#include <disBroker/startTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtStartTranslator::DtStartTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalStartInteraction::theKind )
      {
      }

      DtStartTranslator::~DtStartTranslator()
      {
      }

      bool DtStartTranslator::isPortalDiscoverable(
         const DtPortalStartInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.originatingEntity())
            && testGlobalIdMapping("Receiver ID",inter.receivingEntity()) );
      }

      DtPortalStartInteraction* DtStartTranslator::translate(
         DtPortalStartInteraction* destination, const DtStartResumePdu& source )
      {
         destination->setOriginatingEntity( disBroker()->convertGlobalId( source.senderId() ));
         destination->setReceivingEntity( disBroker()->convertGlobalId( source.receiverId() ));
         destination->setRequestIdentifier( source.requestId() );
         destination->setRealWorldTime( source.realWorldTime() );
         destination->setRealWorldTimeType( source.realWorldTimeType() );
         destination->setSimulationTime( source.simulationTime() );
         destination->setSimulationTimeType( source.simulationTimeType() );

         return destination;
      }

      DtStartResumePdu* DtStartTranslator::translate(
         DtStartResumePdu* destination, const DtPortalStartInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId( source.originatingEntity() ));
         destination->setReceiverId( disBroker()->convertGlobalId( source.receivingEntity() ));
         destination->setRealWorldTime( source.realWorldTime() );
         destination->setRealWorldTimeType(source.realWorldTimeType() );
         destination->setSimulationTime( source.simulationTime() );
         destination->setSimulationTimeType( source.simulationTimeType() );
         destination->setRequestId( source.requestIdentifier() );

         return destination;
      }

   }
}
