/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file collisionTranslator.h
//! \brief Contains the DtCollisionTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/collisionInteraction.h>
#include <portal/pCollisionInter.h>

namespace MAKVrExchange
{

   class DtPortalCollisionInteraction;

   namespace DtDisBroker
   {

      //! \brief Provides Collision interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtCollisionTranslator
         : public DtDisInteractionTranslator<DtPortalCollisionInteraction,DtCollisionInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Collision" );

         //! \brief CTOR.
         DtCollisionTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtCollisionTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalCollisionInteraction& inter );

         //! \brief Translates the collision interaction into the portal.
         virtual DtPortalCollisionInteraction* translate(
            DtPortalCollisionInteraction* destination,
            const DtCollisionInteraction& source );

         //! \brief Translates the portal collision interaction from the portal.
         virtual DtCollisionInteraction* translate( DtCollisionInteraction* destination,
            const DtPortalCollisionInteraction& source );

      };

   }
}
