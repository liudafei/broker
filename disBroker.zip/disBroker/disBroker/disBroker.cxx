/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disBroker.cxx
//! \brief Contains the DtDisBroker class definition.
//! \ingroup disBroker

#include <disBroker/disBroker.h>
#include <disBroker/disBrokerInitializer.h>

#include <portal/pConnection.h>
#include <portal/brokerErrorMessage.h>

#include <broker/statisticsManager.h>

#include <disBroker/acknowledgeTranslator.h>
#include <disBroker/actionRequestTranslator.h>
#include <disBroker/actionResponseTranslator.h>
#include <disBroker/activeSonarTranslator.h>
#include <disBroker/additionalPassiveActivitiesTranslator.h>
#include <disBroker/aggregateTranslator.h>
#include <disBroker/arealObjectTranslator.h>
#include <disBroker/collisionTranslator.h>
#include <disBroker/commentTranslator.h>
#include <disBroker/createEntityTranslator.h>
#include <disBroker/dataTranslator.h>
#include <disBroker/dataQueryTranslator.h>
#include <disBroker/designatorTranslator.h>
#include <disBroker/detonationTranslator.h>
#include <disBroker/emitterSystemTranslator.h>
#include <disBroker/entityIdMapper.h>
#include <disBroker/entityTranslator.h>
#include <disBroker/environmentProcessTranslator.h>
#include <disBroker/eventIdMapper.h>
#include <disBroker/eventReportTranslator.h>
#include <disBroker/fireTranslator.h>
#include <disBroker/griddedDataTranslator.h>
#include <disBroker/iffTranslator.h>
#include <disBroker/underwaterAcousticsPublisherManager.h>
#include <disBroker/linearObjectTranslator.h>
#include <disBroker/loggerControlTranslator.h>
#include <disBroker/pointObjectTranslator.h>
#include <disBroker/propulsionNoiseTranslator.h>
#include <disBroker/radioReceiverTranslator.h>
#include <disBroker/radioSignalTranslator.h>
#include <disBroker/radioTransmitterTranslator.h>
#include <disBroker/removeEntityTranslator.h>
#include <disBroker/repairCompleteTranslator.h>
#include <disBroker/repairResponseTranslator.h>
#include <disBroker/resupplyCancelTranslator.h>
#include <disBroker/resupplyOfferTranslator.h>
#include <disBroker/resupplyReceivedTranslator.h>
#include <disBroker/serviceRequestTranslator.h>
#include <disBroker/setDataTranslator.h>
#include <disBroker/startTranslator.h>
#include <disBroker/stopTranslator.h>
#include <disBroker/transferControlTranslator.h>

// Workaround for VRL Feature #4025
// Revert when that is fixed.
#include <disBroker/noRelAggregateTranslator.h>
#include <disBroker/noRelEntityTranslator.h>

#include <vlutil/vlInetInterfaceUtils.h>
#include <vlutil/vlProcessControl.h>
#include <vlutil/vlInetAddrUtils.h>
#include <vlutil/vlExceptions.h>

#include <vl/exerciseConnInitializer.h>
#include <vl/exerciseConn.h>

#include <QtCore/QTimer>
#include <QApplication>

#include <assert.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtUnderwaterAcousticsPublisherManagerCreator
         DtDisBroker::theUnderwaterAcousticsPublisherManagerCreator = 0;

      DtGlobalIdMapperCreator DtDisBroker::theGlobalIdMapperCreator = 0;

      DtBroker* DtDisBroker::create( DtBrokerInitializer* init )
      {
         DtDisBroker* broker = new DtDisBroker();
         broker->initialize( dynamic_cast<DtDisBrokerInitializer*>(init) );
         return broker;
      }

      DtDisBroker::DtDisBroker()
         : ParentClass()
         , myDisMcastDevice( 0 )
         , myUndwaAcPublisherManager( 0 )
         , myGlobalIdMapper( 0 )
         , myEventIdMapper( 0 )
         , myEntityIdMapper( 0 )
      {
      }

      DtDisBroker::~DtDisBroker()
      {
         DtInfo << "Broker(" << brokerName() << "): Shutting down." << std::endl;
      }

      void DtDisBroker::initialize( DtDisBrokerInitializer* init )
      {
         setupTranslators( init );
         ParentClass::initialize( init );
      }

      void DtDisBroker::setupTranslators( DtDisBrokerInitializer* init )
      {
         // Workaround for VRL Feature #4025 - Revert when that is fixed.
         // Set up translators for Relative Location PDU sensitive objects.
         if ( init->sendRelativeLocationPdus() )
         {
            myObjectTranslatorFactory.addCreator<DtAggregateTranslator>();
            myObjectTranslatorFactory.addCreator<DtEntityTranslator>();
         }
         else
         {
            myObjectTranslatorFactory.addCreator<DtNoRelAggregateTranslator>();
            myObjectTranslatorFactory.addCreator<DtNoRelEntityTranslator>();
         }

         // Set up the object translators.
         myObjectTranslatorFactory.addCreator<DtActiveSonarTranslator>();
         myObjectTranslatorFactory.addCreator<DtAdditionalPassiveActivitiesTranslator>();
         myObjectTranslatorFactory.addCreator<DtArealObjectTranslator>();
         myObjectTranslatorFactory.addCreator<DtDesignatorTranslator>();
         myObjectTranslatorFactory.addCreator<DtEmitterSystemTranslator>();
         myObjectTranslatorFactory.addCreator<DtEnvironmentProcessTranslator>();
         myObjectTranslatorFactory.addCreator<DtGriddedDataObjectTranslator>();
         myObjectTranslatorFactory.addCreator<DtIffTranslator>();
         myObjectTranslatorFactory.addCreator<DtLinearObjectTranslator>();
         myObjectTranslatorFactory.addCreator<DtPointObjectTranslator>();
         myObjectTranslatorFactory.addCreator<DtPropulsionNoiseTranslator>();
         myObjectTranslatorFactory.addCreator<DtRadioReceiverTranslator>();
         myObjectTranslatorFactory.addCreator<DtRadioTransmitterTranslator>();

         // Set up the interaction translators.
         myInteractionTranslatorFactory.addCreator<DtAcknowledgeTranslator>();
         myInteractionTranslatorFactory.addCreator<DtActionRequestTranslator>();
         myInteractionTranslatorFactory.addCreator<DtActionResponseTranslator>();
         myInteractionTranslatorFactory.addCreator<DtCollisionTranslator>();
         myInteractionTranslatorFactory.addCreator<DtCommentTranslator>();
         myInteractionTranslatorFactory.addCreator<DtCreateEntityTranslator>();
         myInteractionTranslatorFactory.addCreator<DtDataQueryTranslator>();
         myInteractionTranslatorFactory.addCreator<DtDataTranslator>();
         myInteractionTranslatorFactory.addCreator<DtDetonationTranslator>();
         myInteractionTranslatorFactory.addCreator<DtEventReportTranslator>();
         myInteractionTranslatorFactory.addCreator<DtFireTranslator>();
         myInteractionTranslatorFactory.addCreator<DtLoggerControlTranslator>();
         myInteractionTranslatorFactory.addCreator<DtRadioSignalTranslator>();
         myInteractionTranslatorFactory.addCreator<DtRemoveEntityTranslator>();
         myInteractionTranslatorFactory.addCreator<DtRepairCompleteTranslator>();
         myInteractionTranslatorFactory.addCreator<DtRepairResponseTranslator>();
         myInteractionTranslatorFactory.addCreator<DtResupplyOfferTranslator>();
         myInteractionTranslatorFactory.addCreator<DtResupplyCancelTranslator>();
         myInteractionTranslatorFactory.addCreator<DtResupplyReceivedTranslator>();
         myInteractionTranslatorFactory.addCreator<DtServiceRequestTranslator>();
         myInteractionTranslatorFactory.addCreator<DtSetDataTranslator>();
         myInteractionTranslatorFactory.addCreator<DtStartTranslator>();
         myInteractionTranslatorFactory.addCreator<DtStopTranslator>();
         myInteractionTranslatorFactory.addCreator<DtTransferControlTranslator>();
      }

      void DtDisBroker::startBroker()
      {
         DtDisBrokerInitializer* init = disInitializer();

         DtDisBroker::initDisConnection( *init );

         if ( ! init->splitUnderwaterAcousticPdus() )
         {
            if ( underwaterAcousticsPublisherManagerCreator() )
            {
               myUndwaAcPublisherManager = (*underwaterAcousticsPublisherManagerCreator())();
            }
            else
            {
               myUndwaAcPublisherManager = new DtUnderwaterAcousticsPublisherManager();
            }
         }

         if ( globalIdMapperCreator() )
         {
            myGlobalIdMapper = (*globalIdMapperCreator())();
         }
         else
         {
            myGlobalIdMapper = new DtGlobalIdMapper();
         }
         myGlobalIdMapper->setParseUnknownIds( init->parseUnknownIds() );
         myGlobalIdMapper->setDebug( init->debugGlobalIdMapping() );

         myEntityIdMapper = new DtEntityIdMapper( init->siteId(), init->applicationNumber() );
         myEntityIdMapper->setDebug( init->debugEntityIdMapping() );
         if ( init->usePersistentEntityIds() )
         {
            myEntityIdMapper->loadPersistentNumMappingFile();
         }

         myEventIdMapper = new DtEventIdMapper( init->siteId(),
            init->applicationNumber(), init->remapDisIds() );
         myEventIdMapper->setDebug( init->debugEventIdMapping() );

         // Call base implementation.
         ParentClass::startBroker();
      }

      void DtDisBroker::logBrokerSettings( DtBrokerInitializer* init )
      {
         ParentClass::logBrokerSettings( init );

         DtDisBrokerInitializer* disInit = (DtDisBrokerInitializer*) init;

         DtInfo << "Broker(" << brokerName() << "): Parse Unknown IDs: " << disInit->parseUnknownIds() << std::endl;
         DtInfo << "Broker(" << brokerName() << "): Remap DIS IDs: " << disInit->remapDisIds() << std::endl;
         DtInfo << "Broker(" << brokerName() << "): Use Persistent IDs: " << disInit->usePersistentEntityIds() << std::endl;

         DtVerbose << "Broker(" << brokerName() << "): Setting ProtocolVersionToSend: " << disInit->protocolVersionToSend() << std::endl;
         DtVerbose << "Broker(" << brokerName() << "): Setting ProtocolVersionToRecvMin: " << disInit->protocolVersionToRecvMin() << std::endl;
         DtVerbose << "Broker(" << brokerName() << "): Setting ProtocolVersionToRecvMax: " << disInit->protocolVersionToRecvMax() << std::endl;
         DtVerbose << "Broker(" << brokerName() << "): Debug Global ID Mapping: " << disInit->debugGlobalIdMapping() << std::endl;
      }

      void DtDisBroker::initDisConnection( DtDisBrokerInitializer& init )
      {
         // Set this to some value that's not success while still implementing
         DtExerciseConn::InitializationStatus status = DtExerciseConn::DtINIT_SUCCESS;

         // Protocol versions are set via global variables.
         DtProtocolVersionToSend = init.protocolVersionToSend();
         DtProtocolVersionToRecvMin = init.protocolVersionToRecvMin();
         DtProtocolVersionToRecvMax = init.protocolVersionToRecvMax();

         DtExerciseConnInitializer exConnInit;
         exConnInit.setPort( init.disPort() );
         exConnInit.setExerciseId( init.exerciseId() );
         exConnInit.setApplicationNumber( init.applicationNumber() );
         exConnInit.setSiteId( init.siteId() );
         exConnInit.setDestinationAddress( init.destinationAddress() );
         exConnInit.setDeviceAddress( init.deviceAddress() );
         exConnInit.setSubnetMask( init.subnetMask() );
         exConnInit.setMulticastAddresses( init.mcastSubscriptionSet() );
         exConnInit.setSendBufferSize( init.socketSendBufferSize() );
         exConnInit.setReceiveBufferSize( init.socketReceiveBufferSize() );
         exConnInit.setMulticastTtl( init.multicastTimeToLive() );

         // Always suppress self reflection.
         exConnInit.setSuppressSelfReflect( true );

         if ( ! DtInetDevice(DtInetAddr(exConnInit.deviceAddress())).isOk() )
         {
            DtInetAddr device( chooseNewDeviceAddress() );
            exConnInit.setDeviceAddress( device.toDtString() );
            exConnInit.setDestinationAddress( device.getBroadcastAddr()->toDtString() );

            DtInfo << "Configured device address (" << init.deviceAddress() << ") is invalid." << std::endl;
            DtInfo << "Using alternate device: " << exConnInit.deviceAddress() << std::endl;

            // Update the initializer so the connection dialog displays the right address.
            init.setDestinationAddress( device.getBroadcastAddr()->toDtString() );
            init.setDeviceAddress( device.toDtString() );
         }

         // If the exercise connection is already created, destroy it and recreate.
         // This can happen if the broker is extended and startBroker is called again.
         DtDELETE( myExConn );

         // Tell the thresholder to use the configured thresholds.
         DtThresholder::setDfltTranslationThreshold( init.locationThreshold() );
         DtThresholder::setDfltRotationThreshold( init.rotationThreshold() );

         myExConn = new DtExerciseConn( exConnInit, &status );
         if ( status != DtExerciseConn::DtINIT_SUCCESS )
         {
            DtDELETE( myDisMcastDevice );

            if ( status == DtExerciseConn::DtCOULD_NOT_CREATE_SOCKET )
            {
               DtTHROW_NEW( DtException, "DtExerciseConn failure: could not create socket" );
            }
            else
            {
               DtTHROW_NEW( DtException, "Unknown problem constructing DIS exConn." );
            }
         }

         if ( init.useAbsoluteTimeStamping() )
         {
            myExConn->setTimeStampType( DtTimeStampAbsolute );
         }

         // set the initial time
         myExConn->clock()->setSimTime( simTime() );
      }

      DtDisBrokerInitializer* DtDisBroker::disInitializer()
      {
         return (DtDisBrokerInitializer*) myBrokerInitializer;
      }

      void DtDisBroker::shutdown()
      {
         if ( disInitializer()->usePersistentEntityIds() )
         {
            myEntityIdMapper->savePersistentNumMappingFile();
         }

         ParentClass::shutdown();

         DtDELETE( myDisMcastDevice );
         DtDELETE( myGlobalIdMapper );
         DtDELETE( myEventIdMapper );
         DtDELETE( myEntityIdMapper );
      }

      void DtDisBroker::tick()
      {
         try
         {
            myStatisticsManager->startSection( DtFrameTimer::MESSAGE_PROC );

            int num = disInitializer()->numPdusReadPerTimeCheck();
            DtTime timeout = disInitializer()->drainTimeout();
            myExConn->drainInput( timeout, num );

            myExConn->clock()->setSimTime( simTime() );
            myStatisticsManager->endSection( DtFrameTimer::MESSAGE_PROC );
         }
         DtCATCH_AND_WARN( DtWarn );

         if ( ! disInitializer()->splitUnderwaterAcousticPdus() )
         {
            try
            {
               myUndwaAcPublisherManager->tickPublishers();
            }
            DtCATCH_AND_WARN( DtWarn );
         }

         // Tick the translators.
         ParentClass::tick();
      }

      DtString DtDisBroker::chooseNewDeviceAddress() const
      {
         {  // Check IPV4 addresses and return first one that's not loopback.
            DtInetUtils::DtHostDeviceList deviceList = DtInetUtils::scanInetDevices( true, false );
            DtInetUtils::DtHostDeviceList::iterator deviceItr = deviceList.begin();
            DtInetUtils::DtHostDeviceList::iterator deviceEnd = deviceList.end();
            for ( ; deviceItr != deviceEnd; ++deviceItr )
            {
               DtInetDeviceSP device = *deviceItr;
               if ( device && device->ipv4Addr() )
               {
                  if ( device->ipv4Addr()->toDtString() != "127.0.0.1" )
                  {
                     return device->ipv4Addr()->toDtString();
                  }
               }
            }
         }

         {  // Check IPV6 addresses and return first one that's not loopback.
            DtInetUtils::DtHostDeviceList deviceList = DtInetUtils::scanIpv6Devices( true );
            DtInetUtils::DtHostDeviceList::iterator deviceItr = deviceList.begin();
            DtInetUtils::DtHostDeviceList::iterator deviceEnd = deviceList.end();
            for ( ; deviceItr != deviceEnd; ++deviceItr )
            {
               DtInetDeviceSP device = *deviceItr;
               if ( device && device->ipv6Addr() )
               {
                  if ( device->ipv4Addr()->toDtString() != "::1%1" )
                  {
                     return device->ipv6Addr()->toDtString();
                  }
               }
            }
         }

         // Default to loopback.
         return "127.0.0.1";
      }

      void DtDisBroker::updateSimTime() const
      {
         if ( myExConn && myExConn->timeStampType() == DtTimeStampAbsolute )
         {
            portalConnection()->clock()->setSimTime(
               portalConnection()->clock()->absRealTime() );
         }
         else
         {
            portalConnection()->clock()->setSimTime(
               portalConnection()->clock()->elapsedRealTime() );
         }
      }

      DtTime DtDisBroker::heartbeatInterval() const
      {
         return ((DtDisBrokerInitializer*)myBrokerInitializer)->heartbeatInterval();
      }

      DtTime DtDisBroker::timeoutInterval() const
      {
         return ((DtDisBrokerInitializer*)myBrokerInitializer)->timeoutInterval();
      }

      bool DtDisBroker::remapDisIds() const
      {
         return ((DtDisBrokerInitializer*)myBrokerInitializer)->remapDisIds();
      }

      bool DtDisBroker::usePersistentIds() const
      {
         return ((DtDisBrokerInitializer*)myBrokerInitializer)->usePersistentEntityIds();
      }

      bool DtDisBroker::dumpGuiToText() const
      {
         return ((DtDisBrokerInitializer*)myBrokerInitializer)->dumpGuiToText();
      }

      void DtDisBroker::setUnderwaterAcousticsPublisherManagerCreator(
         DtUnderwaterAcousticsPublisherManagerCreator func )
      {
         theUnderwaterAcousticsPublisherManagerCreator = func;
      }

      DtUnderwaterAcousticsPublisherManagerCreator
         DtDisBroker::underwaterAcousticsPublisherManagerCreator()
      {
         return theUnderwaterAcousticsPublisherManagerCreator;
      }

      void DtDisBroker::setGlobalIdMapperCreator(DtGlobalIdMapperCreator func)
      {
         theGlobalIdMapperCreator = func;
      }

      DtGlobalIdMapperCreator DtDisBroker::globalIdMapperCreator()
      {
         return theGlobalIdMapperCreator;
      }

      DtGlobalObjectDesignator DtDisBroker::convertGlobalId( const DtString& id )
      {
         return globalIdMapper()->convertPortalGidToDisGid( id );
      }

      DtString DtDisBroker::convertGlobalId( const DtGlobalObjectDesignator& id )
      {
         return globalIdMapper()->convertDisGidToPortalGid( id );
      }

      DtEntityIdentifier DtDisBroker::convertPortalEntIdToDisEntId(
         const DtEntityIdentifier& portalId )
      {
         return *(entityIdMapper()->convertPortalEidToDisEid(portalId));
      }

      DtEntityIdentifier DtDisBroker::convertDisEntIdToPortalEntId(
         const DtEntityIdentifier& disId )
      {
         return *(entityIdMapper()->convertDisEidToPortalEid(disId));
      }

   }
}
