/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file detonationTranslator.cxx
//! \brief Contains the DtDetonationTranslator class definition.
//! \ingroup disBroker

#include <disBroker/detonationTranslator.h>
#include <disBroker/eventIdMapper.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtDetonationTranslator::DtDetonationTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalDetonationInteraction::theKind )
      {
      }

      DtDetonationTranslator::~DtDetonationTranslator()
      {
      }

      bool DtDetonationTranslator::isPortalDiscoverable(
         const DtPortalDetonationInteraction& inter )
      {
         return ( testGlobalIdMapping("Target ID",inter.targetId())
            && testGlobalIdMapping("Attacker ID",inter.attackerId())
            && testGlobalIdMapping("Munition ID",inter.munitionId()) );
      }

      DtPortalDetonationInteraction* DtDetonationTranslator::translate(
         DtPortalDetonationInteraction* destination, const DtDetonationInteraction& source )
      {
         destination->setAttackerId( disBroker()->convertGlobalId( source.attackerId() ));
         destination->setTargetId( disBroker()->convertGlobalId( source.targetId() ));
         destination->setMunitionId( disBroker()->convertGlobalId( source.munitionId() ));
         destination->setEventId( disBroker()->eventIdMapper()->convertEventId(source.eventId() ));
         destination->setVelocity( source.velocity() );
         destination->setWorldLocation( source.worldLocation() );
         destination->setResult( source.result() );
         destination->setMunitionType( source.munitionType().string() );
         destination->setWarheadType( source.warheadType() );

         destination->setEntityLocation( source.entityLocation() );
         destination->setFuseType( source.fuseType() );
         destination->setQuantity( source.quantity() );
         destination->setRate( source.rate() );

         try
         {
            const DtArticulatedPartCollection& apList = source.articulatedParts();
            DtArticulatedPartCollection newApList(apList);
            destination->setArticulatedPartList( newApList );
         }
         catch (DtException&)
         {
            DtWarn << "Error Parsing Articulated Parts for detonation " << source.eventId().string();
         }

         return destination;
      }

      DtDetonationInteraction* DtDetonationTranslator::translate(
         DtDetonationInteraction* destination, const DtPortalDetonationInteraction& source )
      {
         destination->setAttackerId( disBroker()->convertGlobalId( source.attackerId() ));
         destination->setTargetId( disBroker()->convertGlobalId( source.targetId() ));
         destination->setMunitionId( disBroker()->convertGlobalId( source.munitionId() ));
         destination->setEventId( disBroker()->eventIdMapper()->convertEventId( source.eventId() ));
         destination->setVelocity( source.velocity() );
         destination->setWorldLocation( source.worldLocation() );
         destination->setResult( (DtDetonationResult)source.result() );
         destination->setFuseType( (DtDetonatorFuze)source.fuseType() );
         destination->setMunitionType( source.munitionType().string() );
         destination->setQuantity( source.quantity() );
         destination->setRate( source.rate() );
         destination->setWarheadType( (DtWarheadType)source.warheadType() );

         destination->setEntityLocation( source.entityLocation() );

         try
         {
            const DtArticulatedPartCollection& apList = source.articulatedPartList();
            DtArticulatedPartCollection newApList(apList);
            destination->setArticulatedParts( newApList );
         }
         catch (DtException&)
         {
            DtWarn << "Error Parsing Articulated Parts for detonation " << source.eventId();
         }

         return destination;
      }

   }
}
