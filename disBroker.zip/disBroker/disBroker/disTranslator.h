/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disTranslator.h
//! \brief Contains the DtDisObjectTranslator and DtDisInteractionTranslator base classes.
//! \ingroup disBroker

#pragma once

// Disable warning about missing operators.
// Comparison and assignment operators are declared but not defined
// to prevent their usage, but this causes a warning in template classes.
#pragma warning( disable : 4661 )

#include <disBroker/dllExport.h>
#include <disBroker/globalIdMapper.h>

#include <broker/baseObjectTranslator.h>
#include <broker/baseInteractionTranslator.h>

#include <portal/pReflectedObjectManagerTypes.h>
#include <portal/pObjectPublisherTypes.h>

// All DIS Translators must have the following template arguments:
// The integer define of the DtPortalMessageKind,
// The PortalObject this message translates,
// The Reflected Portal Object class the message translates
// The Reflected DIS Object class
// The reflected list of objects
// The state repository class of the DIS Object
// The publisher class of the DIS Object
#define DIS_TEMPLATE_LIST \
   template \
   < class T_PortalObject \
   , class T_PortalReflectedObject \
   , class T_DisReflectedObject \
   , class T_DisReflectedObjectList \
   , class T_DisObjectStateRepository \
   , class T_DisObjectPublisher>

#define DIS_TEMPLATE_FUNCTION \
   T_PortalObject, T_PortalReflectedObject, \
   T_DisReflectedObject, T_DisReflectedObjectList, \
   T_DisObjectStateRepository, T_DisObjectPublisher

class DtInteraction;
class DtObjectPublisher;
class DtStateRepository;
class DtReflectedObject;

namespace MAKVrExchange
{

   class DtRequestTranslationDiagnosticMessage;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Base class for all DIS object translators.
      //! This template base class encapsulates code common to all object
      //! translators. This includes creation of reflected object lists and
      //! the registration of callbacks with those lists, logic for ticking and
      //! enabling the translator, and logic for creating publishers and
      //! receiving incoming updates and translating them.
      //! New translators subclassing this base class must provide the
      //! following template arguments:
      //! \li The translator's Portal object.
      //! \li The translator's Portal reflected object.
      //! \li The translator's DIS reflected object.
      //! \li The translator's DIS reflected object list.
      //! \li The translator's DIS object state repository.
      //! \li The translator's DIS object publisher.
      //! It is possible that certain publishers and/or reflected lists may
      //! have different method signatures, causing compilation errors in the
      //! DtDisObjectTranslator itself. In this case, the method in question
      //! should be defined as a template specialization either with the
      //! desired implementation, or as an empty method which is then
      //! overridden in the translator class. The DtGenericTranslator
      //! demonstrates how this may be done.
      //! \ingroup disBroker
      DIS_TEMPLATE_LIST
      class DtDisObjectTranslator
         : public DtBaseObjectTranslator<T_PortalObject,T_PortalReflectedObject>
      {
      public:

         //! Enums used with the ObjectAction callback
         typedef enum
         {
            none = 0,
            discover = 1, //! This callback is regarding an object Discovery
            update = 2,   //! This callback is regarding an object Update
            remove = 3    //! This callback is regarding an object Deletion
         } UpdateType;

         //! \brief Typedef for the templated class type.
         typedef DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION> ParentClass;

         //! \brief Typedef for the templated base class type.
         typedef DtBaseObjectTranslator<T_PortalObject,T_PortalReflectedObject> BaseTranslatorClass;

      public:

         //! \brief CTOR.
         DtDisObjectTranslator( DtBroker* broker,
            const DtString& name, DtPortalMessageKind kind );

         //! \brief Virtual DTOR.
         virtual ~DtDisObjectTranslator();

         //! \brief Enables or disables the translator reflecting objects from DIS.
         virtual void enableReflectTranslator( bool enabled );

         //! \brief Tells all publishers to send an update next tick.
         virtual void forceUpdateAll();

         //! \brief Ticks the publishers for the translated DIS and Portal objects.
         virtual void tick();

         virtual DtDisBroker* disBroker();
         virtual const DtDisBroker* disBroker() const;

      protected:

         //! @name DIS Callback Initialization
         //! @{

         virtual void initializeDisCallbacks();
         virtual void removeDisCallbacks();

         //! @}

         //! @name Broker Object Management Methods
         //! @{

         //! Creates a broker object for the given reflected object.
         virtual DtBrokerObject* createBrokerObject( const DtReflectedObject* refObj );
         virtual DtBrokerObject* createBrokerObject( const DtPortalReflectedObject* refObj );

         //! Find the broker object for the given reflected object.
         //! Returns NULL if the requested broker object doesn't exist.
         virtual DtBrokerObject* findBrokerObject( const DtReflectedObject* refObj );
         virtual DtBrokerObject* findBrokerObject( const DtPortalReflectedObject* refObj );

         //! Find the broker object for the object with the given name.
         //! Returns NULL if the requested broker object doesn't exist.
         virtual DtBrokerObject* findBrokerObject( const DtString& objectName );

         //! Find the broker object for the given reflected object.
         //! Returns NULL if the requested broker object doesn't exist.
         //! Unregisters the broker object - caller is responsible for deletion.
         virtual DtBrokerObject* releaseBrokerObject( const DtReflectedObject* refObj );
         virtual DtBrokerObject* releaseBrokerObject( const DtPortalReflectedObject* refObj );

         //! @}

         //! @name DIS Callbacks
         //! @{

         //! \brief The DIS reflected list's discovery condition callback.
         //! \returns whether the given reflected object is discoverable.
         static bool disDiscoveryCriteria( DtReflectedObject* refObj, void* usr );

         //! \brief Callback called when an object is added to the reflected list.
         static void disObjectAddedCb( T_DisReflectedObject* refObj, void* usr );

         //! \brief Callback called when an object in the reflected list is updated.
         static void disObjectUpdatedCb( T_DisReflectedObject* refObj, void* usr );

         //! \brief Callback called when an object in the reflected list is deleted.
         static void disObjectDeletedCb( T_DisReflectedObject* refObj, void* usr );

         //! @}

         //! @name Portal to DIS Discoverable/Publishable Checks.
         //! @{

         //! \brief Creates broker object for reflected Portal object.
         //! Calls isDisPublishable to determine if it's discoverable.
         virtual bool isPortalDiscoverable( const DtPortalReflectedObject* refObj );

         //! \brief Tests whether the object is publishable as a DIS object.
         //! Default implementation always returns true.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const T_PortalReflectedObject* refObj );

         //! @}

         //! @name DIS to Portal Discoverable/Publishable Checks.
         //! @{

         //! \brief Creates broker object for reflected DIS object.
         //! Calls isPortalPublishable to determine if it's discoverable.
         virtual bool isDisDiscoverable( const DtReflectedObject* refObj );

         //! @}

         //! @name Call Object Callback Methods.
         //! Overridden to call printDumpGuiToText if enabled.
         //! @{

         virtual void callObjectDiscoverCallbacks( const DtBrokerObject* obj );
         virtual void callObjectUpdateCallbacks( const DtBrokerObject* obj );
         virtual void callObjectRemoveCallbacks( const DtBrokerObject* obj );

         //! @}

         //! @name Object Discovery Methods
         //! Discovers the given object by creating a broker obj and publisher.
         //! Once it has been determined that the given reflected object is
         //! discoverable, this method creates a DtBrokerObject for the
         //! object, creates a publisher for it, and processes the discovery
         //! as the object's first update.
         //! Called from the reflected lists' object added callbacks.
         //! @{

         virtual void discoverDisObject( T_DisReflectedObject& obj );
         virtual void discoverPortalObject( const T_PortalReflectedObject& obj );

         //! @}

         //! @name Publisher Creation Methods
         //! \brief Creates a publisher for the given object.
         //! Verifies the given DtBrokerObject has a valid reflected object
         //! pointer, instantiates a new publisher for it, and stores the
         //! publisher in the broker object.
         //! Called from the respective object discovery methods.
         //! @{

         virtual void createDisPublisher( DtBrokerObject* brokerObj );

         //! Determines the name to use for the given reflected object.
         //! Translators which need to perform name mapping (eg. for using
         //! the object's marking text as its name) can override this method.
         //! Default implementation uses the object's identifier.
         //! Called by ::createDisPublisher.
         virtual DtString disObjectName( const T_PortalReflectedObject* refObj ) const;

         //! Maps the reflected object's global or entity identifier to a DIS id.
         virtual DtEntityIdentifier mapIdentifier( const T_PortalReflectedObject* refObj,
            const DtString& identifier );

         //! Maps the entity IDs with respect to the remapDisIds setting.
         virtual DtEntityIdentifier mapObjectId( const DtEntityIdentifier& identifier );

         //! Instantiates the publisher for the given reflected object.
         //! This may be overridden to modify the constructor used to create
         //! the publisher or perform additional publisher initialization.
         //! Default implementation attempts to create the publisher using
         //! the given name (the value returned from ::disObjectName), then
         //! attempts to create the publisher again with no name if the first
         //! attempt fails.
         //! Called by ::createDisPublisher.
         virtual DtObjectPublisher* instantiateDisPublisher(
            const T_PortalReflectedObject* refObj, const DtEntityIdentifier& name );

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! This method can be overridden to perform mapping for different types
         //! of objects as well (emitters, etc.).
         virtual bool performDisGlobalIdMapping( const DtObjectPublisher* publisher,
            const T_PortalReflectedObject& refObj,
            DtGlobalIdMapper::ObjectType type = DtGlobalIdMapper::EntityType,
            int systemId = DtGlobalIdMapper::NoSystemId,
            int beamId = DtGlobalIdMapper::NoBeamId );

         virtual void createPortalPublisher( DtBrokerObject* brokerObj );

         //! Determines the name to use for the given reflected object.
         //! Translators which need to perform name mapping (eg. for using
         //! the object's marking text as its name) can override this method.
         //! Default implementation uses the object's identifier.
         //! Called by ::createPortalPublisher.
         virtual DtString portalObjectName( const T_DisReflectedObject* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! This method can be overridden to perform mapping for different types
         //! of objects as well (emitters, etc.).
         virtual bool performPortalGlobalIdMapping(
            const DtPortalObjectPublisherTemplate<T_PortalObject>* publisher,
            const T_DisReflectedObject& refObj,
            DtGlobalIdMapper::ObjectType type = DtGlobalIdMapper::EntityType,
            int systemId = DtGlobalIdMapper::NoSystemId,
            int beamId = DtGlobalIdMapper::NoBeamId );

         //! @}

         //! @name Object Update Methods
         //! \brief Updates the broker object and outgoing (translated) object.
         //! Updates the broker object with information from the updated
         //! reflected object, calls the translator's object update callbacks,
         //! updates the filtered state of the object, re-translates the object,
         //! and prints debugging info (if translator debugging is turned on).
         //! Called from the reflected lists' object update callbacks.
         //! @{

         virtual void receiveDisUpdate( T_DisReflectedObject& obj );
         virtual void receivePortalUpdate( const T_PortalReflectedObject& obj );

         //! @}

         //! @name Broker Object Update Methods
         //! \brief Updates the broker object with info from the given state rep.
         //! Default implementations only update the broker object's last update
         //! time and isPublishable state.
         //! Implementing translators may override this method to cache relevant
         //! information from the object's state repository in the broker object.
         //! Called by ::receiveDisUpdate and ::receivePortalUpdate, respectively.
         //! @{

         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const T_DisObjectStateRepository& sr );
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj,
            const T_PortalObject& sr );

         //! @}

         //! \brief Ensures the given object is properly filtered.
         //! Checks the object against configured filters and sets the object's
         //! filtered state in the Portal publisher and broker object.
         //! Default implementation simply checks the object's identifier
         //! against configured name filters. Translators wishing to perform
         //! type, marking text, or other types of filtering must override
         //! this method and check the object against the configured filters.
         //! Called by ::receiveDisUpdate.
         virtual void updateFilteredState( DtBrokerObject* brokerObj,
            DtPortalObjectPublisherTemplate<T_PortalObject>* publisher,
            T_DisReflectedObject* refObj );

         //! \brief Called by ::receivePortalUpdate.
         //! This function does not check against any filters.  This is for derived
         //! translators to overwrite.
         virtual void updateFilteredState( DtBrokerObject* brokerObj,
            const T_PortalReflectedObject* refObj );

         //! \brief Checks location filtering and returns the filtered state.
         //! If the location filtering interval has elapsed, the location
         //! filters are checked against the location. If not, the last
         //! filter check's result is returned.
         virtual bool filterLocation( const DtReflectedObject& refObj,
            const DtVector& location );

         //! \brief Checks location filtering and returns the filtered state.
         virtual bool filterLocation( const DtPortalReflectedObject& refObj,
            const DtVector& location );

         //! @name Object Removal Methods.
         //! Called when an object is removed from it's reflected list.
         //! @{

         virtual void removeDisObject( const DtReflectedObject& refObj );
         virtual void removePortalObject( const T_PortalReflectedObject& refObj );

         //! @}

         //! @name Object Deletion Methods
         //! \brief Destroys publishers for the objects being destroyed.
         //! Called from the reflected lists' object deletion callbacks.
         //! @{

         virtual void deleteDisPublisher( DtBrokerObject* brokerObj );
         virtual void deletePortalPublisher( DtBrokerObject* brokerObj );

         //! @}

         //! \brief Static translation diagnostic request callback.
         static void requestTransDiagCb( const DtRequestTranslationDiagnosticMessage& msg, void* usr );

         //! \brief Virtual translation diagnostic request callback.
         virtual void requestTransDiagCb( const DtRequestTranslationDiagnosticMessage& msg );

         //! \brief Print debug info for the given state reps.
         virtual void printIncomingOutgoingStateReps(
            const DtPortalObject& incoming, const DtStateRepository& outgoing ) const;

         //! \brief Print debug info for the given state reps.
         virtual void printIncomingOutgoingStateReps(
            const DtStateRepository& incoming, const DtPortalObject& outgoing ) const;

         //! \brief Build and send debugging message for GUI debugging.
         //! Protocol independent version - looks up object with given name
         //! and calls the appropriate version of ::performPortalDebugging.
         virtual void performPortalDebugging( const DtString& objectName );

         //! \brief Build and send debugging message for GUI debugging.
         virtual void performPortalDebugging( const DtPortalObject& incoming,
            const DtStateRepository& outgoing );

         //! \brief Build and send debugging message for GUI debugging.
         virtual void performPortalDebugging( const DtStateRepository& incoming,
            const DtPortalObject& outgoing );

         virtual void printDumpGuiToText( const DtBrokerObject& brokerObj,
            UpdateType ut ) const;

         //! Returns the current number of objects.
         virtual unsigned int numObjects() const;

         //! \brief Performs any virtual shutdown logic prior to deletion.
         //! Overridden to call removeDisCallbacks.
         virtual void shutdown();

      public:

         //! \brief Translates the given DIS object to a Portal object (abstract).
         //! This method must be implemented by the subclassing translator.
         virtual T_PortalObject* translate( T_PortalObject* destination,
            const T_DisObjectStateRepository& source,
            const T_DisReflectedObject& refObj ) = 0;

         //! \brief Translates the given Portal object to an DIS object (abstract).
         //! This method must be implemented by the subclassing translator.
         virtual T_DisObjectStateRepository* translate(
            T_DisObjectStateRepository* destination, const T_PortalObject& source,
            const T_PortalReflectedObject& refObj ) = 0;

      private:

         //! \brief Private Copy CTOR (Not implemented -- Do Not Copy).
         DtDisObjectTranslator( const DtDisObjectTranslator& other );

         //! \brief Private Assignment Operator (Not implemented -- Do Not Copy).
         DtDisObjectTranslator& operator = ( const DtDisObjectTranslator& other );

         //! \brief Private Comparison Operator (Not implemented -- Do Not Compare).
         bool operator == ( const DtDisObjectTranslator& rightOperand ) const;

         //! \brief Private Comparison Operator (Not implemented -- Do Not Compare).
         bool operator != ( const DtDisObjectTranslator& rightOperand ) const;

      protected:

         T_DisReflectedObjectList* myDisReflectedList;

         typedef std::pair<DtTime,bool> LocationFilteringInfo;
         typedef std::map<const DtReflectedObject*,LocationFilteringInfo> LocationFilteringMap;
         LocationFilteringMap myLocationFilteringMap;

         typedef std::map<const DtReflectedObject*,DtBrokerObject*> DisToPortalReflectedMap;
         typedef std::map<const DtPortalReflectedObject*,DtBrokerObject*> PortalToDisReflectedMap;

         DisToPortalReflectedMap myPortalPublisherMap;
         PortalToDisReflectedMap myDisPublisherMap;

         typedef std::set<DtString> TransDebugObjectNamesSet;
         TransDebugObjectNamesSet myTransDebugNames;

      };


      //! \brief Base class for all DIS interaction translators.
      //! This template base class encapsulates code common to all interaction
      //! translators. This includes registration of interaction callbacks
      //! and creation of translated outgoing interactions.
      //! New translators subclassing this base class must provide the
      //! following template arguments:
      //! \li The translator's Portal interaction.
      //! \li The translator's DIS interaction.
      //! It is possible that certain publishers and/or reflected lists may
      //! have different method signatures, causing compilation errors in the
      //! DtDisInteractionTranslator itself. In this case, the method in
      //! question should be defined as a template specialization either with
      //! the desired implementation, or as an empty method which is then
      //! overridden in the translator class. The DtGenericInteractionTranslator
      //! demonstrates how this may be done.
      //! \ingroup disBroker
      template <class PortalInterType,class DisInterType>
      class DtDisInteractionTranslator
         : public DtBaseInteractionTranslator<PortalInterType>
      {
      public:

         //! \brief Typedef for the templated class type.
         typedef DtDisInteractionTranslator<PortalInterType,DisInterType> ParentClass;

      public:

         //! \brief CTOR.
         DtDisInteractionTranslator( DtBroker* broker,
            const DtString& name, DtPortalMessageKind kind );

         //! \brief Virtual DTOR.
         virtual ~DtDisInteractionTranslator();

         //! \brief Enables or disables the translator reflecting from DIS.
         virtual void enableReflectTranslator( bool enabled );

         virtual DtDisBroker* disBroker();
         virtual const DtDisBroker* disBroker() const;

         //! \brief Checks the waitlist for postponed interaction discoveries.
         virtual void tick();

      protected:

         //! @name Callback initialization methods.
         //! @{

         virtual void initializeDisCallbacks();
         virtual void removeDisCallbacks();

         //! @}

         //! @name Incoming Interaction Callbacks
         //! Callback called when interactions are received.
         //! @{

         static void receiveDisInteraction( DisInterType* inter, void* usr );
         virtual void receiveDisInteraction( const DisInterType& inter );

         //! @}

         //! \brief Portal interaction processing callback.
         //! Overridden to check for incomplete global ID mappings.
         virtual void receivePortalInteraction( const PortalInterType& inter );

         //! @name Interaction Creation Methods
         //! Translates and sends the given (incoming) interaction.
         //! Creates a new interaction of the outgoing type, translates the
         //! information in the incoming interaction into it, prints debug
         //! information if translator debugging is on, and sends it.
         //! Called from the respective interaction callbacks.
         //! @{

         virtual void createInteraction( const PortalInterType& inter );
         virtual void createPortalInteraction( const DisInterType& inter );

         //! @}

         //! Translates the given DIS interaction to a Portal interaction (abstract).
         //! This method must be implemented by the subclassing translator.
         virtual PortalInterType* translate( PortalInterType* destination,
            const DisInterType& source ) = 0;

         //! Translates the given Portal interaction to a DIS interaction (abstract).
         //! This method must be implemented by the subclassing translator.
         virtual DisInterType* translate( DisInterType* destination,
            const PortalInterType& source ) = 0;

         //! Prints incoming and outgoing interactions (before and after translation) to DtInfo.
         virtual void printIncomingOutgoingInteractions( const DtPortalInteraction& incoming,
            const DtInteraction& outgoing ) const;

         //! Prints incoming and outgoing interactions (before and after translation) to DtInfo.
         virtual void printIncomingOutgoingInteractions( const DtInteraction& incoming,
            const DtPortalInteraction& outgoing ) const;

         //! \brief Checks whether a valid global id mapping exists for the given ID.
         //! If not, this method uses the given idName to print a warning to the log.
         virtual bool testGlobalIdMapping( const DtString& idName, const DtString& id );

         //! \brief Performs any virtual shutdown logic prior to deletion.
         //! Overridden to call removeDisCallbacks.
         virtual void shutdown();

      private:

         //! \brief Private Copy CTOR (Not implemented -- Do Not Copy).
         DtDisInteractionTranslator( const DtDisInteractionTranslator& other );

         //! \brief Private Assignment Operator (Not implemented -- Do Not Copy).
         DtDisInteractionTranslator& operator = ( const DtDisInteractionTranslator& other );

         //! \brief Private Comparison Operator (Not implemented -- Do Not Compare).
         bool operator == ( const DtDisInteractionTranslator& rightOperand ) const;

         //! \brief Private Comparison Operator (Not implemented -- Do Not Compare).
         bool operator != ( const DtDisInteractionTranslator& rightOperand ) const;

      protected:

         typedef std::vector<PortalInterType> InteractionWaitList;
         InteractionWaitList myInteractionWaitList;

      };

   }
}

#define _disTranslator_INL_
#include <disBroker/disTranslator.inl>
#undef _disTranslator_INL_
