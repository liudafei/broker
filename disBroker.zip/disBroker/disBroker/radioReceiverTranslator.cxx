/*****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioReceiverTranslator.cxx
//! \brief Contains the DtRadioReceiverTranslator class definition.
//! \ingroup disBroker

#include <disBroker/radioReceiverTranslator.h>
#include <disBroker/disBrokerInitializer.h>
#include <disBroker/globalIdMapper.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtRadioReceiverTranslator::DtRadioReceiverTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, "Radio Receiver", DtPortalRadioReceiverObject::theKind )
      {
      }

      DtRadioReceiverTranslator::~DtRadioReceiverTranslator()
      {
      }

      bool DtRadioReceiverTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedRadioReceiverObject* refObj )
      {
         DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->radioReceiverNeedsEntityId() )
         {
            int index = refObj->sr()->radioIndex();
            DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::RadioReceiverType;
            DtEntityIdentifier newId = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
               refObj->sr()->identifier(), &objType, &index );
            if ( newId == DtEntityIdentifier::nullId() )
            {
               newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
                  refObj->sr()->entityIdentifier() );
            }
            if ( newId == DtEntityIdentifier::nullId() )
            {
               DtInfo << "DtRadioReceiverTranslator: " << brokerObj->objectName()
                  << ": Entity Id not present, object incomplete" << std::endl;
               brokerObj->setDropReason( "Missing Entity ID" );
               return false;
            }
         }
         if ( discoveryCriteria->radioReceiverNeedsHostId()
            && refObj->sr()->hostObjectIdentifier() == "" )
         {
            DtInfo << "DtRadioReceiverTranslator: " << brokerObj->objectName()
               << ": Host Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Host ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<RADIO_RECV_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedRadioReceiverObject* refObj,
         const DtString& identifier )
      {
         // Get and convert the identifier.
         int index = refObj->sr()->radioIndex();
         DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::RadioReceiverType;
         DtGlobalIdMapper::DisId newId = disBroker()->globalIdMapper()
            ->convertPortalGidToDisGid( identifier.string(), &objType, &index );
         if ( newId == DtEntityIdentifier::nullId() )
         {
            newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
               refObj->sr()->entityIdentifier() );
         }
         return newId;
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<RADIO_RECV_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedRadioReceiverObject* refObj, const DtEntityIdentifier& objectName )
      {
         DtRadioReceiverPublisher* publisher = NULL;
         try
         {
            publisher = new DtRadioReceiverPublisher( disBroker()->connection(),
               objectName, refObj->sr()->radioIndex() );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      bool DtRadioReceiverTranslator::performDisGlobalIdMapping(
         const DtObjectPublisher* publisher, const DtPortalReflectedRadioReceiverObject& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performDisGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::RadioReceiverType, refObj.sr()->radioIndex(),
            beamId );
      }

      DtString DtRadioReceiverTranslator::portalObjectName(
         const DtReflectedRadioReceiver* refObj ) const
      {
         DtString newObjectName( refObj->globalId().string() );
         newObjectName += "-";
         newObjectName += refObj->rsr()->radioId();
         newObjectName += "Rvrx";
         return newObjectName;
      }

      bool DtRadioReceiverTranslator::performPortalGlobalIdMapping(
         const DtPortalRadioReceiverObjectPublisher* publisher,
         const DtReflectedRadioReceiver& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performPortalGlobalIdMapping( publisher,
            refObj, DtGlobalIdMapper::RadioReceiverType,
            refObj.rsr()->radioId(), beamId );
      }

      void DtRadioReceiverTranslator::deleteDisPublisher( DtBrokerObject* brokerObj )
      {
         DtRadioReceiverPublisher* publisher =
            static_cast<DtRadioReceiverPublisher*>( brokerObj->publisherPtr() );
         const DtPortalReflectedRadioReceiverObject* refObj =
            static_cast<const DtPortalReflectedRadioReceiverObject*>(
               brokerObj->reflectedObjPtr() );
         if ( publisher && refObj )
         {
            DtU32 radioIndex = refObj->sr()->radioIndex();
            disBroker()->globalIdMapper()->remove( refObj->sr()->entityIdentifier(),
               DtGlobalIdMapper::RadioReceiverType, radioIndex );
            brokerObj->setPublisherPtr( 0 );
            DtDELETE( publisher );
         }
      }

      DtPortalRadioReceiverObject* DtRadioReceiverTranslator::translate(
         DtPortalRadioReceiverObject* destination, const DtRadioReceiverRepository& source,
         const DtReflectedRadioReceiver& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         destination->setRadioIndex( source.radioId() );
         destination->setReceivedPower( source.receivedPower() );
         destination->setReceivedTransmitterIdentifier( disBroker()->globalIdMapper()
            ->convertDisGidToPortalGid(source.transmitterId() ) );
         destination->setRadioTransmitterIndex( source.transmitterRadioId() );
         destination->setReceiverOperationalStatus( source.receiverState() );

         return destination;
      }

      DtRadioReceiverRepository* DtRadioReceiverTranslator::translate(
         DtRadioReceiverRepository* destination, const DtPortalRadioReceiverObject& source,
         const DtPortalReflectedRadioReceiverObject& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         int index = 0;
         DtGlobalIdMapper::ObjectType type;
         DtEntityIdentifier id = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
            source.receivedTransmitterIdentifier(), &type, &index );

         destination->setTransmitterId( id );
         destination->setTransmitterRadioId( index );
         destination->setRadioId( source.radioIndex() );
         destination->setReceivedPower( source.receivedPower() );
         destination->setTransmitterRadioId( source.radioTransmitterIndex() );
         destination->setReceiverState( (DtRadioReceiverState) source.receiverOperationalStatus() );

         return destination;
      }

   }
}
