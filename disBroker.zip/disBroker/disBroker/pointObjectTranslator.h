/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file pointObjectTranslator.h
//! \brief Contains the DtPointObjectTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/pointObjectPublisher.h>
#include <vl/reflectedPointObjectList.h>

class DtReflectedPointObject;
class DtPointObjectRepository;

#define POINT_OBJECT_TEMPLATE_ARGS \
   DtPortalPointObject, DtPortalReflectedPointObject, \
   DtReflectedPointObject, DtReflectedPointObjectList, \
   DtPointObjectRepository, DtPointObjectPublisher

namespace MAKVrExchange
{

   class DtPortalPointObject;

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<POINT_OBJECT_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedPointObject* refObj, const DtString& identifier );

      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<POINT_OBJECT_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedPointObject* refObj, const DtEntityIdentifier& name );


      //! \brief Provides Point Object translation between DIS and the Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtPointObjectTranslator
         : public DtDisObjectTranslator<POINT_OBJECT_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Point Object" );

         //! \brief CTOR.
         DtPointObjectTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtPointObjectTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedPointObject& refObj ) const;

         //! \brief Gets the reflected object's entity id for publisher creation.
         virtual DtString disObjectName( const DtPortalReflectedPointObject* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const DtPointObjectRepository& sr );

         //! \brief Construct the portal object name.
         //! Overridden to construct a point object name.
         virtual DtString portalObjectName( const DtReflectedPointObject* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj,
            const DtPortalPointObject& sr );

         //! \brief Translates a Point Object into the portal.
         virtual DtPortalPointObject* translate( DtPortalPointObject* dest,
            const DtPointObjectRepository& src, const DtReflectedPointObject& refObj );

         //! \brief Translates a Point Object from the portal.
         virtual DtPointObjectRepository* translate( DtPointObjectRepository* dest,
            const DtPortalPointObject& src, const DtPortalReflectedPointObject& refObj );

      };

   }
}
