/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file stopTranslator.cxx
//! \brief Contains the DtStopTranslator class definition.
//! \ingroup disBroker

#include <disBroker/stopTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {
      DtStopTranslator::DtStopTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalStopInteraction::theKind )
      {
      }

      DtStopTranslator::~DtStopTranslator()
      {
      }

      bool DtStopTranslator::isPortalDiscoverable(
         const DtPortalStopInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.originatingEntity())
            && testGlobalIdMapping("Receiver ID",inter.receivingEntity()) );
      }

      DtPortalStopInteraction* DtStopTranslator::translate(
         DtPortalStopInteraction* destination, const DtStopFreezeInteraction& source )
      {
         destination->setOriginatingEntity( disBroker()->convertGlobalId( source.senderId() ));
         destination->setReceivingEntity( disBroker()->convertGlobalId( source.receiverId() ));
         destination->setRequestIdentifier( source.requestId() );
         destination->setRealWorldTime( source.realWorldTime() );
         destination->setReason( source.reason() );

         DtNetU8 frozen = source.frozenBehavior();

         if ( (frozen & 0x01) == 0x01 )
         {
            destination->setRunInternalSimulationClock( true );
         }
         if ( (frozen & 0x02) == 0x02 )
         {
            destination->setUpdateAttributes( true );
         }
         if ( (frozen & 0x04) == 0x04 )
         {
            destination->setReflectValues( true );
         }

         return destination;
      }

      DtStopFreezeInteraction* DtStopTranslator::translate(
         DtStopFreezeInteraction* destination, const DtPortalStopInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId( source.originatingEntity() ));
         destination->setReceiverId( disBroker()->convertGlobalId( source.receivingEntity() ));
         destination->setRealWorldTime( source.realWorldTime() );
         destination->setRequestId( source.requestIdentifier() );
         destination->setReason( (DtStopReason)source.reason() );

         DtNetU8 frozen = 0x00;
         if ( source.runInternalSimulationClock() )
         {
            frozen = frozen | 0x01;
         }
         if ( source.updateAttributes() )
         {
            frozen = frozen | 0x02;
         }
         if ( source.reflectValues() )
         {
            frozen = frozen | 0x04;
         }

         destination->setFrozenBehavior( frozen );

         return destination;
      }

   }
}
