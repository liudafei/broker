/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file propulsionNoiseTranslator.cxx
//! \brief Contains the DtPropulsionNoiseTranslator class definition.
//! \ingroup disBroker

#include <disBroker/propulsionNoiseTranslator.h>
#include <disBroker/disBrokerInitializer.h>
#include <disBroker/eventIdMapper.h>

#include <vl/underwaterAcousticsPublisher.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtPropulsionNoiseTranslator::DtPropulsionNoiseTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, "Propulsion Noise", DtPortalPropulsionNoiseObject::theKind )
      {
      }

      DtPropulsionNoiseTranslator::~DtPropulsionNoiseTranslator()
      {
      }

      bool DtPropulsionNoiseTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedPropulsionNoiseObject* refObj )
      {
         DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->underwaterAcousticsNeedsEntityId() )
         {
            DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::PropulsionNoiseType;
            DtEntityIdentifier newId = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
               refObj->sr()->identifier(), &objType );
            if ( newId == DtEntityIdentifier::nullId() )
            {
               newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
                  refObj->sr()->entityIdentifier() );
            }
            if ( newId == DtEntityIdentifier::nullId() )
            {
               DtInfo << "DtPropulsionNoiseTranslator: " << brokerObj->objectName()
                  << ": Entity Id not present, object incomplete" << std::endl;
               brokerObj->setDropReason( "Missing Entity ID" );
               return false;
            }
         }
         if ( discoveryCriteria->underwaterAcousticsNeedsHostId()
            && refObj->sr()->hostObjectIdentifier().isEmpty() )
         {
            DtInfo << "DtPropulsionNoiseTranslator: " << brokerObj->objectName()
               << ": Host Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Host ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      DtObjectPublisher* DtPropulsionNoiseTranslator::instantiateDisPublisher(
         const DtPortalReflectedPropulsionNoiseObject* refObj,
         const DtEntityIdentifier& objectId )
      {
         DtObjectPublisher* objectPublisher = NULL;
         if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
         {
            objectPublisher = new DtPropulsionNoisePublisher(
               disBroker()->connection(), objectId );
         }
         else
         {
            DtUnderwaterAcousticsPublisherManager* mgr =
               disBroker()->underwaterAcousticsPublisherManager();
            DtString hostId = refObj->sr()->hostObjectIdentifier();
            DtUnderwaterAcousticsPublisher* publisher =
               mgr->findPublisher( hostId );
            if ( ! publisher )
            {
               publisher = new DtUnderwaterAcousticsPublisher(
                  disBroker()->connection(), objectId );
               mgr->registerPublisher( hostId, publisher );
            }
            mgr->checkoutPublisher( publisher );
            objectPublisher = publisher;
         }
         return objectPublisher;
      }

      void DtPropulsionNoiseTranslator::createDisPublisher( DtBrokerObject* brokerObj )
      {
         try
         {
            // Get the reflected object and make sure it exists.
            const DtPortalReflectedPropulsionNoiseObject* refObj =
               static_cast<const DtPortalReflectedPropulsionNoiseObject*>(
                  brokerObj->reflectedObjPtr() );
            assert( refObj );

            // Get and convert the identifier and create the publisher.
            DtString objectName = disObjectName( refObj );
            DtGlobalIdMapper::DisId newId = mapIdentifier( refObj, objectName );

            // Workaround for OTD #58282:
            // Null and Default IDs should be treated the same during publisher instantiation.
            newId = ( newId == DtEntityIdentifier::nullId() ? DtEntityIdentifier::defaultId() : newId );

            DtObjectPublisher* publisher = instantiateDisPublisher( refObj, newId );

            // Abort if no publisher was instantiated.
            if ( ! publisher )
            {
               brokerObj->setDropReason( "Publisher instantiation failed" );
               DtWarn << name() << " Translator dropping object: " <<
                  refObj->sr()->identifier() << std::endl;
               brokerObj->setPublisherPtr( NULL );
               brokerObj->setIsDropped( true );
               return;
            }

            // Set up the global ID Mapping
            if ( ! performDisGlobalIdMapping(publisher,*refObj, DtGlobalIdMapper::PropulsionNoiseType) )
            {
               // Object dropped, publisher no longer needed and will be deleted with the release.
               DtUnderwaterAcousticsPublisherManager* mgr = disBroker()->underwaterAcousticsPublisherManager();
               mgr->releasePublisher( refObj->sr()->hostObjectIdentifier() );

               // Note that the object is being dropped in the log file.
               DtWarn << this->name() << " translator dropping object: " << refObj->sr()->identifier() << std::endl;

               // Abort if the name is invalid and destroy the publisher.
               brokerObj->setDropReason( "Name collision" );
               brokerObj->setPublisherPtr( NULL );
               brokerObj->setIsDropped( true );
               return;
            }

            brokerObj->setPublisherPtr( publisher );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      DtString DtPropulsionNoiseTranslator::portalObjectName(
         const DtReflectedPropulsionNoise* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "PNvrx";
      }

      bool DtPropulsionNoiseTranslator::performPortalGlobalIdMapping(
         const DtPortalPropulsionNoisePublisher* publisher,
         const DtReflectedPropulsionNoise& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performPortalGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::PropulsionNoiseType );
      }

      void DtPropulsionNoiseTranslator::receivePortalUpdate(
         const DtPortalReflectedPropulsionNoiseObject& object )
      {
         try
         {
            DtBrokerObject* brokerObject = findBrokerObject( &object );
            if ( ! brokerObject )
            {
               DtWarn << "Received update call for deleted portal emitter system: "
                  << object.sr()->hostObjectIdentifier() << std::endl;
               return;
            }
            assert( brokerObject );

            const DtPortalPropulsionNoiseObject& portalPropNoise = *(object.sr());

            updatePortalBrokerObject( brokerObject, portalPropNoise );

            callObjectUpdateCallbacks( brokerObject );

            // Abort if the object has been dropped.
            if ( brokerObject->isDropped() )
            {
               return;
            }

            DtObjectPublisher* objectPublisher = NULL;
            DtPropulsionNoiseStateRepository* disPropNoiseSr = NULL;
            if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
            {
               DtPropulsionNoisePublisher* publisher =
                  static_cast<DtPropulsionNoisePublisher*>(
                     brokerObject->publisherPtr() );
               assert( publisher );

               disPropNoiseSr = publisher->psr();
               objectPublisher = publisher;
            }
            else
            {
               DtUnderwaterAcousticsPublisher* publisher =
                  static_cast<DtUnderwaterAcousticsPublisher*>(
                     brokerObject->publisherPtr() );
               assert( publisher );

               disPropNoiseSr = &publisher->usr()->propNoiseStateRep();
               objectPublisher = publisher;
            }

            translate( disPropNoiseSr, portalPropNoise, object );

            if ( myBroker->brokerInitializer()->oneToOneMapping() )
            {
               objectPublisher->forceUpdate();
            }

            if ( myBroker->isTranslatorDebuggingOn(name()) )
            {
               printIncomingOutgoingStateReps( portalPropNoise, *disPropNoiseSr );
            }

            if ( isPublishEnabled() )
            {
               objectPublisher->tick();
            }

            performPortalDebugging( portalPropNoise, *disPropNoiseSr );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      void DtPropulsionNoiseTranslator::deleteDisPublisher( DtBrokerObject* brokerObject )
      {
         DtObjectPublisher* publisher =
            static_cast<DtObjectPublisher*>( brokerObject->publisherPtr() );
         const DtPortalReflectedPropulsionNoiseObject* reflectedObj =
            static_cast<const DtPortalReflectedPropulsionNoiseObject*>(
               brokerObject->reflectedObjPtr() );
         if ( ! disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
         {
            DtUnderwaterAcousticsPublisherManager* mgr =
               disBroker()->underwaterAcousticsPublisherManager();
            mgr->releasePublisher( reflectedObj->sr()->hostObjectIdentifier() );
         }

         if ( publisher && reflectedObj )
         {
            DtGlobalIdMapper::ObjectType type =
               DtGlobalIdMapper::PropulsionNoiseType;
            disBroker()->globalIdMapper()->remove(
               reflectedObj->sr()->entityIdentifier(), type );
            brokerObject->setPublisherPtr( 0 );
            if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
            {
               DtDELETE( publisher );
            }
         }
      }

      DtPortalPropulsionNoiseObject* DtPropulsionNoiseTranslator::translate(
         DtPortalPropulsionNoiseObject* destination, const DtPropulsionNoiseStateRepository& source,
         const DtReflectedPropulsionNoise& refObj )
      {
         // Translate underwater acoustics attributes.
         ParentClass::translate( destination, source, refObj );

         // Propulsion Noise Attribute Translation.
         destination->setHullMaskerOn( source.hullMaskerOn() );
         destination->setPassiveParameterIndex( source.passiveParameterIndex() );
         destination->setPropulsionPlantConfiguration( source.propulsionPlantConfiguration() );

         // Remove all shaft rate datas.
         // Removing and re-adding may not be the most efficient.
         // We can come back and optimize this later.
         destination->shaftRateData().clear();

         const std::vector<DtUnderwaterAcousticShaftSpeed>& sourceShaftRateDatas = source.shaftRateData();
         std::vector<DtUnderwaterAcousticShaftSpeed>::const_iterator itr = sourceShaftRateDatas.begin();
         std::vector<DtUnderwaterAcousticShaftSpeed>::const_iterator end = sourceShaftRateDatas.end();
         DtShaftRateDataList& destinationShaftRateData = destination->shaftRateData();
         for ( ; itr != end; ++itr )
         {
            DtShaftRateData shaftRateData;
            translate( &shaftRateData, *itr );
            destinationShaftRateData.insert( destinationShaftRateData.end(), shaftRateData );
         }

         return destination;
      }

      DtPropulsionNoiseStateRepository* DtPropulsionNoiseTranslator::translate(
         DtPropulsionNoiseStateRepository* destination, const DtPortalPropulsionNoiseObject& source,
         const DtPortalReflectedPropulsionNoiseObject& refObj )
      {
         // Translate underwater acoustics attributes.
         ParentClass::translate( destination, source, refObj );

         // Propulsion Noise Attribute Translation.
         destination->setHullMaskerOn( source.hullMaskerOn() );
         destination->setPassiveParameterIndex( source.passiveParameterIndex() );
         destination->setPropulsionPlantConfiguration( (DtUnderwaterAcousticPropulsionPlantConfig) source.propulsionPlantConfiguration() );

         // Translate shaft rate data and store in destination list.
         std::vector<DtUnderwaterAcousticShaftSpeed> destinationShaftRateData;
         const DtShaftRateDataList& sourceShaftRateDatas = source.shaftRateData();
         DtShaftRateDataList::const_iterator itr = sourceShaftRateDatas.begin();
         DtShaftRateDataList::const_iterator end = sourceShaftRateDatas.end();
         for ( ; itr != end; ++itr )
         {
            DtUnderwaterAcousticShaftSpeed shaftRateData;
            translate( &shaftRateData, *itr );
            destinationShaftRateData.insert( destinationShaftRateData.end(), shaftRateData );
         }
         destination->setShaftRateData( destinationShaftRateData );

         return destination;
      }

      DtShaftRateData* DtPropulsionNoiseTranslator::translate(
         DtShaftRateData* destination, const DtUnderwaterAcousticShaftSpeed& source )
      {
         destination->setCurrentShaftRPM( source.currentShaftRPM() );
         destination->setOrderedShaftRPM( source.orderedShaftRPM() );
         destination->setShaftRPM_RateOfChange( source.shaftRPM_RateOfChange() );
         return destination;
      }

      DtUnderwaterAcousticShaftSpeed* DtPropulsionNoiseTranslator::translate(
         DtUnderwaterAcousticShaftSpeed* destination, const DtShaftRateData& source )
      {
         destination->setCurrentShaftRPM( source.currentShaftRPM() );
         destination->setOrderedShaftRPM( source.orderedShaftRPM() );
         destination->setShaftRPM_RateOfChange( source.shaftRPM_RateOfChange() );
         return destination;
      }

   }
}
