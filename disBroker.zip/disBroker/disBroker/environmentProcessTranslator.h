/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file environmentProcessTranslator.h
//! \brief Contains the DtEnvironmentProcessTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/environmentProcessPublisher.h>
#include <vl/reflectedEnvironmentProcessList.h>

class DtReflectedEnvironmentProcess;
class DtEnvironmentProcessRepository;

#define ENV_PROC_TEMPLATE_ARGS \
   DtPortalEnvironmentProcessObject, DtPortalReflectedEnvironmentProcessObject, \
   DtReflectedEnvironmentProcess, DtReflectedEnvironmentProcessList, \
   DtEnvironmentProcessRepository, DtEnvironmentProcessPublisher

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<ENV_PROC_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedEnvironmentProcessObject* refObj,
         const DtString& identifier );

      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<ENV_PROC_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedEnvironmentProcessObject* refObj,
         const DtEntityIdentifier& objectName );


      //! \brief Provides Environment Process object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtEnvironmentProcessTranslator
         : public DtDisObjectTranslator<ENV_PROC_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Environment Process" );

         //! \brief CTOR.
         DtEnvironmentProcessTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtEnvironmentProcessTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedEnvironmentProcessObject* refObj );

         //! Determines the name to use for the given reflected object.
         //! Translators which need to perform name mapping (eg. for using
         //! the object's marking text as its name) can override this method.
         //! Default implementation uses the object's identifier.
         //! Called by ::createDisPublisher.
         virtual DtString disObjectName( const DtPortalReflectedEnvironmentProcessObject* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const DtEnvironmentProcessRepository& sr );

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! This method can be overridden to perform mapping for different types
         //! of objects as well (emitters, etc.).
         virtual bool performDisGlobalIdMapping( const DtObjectPublisher* publisher,
            const DtPortalReflectedEnvironmentProcessObject& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Construct the portal object name.
         //! Overridden to construct an active sonar name.
         virtual DtString portalObjectName( const DtReflectedEnvironmentProcess* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj,
            const DtPortalEnvironmentProcessObject& sr );

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! This method can be overridden to perform mapping for different types
         //! of objects as well (emitters, etc.).
         virtual bool performPortalGlobalIdMapping(
            const DtPortalEnvironmentProcessObjectPublisher* publisher,
            const DtReflectedEnvironmentProcess& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Translates an Environment Process Object to the portal.
         virtual DtPortalEnvironmentProcessObject* translate(
            DtPortalEnvironmentProcessObject* destination,
            const DtEnvironmentProcessRepository& source,
            const DtReflectedEnvironmentProcess& refObj );

         //! \brief Translates a portal Emitter System from the portal.
         virtual DtEnvironmentProcessRepository* translate(
            DtEnvironmentProcessRepository* destination,
            const DtPortalEnvironmentProcessObject& source,
            const DtPortalReflectedEnvironmentProcessObject& refObj );

      };

   }
}
