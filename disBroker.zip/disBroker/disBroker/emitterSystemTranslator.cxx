/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file emitterSystemTranslator.cxx
//! \brief Contains the DtEmitterSystemTranslator class definition.
//! \ingroup disBroker

#include <disBroker/emitterSystemTranslator.h>
#include <disBroker/disBrokerInitializer.h>
#include <disBroker/eventIdMapper.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtEmitterSystemTranslator::DtEmitterSystemTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalEmitterSystemObject::theKind )
      {
      }

      DtEmitterSystemTranslator::~DtEmitterSystemTranslator()
      {
      }

      bool DtEmitterSystemTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedEmitterSystemObject* refObj )
      {
         const DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->emitterSystemNeedsEntityId() )
         {
            int index = refObj->sr()->emitterIndex();
            DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::EmitterSystemType;
            DtEntityIdentifier newId = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
               refObj->sr()->identifier(), &objType, &index );
            if ( newId == DtEntityIdentifier::nullId() )
            {
               newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
                  refObj->sr()->entityIdentifier() );
            }
            if ( newId == DtEntityIdentifier::nullId() )
            {
               DtInfo << "DtEmitterSystemTranslator: " << brokerObj->objectName()
                  << ": Entity Id not present, object incomplete" << std::endl;
               brokerObj->setDropReason( "Missing Entity ID" );
               return false;
            }
         }
         if ( discoveryCriteria->emitterSystemNeedsHostId()
            && refObj->sr()->hostObjectIdentifier() == "" )
         {
            DtInfo << "DtEmitterSystemTranslator: " << brokerObj->objectName()
               << ": Host Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Host ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      bool DtEmitterSystemTranslator::performDisGlobalIdMapping(
         const DtObjectPublisher* publisher, const DtPortalReflectedEmitterSystemObject& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performDisGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::EmitterSystemType, refObj.sr()->emitterIndex(),
            beamId );
      }

      DtString DtEmitterSystemTranslator::portalObjectName(
         const DtReflectedEmitterSystem* refObj ) const
      {
         DtString newEntityName( refObj->globalId().string() );
         newEntityName += "-";
         newEntityName += refObj->esr()->emitterNumber();
         newEntityName += "Evrx";
         return newEntityName;
      }

      bool DtEmitterSystemTranslator::performPortalGlobalIdMapping(
         const DtPortalEmitterSystemObjectPublisher* publisher,
         const DtReflectedEmitterSystem& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performPortalGlobalIdMapping( publisher,
            refObj, DtGlobalIdMapper::EmitterSystemType,
            refObj.esr()->emitterNumber(), beamId );
      }

      void DtEmitterSystemTranslator::deleteDisPublisher( DtBrokerObject* brokerObj )
      {
         DtEmitterSystemPublisher* publisher =
            static_cast<DtEmitterSystemPublisher*>( brokerObj->publisherPtr() );
         const DtPortalReflectedEmitterSystemObject* refObj =
            static_cast<const DtPortalReflectedEmitterSystemObject*>(
               brokerObj->reflectedObjPtr() );
         if ( publisher && refObj )
         {
            DtU32 emitterIndex = refObj->sr()->emitterIndex();
            disBroker()->globalIdMapper()->remove( refObj->sr()->entityIdentifier(),
               DtGlobalIdMapper::EmitterSystemType, emitterIndex );
            brokerObj->setPublisherPtr( 0 );
            DtDELETE( publisher );
         }
      }

      DtPortalEmitterSystemObject* DtEmitterSystemTranslator::translate(
         DtPortalEmitterSystemObject* destination, const DtEmitterSystemRepository& source,
         const DtReflectedEmitterSystem& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         destination->setEmitterType( source.emitterName() );
         destination->setEmitterFunctionCode( source.emitterFunction() );
         destination->setEmitterIndex( source.emitterNumber() );
         destination->setEventIdentifier( disBroker()->eventIdMapper()->convertEventId( source.eventId() ) );

         // Remove all beams. Previously we walked the list and removed only the beams
         // that were not in the source list. This code was complicated and involved
         // multiple list passes. It may not be the most efficient way to update the list
         // but nuking it and filling it back in is clear and clean. We can optimize this
         // if we later figure out this is a bottle neck.
         destination->emitterBeamList().clear();

         DtListItem* beamItem = source.beamList()->first();
         DtEmitterBeamRepository* sourceBeam = NULL;
         while ( beamItem )
         {
            sourceBeam = static_cast<DtEmitterBeamRepository*>( beamItem->data() );

            // Create the beam if it doesn't exist
            DtEmitterBeamData* destinationBeam = destination->findBeam( sourceBeam->beamId() );
            if ( destinationBeam == NULL )
            {
               DtEmitterBeamData newBeam;
               newBeam.setEventIdentifier( destination->eventIdentifier() );
               newBeam.setEmitterSystemIdentifier( destination->identifier() );
               DtEmitterBeamList::iterator itr = destination->emitterBeamList().insert(
                  destination->emitterBeamList().end(), newBeam );
               destinationBeam = &(*itr);
            }

            translate( destinationBeam, *sourceBeam );

            beamItem = beamItem->next();
         }

         return destination;
      }

      DtEmitterBeamData* DtEmitterSystemTranslator::translate(
         DtEmitterBeamData* destination, const DtEmitterBeamRepository& source )
      {
         destination->setBeamType( source.beamType() );
         destination->setBeamParameterIndex( source.beamParameterIndex() );
         destination->setBeamAzimuthCenter( source.azimuthCenter() );
         destination->setBeamAzimuthSweep( source.azimuthSweep() );
         destination->setBeamElevationCenter( source.elevationCenter() );
         destination->setBeamElevationSweep( source.elevationSweep() );
         destination->setBeamFunctionCode( source.beamFunction() );
         destination->setBeamIdentifier( source.beamId() );
         destination->setEffectiveRadiatedPower( source.ERP() );
         destination->setEmissionFrequency( source.frequency() );
         destination->setFrequencyRange( source.frequencyRange() );
         destination->setPulseRepetitionFrequency( source.PRF() );
         destination->setPulseWidth( source.pulseWidth() );
         destination->setSweepSynch( source.sweepSync() );

         const DtTrackJamDesignatorList& sourceTargets = source.trackJamTargets();
         std::vector<DtString>* destinationTargets = NULL;

         if ( destination->beamType() == DtEmitterBeamData::RadarBeam
            || destination->beamType() == DtEmitterBeamData::TrackBeam )
         {
            destination->setHighDensityTrack( source.highDensity() );
            destinationTargets = &destination->trackObjectIdentifiers();
         }
         else if ( destination->beamType() == DtEmitterBeamData::JamBeam )
         {
            destination->setHighDensityJam( source.highDensity() );
            destination->setJammingModeSequence( source.jammingModeSequence() );

            destinationTargets = &destination->jammedObjectIdentifiers();
         }

         // If there are targets, translate them.
         if ( destinationTargets != NULL )
         {
            destinationTargets->clear();
            for ( int index = 0; index < sourceTargets.numObjects(); ++index )
            {
               bool isValid = true;
               const DtGlobalObjectDesignator& object = sourceTargets.object( index, &isValid );
               if ( isValid )
               {
                  destinationTargets->push_back( disBroker()->globalIdMapper()
                     ->convertDisGidToPortalGid(object) );
               }
            }
         }

         return destination;
      }

      DtEmitterSystemRepository* DtEmitterSystemTranslator::translate(
         DtEmitterSystemRepository* destination, const DtPortalEmitterSystemObject& source,
         const DtPortalReflectedEmitterSystemObject& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         destination->setEmitterFunction( (DtEmissionFunc) source.emitterFunctionCode() );
         destination->setEmitterName( (DtEmitterSysName) source.emitterType() );
         destination->setEmitterNumber( source.emitterIndex() );
         destination->setEventId( disBroker()->eventIdMapper()->convertEventId(source.eventIdentifier()) );

         // Remove all beams from the destination not found within the source
         DtListItem* beamItem = destination->beamList()->first();
         DtEmitterBeamRepository* destinationBeam = NULL;
         while ( beamItem )
         {
            DtEmitterBeamRepository* destinationBeam =
               static_cast<DtEmitterBeamRepository*>( beamItem->data() );
            beamItem = beamItem->next(); // must update beamItem before a potential removeBeam
            if ( ! source.isBeamWithinList(destinationBeam->beamId()) )
            {
               destination->removeBeam( destinationBeam->beamId() );
            }
         }

         // Iterate over all incoming beams and translate them into the destination.
         const DtEmitterBeamList& sourceBeams = source.emitterBeamList();
         DtEmitterBeamList::const_iterator itr = sourceBeams.begin();
         DtEmitterBeamList::const_iterator end = sourceBeams.end();
         for ( ; itr != end; ++itr )
         {
            // If the beam doesn't exist, add it.
            DtU8 index = itr->beamIdentifier();
            destinationBeam = destination->beamSRById( index, NULL );
            if ( destinationBeam == NULL )
            {
               DtEmitterSysRetCode returnCode = DtEmitterSuccess;
               destinationBeam = destination->addBeam( index, (DtBeamType) itr->beamType(), &returnCode );

               if ( returnCode != DtEmitterSuccess
                  && returnCode != DtDuplicateBeamId )
               {
                  destinationBeam = NULL;
                  DtWarn << "Couldn't add a new Emitter Beam with index=" << index
                     << " and type=" << DtEnumString( (DtEmitterBeamData::BeamType)itr->beamType() )
                     << std::endl;
               }
               else
               {
                  destinationBeam->setEntityId( destination->entityId() );
                  destinationBeam->setEventId( destination->eventId() );
               }
            }

            if ( destinationBeam != NULL )
            {
               translate( destinationBeam, *itr );

               // Map the portal beam identifier to the outgoing emitter beam id.
               if ( ! itr->identifier().isEmpty() )
               {
                  disBroker()->globalIdMapper()->add( itr->identifier(), destination->hostId(),
                     DtGlobalIdMapper::EmitterSystemType, source.emitterIndex(), index );
               }

               destinationBeam->setEmittingSystemId( destination->emitterNumber() );
               if ( destinationBeam->entityId() == DtEntityIdentifier() )
               {
                  destinationBeam->setEntityId( destination->entityId() );
               }
               if ( destinationBeam->eventId() == DtEventId() )
               {
                  destinationBeam->setEventId( destination->eventId() );
               }
            }
         }

         return destination;
      }

      DtEmitterBeamRepository* DtEmitterSystemTranslator::translate(
         DtEmitterBeamRepository* destination, const DtEmitterBeamData& source )
      {
         destination->setAzimuthCenter( source.beamAzimuthCenter() );
         destination->setAzimuthSweep( source.beamAzimuthSweep() );
         destination->setBeamFunction( (DtBeamFunc)source.beamFunctionCode() );
         destination->setBeamId( source.beamIdentifier() );
         destination->setBeamParameterIndex( source.beamParameterIndex() );
         destination->setElevationCenter( source.beamElevationCenter() );
         destination->setElevationSweep( source.beamElevationSweep() );
         destination->setERP( source.effectiveRadiatedPower() );
         destination->setFrequency( source.emissionFrequency() );
         destination->setFrequencyRange( source.frequencyRange() );
         destination->setPRF( source.pulseRepetitionFrequency() );
         destination->setPulseWidth( source.pulseWidth() );
         destination->setSweepSync( source.sweepSynch() );
         destination->setBeamType( (DtBeamType)source.beamType() );
         bool isJamming = false;

         DtTrackJamDesignatorList* destinationTargets = destination->trackJamTargets();
         const std::vector<DtString>* sourceTargets = NULL;

         if ( destination->beamType() == DtRadarBeam
            || destination->beamType() == DtTrackBeam )
         {
            destination->setHighDensity( source.highDensityTrack() );
            sourceTargets = &source.trackObjectIdentifiers();
         }
         else if ( destination->beamType() == DtJamBeam )
         {
            destination->setHighDensity( source.highDensityJam() );
            destination->setJammingModeSequence( source.jammingModeSequence() );

            sourceTargets = &source.jammedObjectIdentifiers();
            isJamming = true;
         }

         // If there are targets, translate them.
         if ( sourceTargets != NULL )
         {
            int index = 0;
            destinationTargets->setNumObjects( 0 );
            destinationTargets->setNumObjects( sourceTargets->size() );
            std::vector<DtString>::const_iterator itr = sourceTargets->begin();
            std::vector<DtString>::const_iterator end = sourceTargets->end();
            for ( ; itr != end; ++itr, ++index )
            {
               DtTrackJamDesignator designator;
               if ( isJamming )
               {
                  // If its a jammer then this must map to a beam...
                  int beamId = DtGlobalIdMapper::NoBeamId;
                  int emitterId = DtGlobalIdMapper::NoSystemId;
                  DtGlobalIdMapper::ObjectType otype = DtGlobalIdMapper::NoType;

                  DtEntityIdentifier ent( disBroker()->globalIdMapper()
                     ->convertPortalGidToDisGid(*itr,&otype,&emitterId,&beamId) );

                  designator.setSite( ent.site() );
                  designator.setHost( ent.host() );
                  designator.setEntityNum( ent.entityNum() );

                  designator.setEmitterId( emitterId );
                  designator.setBeamId( beamId );

                  destinationTargets->setObject( index, designator );
               }
               else
               {
                  // If its not jamming then its tracking, and this just maps to an entity
                  DtEntityIdentifier ent( disBroker()->globalIdMapper()
                     ->convertPortalGidToDisGid(*itr) );

                  designator.setSite( ent.site() );
                  designator.setHost( ent.host() );
                  designator.setEntityNum( ent.entityNum() );

                  destinationTargets->setObject( index, designator );
               }
            }
         }

         return destination;
      }

   }
}
