/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file setDataTranslator.cxx
//! \brief Contains the DtSetDataTranslator class definition.
//! \ingroup disBroker

#include <disBroker/setDataTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtSetDataTranslator::DtSetDataTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalSetDataInteraction::theKind )
      {
      }

      DtSetDataTranslator::~DtSetDataTranslator()
      {
      }

      bool DtSetDataTranslator::isPortalDiscoverable(
         const DtPortalSetDataInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.originatingEntity())
            && testGlobalIdMapping("Receiver ID",inter.receivingEntity()) );
      }

      DtPortalSetDataInteraction* DtSetDataTranslator::translate(
         DtPortalSetDataInteraction* destination, const DtSetDataInteraction& source )
      {
         {  // Fixed Datums
            DtFixedLengthDataArray* fixedDatums = &destination->fixedDatums();
            fixedDatums->resize( source.numFixedFields() );

            DtFixedLengthDataArray::iterator pos = fixedDatums->begin();
            // Indexes for Var Datums start at 1 in VR-Link
            for ( size_t index = 1; pos != fixedDatums->end(); ++pos, ++index )
            {
               (*pos).setId( source.fixedDatumId( index ));
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtU32 fixedValue = source.datumValUnsigned32( DtFixed, index, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  (*pos).setValue( fixedValue );
               }
            }
         }

         destination->setOriginatingEntity( disBroker()->convertGlobalId( source.senderId() ));
         destination->setReceivingEntity( disBroker()->convertGlobalId( source.receiverId() ));
         destination->setRequestIdentifier( source.requestId());

         {  // Variable Datum Set
            DtAttributeValuePairList* variableDatumSet = &destination->variableDatumSet();
            variableDatumSet->resize( source.numVarFields() );

            DtAttributeValuePairList::iterator pos = variableDatumSet->begin();
            // Indexes for Var Datums start at 1 in VR-Link
            for ( size_t index = 1; pos != variableDatumSet->end(); ++pos, ++index )
            {
               (*pos).first = DtString( source.varDatumId( index ));
               (*pos).second.setData( source.datumValByteArray( DtVar, index ),
                  source.datumSizeBytes( DtVar, index ));
            }
         }

         return destination;
      }

      DtSetDataInteraction* DtSetDataTranslator::translate(
         DtSetDataInteraction* destination, const DtPortalSetDataInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId( source.originatingEntity() ));
         destination->setReceiverId( disBroker()->convertGlobalId( source.receivingEntity() ));
         destination->setRequestId( source.requestIdentifier());

         {  // Fixed Datum Set
            destination->setNumFixedFields( source.fixedDatums().size() );

            DtFixedLengthDataArray::const_iterator pos = source.fixedDatums().begin();
            // Indexes for Var Datums start at 1 in VR-Link
            for (int index = 1; pos != source.fixedDatums().end(); ++pos, ++index)
            {
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtDatumParam id = (DtDatumParam)(*pos).id();
               destination->setDatumParam( DtFixed, index, id, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  DtU32 value = (*pos).value();
                  destination->setDatumValUnsigned32( DtFixed, index, value, &returnCode );
               }
            }
         }

         {  // Variable Datum true
            destination->setNumVarFields( source.variableDatumSet().size() );

            DtAttributeValuePairList::const_iterator pos = source.variableDatumSet().begin();
            // Indexes for Var Datums start at 1 in VR-Link
            for (int index = 1; pos != source.variableDatumSet().end(); ++pos, ++index)
            {
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtDatumParam varDatumId = (DtDatumParam)atol( (*pos).first );
               destination->setDatumParam( DtVar, index, varDatumId, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  int length = (*pos).second.size();
                  destination->setVarDataBytes( index, length, &returnCode );
                  const char* value = (*pos).second.data();
                  destination->setDatumValByteArray( DtVar, index, value, &returnCode );
               }
            }
         }

         return destination;
      }

   }
}
