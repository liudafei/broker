/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file activeSonarTranslator.h
//! \brief Contains the DtActiveSonarTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/underwaterAcousticTranslator.h>
#include <vl/reflectedActiveSonarList.h>
#include <vl/activeSonarPublisher.h>

class DtReflectedActiveSonar;
class DtActiveSonarStateRepository;

#define ACTIVE_SONAR_TEMPLATE_ARGS \
   DtPortalActiveSonar, DtPortalReflectedActiveSonar, \
   DtReflectedActiveSonar, DtReflectedActiveSonarList, \
   DtActiveSonarStateRepository, DtActiveSonarPublisher

namespace MAKVrExchange
{

   class DtActiveSonarBeamData;

   namespace DtDisBroker
   {

      //! \brief Provides Active Sonar translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtActiveSonarTranslator
         : public DtUnderwaterAcousticTranslator<ACTIVE_SONAR_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Active Sonar" );

         //! \brief CTOR.
         DtActiveSonarTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtActiveSonarTranslator();

      protected:

         //! Instantiates the publisher for the given reflected object.
         //! This may be overridden to modify the constructor used to create
         //! the publisher or perform additional publisher initialization.
         //! Default implementation attempts to create the publisher using
         //! the given name (the value returned from ::disObjectName), then
         //! attempts to create the publisher again with no name if the first
         //! attempt fails.
         //! Called by ::createDisPublisher.
         virtual DtObjectPublisher* instantiateDisPublisher(
            const DtPortalReflectedActiveSonar* refObj, const DtEntityIdentifier& name );

         //! \brief Creates a new publisher and handles identifier mapping.
         //! Overridden to perform active sonar specific mapping.
         virtual void createDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Construct the portal object name.
         //! Overridden to construct an active sonar name.
         virtual DtString portalObjectName( const DtReflectedActiveSonar* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! This method can be overridden to perform mapping for different types
         //! of objects as well (emitters, etc.).
         virtual bool performPortalGlobalIdMapping(
            const DtPortalActiveSonarPublisher* publisher, const DtReflectedActiveSonar& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Processes incoming portal updates.
         //! Overridden to properly cast publisher to get the
         //! state rep and to ensure beam identifiers are set correctly.
         virtual void receivePortalUpdate( const DtPortalReflectedActiveSonar& object );

         //! \brief Destroy the DtActiveSonarPublisher of the brokerObject.
         //! Overridden to correctly destroy the instantiated publisher and
         //! remove it from the manager if underwater acoustic PDUs aren't split.
         virtual void deleteDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedActiveSonar* refObj );

         //! \brief Translates an Active Sonar into the portal.
         virtual DtPortalActiveSonar* translate( DtPortalActiveSonar* destination,
            const DtActiveSonarStateRepository& source, const DtReflectedActiveSonar& refObj );

         //! \brief Translates an Active Sonar from the portal.
         virtual DtActiveSonarStateRepository* translate( DtActiveSonarStateRepository* destination,
            const DtPortalActiveSonar& source, const DtPortalReflectedActiveSonar& refObj );

         //! \brief Translates an Active Sonar Beam into the portal.
         virtual DtActiveSonarBeamData* translate( DtActiveSonarBeamData* destination,
            const DtActiveSonarBeamRepository& source );

         //! \brief Translates an Active Sonar Beam from the portal.
         virtual DtActiveSonarBeamRepository* translate( DtActiveSonarBeamRepository* destination,
            const DtActiveSonarBeamData& source );

      };

   }
}
