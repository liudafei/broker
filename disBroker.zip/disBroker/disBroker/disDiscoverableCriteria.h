/*****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disDiscoverableCriteria.h
//! \brief Contains the DtDisDiscoverableCriteria class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/dllExport.h>
#include <broker/brokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //! \class DtDisDiscoverableCriteria
      //! \brief Provides discoverable criteria initialization parameters to the
      //! \ref DtDisBroker "DIS Broker"
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDisDiscoverableCriteria
      {
      public:

         //! \brief Constructor.
         DtDisDiscoverableCriteria( DtVariableGroup* parentVariable );

         //! \brief Destructor frees memory.
         virtual ~DtDisDiscoverableCriteria();

         //! \brief Assignment operator
         virtual DtDisDiscoverableCriteria& operator = ( const DtDisDiscoverableCriteria& other );

         virtual bool aggregateNeedsEntityId() const;
         virtual bool aggregateNeedsEntityType() const;
         virtual bool aggregateNeedsLocation() const;
         virtual bool designatorNeedsEntityId() const;
         virtual bool designatorNeedsHostId() const;
         virtual bool emitterSystemNeedsEntityId() const;
         virtual bool emitterSystemNeedsHostId() const;
         virtual bool entityNeedsEntityType() const;
         virtual bool entityNeedsLocation() const;
         virtual bool environmentProcessNeedsProcessId() const;
         virtual bool griddedDataNeedsGridId() const;
         virtual bool iffNeedsEntityId() const;
         virtual bool iffNeedsHostId() const;
         virtual bool radioReceiverNeedsEntityId() const;
         virtual bool radioReceiverNeedsHostId() const;
         virtual bool radioTransmitterNeedsEntityId() const;
         virtual bool radioTransmitterNeedsHostId() const;
         virtual bool underwaterAcousticsNeedsAcousticId() const;
         virtual bool underwaterAcousticsNeedsEntityId() const;
         virtual bool underwaterAcousticsNeedsHostId() const;

         virtual void setAggregateNeedsEntityId( bool );
         virtual void setAggregateNeedsEntityType( bool );
         virtual void setAggregateNeedsLocation( bool );
         virtual void setDesignatorNeedsEntityId( bool );
         virtual void setDesignatorNeedsHostId( bool );
         virtual void setEmitterSystemNeedsEntityId( bool );
         virtual void setEmitterSystemNeedsHostId( bool );
         virtual void setEntityNeedsEntityType( bool );
         virtual void setEntityNeedsLocation( bool );
         virtual void setEnvironmentProcessNeedsProcessId( bool );
         virtual void setGriddedDataNeedsGridId( bool );
         virtual void setIffNeedsEntityId( bool );
         virtual void setIffNeedsHostId( bool );
         virtual void setRadioReceiverNeedsEntityId( bool );
         virtual void setRadioReceiverNeedsHostId( bool );
         virtual void setRadioTransmitterNeedsEntityId( bool );
         virtual void setRadioTransmitterNeedsHostId( bool );
         virtual void setUnderwaterAcousticsNeedsAcousticId( bool );
         virtual void setUnderwaterAcousticsNeedsEntityId( bool );
         virtual void setUnderwaterAcousticsNeedsHostId( bool );

      private:

         //! \brief Copy constructor not implemented - cannot be copied.
         DtDisDiscoverableCriteria( const DtDisDiscoverableCriteria& other );

      protected:

         DtVariableGroup myAggregateCriteria;
         DtVariableGroup myDesignatorCriteria;
         DtVariableGroup myEmitterSystemCriteria;
         DtVariableGroup myEntityCriteria;
         DtVariableGroup myEnvironmentProcessCriteria;
         DtVariableGroup myGriddedDataCriteria;
         DtVariableGroup myIFFCriteria;
         DtVariableGroup myRadioRecvCriteria;
         DtVariableGroup myRadioTransCriteria;
         DtVariableGroup myUnderwaterAcousticsCriteria;

         DtConfigVariable<bool> myAgregateEntityId;
         DtConfigVariable<bool> myAgregateEntityType;
         DtConfigVariable<bool> myAgregateLocation;
         DtConfigVariable<bool> myDesignatorEntityId;
         DtConfigVariable<bool> myDesignatorHostId;
         DtConfigVariable<bool> myEmitterSystemEntityId;
         DtConfigVariable<bool> myEmitterSystemHostId;
         DtConfigVariable<bool> myEntityEntityType;
         DtConfigVariable<bool> myEntityLocation;
         DtConfigVariable<bool> myEnvironmentProcessId;
         DtConfigVariable<bool> myGriddedDataGridId;
         DtConfigVariable<bool> myIFFEntityId;
         DtConfigVariable<bool> myIFFHostId;
         DtConfigVariable<bool> myRadioRecvEntityId;
         DtConfigVariable<bool> myRadioRecvHostId;
         DtConfigVariable<bool> myRadioTransEntityId;
         DtConfigVariable<bool> myRadioTransHostId;
         DtConfigVariable<bool> myUnderwaterAcousticsAcousticId;
         DtConfigVariable<bool> myUnderwaterAcousticsEntityId;
         DtConfigVariable<bool> myUnderwaterAcousticsHostId;

      };

   }
}
