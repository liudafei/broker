/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file resupplyCancelTranslator.cxx
//! \brief Contains the DtResupplyCancelTranslator class definition.
//! \ingroup disBroker

#include <disBroker/resupplyCancelTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtResupplyCancelTranslator::DtResupplyCancelTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalResupplyCancelInteraction::theKind )
      {
      }

      DtResupplyCancelTranslator::~DtResupplyCancelTranslator()
      {
      }

      bool DtResupplyCancelTranslator::isPortalDiscoverable(
         const DtPortalResupplyCancelInteraction& inter )
      {
         return ( testGlobalIdMapping("Receiving ID",inter.receivingId())
            && testGlobalIdMapping("Supplying ID",inter.supplyingId()) );
      }

      DtPortalResupplyCancelInteraction* DtResupplyCancelTranslator::translate(
         DtPortalResupplyCancelInteraction* destination, const DtResupplyCancelInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setSupplyingId( disBroker()->convertGlobalId(source.supplyingId()) );
         return destination;
      }

      DtResupplyCancelInteraction* DtResupplyCancelTranslator::translate(
         DtResupplyCancelInteraction* destination, const DtPortalResupplyCancelInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setSupplyingId( disBroker()->convertGlobalId(source.supplyingId()) );
         return destination;
      }

   }
}
