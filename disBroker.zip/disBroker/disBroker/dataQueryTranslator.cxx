/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file dataQueryTranslator.cxx
//! \brief Contains the DtDataQueryTranslator class definition.
//! \ingroup disBroker

#include <disBroker/dataQueryTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtDataQueryTranslator::DtDataQueryTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalDataQueryInteraction::theKind )
      {
      }

      DtDataQueryTranslator::~DtDataQueryTranslator()
      {
      }

      bool DtDataQueryTranslator::isPortalDiscoverable(
         const DtPortalDataQueryInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.originatingEntity())
            && testGlobalIdMapping("Receiver ID",inter.receivingEntity()) );
      }

      DtPortalDataQueryInteraction* DtDataQueryTranslator::translate(
         DtPortalDataQueryInteraction* destination, const DtDataQueryInteraction& source )
      {
         destination->setOriginatingEntity( disBroker()->convertGlobalId(source.senderId()) );
         destination->setReceivingEntity( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setRequestIdentifier( source.requestId() );
         destination->setTimeInterval( source.timeInterval() );

         // Note: this starts on 1 instead of 0 due to strangeness in VR-Link

         {  // Copy Fixed datums...
            std::vector<DtU32>* fixedDatums = &destination->fixedDatums();
            fixedDatums->resize( source.numFixedFields() );

            for ( unsigned int index = 1; index <= source.numFixedFields(); ++index )
            {
               (*fixedDatums)[index-1] =  (DtU32) source.fixedDatumId( index );
            }
         }

         {  // Copy Variable datums...
            std::vector<DtU32>* varDatums = &destination->variableDatums();
            varDatums->resize( source.numVarFields() );

            for ( unsigned int index = 1; index <= source.numVarFields(); ++index )
            {
               (*varDatums)[index-1] =  (DtU32) source.varDatumId( index );
            }
         }

         return destination;
      }

      DtDataQueryInteraction* DtDataQueryTranslator::translate(
         DtDataQueryInteraction* destination, const DtPortalDataQueryInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId(source.originatingEntity()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receivingEntity()) );
         destination->setRequestId( source.requestIdentifier() );
         destination->setTimeInterval( source.timeInterval() );

         destination->initDatumIds( source.fixedDatums().size(), source.variableDatums().size() );

         {  // Copy Fixed datums...
            const std::vector<DtU32>* fixedDatums = &source.fixedDatums();
            for ( unsigned int index = 1; index <= destination->numFixedFields(); ++index )
            {
               destination->setFixedDatumId( index, (DtDatumParam)(*fixedDatums)[index-1] );
            }
         }

         {  // Copy Variable datums...
            const std::vector<DtU32>* varDatums = &source.variableDatums();
            for ( unsigned int index = 1; index <= destination->numVarFields(); ++index )
            {
               destination->setVarDatumId( index, (DtDatumParam)(*varDatums)[index-1] );
            }
         }

         return destination;
      }

   }
}
