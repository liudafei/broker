/*****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disDiscoverableCriteria.cxx
//! \brief Contains the DtDisDiscoverableCriteria class declaration.
//! \ingroup disBroker

#include <disBroker/disDiscoverableCriteria.h>
#include <mtl/variableGroup.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtDisDiscoverableCriteria::DtDisDiscoverableCriteria( DtVariableGroup* parentVariable )
         : myAggregateCriteria( parentVariable, "aggregate" )
         , myDesignatorCriteria( parentVariable, "designator" )
         , myEmitterSystemCriteria( parentVariable, "emitterSystem" )
         , myEntityCriteria( parentVariable, "entity" )
         , myEnvironmentProcessCriteria( parentVariable, "environmentProcess" )
         , myGriddedDataCriteria( parentVariable, "griddedData" )
         , myIFFCriteria( parentVariable, "iff" )
         , myRadioRecvCriteria( parentVariable, "radioReceiver" )
         , myRadioTransCriteria( parentVariable, "radioTransmitter" )
         , myUnderwaterAcousticsCriteria( parentVariable, "underwaterAcoustics" )
         , myAgregateEntityId( myAggregateCriteria, "entityId", "1", "Entity ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myAgregateEntityType( myAggregateCriteria, "entityType", "1", "Entity Type",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myAgregateLocation( myAggregateCriteria, "location", "1", "Location",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myDesignatorEntityId( myDesignatorCriteria, "entityId", "1", "Entity ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myDesignatorHostId( myDesignatorCriteria, "hostId", "1", "Host ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myEmitterSystemEntityId( myEmitterSystemCriteria, "entityId", "1", "Entity ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myEmitterSystemHostId( myEmitterSystemCriteria, "hostId", "0", "Host ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myEntityEntityType( myEntityCriteria, "entityType", "1", "Entity Type",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myEntityLocation( myEntityCriteria, "location", "1", "Location",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myEnvironmentProcessId( myEnvironmentProcessCriteria, "processId", "1", "Process ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myGriddedDataGridId( myGriddedDataCriteria, "gridId", "0", "Grid ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myIFFEntityId( myIFFCriteria, "entityId", "1", "Entity ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myIFFHostId( myIFFCriteria, "hostId", "1", "Host ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myRadioRecvEntityId( myRadioRecvCriteria, "entityId", "1", "Entity ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myRadioRecvHostId( myRadioRecvCriteria, "hostId", "1", "Host ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myRadioTransEntityId( myRadioTransCriteria, "entityId", "1", "Entity ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myRadioTransHostId( myRadioTransCriteria, "hostId", "1", "Host ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myUnderwaterAcousticsAcousticId( myUnderwaterAcousticsCriteria, "acousticId", "1", "Acoustic ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myUnderwaterAcousticsEntityId( myUnderwaterAcousticsCriteria, "entityId", "1", "Entity ID",
            DtBaseConfigVariable::DtScopeConfigFile )
         , myUnderwaterAcousticsHostId( myUnderwaterAcousticsCriteria, "hostId", "0", "Host ID",
            DtBaseConfigVariable::DtScopeConfigFile )
      {
      }

      DtDisDiscoverableCriteria::~DtDisDiscoverableCriteria()
      {
      }

      DtDisDiscoverableCriteria& DtDisDiscoverableCriteria::operator = (
         const DtDisDiscoverableCriteria& other )
      {
         // Avoid assignment to self.
         if ( this == &other )
         {
            return *this;
         }

         myAgregateEntityId = other.myAgregateEntityId;
         myAgregateEntityType = other.myAgregateEntityType;
         myAgregateLocation = other.myAgregateLocation;
         myDesignatorEntityId = other.myDesignatorEntityId;
         myDesignatorHostId = other.myDesignatorHostId;
         myEmitterSystemEntityId = other.myEmitterSystemEntityId;
         myEmitterSystemHostId = other.myEmitterSystemHostId;
         myEntityEntityType = other.myEntityEntityType;
         myEntityLocation = other.myEntityLocation;
         myEnvironmentProcessId = other.myEnvironmentProcessId;
         myGriddedDataGridId = other.myGriddedDataGridId;
         myIFFEntityId = other.myIFFEntityId;
         myIFFHostId = other.myIFFHostId;
         myRadioRecvEntityId = other.myRadioRecvEntityId;
         myRadioRecvHostId = other.myRadioRecvHostId;
         myRadioTransEntityId = other.myRadioTransEntityId;
         myRadioTransHostId = other.myRadioTransHostId;
         myUnderwaterAcousticsAcousticId = other.myUnderwaterAcousticsAcousticId;
         myUnderwaterAcousticsEntityId = other.myUnderwaterAcousticsEntityId;
         myUnderwaterAcousticsHostId = other.myUnderwaterAcousticsHostId;

         return *this;
      }

      bool DtDisDiscoverableCriteria::aggregateNeedsEntityId() const
      {
         return myAgregateEntityId.value();
      }

      bool DtDisDiscoverableCriteria::aggregateNeedsEntityType() const
      {
         return myAgregateEntityType.value();
      }

      bool DtDisDiscoverableCriteria::aggregateNeedsLocation() const
      {
         return myAgregateLocation.value();
      }

      bool DtDisDiscoverableCriteria::designatorNeedsEntityId() const
      {
         return myDesignatorEntityId.value();
      }

      bool DtDisDiscoverableCriteria::designatorNeedsHostId() const
      {
         return myDesignatorHostId.value();
      }

      bool DtDisDiscoverableCriteria::emitterSystemNeedsEntityId() const
      {
         return myEmitterSystemEntityId.value();
      }

      bool DtDisDiscoverableCriteria::emitterSystemNeedsHostId() const
      {
         return myEmitterSystemHostId.value();
      }

      bool DtDisDiscoverableCriteria::entityNeedsEntityType() const
      {
         return myEntityEntityType.value();
      }

      bool DtDisDiscoverableCriteria::entityNeedsLocation() const
      {
         return myEntityLocation.value();
      }

      bool DtDisDiscoverableCriteria::environmentProcessNeedsProcessId() const
      {
         return myEnvironmentProcessId.value();
      }

      bool DtDisDiscoverableCriteria::griddedDataNeedsGridId() const
      {
         return myGriddedDataGridId.value();
      }

      bool DtDisDiscoverableCriteria::iffNeedsEntityId() const
      {
         return myIFFEntityId.value();
      }

      bool DtDisDiscoverableCriteria::iffNeedsHostId() const
      {
         return myIFFHostId.value();
      }

      bool DtDisDiscoverableCriteria::radioReceiverNeedsEntityId() const
      {
         return myRadioRecvEntityId.value();
      }

      bool DtDisDiscoverableCriteria::radioReceiverNeedsHostId() const
      {
         return myRadioRecvHostId.value();
      }

      bool DtDisDiscoverableCriteria::radioTransmitterNeedsEntityId() const
      {
         return myRadioTransEntityId.value();
      }

      bool DtDisDiscoverableCriteria::radioTransmitterNeedsHostId() const
      {
         return myRadioTransHostId.value();
      }

      bool DtDisDiscoverableCriteria::underwaterAcousticsNeedsAcousticId() const
      {
         return myUnderwaterAcousticsAcousticId.value();
      }

      bool DtDisDiscoverableCriteria::underwaterAcousticsNeedsEntityId() const
      {
         return myUnderwaterAcousticsEntityId.value();
      }

      bool DtDisDiscoverableCriteria::underwaterAcousticsNeedsHostId() const
      {
         return myUnderwaterAcousticsHostId.value();
      }

      void DtDisDiscoverableCriteria::setAggregateNeedsEntityId( bool val )
      {
         myAgregateEntityId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setAggregateNeedsEntityType( bool val )
      {
         myAgregateEntityType.setValue(val);
      }

      void DtDisDiscoverableCriteria::setAggregateNeedsLocation( bool val )
      {
         myAgregateLocation.setValue(val);
      }

      void DtDisDiscoverableCriteria::setDesignatorNeedsEntityId( bool val )
      {
         myDesignatorEntityId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setDesignatorNeedsHostId( bool val )
      {
         myDesignatorHostId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setEmitterSystemNeedsEntityId( bool val )
      {
         myEmitterSystemEntityId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setEmitterSystemNeedsHostId( bool val )
      {
         myEmitterSystemHostId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setEntityNeedsEntityType( bool val )
      {
         myEntityEntityType.setValue(val);
      }

      void DtDisDiscoverableCriteria::setEntityNeedsLocation( bool val )
      {
         myEntityLocation.setValue(val);
      }

      void DtDisDiscoverableCriteria::setEnvironmentProcessNeedsProcessId( bool val )
      {
         myEnvironmentProcessId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setGriddedDataNeedsGridId( bool val )
      {
         myGriddedDataGridId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setIffNeedsEntityId( bool val )
      {
         myIFFEntityId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setIffNeedsHostId( bool val )
      {
         myIFFHostId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setRadioReceiverNeedsEntityId( bool val )
      {
         myRadioRecvEntityId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setRadioReceiverNeedsHostId( bool val )
      {
         myRadioRecvHostId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setRadioTransmitterNeedsEntityId( bool val )
      {
         myRadioTransEntityId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setRadioTransmitterNeedsHostId( bool val )
      {
         myRadioTransHostId.setValue(val);
      }

      void DtDisDiscoverableCriteria::setUnderwaterAcousticsNeedsAcousticId( bool val )
      {
         myUnderwaterAcousticsAcousticId.setValue( val );
      }

      void DtDisDiscoverableCriteria::setUnderwaterAcousticsNeedsEntityId( bool val )
      {
         myUnderwaterAcousticsEntityId.setValue( val );
      }

      void DtDisDiscoverableCriteria::setUnderwaterAcousticsNeedsHostId( bool val )
      {
         myUnderwaterAcousticsHostId.setValue( val );
      }

   }
}
