/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file linearObjectTranslator.cxx
//! \brief Contains the DtLinearObjectTranslator class definition.
//! \ingroup disBroker

#include <disBroker/linearObjectTranslator.h>
#include <disBroker/disBrokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtLinearObjectTranslator::DtLinearObjectTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalLinearObject::theKind )
      {
         DtLinearObjectPublisher::setDfltTimeThreshold( ((DtDisBroker*)broker)->heartbeatInterval() );
      }

      DtLinearObjectTranslator::~DtLinearObjectTranslator()
      {
      }

      bool DtLinearObjectTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedLinearObject& refObj ) const
      {
         if ( refObj.sr()->objectIdentifier() == DtEntityIdentifier() )
         {
            DtInfo << "DtLinearObjectTranslator: " << brokerObj->objectName()
               << ": Object Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Object ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<LINEAR_OBJECT_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedLinearObject* refObj,
         const DtString& identifier )
      {
         return mapObjectId( DtEntityIdentifier(identifier) );
      }

      DtString DtLinearObjectTranslator::disObjectName(
         const DtPortalReflectedLinearObject* refObj ) const
      {
         return refObj->sr()->objectIdentifier().string();
      }

      void DtLinearObjectTranslator::updateDisBrokerObject( DtBrokerObject* brokerObj,
         const DtLinearObjectRepository& sr )
      {
         ParentClass::updateDisBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.objectId().string() );
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<LINEAR_OBJECT_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedLinearObject* refObj, const DtEntityIdentifier& name )
      {
         DtLinearObjectPublisher* publisher = NULL;
         try
         {
            // Instantiate the publisher.
            publisher = new DtLinearObjectPublisher( refObj->sr()->objectType(),
               disBroker()->connection(), name );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      DtString DtLinearObjectTranslator::portalObjectName(
         const DtReflectedLinearObject* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "LOvrx";
      }

      void DtLinearObjectTranslator::updatePortalBrokerObject( DtBrokerObject* brokerObj,
         const DtPortalLinearObject& sr )
      {
         ParentClass::updatePortalBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.objectIdentifier().string() );
      }

      DtPortalLinearObject* DtLinearObjectTranslator::translate(
         DtPortalLinearObject* dest, const DtLinearObjectRepository& src,
         const DtReflectedLinearObject& refObj )
      {
         // env. object attributes.
         dest->setObjectIdentifier( *disBroker()->entityIdMapper()
            ->convertDisEidToPortalEid(src.objectId()) );
         dest->setReferencedObjectId( disBroker()->entityIdMapper()
            ->convertDisEidToPortalEid(src.referencedObjectId())->string() );
         dest->setUpdateNumber( src.updateNumber() );
         dest->setForceId( src.forceId() );
         dest->setRequestorId( src.requesterSimId() );
         dest->setReceivingId( src.receivingSimId() );

         // env. object type.
         dest->setObjectType( src.objectType() );

         // linear segment data.
         int numSegments = src.numSegments();
         DtLinearSegmentRecord sourceSegment;
         DtLinearSegmentParameterList segments;
         DtLinearSegmentData destinationSegment;
         dest->setNumSegments( src.numSegments() );
         for ( int i = 0; i < numSegments; ++i )
         {
            src.segment( i, sourceSegment );
            translate( &destinationSegment, sourceSegment );
            segments.push_back( destinationSegment );
         }
         dest->setSegmentParameters( segments );

         return dest;
      }

      DtLinearSegmentData* DtLinearObjectTranslator::translate(
         DtLinearSegmentData* dest, const DtLinearSegmentRecord& src )
      {
         dest->setSegmentNumber( src.segmentNumber() );
         dest->setModifications( src.modifications() );
         dest->setSpecificAppearance( src.specificAppearance() );
         dest->setGeneralAppearance( src.generalAppearance() );
         dest->setLocation( src.location() );
         dest->setOrientation( src.orientation() );
         dest->setLength( src.length() );
         dest->setWidth( src.width() );
         dest->setHeight( src.height() );
         dest->setDepth( src.depth() );
         return dest;
      }

      DtLinearObjectRepository* DtLinearObjectTranslator::translate(
         DtLinearObjectRepository* dest, const DtPortalLinearObject& src,
         const DtPortalReflectedLinearObject& refObj )
      {
         // env. object attributes.
         dest->setObjectId( *disBroker()->entityIdMapper()
            ->convertPortalEidToDisEid(src.objectIdentifier()) );
         dest->setReferencedObjectId( *disBroker()->entityIdMapper()
            ->convertPortalEidToDisEid(DtEntityIdentifier(src.referencedObjectId())) );
         dest->setUpdateNumber( src.updateNumber() );
         dest->setForceId( (DtForceType) src.forceId() );
         dest->setRequesterSimId( src.requestorId() );
         dest->setReceivingSimId( src.receivingId() );

         // env. object type.
         dest->setObjectType( src.objectType() );

         // linear segment data.
         DtLinearSegmentRecord segment;
         int numSegments = src.numSegments();
         dest->setNumSegments( src.numSegments() );
         for ( int i = 0; i < numSegments; ++i )
         {
            translate( &segment, src.segmentParameters()[i] );
            dest->setSegment( i, segment );
         }

         return dest;
      }

      DtLinearSegmentRecord* DtLinearObjectTranslator::translate(
         DtLinearSegmentRecord* dest, const DtLinearSegmentData& src )
      {
         dest->setSegmentNumber( src.segmentNumber() );
         dest->setModifications( src.modifications() );
         dest->setSpecificAppearance( src.specificAppearance() );
         dest->setGeneralAppearance( src.generalAppearance() );
         dest->setLocation( src.location() );
         dest->setOrientation( src.orientation() );
         dest->setLength( src.length() );
         dest->setWidth( src.width() );
         dest->setHeight( src.height() );
         dest->setDepth( src.depth() );
         return dest;
      }

   }
}
