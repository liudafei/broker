/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file transferControlTranslator.h
//! \brief Contains the DtTransferControlTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/transferControlInteraction.h>
#include <portal/pTransferControlInteraction.h>

namespace MAKVrExchange
{

   class DtPortalTransferControlInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides TransferControl interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtTransferControlTranslator
         : public DtDisInteractionTranslator<DtPortalTransferControlInteraction,DtTransferControlInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Transfer Control" );

         //! \brief CTOR.
         DtTransferControlTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtTransferControlTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalTransferControlInteraction& inter );

         //! \brief Translates the transfer control interaction into the portal.
         virtual DtPortalTransferControlInteraction* translate(
            DtPortalTransferControlInteraction* destination,
            const DtTransferControlInteraction& source );

         //! \brief Translates the transfer control interaction from the portal.
         virtual DtTransferControlInteraction* translate( DtTransferControlInteraction* destination,
            const DtPortalTransferControlInteraction& source );

      };

   }
}
