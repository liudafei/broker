/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file dataQueryTranslator.h
//! \brief Contains the DtDataQueryTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/dataQueryInteraction.h>
#include <portal/pDataQueryInter.h>

namespace MAKVrExchange
{

   class DtPortalDataQueryInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides DataQuery interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDataQueryTranslator
         : public DtDisInteractionTranslator<DtPortalDataQueryInteraction,DtDataQueryInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Data Query" );

         //! \brief CTOR.
         DtDataQueryTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtDataQueryTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalDataQueryInteraction& inter );

         //! \brief Translates the data query interaction into the portal.
         virtual DtPortalDataQueryInteraction* translate(
            DtPortalDataQueryInteraction* destination,
            const DtDataQueryInteraction& source );

         //! \brief Translates the portal data query interaction from the portal.
         virtual DtDataQueryInteraction* translate( DtDataQueryInteraction* destination,
            const DtPortalDataQueryInteraction& source );

      };

   }
}
