/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file linearObjectTranslator.h
//! \brief Contains the DtLinearObjectTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/linearObjectPublisher.h>
#include <vl/reflectedLinearObjectList.h>

class DtReflectedLinearObject;
class DtLinearObjectRepository;

#define LINEAR_OBJECT_TEMPLATE_ARGS \
   DtPortalLinearObject, DtPortalReflectedLinearObject, \
   DtReflectedLinearObject, DtReflectedLinearObjectList, \
   DtLinearObjectRepository, DtLinearObjectPublisher

namespace MAKVrExchange
{

   class DtPortalLinearObject;

   namespace DtDisBroker
   {

      template <>
      DT_DLL_DISBROKER DtEntityIdentifier
         DtDisObjectTranslator<LINEAR_OBJECT_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedLinearObject* refObj, const DtString& identifier );

      template <>
      DT_DLL_DISBROKER DtObjectPublisher*
         DtDisObjectTranslator<LINEAR_OBJECT_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedLinearObject* refObj, const DtEntityIdentifier& name );


      //! \brief Provides Linear Object translation between DIS and the Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtLinearObjectTranslator
         : public DtDisObjectTranslator<LINEAR_OBJECT_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Linear Object" );

         //! \brief CTOR.
         DtLinearObjectTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtLinearObjectTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be published.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedLinearObject& refObj ) const;

         //! \brief Gets the reflected object's entity id for publisher creation.
         virtual DtString disObjectName( const DtPortalReflectedLinearObject* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const DtLinearObjectRepository& sr );

         //! \brief Construct the portal object name.
         //! Overridden to construct a point object name.
         virtual DtString portalObjectName( const DtReflectedLinearObject* refObj ) const;

         //! \brief Updates the broker object with the latest information.
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj,
            const DtPortalLinearObject& sr );

         // Translate from PDU to Portal.
         virtual DtPortalLinearObject* translate( DtPortalLinearObject* dest,
            const DtLinearObjectRepository& src, const DtReflectedLinearObject& refObj );

         // Translate segment data from PDU to Portal.
         DtLinearSegmentData* translate( DtLinearSegmentData* dest,
            const DtLinearSegmentRecord& src );

         // Translate from Portal to PDU.
         virtual DtLinearObjectRepository* translate( DtLinearObjectRepository* dest,
            const DtPortalLinearObject& src, const DtPortalReflectedLinearObject& refObj );

         // Translate segment data from Portal to PDU.
         DtLinearSegmentRecord* translate( DtLinearSegmentRecord* dest,
            const DtLinearSegmentData& src );

      };

   }
}
