/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file globalIdMapper.h
//! \brief Contains the DtGlobalIdMapper class declaration.
//! \ingroup disBroker

#pragma  once

#include <disBroker/dllExport.h>
#include <vlpi/entityIdentifier.h>
#include <vlutil/vlHashlist.h>
#include <vlutil/vlHashKeys.h>
#include <vlutil/vlString.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      class DtGlobalIdMapper;

      //! A Function pointer for a GlobalIdMapper creator function.
      typedef DtGlobalIdMapper* (*DtGlobalIdMapperCreator)();

      //! DtGlobalIdMapper is used by the DIS Broker to convert between Portal
      //! ObjectIds and DIS Entity IDs.
      //!
      //! In the portal, all objects have unique IDs which are strings. In DIS
      //! some Objects have non-unique EntityIDs, like Emitter Systems and
      //! Radios. These object types use the entity ID of the entity they are
      //! attached to, plus some other unique features, such as a Radio ID, or an
      //! Emitter System ID.
      //!
      //! For example, for DIS Entities, the unique key is just the DtEntityIdentifier,
      //! but for DIS Radios the unique key is composed of (Host Entity Identifier, RadioId).
      //! Because of this, the Global ID mapper requires DIS IDs to be composed of
      //! the DtEntityIdentifier, EntityType, SystemId, and the BeamId, all of which can be
      //! null. Use the enumerations provided to build up unique DIS keys. For example,
      //! a unique DIS key could be "1:2:3";ObjectType = EntityType;SystemId=NoSystemId;
      //! BeamId=NoBeamId;
      class DT_DLL_DISBROKER DtGlobalIdMapper
      {
      public:

         //! A typedef to make it easier to see what kid of ID this is. In DIS all
         //! objects have (as a minimum) a DtEntityIdentifier. Users should note that
         //! for some object types the DtEntityIdentifier is not sufficient to produce
         //! a unique ID. VR-Link further types this to DtGlobalObjectIdentifier to
         //! produce a protocol independent API.
         typedef DtEntityIdentifier DisId;

         //! A typedef to make it easier to see what kind of ID this is. All objects
         //! in the Portal are identified with a unique string.
         typedef DtString PortalId;

         //! This is an emitter number which represents NO emitter. If the systemId
         //! is set to NoSystemId, it means this entity is not an Emitter system.
         enum { NoSystemId = -1 };
         enum { NoBeamId = -1 };

         typedef enum {
            NoType = -1,
            EntityType = 0,
            EmitterSystemType = 1,
            RadioTransmitterType = 2,
            RadioReceiverType = 3,
            EmitterBeamType = 4,
            EnvironmentProcess = 5,
            GridData = 6,
            ActiveSonarType = 7,
            AdditionalPassiveActivitesType = 8,
            PropulsionNoiseType = 9,
            DesignatorType = 10,
            IffType = 11
         } ObjectType;

         //! Default Constructor
         DtGlobalIdMapper();

         //! Default Destructor
         virtual ~DtGlobalIdMapper();

         //! Adds a map to this ID, returns true when the map was added
         //! successfully. Returns false if one of the IDs already existed.
         virtual bool add( const PortalId& portal_name, const DisId& dis_name,
            ObjectType oType = EntityType, int systemId = NoSystemId,
            int beamId = NoBeamId );

         //! Removes the Portal/DIS ID pair identified by the Portal ID portal_name.
         //! This removes the complete mapping, so the user only needs to delete
         //! one member of the pair to get both members.
         virtual void remove( const PortalId& portal_name );

         //! Removed the Portal/DIS ID pair identified by the DIS ID.
         //! This removes the complete mapping, so the user only needs to delete
         //! one member of the pair to get both members.
         virtual void remove( const DisId& dis_name, ObjectType otype = EntityType,
            int systemId = NoSystemId, int beamId = NoBeamId );

         //! This is the compliment to add, it does the work of the previous two
         //! functions.
         virtual void remove( const PortalId& portal_name, const DisId& dis_name,
            ObjectType otype = EntityType, int systemId = NoSystemId,
            int beamId = NoBeamId );

         //! For a DIS or Portal ID it will return the corresponding Name (if
         //! you pass DIS you get an Portal name back). We get NULL if there is
         //! no registered name
         virtual const PortalId& convertDisGidToPortalGid( const DisId& dis_name,
            ObjectType = EntityType, int systemId = NoSystemId, int beamId = NoBeamId );

         //! if disNum is not null and if the Portal object is a non EntityType, both
         //! the type and the system ID will be set if passed a non null value
         virtual const DisId& convertPortalGidToDisGid( const PortalId& portal_name,
            ObjectType* otype = 0, int* systemId = 0, int* beamId = 0 );

         //! Returns true if there is no known object with the same ID.
         virtual bool unique( const PortalId& portal_name ) const;

         //! Returns true if there is no known object with the same ID.
         virtual bool unique( const DisId& dis_name, ObjectType oType = EntityType,
            int systemId = NoSystemId, int beamId = NoBeamId ) const;

         //! turns on debugging for this class. This is useful if the user
         //! suspects something is not being mapped right. When set to true
         //! every add, remove and map will be sent to DtInfo
         virtual void setDebug( bool debugOn );

         //! Returns the parameter of the last setDebug call.
         virtual bool debug () const;

         //! When set to true, if a map can't be found for a Portal ID,
         //! the class will try to parse an ID out of it. For example,
         //! an unmapped id of "1:3:23" will parse out the DIS ID 1:3:23.
         virtual void setParseUnknownIds(bool parseOn);

         //! See setparseUnknownIds.
         virtual bool parseUnknownIds() const;

      protected:

         //! Utility function to create Poral ID from DIS ID
         const PortalId& parseAndCreatePortalId( const DisId& disName, const DtStringHashKey& disKey,
            ObjectType oType = EntityType, int systemId = NoSystemId, int beamId = NoBeamId );

         //! Utility function to create DIS ID from Poral ID (if Poral ID --> "x:y:z...")
         const DisId& parseAndCreateDisId( const PortalId& portalName, const DtStringHashKey& portalKey,
            ObjectType* oType = 0, int* systemId = 0, int* beamId = 0 );

         virtual bool addUnknownIds( const PortalId& portal_name, const DisId& dis_name,
            ObjectType oType = EntityType, int systemId = NoSystemId, int beamId = NoBeamId );

         DtStringHashKey createDisKey( const DisId& dis_name,
            ObjectType oType, int systemId, int beamId ) const;

      protected:

         bool myDebugOutputOn;
         bool myParseUnknownIds;

         //! a list of Portal ID's hashed by DIS ID's
         DtHashlist *myPortalIdHashList;

         //! a List of DIS ID's hashed by Portal ID's
         DtHashlist *myDisIdHashList;

         //! We need the same type of hash lists for global ID's
         DtHashlist *myUnknownPortalIdHashList;
         DtHashlist *myUnknownDisIdHashList;

         const PortalId myEmptyPortalId;
         const DisId myEmptyDisId;

      };


      //! A simple helper class for DtGlobalIdMapper.
      class DT_DLL_DISBROKER DtDisGlobalIdContainer
      {
      public:

         DtDisGlobalIdContainer(const DtGlobalIdMapper::DisId& gid,
            DtGlobalIdMapper::ObjectType oType = DtGlobalIdMapper::EntityType,
            int sysId= DtGlobalIdMapper::NoSystemId,
            int beamId = DtGlobalIdMapper::NoBeamId);

         ~DtDisGlobalIdContainer();
         int systemId() const;
         int beamId() const;

         DtGlobalIdMapper::ObjectType objectType() const;
         const DtGlobalIdMapper::DisId *gid() const ;

      protected:

         int mySystemId;
         int myBeamId;
         DtGlobalIdMapper::ObjectType myType;
         DtGlobalIdMapper::DisId *myGid;

      };

      DT_DLL_DISBROKER std::ostream& operator << (std::ostream& os, const DtGlobalIdMapper::ObjectType &ut);

   }
}
