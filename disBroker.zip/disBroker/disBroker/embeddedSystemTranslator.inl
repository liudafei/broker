/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file embeddedSystemTranslator.inl
//! \brief Contains the DtEmbeddedSystemTranslator class definition.
//! \ingroup disBroker

#ifndef _embeddedSystemTranslator_INL_
#error "Inline definitions file must be included from declaring header."
#endif

#include <disBroker/embeddedSystemTranslator.h>
#include <vl/embeddedSystemRepository.h>
#include <portal/pEmbeddedSystem.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DIS_TEMPLATE_LIST
      DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::DtEmbeddedSystemTranslator(
            DtBroker* broker, const DtString& name, DtPortalMessageKind kind )
         : DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>( broker, name, kind )
      {
      }

      DIS_TEMPLATE_LIST
      DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::~DtEmbeddedSystemTranslator()
      {
      }

      DIS_TEMPLATE_LIST
      DtString DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::disObjectName(
         const T_PortalReflectedObject* refObj ) const
      {
         return refObj->sr()->hostObjectIdentifier();
      }

      DIS_TEMPLATE_LIST
      void DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::updateDisBrokerObject(
         DtBrokerObject* brokerObj, const T_DisObjectStateRepository& sr )
      {
         DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::updateDisBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.entityId().string() );
      }

      DIS_TEMPLATE_LIST
      void DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::updatePortalBrokerObject(
         DtBrokerObject* brokerObj, const T_PortalObject& sr )
      {
         DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::updatePortalBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.entityIdentifier().string() );
      }

      DIS_TEMPLATE_LIST
      DtPortalEmbeddedSystem* DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::translate(
         DtPortalEmbeddedSystem* destination, const DtEmbeddedSystemRepository& source,
         const T_DisReflectedObject& refObj )
      {
         destination->setEntityIdentifier( source.entityId().string() );
         destination->setRelativePosition( source.relativePosition() );

         destination->setHostObjectIdentifier( this->disBroker()->globalIdMapper()
            ->convertDisGidToPortalGid(source.hostId()) );

         return destination;
      }

      DIS_TEMPLATE_LIST
      DtEmbeddedSystemRepository* DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>::translate(
         DtEmbeddedSystemRepository* destination, const DtPortalEmbeddedSystem& source,
         const T_PortalReflectedObject& refObj )
      {
         // Entity ID is set on publisher instantiation.
         destination->setRelativePosition( source.relativePosition() );

         DtGlobalIdMapper::DisId hostId = this->disBroker()->globalIdMapper()
            ->convertPortalGidToDisGid( source.hostObjectIdentifier() );
         if ( hostId == DtEntityIdentifier::nullId() )
         {
            hostId = *this->disBroker()->entityIdMapper()
               ->convertPortalEidToDisEid( source.entityIdentifier() );
         }
         destination->setHostId( hostId );

         return destination;
      }

   }
}
