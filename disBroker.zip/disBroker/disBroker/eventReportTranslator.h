/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file eventReportTranslator.h
//! \brief Contains the DtEventReportTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pEventReportInter.h>
#include <vl/eventReportInteraction.h>

namespace MAKVrExchange
{

   class DtPortalEventReportInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides Event Report interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtEventReportTranslator
         : public DtDisInteractionTranslator<DtPortalEventReportInteraction,DtEventReportInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Event Report" );

         //! \brief CTOR.
         DtEventReportTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtEventReportTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalEventReportInteraction& inter );

         //! \brief Translates the event report interaction into the portal.
         virtual DtPortalEventReportInteraction* translate(
            DtPortalEventReportInteraction* destination,
            const DtEventReportInteraction& source );

         //! \brief Translates the event report interaction from the portal.
         virtual DtEventReportInteraction* translate(
            DtEventReportInteraction* destination,
            const DtPortalEventReportInteraction& source );

      };

   }
}
