/*****************************************************************************
 * Copyright (c) 2013 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file entityIdMapper.h
//! \brief Contains the DtEntityIdMapper class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/dllExport.h>
#include <vlutil/vlMachineTypes.h>
#include <vlutil/vlFilename.h>
#include <map>

class DtEntityIdentifier;
class DtHashlist;
class DtString;

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //! DtEntityIdMapper is used to map the portal entityID attribute to a DIS entity.
      //! Portal objects have two forms of identification:
      //! a global identifier (which is mapped using the globalIdMapper), and EntityID
      //! which is a triplet similar to the DIS entityID. This Class maps the portal
      //! entityID's to a disEntityId.
      //! \ingroup disBroker
      //! \brief
      class DT_DLL_DISBROKER DtEntityIdMapper
      {
      public:

         DtEntityIdMapper( int siteNum, int appNum );

         virtual ~DtEntityIdMapper();

         //! One of these will be an ID which we are publishing, the other
         //! will be the real ID behind the portal. when someone gives us
         //! an entity ID which we are publishing we need to convert it
         //! back to the original.
         virtual bool add(const DtEntityIdentifier &portalId,
            const DtEntityIdentifier &disId);

         //! remove one. Only need to choose one, the other will get destroyed
         //! at the same time.
         virtual void removePortalId(const DtEntityIdentifier &portalId);
         virtual void removeDisId(const DtEntityIdentifier &disId);

         //! This is the compliment to add, it does the work of the previous two
         //! functions.
         virtual void remove(const DtEntityIdentifier &portalId,
            const DtEntityIdentifier &disId);

         //! For a DIS or Portal ID it will return the corresponding Name (if
         //! you pass DIS you get an Portal name back. We get NULL if there is
         //! no registered name
         virtual const DtEntityIdentifier *convertDisEidToPortalEid(
            const DtEntityIdentifier &disId);
         virtual const DtEntityIdentifier *convertPortalEidToDisEid(
            const DtEntityIdentifier &portalId);


         virtual DtEntityIdentifier getNextDisId();
         virtual DtEntityIdentifier getNextPortalId();

         //! \brief get a persistent ID value if using the persistent ID field
         //! \return 0,0,0 it cannot find a valid name
         virtual DtEntityIdentifier getPersistentId(const DtString& name);

         //! \brief sets the persistent ID of a name. This will be saved on exit
         virtual void setPersistentId(const DtString& name, const DtEntityIdentifier& id);

         virtual void setDebug(bool debugOn);
         virtual bool debug() const;

         virtual bool portalHasMapping(const DtEntityIdentifier& portalId) const;
         virtual bool disHasMapping(const DtEntityIdentifier& disId) const;

         //Persistent Functions
         virtual void loadPersistentNumMappingFile();
         virtual void savePersistentNumMappingFile();

      protected:

         //! Test if this ID was one we created, if so, return true.
         virtual bool publishingPortal(const DtEntityIdentifier &portalId) const;
         virtual bool publishingDis(const DtEntityIdentifier &disId) const;

      private:

         // Copy Constructor not implemented -- do not copy!
         DtEntityIdMapper( const DtEntityIdMapper& orig );

         // Assignment Operator not implemented -- do not copy!
         DtEntityIdMapper& operator = ( const DtEntityIdMapper& orig );

      protected:

         bool myDebugOutputOn;
         int myAppNum;
         int mySiteNum;
         int myNextEnt;

         typedef std::map<DtEntityIdentifier, DtEntityIdentifier*> DtEntityIdMap;

         //! a list of Portal GlobalId's hashed by DIS ID's
         DtEntityIdMap myPortalIdHashList;

         //! a List of DIS GlobalId's hashed by Portal Id's
         DtEntityIdMap myDisIdHashList;

         const DtEntityIdentifier *myEmptyPortalId;
         const DtEntityIdentifier *myEmptyDisId;

         //Used for Persisting entity Ids.
         std::map<DtString,DtEntityIdentifier> myPersistNameToEntityNum;

      };

      inline void DtEntityIdMapper::setDebug(bool debugOn)
      {
         myDebugOutputOn = debugOn;
      }

      inline bool DtEntityIdMapper::debug() const
      {
         return myDebugOutputOn;
      }

   }
}
