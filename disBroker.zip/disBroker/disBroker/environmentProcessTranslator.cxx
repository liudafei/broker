/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file environmentProcessTranslator.cxx
//! \brief Contains the DtEnvironmentProcessTranslator class definition.
//! \ingroup disBroker

#include <disBroker/environmentProcessTranslator.h>
#include <disBroker/disBrokerInitializer.h>
#include <vl/packets/envProcP.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtEnvironmentProcessTranslator::DtEnvironmentProcessTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, "Environment Process", DtPortalEnvironmentProcessObject::theKind )
      {
      }

      DtEnvironmentProcessTranslator::~DtEnvironmentProcessTranslator()
      {
      }

      void DtEnvironmentProcessTranslator::updateDisBrokerObject( DtBrokerObject* brokerObj,
         const DtEnvironmentProcessRepository& sr )
      {
         ParentClass::updateDisBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.environmentalProcessID().string() );
      }

      DtString DtEnvironmentProcessTranslator::portalObjectName(
         const DtReflectedEnvironmentProcess* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "Vvrx";
      }

      void DtEnvironmentProcessTranslator::updatePortalBrokerObject(
         DtBrokerObject* brokerObj, const DtPortalEnvironmentProcessObject& sr )
      {
         ParentClass::updatePortalBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.processIdentifier().string() );
      }

      bool DtEnvironmentProcessTranslator::performPortalGlobalIdMapping(
         const DtPortalEnvironmentProcessObjectPublisher* publisher,
         const DtReflectedEnvironmentProcess& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performPortalGlobalIdMapping( publisher,
            refObj, DtGlobalIdMapper::EnvironmentProcess, systemId, beamId );
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<ENV_PROC_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedEnvironmentProcessObject* refObj,
         const DtString& identifier )
      {
         return mapObjectId( DtEntityIdentifier(identifier) );
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<ENV_PROC_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedEnvironmentProcessObject* refObj,
         const DtEntityIdentifier& objectName )
      {
         DtEnvironmentProcessPublisher* publisher = NULL;
         try
         {
            publisher = new DtEnvironmentProcessPublisher( disBroker()->connection(), objectName );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      DtString DtEnvironmentProcessTranslator::disObjectName(
         const DtPortalReflectedEnvironmentProcessObject* refObj ) const
      {
         return refObj->sr()->processIdentifier().string();
      }

      bool DtEnvironmentProcessTranslator::performDisGlobalIdMapping(
         const DtObjectPublisher* publisher, const DtPortalReflectedEnvironmentProcessObject& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performDisGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::EnvironmentProcess, systemId, beamId );
      }

      bool DtEnvironmentProcessTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedEnvironmentProcessObject* refObj )
      {
         if ( disBroker()->disInitializer()->discoveryCriteria()->environmentProcessNeedsProcessId()
            && refObj->sr()->processIdentifier() == DtEntityIdentifier() )
         {
            DtInfo << "DtEnvironmentProcessTranslator: " << brokerObj->objectName()
               << ": Process Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Environment Process ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      DtPortalEnvironmentProcessObject* DtEnvironmentProcessTranslator::translate(
         DtPortalEnvironmentProcessObject* destination,
         const DtEnvironmentProcessRepository& source,
         const DtReflectedEnvironmentProcess& refObj )
      {
         destination->setProcessIdentifier( *disBroker()->entityIdMapper()->convertDisEidToPortalEid( source.environmentalProcessID() ) );
         destination->setType( source.environmentType() );
         destination->setModelType( source.modelType() );
         destination->setEnvironmentalStatus( source.environmentalStatus() );
         destination->setSequenceNumber( source.sequenceNumber() );

         // Get the incoming version of the PDU.
         int pduVersion = source.protocolVersion();

         destination->environmentRecData().clear();
         int numberOfRecords = source.numberOfEnvironmentalRecords();
         for ( size_t index = 0; index < numberOfRecords; ++index )
         {
            const DtNetEnvironmentalRecord* record = source.recordPointer( index );

            // Get the size from the record and add the header in (if not DIS 7).
            int totalSizeBytes = (int) ceil( record->myLength / 8.0 );
            int headerSizeBytes = sizeof(DtNetEnvironmentalRecord);
            if ( pduVersion < 7 )
            {
               // Add the header to the length to get the total size.
               totalSizeBytes += headerSizeBytes;

               // Store the record in the portal object.
               destination->environmentRecData().push_back( std::make_pair( (unsigned int)
                  index, DtVariableLengthData((const char*)record,totalSizeBytes) ) );
            }
            else
            {
               // Create a temporary copy of the record for modifying.
               char* newRecord = new char[totalSizeBytes];
               memcpy( newRecord, record, totalSizeBytes );

               // Set the length in DIS 6 / RPR format (no header, bits).
               ((DtNetEnvironmentalRecord*)newRecord)->myLength =
                  8*( totalSizeBytes - headerSizeBytes );

               // Store the modified record in the portal object.
               destination->environmentRecData().push_back( std::make_pair( (unsigned int)
                  index, DtVariableLengthData((const char*)newRecord,totalSizeBytes) ) );

               // Delete the modified record.
               delete newRecord;
            }
         }

         return destination;
      }

      DtEnvironmentProcessRepository* DtEnvironmentProcessTranslator::translate(
         DtEnvironmentProcessRepository* destination,
         const DtPortalEnvironmentProcessObject& source,
         const DtPortalReflectedEnvironmentProcessObject& refObj )
      {
         destination->setEnvironmentalProcessID( *disBroker()->entityIdMapper()->convertPortalEidToDisEid( source.processIdentifier() ) );
         destination->setEnvironmentType( DtNetEntityType(source.type()) );
         destination->setModelType( (DtEnvironmentalModelType) source.modelType() );
         destination->setEnvironmentalStatus( source.environmentalStatus() );
         destination->setSequenceNumber( source.sequenceNumber() );

         int numberOfRecords = source.environmentRecData().size();
         destination->setNumberOfEnvironmentalRecords( numberOfRecords );
         DtAttributeValuePairList::const_iterator pos = source.environmentRecData().begin();
         DtAttributeValuePairList::const_iterator end = source.environmentRecData().end();
         for ( ; pos != end; ++pos )
         {
            // Get the index and make sure it's valid.
            long index = strtol( pos->first, 0, 10 );
            if ( index >= 0 && index < numberOfRecords )
            {
               const DtNetEnvironmentalRecord& sourceRecord =
                  (const DtNetEnvironmentalRecord&) *pos->second.data();

               // Set the record size.
               // Workaround for VRL OTD #58808.
               // TODO Revert this workaround when VRL OTD #58808 is fixed.
               // Factor in whether the record is expecting the header to be included in the size.
               // Portal record length will always not include the header length.
               int recordLength = sourceRecord.myLength;
               if ( DtEnvironmentalProcessPdu::lengthIsWholeEnvRec() || DtProtocolVersionToSend >= 7 )
               {
                  // Record length is in bits, multiply byte count by 8.
                  recordLength += 8*sizeof(DtNetEnvironmentalRecord);
               }
               destination->setRecordBitSize( index, recordLength );

               // Set the type and index into the record header.
               // Do this instead of copying the header over as well to avoid length errors.
               DtNetEnvironmentalRecord* destinationRecord = destination->recordPointer( index );
               destinationRecord->myIndex = sourceRecord.myIndex;
               destinationRecord->myType = sourceRecord.myType;

               // Determine the size of the record to be copied.
               // If using DIS 7 encoding, subtract the header from the length (header is initialized above).
               int byteCount = (int) ceil( destinationRecord->myLength / 8.0 );
               if ( DtEnvironmentalProcessPdu::lengthIsWholeEnvRec() || DtProtocolVersionToSend >= 7 )
               {
                  // Record length is in bits, multiply byte count by 8.
                  byteCount -= sizeof(DtNetEnvironmentalRecord);
               }
               memcpy( ((char*)destinationRecord) + 8, ((char*)&sourceRecord) + 8, byteCount );
            }
            else
            {
               DtWarn << "Unable to decode environmental record with index: " << index << std::endl;
               DtWarn << "   Environment process should only contain "
                  << numberOfRecords << " records." << std::endl;
            }
         }

         return destination;
      }

   }
}
