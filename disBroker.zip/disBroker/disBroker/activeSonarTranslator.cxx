/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file activeSonarTranslator.cxx
//! \brief Contains the DtActiveSonarTranslator class definition.
//! \ingroup disBroker

#include <disBroker/activeSonarTranslator.h>
#include <disBroker/disBrokerInitializer.h>
#include <disBroker/eventIdMapper.h>

#include <vl/underwaterAcousticsPublisher.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtActiveSonarTranslator::DtActiveSonarTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalActiveSonar::theKind )
      {
      }

      DtActiveSonarTranslator::~DtActiveSonarTranslator()
      {
      }

      DtObjectPublisher* DtActiveSonarTranslator::instantiateDisPublisher(
         const DtPortalReflectedActiveSonar* refObj, const DtEntityIdentifier& objectId )
      {
         DtObjectPublisher* objectPublisher = NULL;
         if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
         {
            objectPublisher = new DtActiveSonarPublisher(
               disBroker()->connection(), objectId );
         }
         else
         {
            DtUnderwaterAcousticsPublisherManager* mgr =
               disBroker()->underwaterAcousticsPublisherManager();
            DtString hostId = refObj->sr()->hostObjectIdentifier();
            DtUnderwaterAcousticsPublisher* publisher =
               mgr->findPublisher( hostId );
            if ( ! publisher )
            {
               publisher = new DtUnderwaterAcousticsPublisher(
                  disBroker()->connection(), objectId );
               mgr->registerPublisher( hostId, publisher );
            }
            mgr->checkoutPublisher( publisher );
            objectPublisher = publisher;
         }
         return objectPublisher;
      }

      void DtActiveSonarTranslator::createDisPublisher( DtBrokerObject* brokerObj )
      {
         try
         {
            // Get the reflected object and make sure it exists.
            const DtPortalReflectedActiveSonar* refObj =
               static_cast<const DtPortalReflectedActiveSonar*>( brokerObj->reflectedObjPtr() );
            assert( refObj );

            // Instantiate the publisher.
            DtString objectName = disObjectName( refObj );
            DtGlobalIdMapper::DisId newId = mapIdentifier( refObj, objectName );

            // Workaround for OTD #58282:
            // Null and Default IDs should be treated the same during publisher instantiation.
            newId = ( newId == DtEntityIdentifier::nullId() ? DtEntityIdentifier::defaultId() : newId );

            DtObjectPublisher* publisher = instantiateDisPublisher( refObj, newId );

            // Abort if no publisher was instantiated.
            if ( publisher == NULL )
            {
               brokerObj->setDropReason( "Publisher instantiation failed" );
               DtWarn << name() << " Translator dropping object: " <<
                  refObj->sr()->identifier().c_str() << std::endl;
               brokerObj->setPublisherPtr( NULL );
               brokerObj->setIsDropped( true );
               return;
            }

            // Set up the global ID Mapping
            if ( ! performDisGlobalIdMapping(publisher,*refObj,
               DtGlobalIdMapper::ActiveSonarType,refObj->sr()->acousticsIdentifier()) )
            {
               // Object dropped, publisher no longer needed and will be deleted with the release.
               DtUnderwaterAcousticsPublisherManager* mgr = disBroker()->underwaterAcousticsPublisherManager();
               mgr->releasePublisher( refObj->sr()->hostObjectIdentifier() );

               // Note that the object is being dropped in the log file.
               DtWarn << this->name() << " translator dropping object: " << refObj->sr()->identifier() << std::endl;

               // Abort if the name is invalid and destroy the publisher.
               brokerObj->setDropReason( "Name collision" );
               brokerObj->setPublisherPtr( NULL );
               brokerObj->setIsDropped( true );
               return;
            }

            brokerObj->setPublisherPtr( publisher );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      DtString DtActiveSonarTranslator::portalObjectName(
         const DtReflectedActiveSonar* refObj ) const
      {
         DtString newEntityName = DtString(refObj->globalId().string());
         newEntityName += "-";
         newEntityName += refObj->asr()->acousticsIdentifier();
         newEntityName += "ASvrx";
         return newEntityName;
      }

      bool DtActiveSonarTranslator::performPortalGlobalIdMapping(
         const DtPortalActiveSonarPublisher* publisher, const DtReflectedActiveSonar& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performPortalGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::ActiveSonarType, refObj.asr()->acousticsIdentifier() );
      }

      void DtActiveSonarTranslator::receivePortalUpdate(
         const DtPortalReflectedActiveSonar& object )
      {
         try
         {
            DtBrokerObject* brokerObject = findBrokerObject( &object );
            if ( ! brokerObject )
            {
               DtWarn << "Received update call for deleted portal emitter system: "
                  << object.sr()->hostObjectIdentifier() << std::endl;
               return;
            }
            assert( brokerObject );

            const DtPortalActiveSonar& portalActiveSonar = *(object.sr());

            updatePortalBrokerObject( brokerObject, portalActiveSonar );

            callObjectUpdateCallbacks( brokerObject );

            // Abort if the object has been dropped.
            if ( brokerObject->isDropped() )
            {
               return;
            }

            // Get the state rep from the publisher.
            DtObjectPublisher* objectPublisher = NULL;
            DtActiveSonarStateRepository* disActiveSonar = NULL;
            if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
            {
               DtActiveSonarPublisher* publisher =
                  static_cast<DtActiveSonarPublisher*>( brokerObject->publisherPtr() );
               assert( publisher );

               disActiveSonar = publisher->asr();
               objectPublisher = publisher;
            }
            else
            {
               DtUnderwaterAcousticsPublisher* publisher =
                  static_cast<DtUnderwaterAcousticsPublisher*>( brokerObject->publisherPtr() );
               assert( publisher );

               DtSonarSysRetCode retcode;
               disActiveSonar = publisher->usr()->activeSonarSRById(
                  portalActiveSonar.acousticsIdentifier(), &retcode );
               if ( retcode != DtSonarSuccess )
               {
                  disActiveSonar = publisher->usr()->addActiveSonar(
                     portalActiveSonar.acousticsIdentifier() );
               }
               objectPublisher = publisher;
            }

            translate( disActiveSonar, portalActiveSonar, object );

            if ( myBroker->brokerInitializer()->oneToOneMapping() )
            {
               objectPublisher->forceUpdate();
            }

            if ( myBroker->isTranslatorDebuggingOn(name()) )
            {
               printIncomingOutgoingStateReps( portalActiveSonar, *disActiveSonar );
            }

            if ( isPublishEnabled() )
            {
               objectPublisher->tick();
            }

            performPortalDebugging( portalActiveSonar, *disActiveSonar );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      bool DtActiveSonarTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedActiveSonar* refObj )
      {
         DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->underwaterAcousticsNeedsAcousticId()
            && refObj->sr()->acousticsIdentifier() == 0 )
         {
            DtInfo << "DtActiveSonarTranslator: " << brokerObj->objectName()
               << ": Acoustic Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Acoustic ID" );
            return false;
         }
         if ( discoveryCriteria->underwaterAcousticsNeedsEntityId() )
         {
            int index = refObj->sr()->acousticsIdentifier();
            DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::ActiveSonarType;
            DtEntityIdentifier newId = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
               refObj->sr()->identifier(), &objType, &index );
            if ( newId == DtEntityIdentifier::nullId() )
            {
               newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
                  refObj->sr()->entityIdentifier() );
            }
            if ( newId == DtEntityIdentifier::nullId() )
            {
               DtInfo << "DtActiveSonarTranslator: " << brokerObj->objectName()
                  << ": Entity Id not present, object incomplete" << std::endl;
               brokerObj->setDropReason( "Missing Entity ID" );
               return false;
            }
         }
         if ( discoveryCriteria->underwaterAcousticsNeedsHostId()
            && refObj->sr()->hostObjectIdentifier().isEmpty() )
         {
            DtInfo << "DtActiveSonarTranslator: " << brokerObj->objectName()
               << ": Host Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Host ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      void DtActiveSonarTranslator::deleteDisPublisher( DtBrokerObject* brokerObject )
      {
         DtObjectPublisher* publisher =
            static_cast<DtObjectPublisher*>( brokerObject->publisherPtr() );
         const DtPortalReflectedActiveSonar* reflectedObj =
            static_cast<const DtPortalReflectedActiveSonar*>( brokerObject->reflectedObjPtr() );
         if ( ! disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
         {
            DtUnderwaterAcousticsPublisherManager* mgr =
               disBroker()->underwaterAcousticsPublisherManager();
            mgr->releasePublisher( reflectedObj->sr()->hostObjectIdentifier() );
         }

         if ( publisher && reflectedObj )
         {
            DtU32 acousticsIdentifier = reflectedObj->sr()->acousticsIdentifier();
            disBroker()->globalIdMapper()->remove( reflectedObj->sr()->entityIdentifier(),
               DtGlobalIdMapper::ActiveSonarType, acousticsIdentifier );
            brokerObject->setPublisherPtr( 0 );
            if ( disBroker()->disInitializer()->splitUnderwaterAcousticPdus() )
            {
               DtDELETE( publisher );
            }
         }
      }

      DtPortalActiveSonar* DtActiveSonarTranslator::translate( DtPortalActiveSonar* destination,
         const DtActiveSonarStateRepository& source, const DtReflectedActiveSonar& refObj )
      {
         // Translate underwater acoustics attributes.
         ParentClass::translate( destination, source, refObj );

         // Active Sonar Attribute Translation.
         destination->setAcousticName( source.acousticName() );
         destination->setFunctionCode( source.functionCode() );
         destination->setAcousticsIdentifier( source.acousticsIdentifier() );

         // Remove all active sonar beams.
         // Removing and re-adding may not be the most efficient.
         // We can come back and optimize this later.
         destination->activeSonarBeamList().clear();

         // Translate active sonar beams into the destination list.
         DtListItem* beamItem = source.beamList()->first();
         DtActiveSonarBeamRepository* sourceBeam = NULL;
         while ( beamItem )
         {
            sourceBeam = static_cast<DtActiveSonarBeamRepository*>( beamItem->data() );

            // If the beam doesnt exist, add it.
            DtActiveSonarBeamData* destinationBeam =
               destination->findBeam( sourceBeam->beamIdentifier() );
            DtActiveSonarBeamList& activeSonarBeamList =
               destination->activeSonarBeamList();
            if ( ! destinationBeam )
            {
               DtActiveSonarBeamData newBeam;
               newBeam.setActiveSonarIdentifier( destination->identifier() );
               newBeam.setEventIdentifier( destination->eventIdentifier() );
               DtActiveSonarBeamList::iterator itr = activeSonarBeamList.insert(
                  activeSonarBeamList.end(), newBeam );
               destinationBeam = &( *itr );
            }

            translate( destinationBeam, *sourceBeam );

            beamItem = beamItem->next();
         }

         return destination;
      }

      DtActiveSonarStateRepository* DtActiveSonarTranslator::translate(
         DtActiveSonarStateRepository* destination, const DtPortalActiveSonar& source,
         const DtPortalReflectedActiveSonar& refObj )
      {
         // Translate underwater acoustics attributes.
         ParentClass::translate( destination, source, refObj );

         // Active Sonar Attribute Translation.
         destination->setAcousticName( (DtUnderwaterAcousticSystemName) source.acousticName() );
         destination->setFunctionCode( (DtUnderwaterAcousticFunction) source.functionCode() );
         destination->setAcousticsIdentifier( source.acousticsIdentifier() );

         // Remove all beams from the destination not found within the source
         DtListItem* beamItem = destination->beamList()->first();
         DtActiveSonarBeamRepository* destinationBeam = NULL;
         while ( beamItem )
         {
            DtActiveSonarBeamRepository* destinationBeam =
               static_cast<DtActiveSonarBeamRepository*>( beamItem->data() );
            beamItem = beamItem->next(); // must update beamItem before a potential removeBeam
            if ( ! source.isBeamWithinList(destinationBeam->beamIdentifier()) )
            {
               destination->removeBeam( destinationBeam->beamIdentifier() );
            }
         }

         // Iterate over all incoming beams and translate them into the destination.
         const DtActiveSonarBeamList& sourceBeams = source.activeSonarBeamList();
         DtActiveSonarBeamList::const_iterator itr = sourceBeams.begin();
         DtActiveSonarBeamList::const_iterator end = sourceBeams.end();
         for ( ; itr != end; ++itr )
         {
            // If the beam doesn't exist, add it.
            DtU8 index = itr->beamIdentifier();
            destinationBeam = destination->beamSRById( index, NULL );
            if ( ! destinationBeam )
            {
               DtSonarBeamRetCode retCode = DtSonarBeamSuccess;
               destinationBeam = destination->addBeam( index, &retCode );
               if ( (retCode != DtSonarBeamSuccess) && (retCode != DtDuplicateSonarBeamId) )
               {
                  destinationBeam = NULL;
                  DtWarn << "Couldn't add a new Active Sonar Beam with index="
                     << index << std::endl;
               }
               else
               {
                  destinationBeam->setEventIdentifier( destination->eventIdentifier() );
               }
            }

            if ( destinationBeam )
            {
               translate( destinationBeam, *itr );

               destinationBeam->setActiveSonarIdentifier( destination->acousticsIdentifier() );
               if ( destinationBeam->eventIdentifier() == DtEventId() )
               {
                  destinationBeam->setEventIdentifier( destination->eventIdentifier() );
               }
            }
         }

         return destination;
      }

      DtActiveSonarBeamData* DtActiveSonarTranslator::translate(
         DtActiveSonarBeamData* destination, const DtActiveSonarBeamRepository& source )
      {
         destination->setActiveEmissionParameterIndex( source.activeEmissionParameterIndex() );
         destination->setActiveSonarIdentifier( source.activeSonarIdentifier() );
         destination->setAzimuthBeamwidth( source.azimuthBeamwidth() );
         destination->setAzimuthCenter( source.azimuthCenter() );
         destination->setBeamIdentifier( source.beamIdentifier() );
         destination->setElevationBeamwidth( source.elevationBeamwidth() );
         destination->setElevationCenter( source.elevationCenter() );
         destination->setEventIdentifier( source.eventIdentifier().string() );
         destination->setScanPattern( source.scanPattern() );
         return destination;
      }

      DtActiveSonarBeamRepository* DtActiveSonarTranslator::translate(
         DtActiveSonarBeamRepository* destination, const DtActiveSonarBeamData& source )
      {
         destination->setActiveEmissionParameterIndex(
            (DtUnderwaterAcousticActiveEmissionParmIndex) source.activeEmissionParameterIndex() );

         bool isInt;
         int activeSonarId = source.activeSonarIdentifier().toInt( &isInt );
         if ( isInt )
         {
            destination->setActiveSonarIdentifier( activeSonarId );
         }

         destination->setAzimuthBeamwidth( source.azimuthBeamwidth() );
         destination->setAzimuthCenter( source.azimuthCenter() );
         destination->setBeamIdentifier( source.beamIdentifier() );
         destination->setElevationBeamwidth( source.elevationBeamwidth() );
         destination->setElevationCenter( source.elevationCenter() );
         destination->setEventIdentifier( source.eventIdentifier().string() );
         destination->setScanPattern( (DtUnderwaterAcousticScanPattern) source.scanPattern() );
         return destination;
      }

   }
}
