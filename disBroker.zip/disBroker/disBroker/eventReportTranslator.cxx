/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file eventReportTranslator.cxx
//! \brief Contains the DtEventReportTranslator class definition.
//! \ingroup disBroker

#include <disBroker/eventReportTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtEventReportTranslator::DtEventReportTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalEventReportInteraction::theKind )
      {
      }

      DtEventReportTranslator::~DtEventReportTranslator()
      {
      }

      bool DtEventReportTranslator::isPortalDiscoverable(
         const DtPortalEventReportInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.senderId())
            && testGlobalIdMapping("Receiver ID",inter.receiverId()) );
      }

      DtPortalEventReportInteraction* DtEventReportTranslator::translate(
         DtPortalEventReportInteraction* destination,
         const DtEventReportInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setEventType( source.eventType() );

         {  // Copy Fixed datum...
            DtFixedLengthDataArray* fixedDatums = &destination->fixedDatums();
            fixedDatums->resize( source.numFixedFields() );

            DtFixedLengthDataArray::iterator pos = fixedDatums->begin();
            for ( int vrlink_index = 1; pos != fixedDatums->end(); ++pos, ++vrlink_index )
            {
               (*pos).setId( source.fixedDatumId( vrlink_index ));
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtU32 fixedValue = source.datumValUnsigned32( DtFixed, vrlink_index, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  (*pos).setValue( fixedValue );
               }
            }
         }

         {  // copy variable datum...
            DtAttributeValuePairList* variableDatumSet = &destination->variableDatumSet();
            variableDatumSet->resize( source.numVarFields() );

            DtAttributeValuePairList::iterator pos = variableDatumSet->begin();
            for ( int vrlink_index = 1; pos != variableDatumSet->end(); ++pos, ++vrlink_index )
            {
               (*pos).first = DtString( source.varDatumId( vrlink_index ));
               (*pos).second.setData( source.datumValByteArray( DtVar, vrlink_index ),
                  source.datumSizeBytes( DtVar, vrlink_index ));
            }
         }

         return destination;
      }

      DtEventReportInteraction* DtEventReportTranslator::translate(
         DtEventReportInteraction* destination,
         const DtPortalEventReportInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setEventType( (DtEventType) source.eventType() );

         {  // Copy Fixed datum...
            destination->setNumFixedFields( source.fixedDatums().size() );

            DtFixedLengthDataArray::const_iterator pos = source.fixedDatums().begin();
            for (int vrlink_index = 1; pos != source.fixedDatums().end(); ++pos, ++vrlink_index)
            {
               DtDatumRetCode  returnCode = DtDatumBadLength;
               DtDatumParam id = (DtDatumParam)(*pos).id();
               destination->setDatumParam( DtFixed, vrlink_index, id, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  DtU32 value = (*pos).value();
                  destination->setDatumValUnsigned32( DtFixed, vrlink_index, value, &returnCode );
               }
            }
         }

         {  // copy variable datum...
            destination->setNumVarFields( source.variableDatumSet().size() );

            DtAttributeValuePairList::const_iterator pos = source.variableDatumSet().begin();
            for (int vrlink_index = 1; pos != source.variableDatumSet().end(); ++pos, ++vrlink_index)
            {
               DtDatumRetCode returnCode = DtDatumBadLength;
               DtDatumParam varDatumId = (DtDatumParam)atol( (*pos).first );
               destination->setDatumParam( DtVar, vrlink_index, varDatumId, &returnCode );
               if (returnCode == DtDatumValid)
               {
                  int length = (*pos).second.size();
                  destination->setVarDataBytes( vrlink_index, length, &returnCode );
                  const char* value = (*pos).second.data();
                  destination->setDatumValByteArray( DtVar, vrlink_index, value, &returnCode );
               }
            }
         }

         return destination;
      }

   }
}
