/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file commentTranslator.h
//! \brief Contains the DtCommentTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/commentInteraction.h>
#include <portal/pCommentInter.h>

namespace MAKVrExchange
{

   class DtPortalCommentInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides Comment interaction translation between DIS and the
      //! VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtCommentTranslator
         : public DtDisInteractionTranslator<DtPortalCommentInteraction,DtCommentInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Comment" );

         //! \brief CTOR.
         DtCommentTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtCommentTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalCommentInteraction& inter );

         //! \brief Translates the comment interaction into the portal.
         virtual DtPortalCommentInteraction* translate(
            DtPortalCommentInteraction* destination,
            const DtCommentInteraction& source );

         //! \brief Translates the portal comment interaction from the portal.
         virtual DtCommentInteraction* translate( DtCommentInteraction* destination,
            const DtPortalCommentInteraction& source );

      };

   }
}
