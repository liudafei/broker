/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file acknowledgeTranslator.cxx
//! \brief Contains the DtAcknowledgeTranslator class definition.
//! \ingroup disBroker

#include <disBroker/acknowledgeTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtAcknowledgeTranslator::DtAcknowledgeTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalAcknowledgeInteraction::theKind )
      {
      }

      DtAcknowledgeTranslator::~DtAcknowledgeTranslator()
      {
      }

      bool DtAcknowledgeTranslator::isPortalDiscoverable(
         const DtPortalAcknowledgeInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.originatingEntity())
            && testGlobalIdMapping("Receiver ID",inter.receivingEntity()) );
      }

      DtPortalAcknowledgeInteraction* DtAcknowledgeTranslator::translate(
         DtPortalAcknowledgeInteraction* destination, const DtAcknowledgeInteraction& source )
      {
         destination->setOriginatingEntity( disBroker()->convertGlobalId( source.senderId() ));
         destination->setReceivingEntity( disBroker()->convertGlobalId( source.receiverId() ));
         destination->setRequestIdentifier( source.requestId() );
         destination->setAcknowledgeFlag( source.acknowledgeFlag() );
         destination->setResponseFlag( source.responseFlag() );

         return destination;
      }

      DtAcknowledgeInteraction* DtAcknowledgeTranslator::translate(
         DtAcknowledgeInteraction* destination, const DtPortalAcknowledgeInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId( source.originatingEntity() ));
         destination->setReceiverId( disBroker()->convertGlobalId( source.receivingEntity() ));
         destination->setAcknowledgeFlag( (DtAcknowledgeFlag)source.acknowledgeFlag() );
         destination->setResponseFlag( (DtResponseFlag)source.responseFlag() );
         destination->setRequestId( source.requestIdentifier() );

         return destination;
      }

   }
}
