/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file pointObjectTranslator.cxx
//! \brief Contains the DtPointObjectTranslator class definition.
//! \ingroup disBroker

#include <disBroker/pointObjectTranslator.h>
#include <disBroker/disBrokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtPointObjectTranslator::DtPointObjectTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalPointObject::theKind )
      {
         DtPointObjectPublisher::setDfltTimeThreshold( ((DtDisBroker*)broker)->heartbeatInterval() );
      }

      DtPointObjectTranslator::~DtPointObjectTranslator()
      {
      }

      bool DtPointObjectTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedPointObject& refObj ) const
      {
         if ( refObj.sr()->objectIdentifier() == DtEntityIdentifier() )
         {
            DtInfo << "DtPointObjectTranslator: " << brokerObj->objectName()
               << ": Object Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Object ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<POINT_OBJECT_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedPointObject* refObj,
         const DtString& identifier )
      {
         return mapObjectId( DtEntityIdentifier(identifier) );
      }

      DtString DtPointObjectTranslator::disObjectName(
         const DtPortalReflectedPointObject* refObj ) const
      {
         return refObj->sr()->objectIdentifier().string();
      }

      void DtPointObjectTranslator::updateDisBrokerObject( DtBrokerObject* brokerObj,
         const DtPointObjectRepository& sr )
      {
         ParentClass::updateDisBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.objectId().string() );
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<POINT_OBJECT_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedPointObject* refObj, const DtEntityIdentifier& name )
      {
         DtPointObjectPublisher* publisher = NULL;
         try
         {
            // Instantiate the publisher.
            publisher = new DtPointObjectPublisher( refObj->sr()->objectType(),
               disBroker()->connection(), name );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      DtString DtPointObjectTranslator::portalObjectName(
         const DtReflectedPointObject* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "POvrx";
      }

      void DtPointObjectTranslator::updatePortalBrokerObject( DtBrokerObject* brokerObj,
         const DtPortalPointObject& sr )
      {
         ParentClass::updatePortalBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.objectIdentifier().string() );
      }

      DtPortalPointObject* DtPointObjectTranslator::translate(
         DtPortalPointObject* dest, const DtPointObjectRepository& src,
         const DtReflectedPointObject& refObj )
      {
         // env. object attributes.
         dest->setObjectIdentifier( *disBroker()->entityIdMapper()
            ->convertDisEidToPortalEid(src.objectId()) );
         dest->setReferencedObjectId( disBroker()->entityIdMapper()
            ->convertDisEidToPortalEid(src.referencedObjectId())->string() );
         dest->setUpdateNumber( src.updateNumber() );
         dest->setForceId( src.forceId() );
         dest->setRequestorId( src.requesterSimId() );
         dest->setReceivingId( src.receivingSimId() );

         // env. object type.
         dest->setObjectType( src.objectType() );

         // point object attributes.
         dest->setModifications( src.modifications() );
         dest->setLocation( src.location() );
         dest->setOrientation( src.orientation() );
         dest->setGeneralAppearance( src.generalAppearance() );
         dest->setSpecificAppearance( src.specificAppearance() );

         return dest;
      }

      DtPointObjectRepository* DtPointObjectTranslator::translate(
         DtPointObjectRepository* dest, const DtPortalPointObject& src,
         const DtPortalReflectedPointObject& refObj )
      {
         // env. object attributes.
         dest->setObjectId( *disBroker()->entityIdMapper()
            ->convertPortalEidToDisEid(src.objectIdentifier()) );
         dest->setReferencedObjectId( *disBroker()->entityIdMapper()
            ->convertPortalEidToDisEid(DtEntityIdentifier(src.referencedObjectId())) );
         dest->setUpdateNumber( src.updateNumber() );
         dest->setForceId( (DtForceType) src.forceId() );
         dest->setRequesterSimId( src.requestorId() );
         dest->setReceivingSimId( src.receivingId() );

         // env. object type.
         dest->setObjectType( src.objectType() );

         // point object attributes.
         dest->setModifications( src.modifications() );
         dest->setLocation( src.location() );
         dest->setOrientation( src.orientation() );
         dest->setGeneralAppearance( src.generalAppearance() );
         dest->setSpecificAppearance( src.specificAppearance() );

         return dest;
      }

   }
}
