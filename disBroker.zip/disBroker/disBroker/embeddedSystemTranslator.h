/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file embeddedSystemTranslator.h
//! \brief Contains the DtEmbeddedSystemTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>

#define DIS_TEMPLATE_LIST \
   template \
   < class T_PortalObject \
   , class T_PortalReflectedObject \
   , class T_DisReflectedObject \
   , class T_DisReflectedObjectList \
   , class T_DisObjectStateRepository \
   , class T_DisObjectPublisher>

#define DIS_TEMPLATE_FUNCTION \
   T_PortalObject, T_PortalReflectedObject, \
   T_DisReflectedObject, T_DisReflectedObjectList, \
   T_DisObjectStateRepository, T_DisObjectPublisher

class DtEmbeddedSystemRepository;

namespace MAKVrExchange
{

   class DtPortalEmbeddedSystem;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Base class for all embedded system translators.
      //! Performs translation common to all embedded systems.
      //! \ingroup disBroker
      DIS_TEMPLATE_LIST
      class DtEmbeddedSystemTranslator : public DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>
      {
      public:

         //! \brief Typedef for the templated class type.
         typedef DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION> ParentClass;

      public:

         //! \brief CTOR.
         DtEmbeddedSystemTranslator( DtBroker* broker,
            const DtString& name, DtPortalMessageKind kind );

         //! \brief Virtual DTOR.
         virtual ~DtEmbeddedSystemTranslator();

      protected:

         //! \brief Determines the name to use for the given reflected object.
         //! Overridden to use the Host Object ID instead of the Entity ID.
         virtual DtString disObjectName( const T_PortalReflectedObject* refObj ) const;

         //! \brief Updates the broker object with info from the given state rep.
         //! Overridden to set the Entity ID as the Object ID.
         virtual void updateDisBrokerObject( DtBrokerObject* brokerObj,
            const T_DisObjectStateRepository& sr );

         //! \brief Updates the broker object with info from the given state rep.
         //! Overridden to set the Entity ID as the Object ID.
         virtual void updatePortalBrokerObject( DtBrokerObject* brokerObj, const T_PortalObject& sr );

         //! \brief Translates the given DIS object to a Portal object.
         virtual DtPortalEmbeddedSystem* translate( DtPortalEmbeddedSystem* destination,
            const DtEmbeddedSystemRepository& source, const T_DisReflectedObject& refObj );

         //! \brief Translates the given Portal object to an DIS object.
         virtual DtEmbeddedSystemRepository* translate( DtEmbeddedSystemRepository* destination,
            const DtPortalEmbeddedSystem& source, const T_PortalReflectedObject& refObj );

      };

   }
}

#define _embeddedSystemTranslator_INL_
#include <disBroker/embeddedSystemTranslator.inl>
#undef _embeddedSystemTranslator_INL_
