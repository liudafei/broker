/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file underwaterAcousticTranslator.h
//! \brief Contains the DtUnderwaterAcousticTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/embeddedSystemTranslator.h>

class DtUnderwaterAcousticsEmissionRepository;

#define DIS_TEMPLATE_LIST \
   template \
   < class T_PortalObject \
   , class T_PortalReflectedObject \
   , class T_DisReflectedObject \
   , class T_DisReflectedObjectList \
   , class T_DisObjectStateRepository \
   , class T_DisObjectPublisher>

#define DIS_TEMPLATE_FUNCTION \
   T_PortalObject, T_PortalReflectedObject, \
   T_DisReflectedObject, T_DisReflectedObjectList, \
   T_DisObjectStateRepository, T_DisObjectPublisher

namespace MAKVrExchange
{

   class DtPortalUnderwaterAcousticObject;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Base class for all embedded system translators.
      //! Performs translation common to all embedded systems.
      //! \ingroup disBroker
      DIS_TEMPLATE_LIST
      class DtUnderwaterAcousticTranslator
         : public DtEmbeddedSystemTranslator<DIS_TEMPLATE_FUNCTION>
      {
      public:

         //! \brief Typedef for the templated class type.
         typedef DtUnderwaterAcousticTranslator<DIS_TEMPLATE_FUNCTION> ParentClass;

      public:

         //! \brief CTOR.
         DtUnderwaterAcousticTranslator( DtBroker* hlaBroker,
            const DtString& name, DtPortalMessageKind kind );

         //! \brief Virtual DTOR.
         virtual ~DtUnderwaterAcousticTranslator();

         //! \brief Translates the given HLA object to a Portal object.
         virtual DtPortalUnderwaterAcousticObject* translate( DtPortalUnderwaterAcousticObject* destination,
            const DtUnderwaterAcousticsEmissionRepository& source, const T_DisReflectedObject& refObj );

         //! \brief Translates the given Portal object to an HLA object.
         virtual DtUnderwaterAcousticsEmissionRepository* translate(
            DtUnderwaterAcousticsEmissionRepository* destination,
            const DtPortalUnderwaterAcousticObject& source,
            const T_PortalReflectedObject& refObj );

      };

   }
}


#define _underwaterAcousticTranslator_INL_
#include <disBroker/underwaterAcousticTranslator.inl>
#undef _underwaterAcousticTranslator_INL_
