/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file transferControlTranslator.cxx
//! \brief Contains the DtTransferControlTranslator class definition.
//! \ingroup disBroker

#include <disBroker/transferControlTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtTransferControlTranslator::DtTransferControlTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalTransferControlInteraction::theKind )
      {
      }

      DtTransferControlTranslator::~DtTransferControlTranslator()
      {
      }

      bool DtTransferControlTranslator::isPortalDiscoverable(
         const DtPortalTransferControlInteraction& inter )
      {
         return ( testGlobalIdMapping("Originating Entity ID",inter.originatingEntity())
            && testGlobalIdMapping("Receiving Entity ID",inter.receivingEntity())
            && testGlobalIdMapping("Transferred Entity ID",inter.transferredEntityID()) );
      }

      DtPortalTransferControlInteraction* DtTransferControlTranslator::translate(
         DtPortalTransferControlInteraction* destination,
         const DtTransferControlInteraction& source )
      {
         //! Set/Get the number of record sets in this list.
         destination->setOriginatingEntity( disBroker()->convertGlobalId(source.originatingEntityID()) );
         destination->setReceivingEntity( disBroker()->convertGlobalId(source.receivingEntityID()) );
         destination->setRequestIdentifier( source.requestID() );
         destination->setTransferType( source.transferType() );
         destination->setTransferredEntityID( disBroker()->convertGlobalId(source.transferredEntityID()) );

         for ( unsigned int i = 0; i < source.numRecordSets(); ++i )
         {
            bool valid = false;
            DtRecordSet record;
            if ( source.getRecordSet(i,record) )
            {
               destination->setRecordSet( i, record );
            }
         }

         return destination;
      }

      DtTransferControlInteraction* DtTransferControlTranslator::translate(
         DtTransferControlInteraction* destination, const DtPortalTransferControlInteraction& source )
      {
         destination->setOriginatingEntityID( disBroker()->convertGlobalId(source.originatingEntity()) );
         destination->setReceivingEntityID( disBroker()->convertGlobalId(source.receivingEntity()) );
         destination->setRequestID( source.requestIdentifier() );
         destination->setTransferType( DtTransferType(source.transferType()) );
         destination->setTransferredEntityID( disBroker()->convertGlobalId(source.transferredEntityID()) );

         for ( unsigned int i = 0; i < source.numRecordSets(); ++i )
         {
            bool valid = false;
            DtRecordSet record = source.recordSet( i, &valid );
            if ( valid )
            {
               destination->setRecordSet( i, record );
            }
         }

         return destination;
      }

   }
}
