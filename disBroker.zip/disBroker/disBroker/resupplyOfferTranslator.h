/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file resupplyOfferTranslator.h
//! \brief Contains the DtResupplyOfferTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/resupplyCancelInteraction.h>
#include <portal/pResupplyOfferInteraction.h>

namespace MAKVrExchange
{

   class DtPortalResupplyOfferInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides ResupplyOffer interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtResupplyOfferTranslator
         : public DtDisInteractionTranslator<DtPortalResupplyOfferInteraction,DtResupplyOfferInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Resupply Offer" );

         //! \brief CTOR.
         DtResupplyOfferTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtResupplyOfferTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalResupplyOfferInteraction& inter );

         //! \brief Translates the resupply offer interaction into the portal.
         virtual DtPortalResupplyOfferInteraction* translate(
            DtPortalResupplyOfferInteraction* destination,
            const DtResupplyOfferInteraction& source );

         //! \brief Translates the resupply offer interaction from the portal.
         virtual DtResupplyOfferInteraction* translate( DtResupplyOfferInteraction* destination,
            const DtPortalResupplyOfferInteraction& source );

      };

   }
}
