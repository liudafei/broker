/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file entityIdMapper.cxx
//! \brief Contains the DtEntityIdMapper class definition.
//! \ingroup disBroker

#include <disBroker/entityIdMapper.h>

#include <vlpi/entityIdentifier.h>

#include <broker/csvFileEntry.h>
#include <broker/csvFileRdr.h>

#include <vlutil/vlHashlist.h>
#include <vlutil/vlHashKeys.h>
#include <vlutil/vlPrint.h>
#include <vlutil/vlUtil.h>

#include <iostream>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtEntityIdMapper::DtEntityIdMapper( int siteNum, int appNum )
         : myEmptyPortalId(0)
         , myEmptyDisId(0)
         , myAppNum(appNum)
         , mySiteNum(siteNum)
         , myNextEnt(1)
         , myDebugOutputOn(false)
         , myPortalIdHashList()
         , myDisIdHashList()
      {
         myEmptyPortalId = new DtEntityIdentifier;
         myEmptyDisId = new DtEntityIdentifier;
      }

      DtEntityIdMapper::~DtEntityIdMapper()
      {
         // Need to go through maps and delete pointers.
         DtEntityIdMap::iterator pos;

         for (pos = myPortalIdHashList.begin(); pos != myPortalIdHashList.end();)
         {
            DtEntityIdentifier* entId = pos->second;
            DtDELETE(entId);
            myPortalIdHashList.erase(pos++);

            /* BANDAID: MSVC8.0's Secure SCL prevents using an iterator which has been
         advanced beyond end().  This is advertised as a feature, since it is illegal.
         Note: other compilers currently being used do not have this 'feature'.  They
         prevent advancing an iterator beyond end().  Same applies for revers_iterator\
         and begin()
             */
            if (myPortalIdHashList.empty())
            {
               break;
            }
         }

         for (pos = myDisIdHashList.begin(); pos != myDisIdHashList.end();)
         {
            DtEntityIdentifier* entId = pos->second;
            DtDELETE(entId);
            myDisIdHashList.erase(pos++);

            /* BANDAID: MSVC8.0's Secure SCL prevents using an iterator which has been
         advanced beyond end().  This is advertised as a feature, since it is illegal.
         Note: other compilers currently being used do not have this 'feature'.  They
         prevent advancing an iterator beyond end().  Same applies for revers_iterator\
         and begin()
             */
            if (myDisIdHashList.empty())
            {
               break;
            }
         }

         DtDELETE(myEmptyPortalId);
         DtDELETE(myEmptyDisId);
      }

      bool
      DtEntityIdMapper::add(const DtEntityIdentifier &portalId,
         const DtEntityIdentifier &disId)
      {
         // Check for NULL Portal ID... Should we also check for NULL DIS?
         // Revisit -- MJI
         if (portalId == DtEntityIdentifier())
         {
            if (myDebugOutputOn)
            {
               DtInfo << "Request to add mapping between " << portalId.string()
               << " and " << disId.string() << ". Will not add NULL id" << std::endl;
            }
            return false;
         }
         if (myDebugOutputOn)
         {
            DtInfo("EntityIdMapper registering portalId =(%s) disId (%s)\n",
               portalId.string(),
               disId.string());
         }

         // make sure that the ID we are publishing is unique,
         // the other one doesn't need to be. Many Portal Id's will be "0:0:0"
         if (  (publishingPortal(portalId) && myDisIdHashList.find(portalId) != myDisIdHashList.end()) ||
            (publishingDis(disId) && myPortalIdHashList.find(disId) != myPortalIdHashList.end()) )
         {
            return false;
         }

         myPortalIdHashList[disId] = new DtEntityIdentifier(portalId);
         myDisIdHashList[portalId] = new DtEntityIdentifier(disId);

         return true;
      }

      bool DtEntityIdMapper::publishingPortal(const DtEntityIdentifier &portalId) const
      {
         if (portalId.host() == myAppNum)
         {
            return true;
         }
         return false;
      }

      bool DtEntityIdMapper::publishingDis(const DtEntityIdentifier &disId) const
      {
         if (disId.host() == myAppNum)
         {
            return true;
         }
         return false;
      }

      const DtEntityIdentifier *
      DtEntityIdMapper::convertDisEidToPortalEid(const DtEntityIdentifier &disId)
      {
         DtEntityIdMap::iterator portalIdIter = myPortalIdHashList.find(disId);

         if (portalIdIter == myPortalIdHashList.end())
         {
            // This is a common condition, when we are just not publishing this
            // entity.
            if (myDebugOutputOn)
            {
               DtVerbose("EntityIdMapper tried to translate  "
                  "disId = (%s), but no Mapping was found.\n",
                  disId.string());
            }
            return (reinterpret_cast<const DtEntityIdentifier *>(&disId));
         }
         if (myDebugOutputOn)
         {
            DtInfo("EntityIdMapper translate  disId = (%s) -> portalId (%s)\n",
               disId.string(), portalIdIter->second->string());
         }
         return portalIdIter->second;
      }

      const DtEntityIdentifier *
      DtEntityIdMapper::convertPortalEidToDisEid(const DtEntityIdentifier &portalId)
      {
         DtEntityIdentifier portalKey = portalId;

         DtEntityIdMap::iterator disIdIter = myDisIdHashList.find(portalId);

         if (disIdIter == myDisIdHashList.end())
         {
            // This is a common condition, when we are just not publishing this
            // entity.
            if (myDebugOutputOn)
            {
               DtVerbose("EntityIdMapper tried to translate "
                  "portalId = (%s), but no mapping was found\n",
                  portalId.string());
            }
            return (reinterpret_cast<const DtEntityIdentifier*>(&portalId));
         }

         if (myDebugOutputOn)
         {
            DtInfo("EntityIdMapper translate  portalId = (%s) -> disId (%s)\n",
               portalId.string(), disIdIter->second->string());
         }

         return disIdIter->second;
      }

      DtEntityIdentifier DtEntityIdMapper::getNextDisId()
      {
         return DtEntityIdentifier(mySiteNum, myAppNum, myNextEnt++ );
      }

      DtEntityIdentifier DtEntityIdMapper::getNextPortalId()
      {
         return DtEntityIdentifier(mySiteNum, myAppNum, myNextEnt++ );
      }

      void DtEntityIdMapper::removePortalId(const DtEntityIdentifier &portalId)
      {
         remove(portalId, *(convertPortalEidToDisEid(portalId)));
      }

      void DtEntityIdMapper::removeDisId(const DtEntityIdentifier &disId)
      {
         remove( *(convertDisEidToPortalEid(disId)), disId);
      }

      void DtEntityIdMapper::remove(const DtEntityIdentifier &portalId,
         const DtEntityIdentifier &disId)
      {
         if (myDebugOutputOn)
         {
            DtInfo("EntityIdMapper removed portalId = (%s) disId (%s)\n",
               portalId.string(), disId.string());
         }

         DtEntityIdMap::iterator portalIter = myPortalIdHashList.find(disId);
         if (portalIter != myPortalIdHashList.end())
         {
            DtEntityIdentifier* portal_Id = portalIter->second;
            DtDELETE(portal_Id);
            myPortalIdHashList.erase(portalIter);
         }

         DtEntityIdMap::iterator disIter =
            myDisIdHashList.find(portalId);
         if (disIter != myDisIdHashList.end())
         {
            DtEntityIdentifier* dis_Id = disIter->second;
            DtDELETE(dis_Id);
            myDisIdHashList.erase(disIter);
         }
      }

      bool DtEntityIdMapper::portalHasMapping(const DtEntityIdentifier& portalId) const
      {
         DtEntityIdMap::const_iterator ptr = myDisIdHashList.find(portalId);

         if (ptr != myDisIdHashList.end())
         {
            return true;
         }
         else
         {
            return false;
         }
      }

      bool DtEntityIdMapper::disHasMapping(const DtEntityIdentifier& disId) const
      {
         DtEntityIdMap::const_iterator ptr = myPortalIdHashList.find(disId);

         if (ptr != myPortalIdHashList.end())
         {
            return true;
         }
         else
         {
            return false;
         }
      }

      DtEntityIdentifier DtEntityIdMapper::getPersistentId(const DtString& name)
      {
         return myPersistNameToEntityNum[name];
      }

      void DtEntityIdMapper::setPersistentId(const DtString& name, const DtEntityIdentifier& id)
      {
         myPersistNameToEntityNum[name] = id;
      }

      void DtEntityIdMapper::loadPersistentNumMappingFile()
      {
         DtCsvFileReader fileReader( "disPersistentEntityNumMap.csv" );
         if ( ! fileReader.openStream() )
         {
            // Could not open file - must be a no entity Num Maps
            return;
         }

         DtCsvFileEntry* entry = NULL;
         DtEntityIdentifier newID;
         newID.setHost(myAppNum);
         newID.setSite(mySiteNum);

         do
         {
            entry = fileReader.readAndParseNextLine( DtCsvFileEntry::creator );
            // At this point, entry is a list of the comma-seperated fields found in the file

            // Is is a comment or blank line? If not, process
            if ( entry && ( entry->name()[0] != ';' ||  entry->name()[1] != ';' ) )
            {
               if ( entry->length() == 1 )
               {
                  unsigned int entityNum = atoi((*entry)[0].c_str());
                  newID.setEntityNum(entityNum);
                  myPersistNameToEntityNum[entry->name().c_str()] = newID;

                  if(entityNum > (unsigned int)myNextEnt)
                  {
                     myNextEnt = entityNum;
                  }
               }
               else
               {
                  //ERROR.. skip for now
               }
            }
         }
         while ( ! fileReader.isEOF() );

         fileReader.closeStream();

      }

      void DtEntityIdMapper::savePersistentNumMappingFile()
      {
         DtInfo << "saving Entity Number Mapping file\n";
         std::ofstream    outfile;
         outfile.open("disPersistentEntityNumMap.csv");
         if(!outfile.is_open()) return; //fail

         for(std::map<DtString,DtEntityIdentifier>::iterator iter = myPersistNameToEntityNum.begin();
            iter != myPersistNameToEntityNum.end();
            ++iter)
         {
            //this is a safety check that the name isn't so big it crashes reading
            if(strlen(iter->first) < 3900)
            {
               outfile << iter->first << "," << iter->second << "\n";
            }
         }
         outfile.close();
      }

   }
}
