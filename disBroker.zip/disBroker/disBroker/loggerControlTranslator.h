/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file loggerControlTranslator.h
//! \brief Contains the logger control toolkit translator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/dllExport.h>
#include <broker/baseInteractionTranslator.h>
#include <portal/pLoggerControlInteraction.h>
#include <loggerControlToolkit/lcInter.h>

namespace MAKVrExchange
{

   class DtPortalLoggerControlInteraction;
   class DtPortalLoggerConnectInteraction;
   class DtPortalLoggerDeleteFileInteraction;
   class DtPortalLoggerEmptyInteraction;
   class DtPortalLoggerEndInteraction;
   class DtPortalLoggerEndOfActionInteraction;
   class DtPortalLoggerHeartbeatInteraction;
   class DtPortalLoggerPauseInteraction;
   class DtPortalLoggerPlayActionInteraction;
   class DtPortalLoggerPlayFileInteraction;
   class DtPortalLoggerPlayInteraction;
   class DtPortalLoggerQuitInteraction;
   class DtPortalLoggerRecordActionInteraction;
   class DtPortalLoggerRecordFileInteraction;
   class DtPortalLoggerRecordInteraction;
   class DtPortalLoggerSetTimeInteraction;
   class DtPortalLoggerSkipTimeInteraction;
   class DtPortalLoggerStartInteraction;
   class DtPortalLoggerStateFlagInteraction;
   class DtPortalLoggerStopInteraction;
   class DtPortalLoggerTimeoutInteraction;
   class DtPortalLoggerTimeScaleInteraction;
   class DtPortalLoggerTotalStateInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides LoggerControl interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtLoggerControlTranslator
         : public DtInteractionTranslator
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Logger Control" );

         //! \brief Registers the function receiveDisInteraction with VR-Link and
         //! receivePortalInteraction() with the \ref portalApplicationGroup "Portal".
         DtLoggerControlTranslator( DtBroker* broker );

         //! \brief Removes the function callbacks receiveDisInteraction() and
         //! receivePortalInteraction() from VR-Link and the
         //! \ref portalApplicationGroup "Portal" respectively.
         virtual ~DtLoggerControlTranslator();

         virtual DtDisBroker* disBroker();
         virtual const DtDisBroker* disBroker() const;

         //! @name Translation enable/disable methods.
         //! @{

         virtual void enableReflectTranslator( bool enabled );
         virtual void enablePublishTranslator( bool enabled );

         //! @}

         //! @name Callback initialization methods.
         //! @{

         virtual void initializeDisCallbacks();
         virtual void removeDisCallbacks();

         virtual void initializePortalCallbacks();
         virtual void removePortalCallbacks();

         //! @}

         //! \brief Performs any virtual shutdown logic prior to deletion.
         virtual void shutdown();

         //! Prints incoming and outgoing interactions (before and after translation) to DtInfo.
         virtual void printIncomingOutgoingInteractions( const DtPortalInteraction& incoming,
            const DtInteraction& outgoing ) const;

         //! Prints incoming and outgoing interactions (before and after translation) to DtInfo.
         virtual void printIncomingOutgoingInteractions( const DtInteraction& incoming,
            const DtPortalInteraction& outgoing ) const;

      protected:

         //! \brief The callback functioned registered by the constructor and used by VR-Link.
         //!
         //! This function is called when a DIS VR-Link loggercontrol interaction occurs.
         //! Calls createPortalInteraction() to send the DIS Interaction \e loggercontrol to the
         //! Portal.
         //!
         //! \param [in] loggercontrol DIS interaction to be sent.
         //! \param [in] usr DtLoggerControlInteractionTranslator object.
         //!
         //! \pre \e loggercontrol is a valid object. \e usr must other be a valid
         //! DtLoggerControlInteractionTranslator or NULL.
         static void receiveDisInteraction( DtLgrControlInteraction* loggerControl, void* usr );

         //! \brief The callback function registered by the constructor and used by
         //! the Portal.
         //!
         //! This function is called when a Portal loggercontrol interaction occurs.  Calls
         //! createInteraction() to send the Portal Interaction \e loggercontrol to
         //! DIS VR-Link.
         //!
         //! \param [in] loggercontrol Portal interaction to be sent.
         //! \param [in] usr DtLoggerControlInteractionTranslator object.
         //!
         //! \pre \e loggercontrol is a valid object.  \e usr must either be a valid
         //! DtLoggerControlInteractionTranslator object, or NULL.
         static void receivePortalInteraction( const DtPortalLoggerConnectInteraction& loggerControl, void* usr);
         static void receivePortalInteraction( const DtPortalLoggerDeleteFileInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerEmptyInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerStopInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerControlInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerEndInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerEndOfActionInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerHeartbeatInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerPauseInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerPlayActionInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerPlayFileInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerPlayInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerQuitInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerRecordActionInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerRecordFileInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerRecordInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerSetTimeInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerSkipTimeInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerStartInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerStateFlagInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerTimeoutInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerTimeScaleInteraction& loggerControl, void* usr );
         static void receivePortalInteraction( const DtPortalLoggerTotalStateInteraction& loggerControl, void* usr );

         //! \brief Sends a portal interaction.
         //!
         //! Takes \e incoming as a DIS interaction, translates it to a Portal interaction,
         //! then sends this portal interaction through #myBroker.
         //!
         //! \param [in] incoming Received DIS VR-Link interaction.
         //!
         //! \pre \e incoming is a valid object
         virtual void createPortalInteraction( const DtLgrControlInteraction& incoming );

         //! \brief Sends a DIS interaction.
         //!
         //! Takes \e incoming as a Portal interaction, translates it to DIS interaction,
         //! then sends this DIS interaction through #myBroker.
         //!
         //! \param [in] incoming Received Portal interaction.
         //!
         //! \pre \e incoming is a valid DtPortalLoggerControlInteraction object.
         virtual void createInteraction( const DtPortalLoggerControlInteraction& incoming );

         //! \brief Translates a DIS VR-Link LoggerControl interaction into a \ref
         //! DtPortalLoggerControlInteraction "VR-Exchange Portal Logger Control interaction".
         //!
         //! Takes the information found in \e source and produces a comparable
         //! DtPortalLoggerControlInteraction message found in \e destination.  This function
         //! is overloaded to provide \ref
         //! translate( DtLgrControlInteraction*, const DtPortalLoggerControlInteraction& )
         //! "translation in the opposite direction".
         //!
         //! \param [out] destination  A \ref DtPortalLoggerControlInteraction
         //! "VR-Exchange Portal LoggerControl interaction".
         //! \param [in]  source  A DIS VR-Link LoggerControl interaction.
         //!
         //! \return Address of \e destination.
         //!
         //! \pre \e destination and \e source are both valid.
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerConnectInteraction* destination,
            const DtLgrControlInteraction& source);
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerDeleteFileInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerEmptyInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerStopInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerEndInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerEndOfActionInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerHeartbeatInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerPauseInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerPlayActionInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerPlayFileInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerPlayInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerQuitInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerRecordActionInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerRecordFileInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerRecordInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerSetTimeInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerSkipTimeInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerStartInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerStateFlagInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerTimeoutInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerTimeScaleInteraction* destination,
            const DtLgrControlInteraction& source );
         virtual DtPortalLoggerControlInteraction* translate(
            DtPortalLoggerTotalStateInteraction* destination,
            const DtLgrControlInteraction& source );

         //! \brief Translates a \ref DtPortalLoggerControlInteraction
         //! "VR-Exchange Portal LoggerControl interaction" into a DIS VR-Link LoggerControl
         //! interaction.
         //!
         //! Takes the information found in \e source and produces a comparable DIS
         //! VR-Link interaction.  This function is overloaded to provide \ref
         //! translate( DtPortalLoggerControlInteraction*, const DtPortalLoggerControlInteraction& )
         //! "translation in the opposite direction".
         //!
         //! \return Address of \e destination
         //!
         //! \param [out] destination  A DIS VR-Link LoggerControl interaction.
         //! \param [in]  source  A \ref DtPortalLoggerControlInteraction
         //! "VR-Exchange Portal LoggerControl interaction".
         //!
         //! \return Address of \e destination
         //!
         //! \pre \e destination and \e source are both valid.
         virtual DtLgrControlInteraction* translate(DtLgrControlInteraction* destination,
            const DtPortalLoggerConnectInteraction& source);
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerDeleteFileInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerEmptyInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerStopInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerEndInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerEndOfActionInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerHeartbeatInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerPauseInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerPlayActionInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerPlayFileInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerPlayInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerQuitInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerRecordActionInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerRecordFileInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerRecordInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerSetTimeInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerSkipTimeInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerStartInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerStateFlagInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerTimeoutInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerTimeScaleInteraction& source );
         virtual DtLgrControlInteraction* translate( DtLgrControlInteraction* destination,
            const DtPortalLoggerTotalStateInteraction& source );

      };

   }
}
