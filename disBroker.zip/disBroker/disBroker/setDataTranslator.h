/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file setDataTranslator.h
//! \brief Contains the DtSetDataTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/setDataInteraction.h>
#include <portal/pSetDataInter.h>

namespace MAKVrExchange
{

   class DtPortalSetDataInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides Set Data interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtSetDataTranslator
         : public DtDisInteractionTranslator<DtPortalSetDataInteraction,DtSetDataInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Set Data" );

         //! \brief CTOR.
         DtSetDataTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtSetDataTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalSetDataInteraction& inter );

         //! \brief Translates the set data interaction into the portal.
         virtual DtPortalSetDataInteraction* translate(
               DtPortalSetDataInteraction* destination,
               const DtSetDataInteraction& source );

         //! \brief Translates the set data interaction from the portal.
         virtual DtSetDataInteraction* translate( DtSetDataInteraction* destination,
            const DtPortalSetDataInteraction& source );

      };

   }
}
