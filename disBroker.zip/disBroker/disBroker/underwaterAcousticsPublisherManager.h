/*****************************************************************************
 * Copyright (c) 2013 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file underwaterAcousticsPublisherManager.h
//! \brief Contains the DtUnderwaterAcousticsPublisherManager class declaration.
//! \ingroup disBroker

#pragma  once

#include <disBroker/dllExport.h>
#include <vlutil/vlString.h>
#include <map>

class DtUnderwaterAcousticsPublisher;

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      class DtUnderwaterAcousticsPublisherManager;

      //! A Function pointer for a GlobalIdMapper creator function.
      typedef DtUnderwaterAcousticsPublisherManager* (*DtUnderwaterAcousticsPublisherManagerCreator)();

      //! \brief Keeps track of DtUnderwaterAcousticsPublishers by host id.
      //! This is used by the underwater acoustics translators when running
      //! in single PDU mode so the various underwater acoustics translators
      //! can share a single DtUnderwaterAcousticsPublisher for a single host
      //! entity.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtUnderwaterAcousticsPublisherManager
      {
      public:

         //! A typedef to make it easier to see what kind of ID this is. All objects
         //! in the Portal are identified with a unique string.
         typedef DtString PortalId;

      public:

         //! \brief Default CTOR.
         DtUnderwaterAcousticsPublisherManager();

         //! \brief Virtual DTOR.
         virtual ~DtUnderwaterAcousticsPublisherManager();

         //! \brief Returns the publisher for the given host id.
         //! \return NULL if there isn't a publisher for the given host id.
         virtual DtUnderwaterAcousticsPublisher* findPublisher(
            const PortalId& hostId ) const;

         //! \brief Registers the publisher for the given host id.
         //! This adds the given publisher to the internal map, storing it
         //! as the publisher for the host id. Further calls to findPublisher
         //! with return this publisher for lookups with the same host id. The
         //! manager takes over ownership of the publisher, and callers should
         //! not delete the publisher themselves.
         virtual bool registerPublisher( const PortalId& hostId,
            DtUnderwaterAcousticsPublisher* publisher );

         //! \brief Tells the manager that another object is using the publisher.
         //! Increments the internal usage count for the given publisher. This
         //! counter is used to determine whether the publisher should be deleted
         //! when released. If objects are still using the publisher, the count
         //! will be positive and the publisher will not be deleted.
         virtual void checkoutPublisher(
            DtUnderwaterAcousticsPublisher* publisher );

         //! \brief Tells the manager that an object is done using the publisher.
         //! Decrements the internal usage count for the publisher associated
         //! with the given host id. If this reduces the count to zero, the
         //! publisher is deleted.
         virtual void releasePublisher( const PortalId& hostId );

         //! \brief Returns the number of publishers in the manager.
         virtual int numPublishers() const;

         //! \brief Ticks all publishers contained in the manager.
         virtual void tickPublishers();

      protected:

         //! This map maps host ids to the publisher they're associated with.
         typedef std::map<PortalId,DtUnderwaterAcousticsPublisher*> PortalIdToPublisherMap;
         PortalIdToPublisherMap myPortalIdToPublisherMap;

         //! This map maps publishers to the count of how many objects are using it.
         typedef std::map<DtUnderwaterAcousticsPublisher*,int> PublisherUsageCountsMap;
         PublisherUsageCountsMap myPublisherUsageCountsMap;

      };

   }
}
