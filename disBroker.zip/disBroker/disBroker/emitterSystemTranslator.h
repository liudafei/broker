/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file emitterSystemTranslator.h
//! \brief Contains the DtEmitterSystemTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/embeddedSystemTranslator.h>
#include <vl/reflectedEmitterSystemList.h>
#include <vl/emitterSystemPublisher.h>

class DtEmitterBeamRepository;
class DtReflectedEmitterSystem;
class DtEmitterSystemRepository;

#define EMITTER_TEMPLATE_ARGS \
   DtPortalEmitterSystemObject, DtPortalReflectedEmitterSystemObject, \
   DtReflectedEmitterSystem, DtReflectedEmitterSystemList, \
   DtEmitterSystemRepository, DtEmitterSystemPublisher

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //! \brief Provides Emitter System object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtEmitterSystemTranslator
         : public DtEmbeddedSystemTranslator<EMITTER_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Emitter System" );

         //! \brief CTOR.
         DtEmitterSystemTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtEmitterSystemTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedEmitterSystemObject* refObj );

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! This method can be overridden to perform mapping for different types
         //! of objects as well (emitters, etc.).
         virtual bool performDisGlobalIdMapping( const DtObjectPublisher* publisher,
            const DtPortalReflectedEmitterSystemObject& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Construct the portal object name.
         //! Overridden to construct an emitter system name.
         virtual DtString portalObjectName( const DtReflectedEmitterSystem* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! Overridden to pass EmitterSystemType enum for object type.
         virtual bool performPortalGlobalIdMapping(
            const DtPortalEmitterSystemObjectPublisher* publisher,
            const DtReflectedEmitterSystem& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Destroy the brokerObject's publisher.
         //! Overridden to correctly unmap the publisher's id.
         virtual void deleteDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Translates an Emitter System to the portal.
         virtual DtPortalEmitterSystemObject* translate( DtPortalEmitterSystemObject* destination,
            const DtEmitterSystemRepository& source, const DtReflectedEmitterSystem& refObj );

         //! \brief Translates an Emitter System Beam to the portal.
         virtual DtEmitterBeamData* translate( DtEmitterBeamData* destination,
            const DtEmitterBeamRepository& source );

         //! \brief Translates a portal Emitter System from the portal.
         virtual DtEmitterSystemRepository* translate( DtEmitterSystemRepository* destination,
            const DtPortalEmitterSystemObject& source, const DtPortalReflectedEmitterSystemObject& refObj );

         //! \brief Translates a portal Emitter System Beam from the portal.
         virtual DtEmitterBeamRepository* translate( DtEmitterBeamRepository* destination,
            const DtEmitterBeamData& source );

      };

   }
}

