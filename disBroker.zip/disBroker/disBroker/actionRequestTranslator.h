/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file actionRequestTranslator.h
//! \brief Contains the DtActionRequestTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pActionRequestInter.h>
#include <vl/actionRequestInteraction.h>

namespace MAKVrExchange
{

   class DtPortalActionRequestInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Translates Action Request Interactions to/from the portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtActionRequestTranslator
         : public DtDisInteractionTranslator<DtPortalActionRequestInteraction,DtActionRequestInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Action Request" );

         //! \brief CTOR.
         DtActionRequestTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtActionRequestTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalActionRequestInteraction& inter );

         //! \brief Translates the action request interaction into the portal.
         virtual DtPortalActionRequestInteraction* translate(
            DtPortalActionRequestInteraction* destination,
            const DtActionRequestInteraction& source );

         //! \brief Translates the portal action request interaction from the portal.
         virtual DtActionRequestInteraction* translate(
            DtActionRequestInteraction* destination,
            const DtPortalActionRequestInteraction& source );

      };

   }
}
