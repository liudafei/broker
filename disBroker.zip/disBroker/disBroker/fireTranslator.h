/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file fireTranslator.h
//! \brief Contains the DtFireTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/fireInteraction.h>
#include <portal/pFireInter.h>

namespace MAKVrExchange
{

   class DtPortalFireInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Translates Fire Interactions to/from the portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtFireTranslator
         : public DtDisInteractionTranslator<DtPortalFireInteraction,DtFireInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Fire" );

         //! \brief CTOR.
         DtFireTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtFireTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalFireInteraction& inter );

         //! \brief Translates the fire interaction into the portal.
         virtual DtPortalFireInteraction* translate(
            DtPortalFireInteraction* destination, const DtFireInteraction& source );

         //! \brief Translates the portal fire interaction from the portal.
         virtual DtFireInteraction* translate( DtFireInteraction* destination,
            const DtPortalFireInteraction& source );

      };

   }
}
