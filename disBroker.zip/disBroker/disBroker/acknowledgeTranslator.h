/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file acknowledgeTranslator.h
//! \brief Contains the DtAcknowledgeTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pAcknowledgeInter.h>
#include <vl/acknowledgeInteraction.h>

namespace MAKVrExchange
{

   class DtPortalAcknowledgeInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Translates Acknowledge Interactions to/from the portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtAcknowledgeTranslator
         : public DtDisInteractionTranslator<DtPortalAcknowledgeInteraction,DtAcknowledgeInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Acknowledge" );

         //! \brief CTOR.
         DtAcknowledgeTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtAcknowledgeTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalAcknowledgeInteraction& inter );

         //! \brief Translates the acknowledge interaction into the portal.
         virtual DtPortalAcknowledgeInteraction* translate(
            DtPortalAcknowledgeInteraction* destination,
            const DtAcknowledgeInteraction& source );

         //! \brief Translates the portal acknowledge interaction from the portal.
         virtual DtAcknowledgeInteraction* translate(
            DtAcknowledgeInteraction* destination,
            const DtPortalAcknowledgeInteraction& source );

      };

   }
}
