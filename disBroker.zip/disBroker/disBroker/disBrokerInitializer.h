/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disBrokerInitializer.h
//! \brief Contains the DtDisBrokerInitializer class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disDiscoverableCriteria.h>
#include <broker/brokerInitializer.h>
#include <mtl/multiConfigVariable.h>
#include <vlutil/vlTime.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //! \brief Provides initialization parameters to the
      //! \ref DtDisBroker "DIS Broker"
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDisBrokerInitializer : public DtBrokerInitializer
      {
      public:

         //! \brief Constructor initializes command line arguments and MTL parameters.
         DtDisBrokerInitializer( int argc = 0, char** argv = 0,
            const char* versionString = "1.0" );

         //! \brief Copy CTOR.
         DtDisBrokerInitializer( const DtDisBrokerInitializer& other );

         //! \brief Virtual DTOR.
         virtual ~DtDisBrokerInitializer();

         //! \brief Assignment operator.
         DtDisBrokerInitializer& operator = ( const DtDisBrokerInitializer& other );

         //! \brief Clone method.
         //! Creates a copy of this initializer - caller is responsible for deletion.
         virtual DtDisBrokerInitializer* clone() const;

         virtual DtDisDiscoverableCriteria* discoveryCriteria();

         //! @name Connection Settings
         //! @{

         //! \brief Returns the port that the
         //! \ref DtDisBroker "DIS broker" should use for
         //! receiving PDU's.
         virtual int disPort() const;
         virtual void setDisPort( int );

         //! \brief Returns the \ref DtDisBroker "DIS broker's" exercise ID.
         virtual int exerciseId() const;
         virtual void setExerciseId( int );

         //! \brief Returns the network address that the \ref DtDisBroker "DIS broker" sends to.
         virtual DtString destinationAddress() const;
         virtual void setDestinationAddress( const DtString& );

         //! \brief Returns the device address for the \ref DtDisBroker "DIS Broker" to use.
         virtual DtString deviceAddress() const;
         virtual void setDeviceAddress( const DtString& );

         //! \brief Returns the \ref DtDisBroker "DIS broker's"
         //! subnet mask.
         //! The subnet mask is the mask to be used with all IP addresses
         //! associated with this broker.
         virtual DtString subnetMask() const;
         virtual void setSubnetMask( const DtString& );

         //! \brief Returns the set of multicast addresses to
         //! subscribe to.
         const std::vector<DtString>& mcastSubscriptionSet() const;
         virtual void setMcastSubscriptionSet( const std::vector<DtString>& );
         virtual void addMcastSubscriptionAddr( const DtString& addr );

         //! \brief Returns the buffer size for the socket
         //! used to send DIS PDU's.
         virtual int socketSendBufferSize() const;
         virtual void setSocketSendBufferSize( int );

         //! \brief Returns the buffer size for the socket
         //! used to receive DIS PDU's.
         virtual int socketReceiveBufferSize() const;
         virtual void setSocketReceiveBufferSize( int );

         //! \brief Returns the time to live if using multicast.
         virtual int multicastTimeToLive() const;
         virtual void setMulticastTimeToLive( int );

         //! @}

         //! @name Translation Settings
         //! @{

         //! \brief Returns true if parameter parseUnknownIds is set to true.
         //! This parameter is used by the globalIdMapper. When set the globalIdMapper
         //! will try to parse string identifiers into DIS IDs.
         virtual bool parseUnknownIds() const;
         virtual void setParseUnknownIds( bool );

         //! \brief Returns whether the \ref DtDisBroker "broker" will
         //! remap DIS ID's.
         //!
         //! If this flag is turned on, the \ref DtDisBroker "broker"
         //! will construct DIS ID's for objects sequentially based on
         //! it's own site ID and host ID.
         virtual bool remapDisIds() const;
         virtual void setRemapDisIds( bool );

         //! if this flag is turned on along with remapDisIds
         //! this will keep track of all ids seen previously
         //! and will use the same values when restarting the exercise
         virtual bool usePersistentEntityIds() const;
         virtual void setUsePersistentEntityIds( bool );

         //! Timeout for wait-listed incomplete interactions.
         virtual DtTime interactionWaitListTimeout() const;
         virtual void setInteractionWaitListTimeout( DtTime );

         //! Whether to send wait-listed incomplete interactions.
         virtual bool sendExpiredWaitListInteractions() const;
         virtual void setSendExpiredWaitListInteractions( bool );

         //! \brief Returns the \ref DtDisBroker "DIS broker's" application
         //! number.
         virtual int applicationNumber() const;
         virtual void setApplicationNumber( int );

         //! \brief Returns the \ref DtDisBroker "DIS broker's" site ID.
         virtual int siteId() const;
         virtual void setSiteId( int );

         //! \brief Returns whether the \ref DtDisBroker "broker" is
         //! using absolute time stamps.
         virtual bool useAbsoluteTimeStamping() const;
         virtual void setUseAbsoluteTimeStamping( bool );

         //! \brief Returns the threshold for location changes to use when sending updates.
         virtual double locationThreshold() const;
         virtual void setLocationThreshold( double );

         //! \brief Returns the threshold for rotation changes to use when sending updates.
         virtual double rotationThreshold() const;
         virtual void setRotationThreshold( double );

         //! \brief Returns the version of the DIS protocol to send PDU's as.
         virtual int protocolVersionToSend() const;
         virtual void setProtocolVersionToSend( int );

         //! \brief Returns the minimum version that the
         //! \ref DtDisBroker "broker" will receive and process.
         virtual int protocolVersionToRecvMin() const;
         virtual void setProtocolVersionToRecvMin( int );

         //! \brief Returns the maximum version that the
         //! \ref DtDisBroker "broker" will receive and process.
         virtual int protocolVersionToRecvMax() const;
         virtual void setProtocolVersionToRecvMax( int );

         //! \brief Returns whether or not articulated parts translating will be disabled.
         virtual bool disableArticulatedParts() const;
         virtual void setDisableArticulatedParts( bool );

         //! Returns whether or not underwater acoustic objects are split into PDUs by type.
         virtual bool splitUnderwaterAcousticPdus() const;
         virtual void setSplitUnderwaterAcousticPdus( bool );

         //! Returns whether or not to publish DI-Guy PDUs.
         virtual bool sendDiGuyPdus() const;
         virtual void setSendDiGuyPdus( bool );

         //! Returns whether or not to publish SEES PDUs.
         virtual bool sendSeesPdus() const;
         virtual void setSendSeesPdus( bool );

         //! Returns whether or not to send relative location PDUs.
         virtual bool sendRelativeLocationPdus() const;
         virtual void setSendRelativeLocationPdus( bool );

         //! @}

         //! @name Debug Settings
         //! @{

         //! \brief Returns whether the DtGlobalIdMapper of the
         //! \ref DtDisBroker "broker" should print out debug statements.
         virtual bool debugGlobalIdMapping() const;
         virtual void setDebugGlobalIdMapping( bool );

         //! \brief Returns whether the DtEntityIdMapper of the
         //! \ref DtDisBroker "broker" should print out debug statements.
         virtual bool debugEntityIdMapping() const;
         virtual void setDebugEntityIdMapping( bool );

         //! \brief Returns whether the DtEventIdMapper of the
         //! \ref DtDisBroker "broker" should print out debug statements.
         virtual bool debugEventIdMapping() const;
         virtual void setDebugEventIdMapping( bool );

         virtual bool dumpGuiToText() const;
         virtual void setDumpGuiToText( bool );

         //! @}

         //! @name Timing Settings
         //! @{

         //! \brief Returns the heartbeat interval.
         //! This is the interval (in seconds) that the
         //! \ref DtDisBroker "broker" will send out heartbeat
         //! updated for DIS objects.
         virtual DtTime heartbeatInterval() const;
         virtual void setHeartbeatInterval( DtTime );

         //! \brief Returns the timeout interval for reflected DIS objects.
         //! This is the time (in seconds) that specifies how long
         //! reflected DIS objects will remain to be processed by
         //! the broker without an update, until they are removed.
         virtual DtTime timeoutInterval() const;
         virtual void setTimeoutInterval( DtTime );

         //! \brief Returns the amount of time (in seconds) the
         //! \ref DtDisBroker "broker" will read from the socket.
         //! If this value is set to -1, the network device will
         //! be read until no more packets remain.
         virtual DtTime drainTimeout() const;
         virtual void setDrainTimeout( DtTime );

         //! \brief Returns the number of PDU's to read per drain.
         virtual int numPdusReadPerTimeCheck() const;
         virtual void setNumPdusReadPerTimeCheck( int );

         //! @}

      protected:

         //! @name Connection Settings.
         //! @{

         //! \brief The port number used to receive DIS PDU's.
         //! Specified by "-P" or "--disPort" on the command line, or
         //! "disPort" in the MTL file.  Defaults to 3000.
         DtConfigVariable<int> myDisPort;

         //! \brief The exercise ID used by the \ref DtDisBroker "broker".
         //! Specified by "-x" or "--exerciseId" on the command line, or
         //! "exerciseId" in the MTL file.  Defaults to 1.
         DtConfigVariable<int> myExerciseId;

         //! \brief The network address to send DIS PDU's to.
         //! Specified by "-A" or "--destinationAddress" on the command line, or
         //! "destAddrString" in the MTL file.  Defaults to "0.0.0.0".
         //! The default value will force the \ref DtDisBroker "broker" to
         //! send PDU's to the first broadcast address found.
         DtConfigVariable<DtString> myDestinationAddress;

         //! \brief The device address that the \ref DtDisBroker "broker" should use to send PDU's.
         //! Specified by "-D" or "--deviceAddress" on the command line, or
         //! "deviceAddress" in the MTL file.  Defaults to "0.0.0.0".
         //! The default value will force the \ref DtDisBroker "broker" to
         //! use the first network device found.
         DtConfigVariable<DtString> myDeviceAddress;

         //! \brief The network mask or prefix length to use.
         //! Specified by "subnetMaskString" in the MTL file.  Defaults to
         //! "". The default value will force the \ref DtDisBroker "broker" to
         //! use the default mask for the address class.
         DtConfigVariable<DtString> mySubnetMask;

         //! \brief The multicast addresses to subscribe to.
         //! Specified by "multicastSubscriptions" in the MTL file.
         //! Defaults to an empty set.
         DtMultiConfigVariable<DtString> myMcastSubscriptionSet;

         //! Specified by "socketSendBufferSize" in the MTL file.
         //! Defaults to 0. The default value will force the
         //! \ref DtDisBroker "broker" to use the operating system's
         //! default size.
         DtConfigVariable<int> mySocketSendBufferSize;

         //! \brief The size of the receive socket buffer
         //! Specified by "socketReceiveBufferSize" in the MTL file.
         //! Defaults to 0. The default value will force the
         //! \ref DtDisBroker "broker" to use the operating system's
         //! default size.
         DtConfigVariable<int> mySocketReceiveBufferSize;

         //! \brief The time to live if using multicast.
         //! Specified by "multicastTimeToLive" in the MTL file.
         //! Defaults to 0.
         DtConfigVariable<int> myMulticastTimeToLive;

         //! @}

         //! @name Translation Settings.
         //! @{

         //! \brief Specifies whether the \ref DtDisBroker "broker"
         //! should parse unknown IDs.
         //! Specified by "parseUnknownIds" in the MTL file.
         //! Defaults to \e false.
         DtConfigVariable<int> myParseUnknownIdsFlag;

         //! \brief Specifies whether the \ref DtDisBroker "broker"
         //! should remap DIS ID's.  See \ref remapDisIds().
         //! Specified by "renameDisObjects" in the MTL file.
         //! Defaults to \e false.
         DtConfigVariable<int> myRemapDisIds;

         //! \brief Specifies whether the \ref DtDisBroker "broker"
         //! should keep remap DIS ID's from session to session.
         //! See \ref usePersistentEntityIds().
         //! Specified by "usePersistentEntityIds" in the MTL file.
         //! Defaults to \e false.
         DtConfigVariable<int> myUsePersistentEntityIds;

         //! \brief The amount of time to wait for valid ID mappings for interactions.
         //! Specified by "interactionWaitListTimeout" in the MTL file.
         //! Defaults to 1.0 (seconds).
         DtConfigVariable<DtTime> myInteractionWaitListTimeout;

         //! \brief Whether or not to send interactions from the wait list.
         //! Specified by "sendExpiredWaitListInteractions" in the MTL file.
         //! Defaults to \e false.
         DtConfigVariable<bool> mySendExpiredWaitListInteractions;

         //! \brief The application number used by the \ref DtDisBroker "broker".
         //! Specified by "-a" or "--applicationNumber" on the command line, or
         //! "applicationNumber" in the MTL file.  Defaults to 27.
         DtConfigVariable<int> myApplicationNumber;

         //! \brief The site ID used by the \ref DtDisBroker "broker".
         //! Specified by "-s" or "--siteId" on the command line, or
         //! "siteId" in the MTL file.  Defaults to 1.
         DtConfigVariable<int> mySiteId;

         //! \brief Specifies whether the \ref DtDisBroker "broker"
         //! should use absolute time-stamping
         //! Specified by "timeStampAbsolute" in the MTL file.
         //! Defaults to \e false.
         DtConfigVariable<int> myUseAbsoluteTimeStamping;

         //! \brief The location threshold for determining when updates should be sent.
         //! Defaults to \e 1.0.
         DtConfigVariable<double> myLocationThreshold;

         //! \brief The rotation threshold for determining when updates should be sent.
         //! Defaults to \e 3 degrees.
         DtConfigVariable<double> myRotationThreshold;

         //! \brief The DIS protocol version to send PDU's as.
         //! Specified by "protocolVersionToSend" in the MTL file.
         //! Defaults to 5.
         DtConfigVariable<int> myProtocolVersionToSend;

         //! \brief The minimum DIS protocol version to receive and process.
         //! Specified by "protocolVersionToRecvMin" in the MTL file.
         //! Defaults to 4.
         DtConfigVariable<int> myProtocolVersionToRecvMin;

         //! \brief The maximum DIS protocol version to receive and process.
         //! Specified by "protocolVersionToRecvMax" in the MTL file.
         //! Defaults to 7.
         DtConfigVariable<int> myProtocolVersionToRecvMax;

         //! \brief Disable Articulated Parts translating flag.
         DtConfigVariable<bool> myDisableArticulatedParts;

         //! \brief If enabled, underwater acoustic objects will
         //! always be published in separate PDUs. Otherwise, all
         //! underwater acoustic objects for a given entity will
         //! share a single PDU.
         DtConfigVariable<bool> mySplitUnderwaterAcousticPdus;

         //! \brief If enabled, outgoing DI-Guy entities will publish
         //! DI-Guy PDUs containing additional DI-Guy information.
         DtConfigVariable<bool> mySendDiGuyPdus;

         //! \brief If enabled, outgoing entities will publish
         //! SEES PDUs containing additional emissions information.
         DtConfigVariable<bool> mySendSeesPdus;

         //! \brief If enabled, outgoing entities and aggregates will publish
         //! relative location PDUs if they have a host entity.
         DtConfigVariable<bool> mySendRelativeLocationPdus;

         //! @}

         //! @name Debug Settings.
         //! @{

         //! \brief Specifies whether the DtGlobalIdMapper should print out
         //! debug statements.
         //! Specified by "debugGlobalIdMapping" in the MTL file.
         //! Defaults to \e false.
         DtConfigVariable<int> myDebugGlobalIdMapping;

         //! \brief Specifies whether the DtEntityIdMapper should print out
         //! debug statements.
         //! Specified by "debugEntityIdMapping" in the MTL file.
         //! Defaults to \e false.
         DtConfigVariable<int> myDebugEntityIdMapping;

         //! \brief Specifies whether the DtEventIdMapper should print out
         //! debug statements.
         //! Specified by "debugEventIdMapping" in the MTL file.
         //! Defaults to \e false.
         DtConfigVariable<int> myDebugEventIdMapping;

         //! \brief If enabled will print a line to the log file
         //! for every object update, creation and destruction.
         //! specified by the "dumpGuiToText" in the MTL file.
         //! Defaults to \e false
         DtConfigVariable<int> myDumpGuiToText;

         //! @}

         //! @name Timing Settings.
         //! @{

         //! \brief The interval at which DIS objects are "heartbeated".
         //! Specified by "heartbeatInterval" in the MTL file.  Defaults to
         //! 5.0 (seconds).
         DtConfigVariable<DtTime> myHeartbeatInterval;

         //! \brief The time it takes to timeout a remote DIS object.
         //! Specified by "timeoutInterval" in the MTL file.  Defaults
         //! to 10.0 (seconds).
         DtConfigVariable<DtTime> myTimeoutInterval;

         //! \brief Specifies the amount time to read from the network
         //! Specified by "drainTimeout" in the MTL file.
         //! Defaults to -1 (read until no more PDU's are found).
         DtConfigVariable<DtTime> myDrainTimeout;

         //! \brief The max number of PDU's to read per drain.
         //! Specified by "numPdusToReadPerTimeCheck" in the MTL file.
         //! Defaults to 100.
         DtConfigVariable<int> myNumPdusReadPerTimeCheck;

         //! @}

         //! \brief Discoverable Criteria
         //! As defined by disDiscoverableCriteria.h, this contains
         //! the requirements for specific translators needed before
         //! choosing to translate or drop an object.
         DtVariableGroup myDiscoverableCriteriaGroup;

         //! Helper class that manages discoverable criteria
         DtDisDiscoverableCriteria* myDiscoverableCriteria;

      };

   }
}
