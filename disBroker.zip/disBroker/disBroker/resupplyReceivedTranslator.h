/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file resupplyReceivedTranslator.h
//! \brief Contains the DtResupplyReceivedTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/resupplyCancelInteraction.h>
#include <portal/pResupplyReceivedInteraction.h>

namespace MAKVrExchange
{

   class DtPortalResupplyReceivedInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides ResupplyReceived interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtResupplyReceivedTranslator
         : public DtDisInteractionTranslator<DtPortalResupplyReceivedInteraction,DtResupplyRecInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Resupply Received" );

         //! \brief CTOR.
         DtResupplyReceivedTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtResupplyReceivedTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalResupplyReceivedInteraction& inter );

         //! \brief Translates the resupply received interaction into the portal.
         virtual DtPortalResupplyReceivedInteraction* translate(
            DtPortalResupplyReceivedInteraction* destination,
            const DtResupplyRecInteraction& source );

         //! \brief Translates the resupply received interaction from the portal.
         virtual DtResupplyRecInteraction* translate( DtResupplyRecInteraction* destination,
            const DtPortalResupplyReceivedInteraction& source );

      };

   }
}
