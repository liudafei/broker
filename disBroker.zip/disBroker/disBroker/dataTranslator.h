/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file dataTranslator.h
//! \brief Contains the DtDataTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/dataInteraction.h>
#include <portal/pDataInter.h>

namespace MAKVrExchange
{

   class DtPortalDataInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides Data interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDataTranslator
         : public DtDisInteractionTranslator<DtPortalDataInteraction,DtDataInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Data" );

         //! \brief CTOR.
         DtDataTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtDataTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalDataInteraction& inter );

         //! \brief Translates the data interaction into the portal.
         virtual DtPortalDataInteraction* translate(
            DtPortalDataInteraction* destination,
            const DtDataInteraction& source );

         //! \brief Translates the portal data interaction from the portal.
         virtual DtDataInteraction* translate( DtDataInteraction* destination,
            const DtPortalDataInteraction& source );

      };

   }
}
