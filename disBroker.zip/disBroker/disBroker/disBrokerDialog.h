/****************************************************************************
 * Copyright (c) 2015 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disBrokerDialog.h
//! \brief Contains the DtDisBrokerDialog class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/dllExport.h>
#include <widgets/brokerDialog.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      class DtDisBroker;
      class DtDisBrokerInitializer;

      //! \brief Responsible for displaying all information about the broker.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDisBrokerDialog : public DtBrokerDialog
      {  Q_OBJECT;
      public:

         //! \brief Static creation method.
         //! Instantiates a new broker dialog.
         //! Default creator for DIS broker dialogs.
         static DtBrokerDialog* create( DtBroker* broker,
            DtBrokerInitializer* init, QWidget* parent = 0 );

      protected:

         //! \brief CTOR.
         DtDisBrokerDialog( DtDisBroker* broker, DtDisBrokerInitializer* init,
            QWidget* parent = 0 );

      public:

         //! \brief Virtual DTOR.
         virtual ~DtDisBrokerDialog();

         //! \brief Accessor for casted DIS Initializer.
         virtual DtDisBrokerInitializer* disInitializer();

      protected:

         //! @name Initialization Methods
         //! @{

         //! \brief Initialize the headers for the object list views.
         virtual void initObjectListViewHeaders();

         //! \brief Instantiate the Connection Settings Widget.
         virtual DtConnectionSettingsWidget* instantiateConnectionSettingsWidget();

         //! \brief Instantiate the General Settings Widget.
         virtual DtGeneralSettingsWidget* instantiateGeneralSettingsWidget();

         //! @}

      private:

         //! Copy CTOR not implemented -- Do Not Copy!
         DtDisBrokerDialog( const DtDisBrokerDialog& other );

         //! Assignment Operator not implemented -- Do Not Copy!
         DtDisBrokerDialog& operator = ( const DtDisBrokerDialog& other );

      protected:

         DtDisBroker* myDisBroker;

      };

   }
}
