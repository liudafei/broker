/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file repairResponseTranslator.cxx
//! \brief Contains the DtRepairResponseTranslator class definition.
//! \ingroup disBroker

#include <disBroker/repairResponseTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtRepairResponseTranslator::DtRepairResponseTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalRepairResponseInteraction::theKind )
      {
      }

      DtRepairResponseTranslator::~DtRepairResponseTranslator()
      {
      }

      bool DtRepairResponseTranslator::isPortalDiscoverable(
         const DtPortalRepairResponseInteraction& inter )
      {
         return ( testGlobalIdMapping("Receiving ID",inter.receivingId())
            && testGlobalIdMapping("Repairing ID",inter.repairingId()) );
      }

      DtPortalRepairResponseInteraction* DtRepairResponseTranslator::translate(
         DtPortalRepairResponseInteraction* destination, const DtRepairResponseInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setRepairingId( disBroker()->convertGlobalId(source.repairingId()) );
         destination->setRepairResult( source.repairResult() );
         return destination;
      }

      DtRepairResponseInteraction* DtRepairResponseTranslator::translate(
         DtRepairResponseInteraction* destination, const DtPortalRepairResponseInteraction& source )
      {
         destination->setReceivingId( disBroker()->convertGlobalId(source.receivingId()) );
         destination->setRepairingId( disBroker()->convertGlobalId(source.repairingId()) );
         destination->setRepairResult( (DtRepairResult) source.repairResult() );
         return destination;
      }

   }
}
