/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file startTranslator.h
//! \brief Contains the DtStartTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/startResumeInteraction.h>
#include <portal/pStartInter.h>

namespace MAKVrExchange
{

   class DtPortalStartInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides Start interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtStartTranslator
         : public DtDisInteractionTranslator<DtPortalStartInteraction,DtStartResumePdu>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Start" );

         //! \brief CTOR.
         DtStartTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtStartTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalStartInteraction& inter );

         //! \brief Translates the start interaction into the portal.
         virtual DtPortalStartInteraction* translate( DtPortalStartInteraction* destination,
             const DtStartResumePdu& source );

         //! \brief Translates the start interaction from the portal.
         virtual DtStartResumePdu* translate( DtStartResumePdu* destination,
            const DtPortalStartInteraction& source );

      };

   }
}
