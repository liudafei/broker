/*****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file underwaterAcousticsPublisherManager.cxx
//! \brief Contains the DtUnderwaterAcousticsPublisherManager class definition.
//! \ingroup disBroker

#include <disBroker/underwaterAcousticsPublisherManager.h>
#include <vl/underwaterAcousticsPublisher.h>
#include <vlutil/vlPrint.h>
#include <vlutil/vlUtil.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtUnderwaterAcousticsPublisherManager::DtUnderwaterAcousticsPublisherManager()
         : myPortalIdToPublisherMap()
         , myPublisherUsageCountsMap()
      {
      }

      DtUnderwaterAcousticsPublisherManager::~DtUnderwaterAcousticsPublisherManager()
      {
         PortalIdToPublisherMap::iterator itr = myPortalIdToPublisherMap.begin();
         PortalIdToPublisherMap::iterator end = myPortalIdToPublisherMap.end();
         for ( ; itr != end; ++itr )
         {
            DtDELETE( itr->second );
         }
         myPublisherUsageCountsMap.clear();
         myPortalIdToPublisherMap.clear();
      }

      DtUnderwaterAcousticsPublisher*
         DtUnderwaterAcousticsPublisherManager::findPublisher(
            const PortalId& hostId ) const
      {
         PortalIdToPublisherMap::const_iterator itr =
            myPortalIdToPublisherMap.find( hostId );
         if ( itr != myPortalIdToPublisherMap.end() )
         {
            return itr->second;
         }
         return NULL;
      }

      bool DtUnderwaterAcousticsPublisherManager::registerPublisher(
         const PortalId& hostId, DtUnderwaterAcousticsPublisher* publisher )
      {
         PortalIdToPublisherMap::iterator itr = myPortalIdToPublisherMap.find( hostId );
         if ( itr != myPortalIdToPublisherMap.end() )
         {
            DtWarn << "Underwater Acoustics Publisher registration requested for"
               " host identifier that already has a publisher." << std::endl;
            return false;
         }

         myPortalIdToPublisherMap.insert( itr, std::make_pair(hostId,publisher) );
         return true;
      }

      void DtUnderwaterAcousticsPublisherManager::checkoutPublisher(
         DtUnderwaterAcousticsPublisher* publisher )
      {
         // Abort if publisher is null for some reason.
         if ( ! publisher )
         {
            return;
         }

         ++myPublisherUsageCountsMap[publisher];
      }

      void DtUnderwaterAcousticsPublisherManager::releasePublisher( const PortalId& hostId )
      {
         // Find the publisher using the hostId to publisher map.
         PortalIdToPublisherMap::iterator pubItr =
            myPortalIdToPublisherMap.find( hostId );
         if ( pubItr == myPortalIdToPublisherMap.end() )
         {
            DtWarn << "Underwater Acoustics publisher not found when attempting to "
               "release the publisher for host object: " << hostId << std::endl;
            return;
         }

         // Find usage count in the usage counts map.
         PublisherUsageCountsMap::iterator countItr =
            myPublisherUsageCountsMap.find( pubItr->second );
         if ( countItr != myPublisherUsageCountsMap.end() )
         {
            // If count is 0 or negative after decrement...
            if ( countItr->second < 2 )
            {
               // Delete the publisher and remove from maps.
               DtUnderwaterAcousticsPublisher* publisher = pubItr->second;
               myPublisherUsageCountsMap.erase( countItr );
               myPortalIdToPublisherMap.erase( pubItr );
               DtDELETE( publisher );
               return;
            }
         }

         // Decrement the usage count.
         --myPublisherUsageCountsMap[pubItr->second];
      }

      int DtUnderwaterAcousticsPublisherManager::numPublishers() const
      {
         return myPortalIdToPublisherMap.size();
      }

      void DtUnderwaterAcousticsPublisherManager::tickPublishers()
      {
         PortalIdToPublisherMap::iterator itr = myPortalIdToPublisherMap.begin();
         PortalIdToPublisherMap::iterator end = myPortalIdToPublisherMap.end();
         for ( ; itr != end; ++itr )
         {
            itr->second->tick();
         }
      }

   }
}
