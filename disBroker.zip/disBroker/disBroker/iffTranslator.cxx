/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file iffTranslator.cxx
//! \brief Contains the DtIffTranslator class definition.
//! \ingroup disBroker

#include <disBroker/iffTranslator.h>
#include <disBroker/disBrokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtIffTranslator::DtIffTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalIffObject::theKind )
      {
      }

      DtIffTranslator::~DtIffTranslator()
      {
      }

      bool DtIffTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedIffObject* refObj )
      {
         DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->iffNeedsEntityId() )
         {
            DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::IffType;
            DtEntityIdentifier newId = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
               refObj->sr()->identifier(), &objType );
            if ( newId == DtEntityIdentifier::nullId() )
            {
               newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
                  refObj->sr()->entityIdentifier() );
            }
            if ( newId == DtEntityIdentifier::nullId() )
            {
               DtInfo << "DtIffTranslator: " << brokerObj->objectName()
                  << ": Entity Id not present, object incomplete" << std::endl;
               brokerObj->setDropReason( "Missing Entity ID" );
               return false;
            }
         }
         if ( discoveryCriteria->iffNeedsHostId()
            && refObj->sr()->hostObjectIdentifier() == "" )
         {
            DtInfo << "DtIffTranslator: " << brokerObj->objectName()
               << ": Host Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Host ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<IFF_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedIffObject* refObj,
         const DtString& identifier )
      {
         // Get and convert the identifier.
         DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::IffType;
         DtGlobalIdMapper::DisId newId = disBroker()->globalIdMapper()
            ->convertPortalGidToDisGid( identifier.string(), &objType );
         if ( newId == DtEntityIdentifier::nullId() )
         {
            newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
               refObj->sr()->entityIdentifier() );
         }
         return newId;
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<IFF_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedIffObject* refObj, const DtEntityIdentifier& name )
      {
         DtIffPublisher* publisher = NULL;
         try
         {
            // Instantiate the publisher.
            publisher = new DtIffPublisher(
               (DtIffAtcNavaidsSysType) refObj->sr()->systemType(),
               disBroker()->connection(), name );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      bool DtIffTranslator::performDisGlobalIdMapping(
         const DtObjectPublisher* publisher, const DtPortalReflectedIffObject& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performDisGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::IffType );
      }

      void DtIffTranslator::deleteDisPublisher( DtBrokerObject* brokerObj )
      {
         DtIffPublisher* publisher =
            static_cast<DtIffPublisher*>( brokerObj->publisherPtr() );
         const DtPortalReflectedIffObject* refObj =
            static_cast<const DtPortalReflectedIffObject*>(
               brokerObj->reflectedObjPtr() );
         if ( publisher && refObj )
         {
            disBroker()->globalIdMapper()->remove(
               refObj->sr()->entityIdentifier(), DtGlobalIdMapper::IffType );
            brokerObj->setPublisherPtr( 0 );
            DtDELETE( publisher );
         }
      }

      DtString DtIffTranslator::portalObjectName( const DtReflectedIff* refObj ) const
      {
         DtString newObjectName(refObj->globalId().string());
         newObjectName += "-";
         newObjectName += refObj->isr()->systemType();
         newObjectName += "-";
         newObjectName += refObj->isr()->systemName();
         newObjectName += "-";
         newObjectName += refObj->isr()->systemDesignator();
         newObjectName += "Ivrx";
         return newObjectName;
      }

      bool DtIffTranslator::performPortalGlobalIdMapping(
         const DtPortalIffObjectPublisher* publisher, const DtReflectedIff& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performPortalGlobalIdMapping( publisher,
            refObj, DtGlobalIdMapper::IffType, refObj.isr()->systemType() );
      }

      DtPortalIffObject* DtIffTranslator::translate( DtPortalIffObject* destination,
         const DtIffStateRepository& source, const DtReflectedIff& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         // Base class attributes for DtPortalIffObject
         destination->setEventNumber( source.eventId().eventNum() );
         destination->setEventIssuingObjectIdentifier( disBroker()->globalIdMapper()
            ->convertDisGidToPortalGid(DtEntityIdentifier(source.eventId().site(),
               source.eventId().host(),0)) );

         destination->setSystemMode( source.systemMode() );
         destination->setSystemName( source.systemName() );
         destination->setSystemType( source.systemType() );
         destination->setModeCAltitudeAvailable( source.modeCAltitudeAvailable() );

         // Layer 1 fields
         destination->setSystemIsOn( source.systemIsOn() );
         destination->setSystemIsOperational( source.systemIsOperational() );
         destination->setFundamentalOpDataParam1( source.modeEnabled(1) );
         destination->setFundamentalOpDataParam2( source.modeEnabled(2) );
         destination->setFundamentalOpDataParam3( source.modeEnabled(3) );
         destination->setFundamentalOpDataParam4( source.modeEnabled(4) );
         destination->setFundamentalOpDataParam5( source.modeEnabled(5) );
         destination->setFundamentalOpDataParam6( source.modeEnabled(6) );

         destination->setAlternateMode4( source.alternateMode4() );
         destination->setEmergencyOn( source.emergencyOn() );
         destination->setIdentSquawkFlashOn( source.identSquawkFlashOn() );
         destination->setStiOn( source.stiOn() );

         destination->setMode1Code( source.modeCode(1) );
         destination->setMode1IsOn( source.modeIsOn(1) );
         destination->setMode1IsDamaged( source.modeIsDamaged(1) );
         destination->setMode1IsMalfunctioning( source.modeIsMalfunctioning(1) );

         destination->setMode2Code( source.modeCode(2) );
         destination->setMode2IsOn( source.modeIsOn(2) );
         destination->setMode2IsDamaged( source.modeIsDamaged(2) );
         destination->setMode2IsMalfunctioning( source.modeIsMalfunctioning(2) );

         destination->setMode3Code( source.modeCode(3) );
         destination->setMode3IsOn( source.modeIsOn(3) );
         destination->setMode3IsDamaged( source.modeIsDamaged(3) );
         destination->setMode3IsMalfunctioning( source.modeIsMalfunctioning(3) );

         destination->setMode4PseudoCrypto( source.mode4PseudoCrypto() );
         destination->setMode4IsOn( source.modeIsOn(4) );
         destination->setMode4IsDamaged( source.modeIsDamaged(4) );
         destination->setMode4IsMalfunctioning( source.modeIsMalfunctioning(4) );

         destination->setModeCAltitude( source.modeCAltitude() );
         destination->setMode5IsOn( source.modeIsOn(5) );
         destination->setMode5IsDamaged( source.modeIsDamaged(5) );
         destination->setMode5IsMalfunctioning( source.modeIsMalfunctioning(5) );

         destination->setModeSIsTcasI( source.modeSIsTcasI() );
         destination->setMode6IsOn( source.modeIsOn(6) );
         destination->setMode6IsDamaged( source.modeIsDamaged(6) );
         destination->setMode6IsMalfunctioning( source.modeIsMalfunctioning(6) );

         // Layer 2 fields
         if ( source.layer2DataAvailable() )
         {
            destination->setLayer2DataAvailable( true );
            destination->setBeamAzimuthCenter( source.beamAzimuthCenter() );
            destination->setBeamAzimuthSweep( source.beamAzimuthSweep() );
            destination->setBeamElevationCenter( source.beamElevationCenter() );
            destination->setBeamElevationSweep( source.beamElevationSweep() );
            destination->setBeamSweepSync( source.beamSweepSync() );

            DtIffAtcNavaidsParameter temp;
            DtAttributeValuePairList attributes;
            for ( int index = 0; index < source.numParameterSets(); ++index )
            {
               if ( source.getParamData(index,temp) )
               {
                  DtVariableLengthData data( (const char *) &temp, sizeof(temp) );
                  attributes.push_back( DtAttributeValuePair("",data) );
               }
            }
            destination->setFundamentalParameterData( attributes );
            destination->setSecondaryOperationalDataParameter1(
               source.secondaryOperationalDataParameter1() );
            destination->setSecondaryOperationalDataParameter2(
               source.secondaryOperationalDataParameter2() );
         }
         else
         {
            destination->setLayer2DataAvailable( false );
         }

         // Derived class attributes: None at this time

         return destination;
      }

      DtIffStateRepository* DtIffTranslator::translate( DtIffStateRepository* destination,
         const DtPortalIffObject& source, const DtPortalReflectedIffObject& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         // Base class attributes for DtPortalIffObject
         DtEntityIdentifier eventIssuingObjectId( disBroker()->globalIdMapper()
            ->convertPortalGidToDisGid(source.eventIssuingObjectIdentifier()) );
         destination->setEventId( DtEventId(eventIssuingObjectId.site(),
            eventIssuingObjectId.host(),source.eventNumber()) );

         destination->setSystemMode( source.systemMode() );
         destination->setSystemName( (DtIffAtcNavaidsSysName) source.systemName() );
         destination->setSystemType( (DtIffAtcNavaidsSysType) source.systemType() );
         destination->setModeCAltitudeAvailable( source.modeCAltitudeAvailable() );

         // Layer 1 fields
         destination->setSystemIsOn( source.systemIsOn() );
         destination->setSystemIsOperational( source.systemIsOperational() );
         destination->setModeEnabled( 1, source.fundamentalOpDataParam1() );
         destination->setModeEnabled( 2, source.fundamentalOpDataParam2() );
         destination->setModeEnabled( 3, source.fundamentalOpDataParam3() );
         destination->setModeEnabled( 4, source.fundamentalOpDataParam4() );
         destination->setModeEnabled( 5, source.fundamentalOpDataParam5() );
         destination->setModeEnabled( 6, source.fundamentalOpDataParam6() );

         destination->setAlternateMode4( source.alternateMode4() );
         destination->setEmergencyOn( source.emergencyOn() );
         destination->setIdentSquawkFlashOn( source.identSquawkFlashOn() );
         destination->setStiOn( source.stiOn() );

         destination->setModeCode( 1, source.mode1Code() );
         destination->setModeIsOn( 1, source.mode1IsOn() );
         destination->setModeIsDamaged( 1, source.mode1IsDamaged() );
         destination->setModeIsMalfunctioning( 1, source.mode1IsMalfunctioning() );

         destination->setModeCode( 2, source.mode2Code() );
         destination->setModeIsOn( 2, source.mode2IsOn() );
         destination->setModeIsDamaged( 2, source.mode2IsDamaged() );
         destination->setModeIsMalfunctioning( 2, source.mode2IsMalfunctioning() );

         destination->setModeCode( 3, source.mode3Code() );
         destination->setModeIsOn( 3, source.mode3IsOn() );
         destination->setModeIsDamaged( 3, source.mode3IsDamaged() );
         destination->setModeIsMalfunctioning( 3, source.mode3IsMalfunctioning() );

         destination->setMode4PseudoCrypto( source.mode4PseudoCrypto() );
         destination->setModeIsOn( 4, source.mode4IsOn() );
         destination->setModeIsDamaged( 4, source.mode4IsDamaged() );
         destination->setModeIsMalfunctioning( 4, source.mode4IsMalfunctioning() );

         destination->setModeCAltitude( source.modeCAltitude() );
         destination->setModeIsOn( 5, source.mode5IsOn() );
         destination->setModeIsDamaged( 5, source.mode5IsDamaged() );
         destination->setModeIsMalfunctioning( 5, source.mode5IsMalfunctioning() );

         destination->setModeSIsTcasI( source.modeSIsTcasI() );
         destination->setModeIsOn( 6, source.mode6IsOn() );
         destination->setModeIsDamaged( 6, source.mode6IsDamaged() );
         destination->setModeIsMalfunctioning( 6, source.mode6IsMalfunctioning() );

         // Layer 2 fields
         if ( source.layer2DataAvailable() )
         {
            destination->setLayer2DataAvailable( true );
            destination->setBeamAzimuthCenter( source.beamAzimuthCenter() );
            destination->setBeamAzimuthSweep( source.beamAzimuthSweep() );
            destination->setBeamElevationCenter( source.beamElevationCenter() );
            destination->setBeamElevationSweep( source.beamElevationSweep() );
            destination->setBeamSweepSync( source.beamSweepSync() );

            DtAttributeValuePairList attributes = source.fundamentalParameterData();
            DtAttributeValuePairList::iterator pos = attributes.begin();
            DtAttributeValuePairList::iterator end = attributes.end();
            destination->setNumParameterSets( attributes.size() );
            for ( int index = 0; pos != attributes.end(); ++pos )
            {
               DtIffAtcNavaidsParameter* data = (DtIffAtcNavaidsParameter*) pos->second.data();
               destination->setParamData( index++, *data );
            }

            destination->setSecondaryOperationalDataParameter1(
               (DtIffOperationalParameter1) source.secondaryOperationalDataParameter1() );
            destination->setSecondaryOperationalDataParameter2(
               (DtIffOperationalParameter2) source.secondaryOperationalDataParameter2() );
         }
         else
         {
            destination->setLayer2DataAvailable( false );
         }

         // Derived class attributes: none at this time.

         return destination;
      }

   }
}
