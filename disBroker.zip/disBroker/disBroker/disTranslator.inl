/****************************************************************************
 * Copyright (c) 2017 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file disTranslator.inl
//! \brief Contains the DtDisObjectTranslator and DtDisInteractionTranslator class definitions.
//! \ingroup disBroker

#ifndef _disTranslator_INL_
#error "Inline definitions file must be included from declaring header."
#endif

#include <disBroker/disBroker.h>
#include <disBroker/entityIdMapper.h>
#include <disBroker/disBrokerInitializer.h>

#include <portal/requestTransDiagnosticMessage.h>
#include <portal/transDiagnosticMessage.h>
#include <portal/pInteraction.h>

#include <broker/brokerObject.h>

#include <vl/stateRepository.h>
#include <vl/objectPublisher.h>
#include <vl/reflectedObject.h>
#include <vl/exerciseConn.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DIS_TEMPLATE_LIST
      DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::DtDisObjectTranslator(
            DtBroker* broker, const DtString& name, DtPortalMessageKind kind )
         : DtBaseObjectTranslator<T_PortalObject,T_PortalReflectedObject>(
            broker, name, kind )
         , myDisReflectedList( 0 )
         , myPortalPublisherMap()
         , myDisPublisherMap()
         , myTransDebugNames()
      {
         if ( disBroker()->connection() == NULL )
         {
            DtTHROW_NEW( DtInvalidInput, "Attempted to instantiate " + this->name()
               + " translator with an invalid exercise connection." );
         }

         // Listen for translation diagnostic message requests.
         DtRequestTranslationDiagnosticMessage::addCallback(
            broker->portalConnection(), requestTransDiagCb, this );
      }

      DIS_TEMPLATE_LIST
      DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::~DtDisObjectTranslator()
      {
         // Stop listening for translation diagnostic message requests.
         DtRequestTranslationDiagnosticMessage::removeCallback(
            this->myBroker->portalConnection(), requestTransDiagCb, this );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::enableReflectTranslator( bool enabled )
      {
         if ( this->myReflectEnabled != enabled )
         {
            if ( enabled )
            {
               this->initializeDisCallbacks();
            }
            else
            {
               this->removeDisCallbacks();
            }
            this->myReflectEnabled = enabled;
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::forceUpdateAll()
      {
         PortalToDisReflectedMap::iterator itr = myDisPublisherMap.begin();
         PortalToDisReflectedMap::iterator end = myDisPublisherMap.end();
         for ( ; itr != end; ++itr )
         {
            if ( itr->second->publisherPtr() && itr->second->isPublishable() )
            {
               DtObjectPublisher* publisher =
                  static_cast<DtObjectPublisher*>( itr->second->publisherPtr() );
               publisher->forceUpdate();
            }
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::tick()
      {
         try
         {
            DtBrokerObject* brokerObj;

            DisToPortalReflectedMap::iterator dpItr = myPortalPublisherMap.begin();
            DisToPortalReflectedMap::iterator dpEnd = myPortalPublisherMap.end();
            for ( ; dpItr != dpEnd; ++dpItr )
            {
               brokerObj = dpItr->second;
               DtPortalObjectPublisherTemplate<T_PortalObject>* publisher =
                  static_cast<DtPortalObjectPublisherTemplate<T_PortalObject>*>(
                     brokerObj->publisherPtr() );
               if ( publisher && brokerObj->isPublishable() )
               {
                  try
                  {
                     publisher->tick();
                  }
                  DtCATCH_AND_PROPAGATE( DtException )
               }
            }

            PortalToDisReflectedMap::iterator pdItr = myDisPublisherMap.begin();
            PortalToDisReflectedMap::iterator pdEnd = myDisPublisherMap.end();
            for ( ; pdItr != pdEnd; ++pdItr )
            {
               brokerObj = pdItr->second;
               T_DisObjectPublisher* publisher =
                  static_cast<T_DisObjectPublisher*>( brokerObj->publisherPtr() );
               if ( publisher && brokerObj->isPublishable() )
               {
                  try
                  {
                     publisher->tick();
                  }
                  DtCATCH_AND_PROPAGATE( DtException );
               }
            }
         }
         DtCATCH_AND_PROPAGATE( DtException );
      }

      DIS_TEMPLATE_LIST
      DtDisBroker* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::disBroker()
      {
         return (DtDisBroker*) this->myBroker;
      }

      DIS_TEMPLATE_LIST
      const DtDisBroker* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::disBroker() const
      {
         return (const DtDisBroker*) this->myBroker;
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::initializeDisCallbacks()
      {
         myDisReflectedList = new T_DisReflectedObjectList( disBroker()->connection() );
         myDisReflectedList->addObjectAdditionCallback( (void(*)(DtReflectedObject*,void*)) disObjectAddedCb, this );
         myDisReflectedList->addObjectRemovalCallback( (void(*)(DtReflectedObject*,void*)) disObjectDeletedCb, this );
         myDisReflectedList->setDiscoveryCondition( (bool(*)(DtReflectedObject*,void*)) disDiscoveryCriteria, this );
         myDisReflectedList->setTimeoutInterval( disBroker()->timeoutInterval() );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::removeDisCallbacks()
      {
         if ( this->myReflectEnabled && myDisReflectedList )
         {
            // Callbacks will be removed when the list is deleted. Also,
            // removal callbacks will need to be called on list deletion.
            DtDELETE( myDisReflectedList );
         }
      }

      DIS_TEMPLATE_LIST
      DtBrokerObject* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::createBrokerObject(
         const DtReflectedObject* refObj )
      {
         DtBrokerObject* brokerObj = new DtBrokerObject( false, this->name() );
         brokerObj->setObjectName( refObj->globalId().string() );
         brokerObj->setFirstUpdate( disBroker()->simTime() );
         brokerObj->setLastUpdate( disBroker()->simTime() );
         brokerObj->setReflectedObjPtr( refObj );
         myPortalPublisherMap[refObj] = brokerObj;

         return brokerObj;
      }

      DIS_TEMPLATE_LIST
      DtBrokerObject* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::createBrokerObject(
         const DtPortalReflectedObject* refObj )
      {
         DtBrokerObject* brokerObj =  new DtBrokerObject( true, this->name() );
         brokerObj->setObjectName( refObj->baseObject()->identifier() );
         brokerObj->setFirstUpdate( disBroker()->simTime() );
         brokerObj->setLastUpdate( disBroker()->simTime() );
         brokerObj->setReflectedObjPtr( refObj );
         myDisPublisherMap[refObj] = brokerObj;

         return brokerObj;
      }

      DIS_TEMPLATE_LIST
      DtBrokerObject* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::findBrokerObject(
         const DtReflectedObject* refObj )
      {
         DisToPortalReflectedMap::iterator pos = myPortalPublisherMap.find( refObj );
         if ( pos != myPortalPublisherMap.end() )
         {
            return pos->second;
         }
         return 0;
      }

      DIS_TEMPLATE_LIST
      DtBrokerObject* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::findBrokerObject(
         const DtPortalReflectedObject* refObj )
      {
         PortalToDisReflectedMap::iterator pos = myDisPublisherMap.find( refObj );
         if ( pos != myDisPublisherMap.end() )
         {
            return pos->second;
         }
         return 0;
      }

      DIS_TEMPLATE_LIST
      DtBrokerObject* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::findBrokerObject(
         const DtString& objectName )
      {
         // Abort if no name was given.
         if ( objectName.isEmpty() )
         {
            return 0;
         }

         {  // Iterate over the Reflected HLA Objects and check for the right object name.
            DisToPortalReflectedMap::iterator itr = myPortalPublisherMap.begin();
            DisToPortalReflectedMap::iterator end = myPortalPublisherMap.end();
            for ( ; itr != end; ++itr )
            {
               if ( itr->second->objectName() == objectName )
               {
                  return itr->second;
               }
            }
         }

         {  // Iterate over the Reflected HLA Objects and check for the right object name.
            PortalToDisReflectedMap::iterator itr = myDisPublisherMap.begin();
            PortalToDisReflectedMap::iterator end = myDisPublisherMap.end();
            for ( ; itr != end; ++itr )
            {
               if ( itr->second->objectName() == objectName )
               {
                  return itr->second;
               }
            }
         }

         // Object wasn't found, return null.
         return 0;
      }

      DIS_TEMPLATE_LIST
      DtBrokerObject* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::releaseBrokerObject(
         const DtReflectedObject* refObj )
      {
         DisToPortalReflectedMap::iterator pos = myPortalPublisherMap.find( refObj );
         if ( pos != myPortalPublisherMap.end() )
         {
            DtBrokerObject* brokerObj = pos->second;
            myPortalPublisherMap.erase( pos );
            return brokerObj;
         }
         return 0;
      }

      DIS_TEMPLATE_LIST
      DtBrokerObject* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::releaseBrokerObject(
         const DtPortalReflectedObject* refObj )
      {
         PortalToDisReflectedMap::iterator pos = myDisPublisherMap.find( refObj );
         if ( pos != myDisPublisherMap.end() )
         {
            DtBrokerObject* brokerObj = pos->second;
            myDisPublisherMap.erase( pos );
            return brokerObj;
         }
         return 0;
      }

      DIS_TEMPLATE_LIST
      bool DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::disDiscoveryCriteria(
         DtReflectedObject* refObj, void* usr )
      {
         if ( usr && refObj )
         {
            return static_cast<DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>*>(usr)
               ->isDisDiscoverable( refObj );
         }
         return false;
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::disObjectAddedCb(
         T_DisReflectedObject* refObj, void* usr )
      {
         DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>* et =
            (DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>*) usr;
         et->discoverDisObject( *refObj );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::disObjectUpdatedCb(
         T_DisReflectedObject* refObj, void* usr )
      {
         DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>* et =
            (DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>*) usr;
         et->receiveDisUpdate( *refObj );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::disObjectDeletedCb(
         T_DisReflectedObject* refObj, void* usr )
      {
         DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>* et =
            (DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>*) usr;
         et->removeDisObject( *refObj );
      }

      DIS_TEMPLATE_LIST
      bool DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::isPortalDiscoverable(
         const DtPortalReflectedObject* refObj )
      {
         // If publishing is disabled, the object isn't discoverable.
         if ( ! this->myPublishEnabled )
         {
            return false;
         }

         // Make sure the broker object for this object exists.
         DtBrokerObject* brokerObj = findBrokerObject( refObj );
         bool alreadyDiscovered = true;
         if ( ! brokerObj )
         {
            brokerObj = createBrokerObject( refObj );
            alreadyDiscovered = false;
         }

         // Check if the object itself is publishable.
         T_PortalReflectedObject* castRefObj = (T_PortalReflectedObject*) refObj;
         bool isPublishable = isDisPublishable( brokerObj, castRefObj );

         // Call the appropriate broker object callbacks.
         if ( alreadyDiscovered )
         {
            this->callObjectUpdateCallbacks( brokerObj );
         }
         else
         {
            this->callObjectDiscoverCallbacks( brokerObj );
         }

         // Return the publishable state.
         return isPublishable;
      }

      DIS_TEMPLATE_LIST
      bool DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::isDisPublishable(
         DtBrokerObject* brokerObj, const T_PortalReflectedObject* refObj )
      {
         // By default all objects are publishable.
         brokerObj->setDropReason( "" );
         return true;
      }

      DIS_TEMPLATE_LIST
      bool DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::isDisDiscoverable(
         const DtReflectedObject* refObj )
      {
         // If reflecting is disabled, the object isn't discoverable.
         if ( ! this->myReflectEnabled )
         {
            return false;
         }

         // Make sure the broker object for this object exists.
         DtBrokerObject* brokerObj = findBrokerObject( refObj );
         bool alreadyDiscovered = true;
         if ( ! brokerObj )
         {
            brokerObj = createBrokerObject( refObj );
            alreadyDiscovered = false;
         }

         // Check if the object itself is publishable.
         bool isPublishable = this->isPortalPublishable( brokerObj );

         // Call the appropriate broker object callbacks.
         if ( alreadyDiscovered )
         {
            this->callObjectUpdateCallbacks( brokerObj );
         }
         else
         {
            this->callObjectDiscoverCallbacks( brokerObj );
         }

         // Return the publishable state.
         return isPublishable;
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::callObjectDiscoverCallbacks(
         const DtBrokerObject* brokerObj )
      {
         // Dump GUI to text.
         if ( disBroker()->dumpGuiToText() )
         {
            printDumpGuiToText( *brokerObj, discover );
         }

         // Call object discovery callbacks.
         BaseTranslatorClass::callObjectDiscoverCallbacks( brokerObj );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::callObjectUpdateCallbacks(
         const DtBrokerObject* brokerObj )
      {
         // Dump GUI to text.
         if ( disBroker()->dumpGuiToText() )
         {
            printDumpGuiToText( *brokerObj, update );
         }

         // Call object update callbacks.
         BaseTranslatorClass::callObjectUpdateCallbacks( brokerObj );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::callObjectRemoveCallbacks(
         const DtBrokerObject* brokerObj )
      {
         // Dump GUI to text.
         if ( disBroker()->dumpGuiToText() )
         {
            printDumpGuiToText( *brokerObj, remove );
         }

         // Call object removal callbacks.
         BaseTranslatorClass::callObjectRemoveCallbacks( brokerObj );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::discoverDisObject(
         T_DisReflectedObject& refObj )
      {
         try
         {
            DtBrokerObject* brokerObj = findBrokerObject( &refObj );
            assert( brokerObj );

            brokerObj->setLastUpdate( disBroker()->simTime() );
            brokerObj->setObjectName( refObj.globalId().string() );
            brokerObj->setIsDiscovered( true );

            createPortalPublisher( brokerObj );

            refObj.addPostUpdateCallback( disObjectUpdatedCb, this );
            receiveDisUpdate( refObj );
         }
         DtCATCH_AND_PROPAGATE( DtException );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::discoverPortalObject(
         const T_PortalReflectedObject& refObj )
      {
         try
         {
            DtBrokerObject* brokerObj = findBrokerObject( &refObj );
            assert( brokerObj );

            brokerObj->setLastUpdate( disBroker()->simTime() );
            brokerObj->setObjectName( refObj.sr()->identifier() );
            brokerObj->setIsDiscovered( true );

            createDisPublisher( brokerObj );

            refObj.addUpdateCallback( this->portalObjectUpdatedCb, this );
            receivePortalUpdate( refObj );
         }
         DtCATCH_AND_PROPAGATE( DtException );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::createDisPublisher(
         DtBrokerObject* brokerObj )
      {
         try
         {
            // Get the reflected object and make sure it exists.
            const T_PortalReflectedObject* refObj =
               static_cast<const T_PortalReflectedObject*>( brokerObj->reflectedObjPtr() );
            assert( refObj );

            // Get and convert the identifier and create the publisher.
            DtString objectName = disObjectName( refObj );
            DtGlobalIdMapper::DisId newId = mapIdentifier( refObj, objectName );

            // Workaround for OTD #58282:
            // Null and Default IDs should be treated the same during publisher instantiation.
            newId = ( newId == DtEntityIdentifier::nullId() ? DtEntityIdentifier::defaultId() : newId );

            DtObjectPublisher* publisher = instantiateDisPublisher( refObj, newId );

            // Abort if no publisher was instantiated.
            if ( publisher == NULL )
            {
               brokerObj->setDropReason( "Publisher instantiation failed" );
               DtWarn << this->name() << " Translator dropping Portal object: "
                  << refObj->sr()->identifier().c_str() << std::endl;
               brokerObj->setPublisherPtr( publisher );
               brokerObj->setIsDropped( true );
               return;
            }

            // Set up the global ID Mapping
            if ( ! performDisGlobalIdMapping(publisher,*refObj) )
            {
               // Note that the object is being dropped in the log file.
               DtWarn << this->name() << " translator dropping Portal object: "
                  << refObj->sr()->identifier() << std::endl;

               // Abort if the name is invalid and destroy the publisher.
               brokerObj->setDropReason( "Name collision" );
               brokerObj->setPublisherPtr( NULL );
               brokerObj->setIsDropped( true );
               DtDELETE( publisher );
               return;
            }

            brokerObj->setPublisherPtr( publisher );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      DIS_TEMPLATE_LIST
      DtString DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::disObjectName(
         const T_PortalReflectedObject* refObj ) const
      {
         return refObj->sr()->identifier();
      }

      DIS_TEMPLATE_LIST
      DtEntityIdentifier DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::mapIdentifier(
         const T_PortalReflectedObject* refObj, const DtString& identifier )
      {
         // Get and convert the identifier.
         DtGlobalIdMapper::DisId newId = disBroker()->globalIdMapper()
            ->convertPortalGidToDisGid( identifier.string() );
         if ( newId == DtEntityIdentifier::nullId() )
         {
            newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
               refObj->sr()->entityIdentifier() );
         }
         return newId;
      }

      DIS_TEMPLATE_LIST
      DtEntityIdentifier DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::mapObjectId(
         const DtEntityIdentifier& identifier )
      {
         DtEntityIdentifier newId;
         DtEntityIdMapper* idMapper = disBroker()->entityIdMapper();
         if ( ! disBroker()->remapDisIds() )
         {
            newId = disBroker()->convertPortalEntIdToDisEntId( identifier );
         }
         else
         {
            if ( disBroker()->usePersistentIds() )
            {
               newId = idMapper->getPersistentId( identifier.string() );
               if ( newId.entityNum() > 0 )
               {
                  idMapper->add( identifier, newId );
               }
               else
               {
                  newId = idMapper->getNextDisId();
                  idMapper->add( identifier, newId );
                  idMapper->setPersistentId( identifier.string(), newId );
               }
            }
            else
            {
               newId = idMapper->getNextDisId();
               idMapper->add( identifier, newId );
            }
         }
         return newId;
      }

      DIS_TEMPLATE_LIST
      DtObjectPublisher* DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::instantiateDisPublisher(
         const T_PortalReflectedObject* refObj, const DtEntityIdentifier& objectName )
      {
         T_DisObjectPublisher* publisher = NULL;
         try
         {
            publisher = new T_DisObjectPublisher( disBroker()->connection(), objectName );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      DIS_TEMPLATE_LIST
      bool DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::performDisGlobalIdMapping(
         const DtObjectPublisher* publisher, const T_PortalReflectedObject& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         if ( ! disBroker()->globalIdMapper()->add( refObj.sr()->identifier(),
            publisher->globalId(), type, systemId, beamId ) )
         {
            if ( ! disBroker()->globalIdMapper()->unique( publisher->globalId(),
               type, systemId, beamId ) )
            {
               DtWarn << "Name collision on new portal object, " << this->name()
                  << " translator dropping object publisher: " << publisher->globalId() << std::endl;
            }
            else if ( ! disBroker()->globalIdMapper()->unique(refObj.sr()->identifier()) )
            {
               DtWarn << "Name collision on new portal object, " << this->name()
                  << " translator dropping reflected object: " << refObj.sr()->identifier() << std::endl;
            }
            return false;
         }
         return true;
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::createPortalPublisher(
         DtBrokerObject* brokerObj )
      {
         try
         {
            DtPortalObjectPublisherTemplate<T_PortalObject>* publisher =
               new DtPortalObjectPublisherTemplate<T_PortalObject>(
                  disBroker()->portalConnection() );

            const T_DisReflectedObject* refObj =
               static_cast<const T_DisReflectedObject*>( brokerObj->reflectedObjPtr() );

            DtString objectName = portalObjectName( refObj );

            publisher->sr()->setIdentifier( objectName );
            brokerObj->setObjectName( objectName );
            brokerObj->setPublisherPtr( publisher );

            // Set up the global ID Mapping
            if ( ! performPortalGlobalIdMapping(publisher,*refObj) )
            {
               // Note that the object is being dropped in the log file.
               DtWarn << this->name() << " translator dropping DIS object: "
                  << refObj->globalId() << std::endl;

               // Abort if the name is invalid and destroy the publisher.
               brokerObj->setDropReason( "Name collision" );
               brokerObj->setPublisherPtr( NULL );
               brokerObj->setIsDropped( true );
               DtDELETE( publisher );
            }
         }
         DtCATCH_AND_PROPAGATE( DtException );
      }

      DIS_TEMPLATE_LIST
      DtString DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::portalObjectName(
         const T_DisReflectedObject* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "vrx";
      }

      DIS_TEMPLATE_LIST
      bool DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::performPortalGlobalIdMapping(
         const DtPortalObjectPublisherTemplate<T_PortalObject>* publisher,
         const T_DisReflectedObject& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         if ( ! disBroker()->globalIdMapper()->add( publisher->sr()->identifier(),
            refObj.globalId(), type, systemId, beamId ) )
         {
            if ( ! disBroker()->globalIdMapper()->unique(publisher->sr()->identifier()) )
            {
               DtWarn << "Name collision on new DIS object, " << this->name()
                  << " translator dropping object publisher: " << publisher->sr()->identifier() << std::endl;
            }
            else if ( ! disBroker()->globalIdMapper()->unique(refObj.globalId()) )
            {
               DtWarn << "Name collision on new DIS object, " << this->name()
                  << " translator dropping reflected object: " << refObj.globalId() << std::endl;
            }
            return false;
         }
         return true;
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::receiveDisUpdate(
         T_DisReflectedObject& refObj )
      {
         try
         {
            DtBrokerObject* brokerObj = findBrokerObject( &refObj );
            if ( ! brokerObj )
            {
               DtWarn << "Received update call for deleted DIS object: "
                  << refObj.globalId() << std::endl;
               return;
            }

            T_DisObjectStateRepository& sr =
               static_cast<T_DisObjectStateRepository&>( *refObj.sr() );

            updateDisBrokerObject( brokerObj, sr );

            this->callObjectUpdateCallbacks( brokerObj );

            // Abort if the object has been dropped.
            if ( brokerObj->isDropped() )
            {
               return;
            }

            DtPortalObjectPublisherTemplate<T_PortalObject>* publisher =
               static_cast<DtPortalObjectPublisherTemplate<T_PortalObject>*>(
                  brokerObj->publisherPtr() );

            updateFilteredState( brokerObj, publisher, &refObj );

            T_PortalObject& newSr = *(publisher->sr());
            translate( &newSr, sr, refObj );

            if ( disBroker()->brokerInitializer()->oneToOneMapping() )
            {
               publisher->forceUpdate();
            }

            if ( disBroker()->isTranslatorDebuggingOn(this->name()) )
            {
               printIncomingOutgoingStateReps( sr, newSr );
            }

            performPortalDebugging( sr, newSr );
         }
         DtCATCH_AND_PROPAGATE( DtException );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::receivePortalUpdate(
         const T_PortalReflectedObject& refObj )
      {
         try
         {
            DtBrokerObject* brokerObj = findBrokerObject( &refObj );
            if ( ! brokerObj )
            {
               DtWarn << "Received update call for deleted Portal object: "
                  << refObj.sr()->identifier() << std::endl;
               return;
            }

            const T_PortalObject& sr = *(T_PortalObject*)(refObj.sr());

            updatePortalBrokerObject( brokerObj, sr );

            this->callObjectUpdateCallbacks( brokerObj );

            updateFilteredState( brokerObj, &refObj );

            // Abort if the object has been dropped or if its filtered.
            if ( brokerObj->isDropped() || brokerObj->isFiltered())
            {
               return;
            }

            T_DisObjectPublisher* publisher =
               static_cast<T_DisObjectPublisher*>( brokerObj->publisherPtr() );
            assert( publisher );

            T_DisObjectStateRepository& newSr =
               static_cast<T_DisObjectStateRepository&>( *publisher->sr() );

            translate( &newSr, sr, refObj );

            if ( disBroker()->brokerInitializer()->oneToOneMapping() )
            {
               publisher->forceUpdate();
            }

            if ( disBroker()->isTranslatorDebuggingOn(this->name()) )
            {
               printIncomingOutgoingStateReps( sr, newSr );
            }

            if ( this->isPublishEnabled() )
            {
               publisher->tick();
            }

            performPortalDebugging( sr, newSr );
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::updateDisBrokerObject(
         DtBrokerObject* brokerObj, const T_DisObjectStateRepository& sr )
      {
         brokerObj->setLastUpdate( disBroker()->simTime() );
         if ( ! brokerObj->isPublishable() )
         {
            brokerObj->setIsPublishable( this->isPortalPublishable(brokerObj) );
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::updatePortalBrokerObject(
         DtBrokerObject* brokerObj, const T_PortalObject& sr )
      {
         brokerObj->setLastUpdate( disBroker()->simTime() );
         if ( ! brokerObj->isPublishable() )
         {
            T_PortalReflectedObject* refObj =
               (T_PortalReflectedObject*) brokerObj->reflectedObjPtr();
            brokerObj->setIsPublishable( isDisPublishable(brokerObj,refObj) );
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::updateFilteredState( DtBrokerObject* brokerObj,
         DtPortalObjectPublisherTemplate<T_PortalObject>* publisher, T_DisReflectedObject* refObj )
      {
         if ( publisher )
         {
            // Get the unique ID then see if this has been marked as a filtered object
            const DtString id = publisher->sr()->identifier();
            const bool isFiltered = disBroker()->objectFilters().isNameFiltered( id );
            publisher->sr()->setFiltered( isFiltered );
            brokerObj->setIsFiltered( isFiltered );
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::updateFilteredState( DtBrokerObject* brokerObj,
         const T_PortalReflectedObject* refObj )
      {
         //NO OP - Overwrite in derived classes
      }

      DIS_TEMPLATE_LIST
      bool DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::filterLocation(
         const DtReflectedObject& refObj, const DtVector& location )
      {
         // Abort if there aren't any location filters configured.
         if ( ! disBroker()->disInitializer()->geoLocationFilters().size() )
         {
            return false;
         }

         // Check if the filtering has already been performed.
         LocationFilteringMap::iterator itr = myLocationFilteringMap.find( &refObj );
         if ( itr != myLocationFilteringMap.end() )
         {
            // Check if the filtering interval has elapsed.
            DtTime locFilterInterval =
               disBroker()->disInitializer()->locationFilteringInterval();
            DtTime curTime = disBroker()->connection()->clock()->absRealTime();
            if ( curTime - itr->second.first < locFilterInterval )
            {
               // Not time to check the location again, return previous result.
               return itr->second.second;
            }
         }

         // Check the latest location against the location filters.
         DtTime time = disBroker()->connection()->clock()->absRealTime();
         const DtFilterManager& objectFilters = disBroker()->objectFilters();
         bool isLocationFiltered = objectFilters.isLocationFiltered( location );
         LocationFilteringInfo filterData = std::make_pair( time, isLocationFiltered );
         myLocationFilteringMap[&refObj] = filterData;
         return isLocationFiltered;
      }

      DIS_TEMPLATE_LIST
      bool DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::filterLocation(
         const DtPortalReflectedObject& refObj, const DtVector& location )
      {
         // Abort if there aren't any location filters configured.
         if ( !disBroker()->disInitializer()->geoLocationFilters().size() )
         {
            return false;
         }

         /*TODO: Implement the following logic for published objects.  This will improve performance
         of filtering portal objects.

         // Check if the filtering has already been performed.
         LocationFilteringMap::iterator itr = myLocationFilteringMap.find(&refObj);
         if (itr != myLocationFilteringMap.end())
         {
            // Check if the filtering interval has elapsed.
            DtTime locFilterInterval =
               disBroker()->disInitializer()->locationFilteringInterval();
            DtTime curTime = disBroker()->connection()->clock()->absRealTime();
            if (curTime - itr->second.first < locFilterInterval)
            {
               // Not time to check the location again, return previous result.
               return itr->second.second;
            }
         }

         // Check the latest location against the location filters.
         DtTime time = disBroker()->connection()->clock()->absRealTime();*/
         const DtFilterManager& objectFilters = disBroker()->objectFilters();
         bool isLocationFiltered = objectFilters.isLocationFiltered( location, true );
         //LocationFilteringInfo filterData = std::make_pair(time, isLocationFiltered);
         //myLocationFilteringMap[&refObj] = filterData;
         return isLocationFiltered;
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::removeDisObject(
         const DtReflectedObject& refObj )
      {
         // Bail out if we are not publishing this one.
         DtBrokerObject* brokerObj = releaseBrokerObject( &refObj );
         if ( ! brokerObj )
         {
            return;
         }

         brokerObj->setLastUpdate( disBroker()->simTime() );

         deletePortalPublisher( brokerObj );

         this->callObjectRemoveCallbacks( brokerObj );

         DtDELETE( brokerObj );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::removePortalObject(
         const T_PortalReflectedObject& refObj )
      {
         // Bail out if we are not publishing this one.
         DtBrokerObject* brokerObj = releaseBrokerObject( &refObj );
         if ( ! brokerObj )
         {
            return;
         }

         brokerObj->setLastUpdate( disBroker()->simTime() );

         this->callObjectRemoveCallbacks( brokerObj );

         deleteDisPublisher( brokerObj );

         DtDELETE( brokerObj );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::deleteDisPublisher(
         DtBrokerObject* brokerObj )
      {
         try
         {
            T_DisObjectPublisher* publisher =
               static_cast<T_DisObjectPublisher*>( brokerObj->publisherPtr() );
            if ( publisher )
            {
               disBroker()->globalIdMapper()->remove( publisher->globalId() );
               brokerObj->setPublisherPtr( 0 );
               DtDELETE( publisher );
            }
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::deletePortalPublisher(
         DtBrokerObject* brokerObj )
      {
         try
         {
            DtPortalObjectPublisherTemplate<T_PortalObject>* publisher =
               static_cast<DtPortalObjectPublisherTemplate<T_PortalObject>*>(
                  brokerObj->publisherPtr() );
            if ( publisher )
            {
               disBroker()->globalIdMapper()->remove( publisher->sr()->identifier() );
               brokerObj->setPublisherPtr( 0 );
               DtDELETE( publisher );
            }
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::requestTransDiagCb(
         const DtRequestTranslationDiagnosticMessage& msg, void* usr )
      {
         ((DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>*)usr)->requestTransDiagCb( msg );
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::requestTransDiagCb(
         const DtRequestTranslationDiagnosticMessage& msg )
      {
         if ( msg.sendingEnabled() )
         {
            myTransDebugNames.insert( msg.objectName() );
            performPortalDebugging( msg.objectName() );
         }
         else
         {
            myTransDebugNames.erase( msg.objectName() );
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::printIncomingOutgoingStateReps(
         const DtPortalObject& incoming, const DtStateRepository& outgoing ) const
      {
         DtInfo << "======== ORIG (Portal) - " << this->name() << " ========" << std::endl;
         DtInfo << incoming;
         DtInfo << "======== NEW (DIS) - " << this->name() << " ========" << std::endl;
         outgoing.printData();
         DtInfo << "------------------------------------------------" << std::endl;
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::printIncomingOutgoingStateReps(
         const DtStateRepository& incoming, const DtPortalObject& outgoing ) const
      {
         DtInfo << "======== ORIG (DIS) - " << this->name() << " ========" << std::endl;
         incoming.printData();
         DtInfo << "======== NEW (Portal) - " << this->name() << " ========" << std::endl;
         DtInfo << outgoing;
         DtInfo << "------------------------------------------------" << std::endl;
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::performPortalDebugging(
         const DtString& objectName )
      {
         // Look up the object's DtBrokerObject, and abort if not found.
         DtBrokerObject* brokerObj = findBrokerObject( objectName );
         if ( ! brokerObj )
         {
            return;
         }

         // Get source and destination state repositories.
         // This needs to be done differently depending on whether it's a portal or protocol object.
         if ( brokerObj->isPortalObject() )
         {
            // Get reflected (Portal) object and state rep.
            const T_PortalReflectedObject* refObj =
               static_cast<const T_PortalReflectedObject*>( brokerObj->reflectedObjPtr() );
            const T_PortalObject& sr = *(T_PortalObject*)(refObj->sr());

            // Get publisher (HLA) and state rep.
            T_DisObjectPublisher* publisher =
               static_cast<T_DisObjectPublisher*>( brokerObj->publisherPtr() );
            T_DisObjectStateRepository& newSr =
               static_cast<T_DisObjectStateRepository&>(*publisher->sr());

            // Send translation monitoring message to Portal.
            performPortalDebugging( sr, newSr );
         }
         else
         {
            // Get reflected (HLA) object and state rep.
            const T_DisReflectedObject* refObj =
               static_cast<const T_DisReflectedObject*>( brokerObj->reflectedObjPtr() );
            const T_DisObjectStateRepository& sr =
               static_cast<const T_DisObjectStateRepository&>( *refObj->sr() );

            // Get publisher (Portal) and state rep.
            DtPortalObjectPublisherTemplate<T_PortalObject>* publisher =
               static_cast<DtPortalObjectPublisherTemplate<T_PortalObject>*>(
                  brokerObj->publisherPtr() );
            T_PortalObject& newSr = *(publisher->sr());

            // Send translation monitoring message to Portal.
            performPortalDebugging( sr, newSr );
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::performPortalDebugging(
         const DtPortalObject& incoming, const DtStateRepository& outgoing )
      {
         if ( myTransDebugNames.size() )
         {
            TransDebugObjectNamesSet::iterator itr =
               myTransDebugNames.find( incoming.identifier() );
            if ( itr != myTransDebugNames.end() )
            {
               std::ostringstream inStr;
               inStr << incoming;

               std::ostringstream outStr;
               outStr << outgoing;

               DtTranslationDiagnosticMessage msg;
               msg.setObjectName( incoming.identifier() );
               msg.setBrokerName( disBroker()->brokerName() );
               msg.setIncomingState( inStr.str().c_str() );
               msg.setOutgoingState( outStr.str().c_str() );
               disBroker()->portalConnection()->send( msg );
            }
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::performPortalDebugging(
         const DtStateRepository& incoming, const DtPortalObject& outgoing )
      {
         if ( myTransDebugNames.size() )
         {
            TransDebugObjectNamesSet::iterator itr =
               myTransDebugNames.find( outgoing.identifier() );
            if ( itr != myTransDebugNames.end() )
            {
               std::ostringstream inStr;
               inStr << incoming;

               std::ostringstream outStr;
               outStr << outgoing;

               DtTranslationDiagnosticMessage msg;
               msg.setObjectName( outgoing.identifier() );
               msg.setBrokerName( disBroker()->brokerName() );
               msg.setIncomingState( inStr.str().c_str() );
               msg.setOutgoingState( outStr.str().c_str() );
               disBroker()->portalConnection()->send( msg );
            }
         }
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::printDumpGuiToText(
         const DtBrokerObject& brokerObj, UpdateType updateType ) const
      {
         // Dump the update to test
         DtInfo << "Broker Update: type=";
         switch ( updateType )
         {
         case DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::none:
            DtInfo << "NONE";
            break;
         case DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::update:
            DtInfo << "UPDATE";
            break;
         case DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::remove:
            DtInfo << "REMOVE";
            break;
         case DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::discover:
            DtInfo << "DISCOVER";
            break;
         default: break;
         }
         DtInfo << " from " << (brokerObj.isPortalObject()?"PORTAL":"DIS");
         DtInfo << " at " << DtString(brokerObj.lastUpdate())
            << " (Translator: " << brokerObj.translatorName() << ")" << std::endl;
         DtInfo << "\tname=" << brokerObj.objectName() << std::endl;
         DtInfo << "\tdisId=" << brokerObj.objectId() << std::endl;
         DtInfo << "\tmarking=" << brokerObj.markingText() << std::endl;
         DtInfo << "\tpublishable=" << brokerObj.isPublishable() << std::endl;
         DtInfo << "\tdiscovered=" << brokerObj.isDiscovered() << std::endl;
         DtInfo << "\tdropped=" << brokerObj.isDropped() << std::endl;
         DtInfo << "\tfiltered=" << brokerObj.isFiltered() << std::endl;
      }

      DIS_TEMPLATE_LIST
      unsigned int DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::numObjects() const
      {
         return myPortalPublisherMap.size() + myDisPublisherMap.size();
      }

      DIS_TEMPLATE_LIST
      void DtDisObjectTranslator<DIS_TEMPLATE_FUNCTION>::shutdown()
      {
         DtBaseObjectTranslator<T_PortalObject,T_PortalReflectedObject>::shutdown();
         removeDisCallbacks();
      }


      //
      // DtDisInteractionTranslator
      //

      template <typename PortalInterType,typename DisInterType>
      DtDisInteractionTranslator<PortalInterType,DisInterType>::DtDisInteractionTranslator(
            DtBroker* broker, const DtString& name, DtPortalMessageKind kind )
         : DtBaseInteractionTranslator<PortalInterType>( broker, name, kind )
         , myInteractionWaitList()
      {
         if ( disBroker()->connection() == NULL )
         {
            DtTHROW_NEW( DtInvalidInput, "Attempted to instantiate " + this->name()
               + " translator whos broker has an invalid exercise connection." );
         }
      }

      template <typename PortalInterType,typename DisInterType>
      DtDisInteractionTranslator<PortalInterType,DisInterType>::~DtDisInteractionTranslator()
      {
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::enableReflectTranslator( bool enabled )
      {
         if ( this->myReflectEnabled != enabled )
         {
            if ( enabled )
            {
               this->initializeDisCallbacks();
            }
            else
            {
               this->removeDisCallbacks();
            }
            this->myReflectEnabled = enabled;
         }
      }

      template <typename PortalInterType,typename DisInterType>
      DtDisBroker* DtDisInteractionTranslator<PortalInterType,DisInterType>::disBroker()
      {
         return (DtDisBroker*) this->myBroker;
      }

      template <typename PortalInterType,typename DisInterType>
      const DtDisBroker* DtDisInteractionTranslator<PortalInterType,DisInterType>::disBroker() const
      {
         return (const DtDisBroker*) this->myBroker;
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::tick()
      {
         // Abort if the interaction timeout is set to zero.
         // If the timeout is set to zero, the wait-list will always be empty.
         DtTime timeoutDuration = disBroker()->disInitializer()->interactionWaitListTimeout();
         if ( ! timeoutDuration )
         {
            return;
         }

         // Iterate through the wait-list and check whether interactions are discoverable.
         bool sendExpired = disBroker()->disInitializer()->sendExpiredWaitListInteractions();
         typename InteractionWaitList::iterator itr = myInteractionWaitList.begin();
         typename InteractionWaitList::iterator end = myInteractionWaitList.end();
         DtTime curTime = disBroker()->portalConnection()->clock()->simTime();
         while ( itr != myInteractionWaitList.end() )
         {
            bool timedOut = ( ( curTime - itr->timeReceived() ) > timeoutDuration );
            bool discoverable = this->isPortalDiscoverable( *itr );

            // If the interaction timed out or became discoverable...
            if ( discoverable || timedOut )
            {
               // If interaction is discoverable or expired and should be sent..
               if ( discoverable || sendExpired )
               {
                  // Print some information to the log file.
                  if ( DtNotifyLevel >= DtNlVerbose )
                  {
                     DtVerbose << "Publishing wait-listed interaction:\n"
                        << *itr << std::endl;
                  }

                  // Perform translation and send interaction.
                  createInteraction( *itr );
               }
               else
               {
                  // Print some information to the log file.
                  if ( DtNotifyLevel >= DtNlVerbose )
                  {
                     DtVerbose << "Dropping wait-listed interaction:\n"
                        << *itr << std::endl;
                  }
               }

               // Remove the interaction from the waitlist.
               itr = myInteractionWaitList.erase( itr );

               // Avoid advancing the iterator twice.
               continue;
            }

            // Advance to the next waitlisted interaction.
            ++itr;
         }
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::initializeDisCallbacks()
      {
         DisInterType::addCallback( disBroker()->connection(),
            receiveDisInteraction, this );
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::removeDisCallbacks()
      {
         if ( this->myReflectEnabled )
         {
            DisInterType::removeCallback( disBroker()->connection(),
               receiveDisInteraction, this );
         }
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::receiveDisInteraction(
         DisInterType* inter, void* usr )
      {
         DtDisInteractionTranslator<PortalInterType,DisInterType>* trans =
            (DtDisInteractionTranslator<PortalInterType,DisInterType>*) usr;
         trans->receiveDisInteraction( *inter );
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::receiveDisInteraction(
         const DisInterType& inter )
      {
         createPortalInteraction( inter );
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::receivePortalInteraction(
         const PortalInterType& inter )
      {
         // If the interaction isn't discoverable...
         if ( ! this->isPortalDiscoverable(inter) )
         {
            // If there is a timeout, add the interaction to the wait list.
            if ( disBroker()->disInitializer()->interactionWaitListTimeout() )
            {
               if ( DtNotifyLevel >= DtNlVerbose )
               {
                  DtVerbose << "Mapping missing, postponing discovery."
                     " Interaction:\n" << inter << std::endl;
               }
               myInteractionWaitList.push_back( inter );
               return;
            }

            // If there isn't a timeout, and we're not sending
            // expired interactions, drop the interaction.
            if ( ! disBroker()->disInitializer()->sendExpiredWaitListInteractions() )
            {
               if ( DtNotifyLevel >= DtNlVerbose )
               {
                  DtVerbose << "Mapping missing, dropping interaction:\n"
                     << inter << std::endl;
               }
               return;
            }

            if ( DtNotifyLevel >= DtNlVerbose )
            {
               DtVerbose << "Mapping missing, sending interaction anyway." << std::endl;
            }
         }

         // Either the interaction is valid or it's not and we're sending it anyway.
         // Translate and send the interaction.
         createInteraction( inter );
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::createInteraction(
         const PortalInterType& in )
      {
         try
         {
            DisInterType out;
            translate( &out, in );

            if ( disBroker()->isTranslatorDebuggingOn(this->name()) )
            {
               printIncomingOutgoingInteractions( in, out );
            }
            disBroker()->connection()->sendStamped( out );
            ++this->myNumInteractions;
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::createPortalInteraction(
         const DisInterType& in )
      {
         try
         {
            PortalInterType out;
            translate( &out, in );

            if ( disBroker()->isTranslatorDebuggingOn(this->name()) )
            {
               printIncomingOutgoingInteractions( in, out );
            }
            disBroker()->portalConnection()->send( out );
            ++this->myNumInteractions;
         }
         DtCATCH_AND_PROPAGATE( DtException )
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::printIncomingOutgoingInteractions(
         const DtPortalInteraction& incoming, const DtInteraction& outgoing ) const
      {
         DtInfo << "======== ORIG (Portal) - " << this->name() << " ========" << std::endl;
         DtInfo << incoming;
         DtInfo << "======== NEW (DIS) - " << this->name() << " ========" << std::endl;
         outgoing.printData();
         DtInfo << "------------------------------------------------" << std::endl;
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::printIncomingOutgoingInteractions(
         const DtInteraction& incoming, const DtPortalInteraction& outgoing ) const
      {
         DtInfo << "======== ORIG (DIS) - " << this->name() << " ========" << std::endl;
         incoming.printData();
         DtInfo << "======== NEW (Portal) - " << this->name() << " ========" << std::endl;
         DtInfo << outgoing;
         DtInfo << "------------------------------------------------" << std::endl;
      }

      template <typename PortalInterType,typename DisInterType>
      bool DtDisInteractionTranslator<PortalInterType,DisInterType>::testGlobalIdMapping(
         const DtString& idName, const DtString& id )
      {
         // If the ID isn't set or is set to the null string, ID is ok as-is.
         if ( ! id.size() || id == DtEntityIdentifier().string() )
         {
            return true;
         }

         // If the ID maps to a valid entity identifier, the mapping is good.
         if ( disBroker()->convertGlobalId(id) != DtEntityIdentifier() )
         {
            return true;
         }

         // In any other case, the mapping is bad and discovery should be put off.
         DtInfo << this->name() << " Translator: No mapping found for "
            << idName << "." << std::endl;
         return false;
      }

      template <typename PortalInterType,typename DisInterType>
      void DtDisInteractionTranslator<PortalInterType,DisInterType>::shutdown()
      {
         DtBaseInteractionTranslator<PortalInterType>::shutdown();
         removeDisCallbacks();
      }

   }
}
