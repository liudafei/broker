/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file collisionTranslator.cxx
//! \brief Contains the DtCollisionTranslator class definition.
//! \ingroup disBroker

#include <disBroker/collisionTranslator.h>
#include <disBroker/eventIdMapper.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtCollisionTranslator::DtCollisionTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, translatorName(), DtPortalCollisionInteraction::theKind )
      {
      }

      DtCollisionTranslator::~DtCollisionTranslator()
      {
      }

      bool DtCollisionTranslator::isPortalDiscoverable(
         const DtPortalCollisionInteraction& inter )
      {
         return ( testGlobalIdMapping("Issuing Object ID",inter.issuingObjectIdentifier())
            && testGlobalIdMapping("Colliding Object ID",inter.collidingObjectIdentifier()) );
      }

      DtPortalCollisionInteraction* DtCollisionTranslator::translate(
         DtPortalCollisionInteraction* destination, const DtCollisionInteraction& source )
      {
         destination->setCollidingObjectIdentifier( disBroker()->convertGlobalId(source.collideId()) );
         destination->setIssuingObjectMass( source.mass() );
         destination->setIssuingObjectVelocityVector( source.velocity() );
         destination->setCollisionType( source.collisionType() );
         destination->setCollisionLocation( source.entityCoords() );
         destination->setEventIdentifier( disBroker()->eventIdMapper()->convertEventId( source.eventId() ));
         destination->setIssuingObjectIdentifier( disBroker()->convertGlobalId(source.issueId()) );

         return destination;
      }

      DtCollisionInteraction* DtCollisionTranslator::translate(
         DtCollisionInteraction* destination, const DtPortalCollisionInteraction& source )
      {
         destination->setCollideId( disBroker()->convertGlobalId(source.collidingObjectIdentifier()) );
         destination->setMass( source.issuingObjectMass() );
         destination->setVelocity( source.issuingObjectVelocityVector() );
         destination->setCollisionType( (DtCollisionType)source.collisionType() );
         destination->setEntityCoords( source.collisionLocation() );
         destination->setEventId( disBroker()->eventIdMapper()->convertEventId( source.eventIdentifier() ));
         destination->setIssueId( disBroker()->convertGlobalId(source.issuingObjectIdentifier()) );

         return destination;
      }

   }
}
