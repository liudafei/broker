/*****************************************************************************
 * Copyright (c) 2013 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file eventIdMapper.h
//! \brief Contains the DtEventIdMapper class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/dllExport.h>
#include <vlutil/vlMachineTypes.h>
#include <vlutil/vlString.h>
#include <map>

class DtEventId;

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //! \class DtEventIdMapper
      //! \ingroup disBroker
      //! \brief This class converts between DIS event ID's and Portal event ID's.
      //!
      //! There are two general strategies followed for mapping depending on the value
      //! of \e remapDisIds as passed to the constructor. If the broker is remapping,
      //! then a new event ID is created from the version passed in. It is stored in a table so
      //! that when we see that ID again we can look it up and use it.
      //! If the broker is not remapping, a new ID is constructed using the old one in a
      //! predictable and repeatable way, and nothing is stored between usages.
      class DT_DLL_DISBROKER DtEventIdMapper
      {
      public:

         //! \brief Constructor initializes members.
         //! \param [in] siteId Specifies the site to use when creating event ID's.
         //! \param [in] hostId Specifies the host to use when creating event ID's.
         //! \param [in] remapDisIds Specifies whether the
         //! \ref DtDisBroker broker is renaming DIS ID's.
         DtEventIdMapper( int siteId, int hostId, bool remapDisIds );

         //! \brief Destructor frees memory.
         virtual ~DtEventIdMapper();

         //! \brief Converts a Portal event ID to a DIS event ID.
         //!
         //! -# Parses the \e portalId to extract the event number (\e portalId
         //! is assumed to be an Portal event ID).
         //! -# If the \ref DtDisBroker "broker" is renaming DIS ID's, checks to
         //! see if \e portalId is in #myEventId map.  If it is, use that, otherwise
         //! construct a new event ID from #mySiteId, #myHostId, and #myNextIdCounter.
         //! -# If the \ref DtDisBroker "broker" is not renaming DIS ID's, check
         //! to see if \e portalId begins with "VRXD", which would signify it comes
         //! from another DIS broker.
         //! -# If it is from another DIS broker, parse out site/host and use that with
         //! #myNextIdCounter to create a new event ID, otherwise, use #mySiteId and
         //! #myHostId.
         //!
         //! \param [in] portalId The original Portal event ID.
         //! \return A DIS event ID that corresponds to \e portalId.
         const DtEventId& convertEventId(const DtString& portalId);

         //! \brief Converts a DIS event ID to a Portal event ID.
         //!
         //! -# If the \ref DtDisBroker "broker" is renaming DIS ID's, check to see if
         //! the \e disId is in #myEventId map.  If it is, use it to create a Portal
         //! ID.  If not, use #myNextIdCounter with #myFedName to create the ID.
         //! -# If the \ref DtDisBroker "broker" is not renaming DIS ID's, construct
         //! the Portal event ID as "VRXD#mySiteId:#myHostId".
         //!
         //! \param [in] disId The original DIS event ID.
         //! \return A Portal event ID that corresponds to \e disId.
         const DtString& convertEventId(const DtEventId& disId);

         //! \brief Sets whether the DtEventIdMapper is printing out debug statements.
         //!
         //! \param [in] debugOn Tells the DtEventIdMapper to print debug statements
         //! or not.\n\e true - print debug\n\e false - do not print debug
         virtual void setDebug(bool debugOn);

         //! \brief Returns whether the DtEventIdMapper is printing debug output.
         //!
         //! \return \e true if it is printing debug statements\n \e false if it
         //! is not printing debug statements
         virtual bool debug() const;

      private:

         // \brief Copy Constructor not implemented -- do not copy!
         DtEventIdMapper( const DtEventIdMapper& );

         // \brief Assignment Operator not implemented -- do not copy!
         DtEventIdMapper& operator = ( const DtEventIdMapper& );

      protected:

         //! \brief typedef for our map type.
         typedef std::map<DtString, unsigned long> StringULongMap;

         //! \brief The Portal ID <-> DIS ID map.
         StringULongMap        myEventIdMap;

         //! \brief Flag to determine whether the \ref DtDisBroker "broker" is
         //! renaming DIS ID's.
         bool                  myRemapDisIdsFlag;

         //! \brief The next event ID to be used.
         unsigned long         myNextIdCounter;

         //! \brief The \ref DtDisBroker "broker's" site ID.
         int                   mySiteId;

         //! \brief The \ref DtDisBroker "broker's" host ID.
         int                   myHostId;

         //! \brief Flag to determine whether the DtEventIdMapper prints debug
         //! output.
         bool                  myDebugOutputOn;

      };

      inline void DtEventIdMapper::setDebug(bool debugOn)
      {
         myDebugOutputOn = debugOn;
      }

      inline bool DtEventIdMapper::debug() const
      {
         return myDebugOutputOn;
      }

   }
}
