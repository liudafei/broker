/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file createEntityTranslator.h
//! brief Contains the DtCreateEntityTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pCreateEntityInter.h>
#include <vl/createEntityInteraction.h>

namespace MAKVrExchange
{

   class DtPortalCreateEntityInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides CreateEntity interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtCreateEntityTranslator
         : public DtDisInteractionTranslator<DtPortalCreateEntityInteraction,DtCreateEntityInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Create Entity" );

         //! \brief CTOR.
         DtCreateEntityTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtCreateEntityTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalCreateEntityInteraction& inter );

         //! \brief Translates the create entity interaction into the portal.
         virtual DtPortalCreateEntityInteraction* translate(
            DtPortalCreateEntityInteraction* destination, const DtCreateEntityInteraction& source );

         //! \brief Translates the portal create entity interaction from the portal.
         virtual DtCreateEntityInteraction* translate( DtCreateEntityInteraction* destination,
            const DtPortalCreateEntityInteraction& source );

      };

   }
}
