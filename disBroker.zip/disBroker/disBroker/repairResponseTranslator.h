/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file repairResponseTranslator.h
//! \brief Contains the DtRepairResponseTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <portal/pRepairResponseInteraction.h>
#include <vl/repairResponsePdu.h>

namespace MAKVrExchange
{

   class DtPortalRepairResponseInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides RepairResponse interaction translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtRepairResponseTranslator
         : public DtDisInteractionTranslator<DtPortalRepairResponseInteraction,DtRepairResponseInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Repair Response" );

         //! \brief CTOR.
         DtRepairResponseTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtRepairResponseTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalRepairResponseInteraction& inter );

         //! \brief Translates the repair response interaction into the portal.
         virtual DtPortalRepairResponseInteraction* translate(
            DtPortalRepairResponseInteraction* destination,
            const DtRepairResponseInteraction& source );

         //! \brief Translates the repair response interaction from the portal.
         virtual DtRepairResponseInteraction* translate( DtRepairResponseInteraction* destination,
            const DtPortalRepairResponseInteraction& source );

      };

   }
}
