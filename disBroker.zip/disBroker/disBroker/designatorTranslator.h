/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file designatorTranslator.h
//! \brief Contains the DtDesignatorTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/embeddedSystemTranslator.h>
#include <vl/reflectedDesignatorList.h>
#include <vl/designatorPublisher.h>

class DtReflectedDesignator;
class DtDesignatorRepository;

#define DESIGNATOR_TEMPLATE_ARGS \
   DtPortalDesignatorObject, DtPortalReflectedDesignatorObject, \
   DtReflectedDesignator, DtReflectedDesignatorList, \
   DtDesignatorRepository, DtDesignatorPublisher

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //! \brief Provides Designator object translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtDesignatorTranslator
         : public DtEmbeddedSystemTranslator<DESIGNATOR_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Designator" );

         //! \brief CTOR.
         DtDesignatorTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtDesignatorTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedDesignatorObject* refObj );

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Overridden to use the designator object type.
         virtual bool performDisGlobalIdMapping( const DtObjectPublisher* publisher,
            const DtPortalReflectedDesignatorObject& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Construct the portal object name.
         //! Overridden to construct a designator object name.
         virtual DtString portalObjectName( const DtReflectedDesignator* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Overridden to use the radio transmitter object type.
         virtual bool performPortalGlobalIdMapping(
            const DtPortalDesignatorObjectPublisher* publisher,
            const DtReflectedDesignator& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */);

         //! \brief Destroy the brokerObject's publisher.
         //! Overridden to correctly unmap the publisher's id.
         virtual void deleteDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Translates a Designator object into the portal.
         virtual DtPortalDesignatorObject* translate( DtPortalDesignatorObject* destination,
            const DtDesignatorRepository& source, const DtReflectedDesignator& refObj );

         //! \brief Translates a Designator object from the portal.
         virtual DtDesignatorRepository* translate( DtDesignatorRepository* destination,
            const DtPortalDesignatorObject& source, const DtPortalReflectedDesignatorObject& refObj );

      };

   }
}
