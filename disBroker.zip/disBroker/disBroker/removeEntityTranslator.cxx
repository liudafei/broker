/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file removeEntityTranslator.cxx
//! \brief Contains the DtRemoveEntityTranslator class definition.
//! \ingroup disBroker

#include <disBroker/removeEntityTranslator.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtRemoveEntityTranslator::DtRemoveEntityTranslator( DtBroker* broker )
         : ParentClass( broker, translatorName(), DtPortalRemoveEntityInteraction::theKind )
      {
      }

      DtRemoveEntityTranslator::~DtRemoveEntityTranslator()
      {
      }

      bool DtRemoveEntityTranslator::isPortalDiscoverable(
         const DtPortalRemoveEntityInteraction& inter )
      {
         return ( testGlobalIdMapping("Sender ID",inter.originatingId())
            && testGlobalIdMapping("Receiver ID",inter.receiverId()) );
      }

      DtPortalRemoveEntityInteraction* DtRemoveEntityTranslator::translate(
         DtPortalRemoveEntityInteraction* destination, const DtRemoveEntityInteraction& source )
      {
         destination->setOriginatingId( disBroker()->convertGlobalId(source.senderId()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setRequestId( source.requestId() );
         return destination;
      }

      DtRemoveEntityInteraction* DtRemoveEntityTranslator::translate(
         DtRemoveEntityInteraction* destination, const DtPortalRemoveEntityInteraction& source )
      {
         destination->setSenderId( disBroker()->convertGlobalId(source.originatingId()) );
         destination->setReceiverId( disBroker()->convertGlobalId(source.receiverId()) );
         destination->setRequestId( source.requestId() );
         return destination;
      }

   }
}
