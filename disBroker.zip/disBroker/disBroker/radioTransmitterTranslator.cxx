/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file radioTransmitterTranslator.cxx
//! \brief Contains the DtRadioTransmitterTranslator class definition.
//! \ingroup disBroker

#include <disBroker/radioTransmitterTranslator.h>
#include <disBroker/disBrokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtRadioTransmitterTranslator::DtRadioTransmitterTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, "Radio Transmitter", DtPortalRadioTransmitterObject::theKind )
      {
      }

      DtRadioTransmitterTranslator::~DtRadioTransmitterTranslator()
      {
      }

      bool DtRadioTransmitterTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedRadioTransmitterObject* refObj )
      {
         DtDisDiscoverableCriteria* discoveryCriteria =
            disBroker()->disInitializer()->discoveryCriteria();
         if ( discoveryCriteria->radioTransmitterNeedsEntityId() )
         {
            int index = refObj->sr()->radioIndex();
            DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::RadioTransmitterType;
            DtEntityIdentifier newId = disBroker()->globalIdMapper()->convertPortalGidToDisGid(
               refObj->sr()->identifier(), &objType, &index );
            if ( newId == DtEntityIdentifier::nullId() )
            {
               newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
                  refObj->sr()->entityIdentifier() );
            }
            if ( newId == DtEntityIdentifier::nullId() )
            {
               DtInfo << "DtRadioTransmitterTranslator: " << brokerObj->objectName()
                  << ": Entity Id not present, object incomplete" << std::endl;
               brokerObj->setDropReason( "Missing Entity ID" );
               return false;
            }
         }
         if ( discoveryCriteria->radioTransmitterNeedsHostId()
            && refObj->sr()->hostObjectIdentifier() == "" )
         {
            DtInfo << "DtRadioTransmitterTranslator: " << brokerObj->objectName()
               << ": Host Id not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Host ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<RADIO_XMIT_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedRadioTransmitterObject* refObj,
         const DtString& identifier )
      {
         // Get and convert the identifier.
         int index = refObj->sr()->radioIndex();
         DtGlobalIdMapper::ObjectType objType = DtGlobalIdMapper::RadioTransmitterType;
         DtGlobalIdMapper::DisId newId = disBroker()->globalIdMapper()
            ->convertPortalGidToDisGid( identifier.string(), &objType, &index );
         if ( newId == DtEntityIdentifier::nullId() )
         {
            newId = *disBroker()->entityIdMapper()->convertPortalEidToDisEid(
               refObj->sr()->entityIdentifier() );
         }
         return newId;
      }

      template <>
      DtObjectPublisher* DtDisObjectTranslator<RADIO_XMIT_TEMPLATE_ARGS>::instantiateDisPublisher(
         const DtPortalReflectedRadioTransmitterObject* refObj, const DtEntityIdentifier& name )
      {
         DtRadioTransmitterPublisher* publisher = NULL;
         try
         {
            publisher = new DtRadioTransmitterPublisher( disBroker()->connection(),
               name, refObj->sr()->radioIndex() );
         }
         DtCATCH_AND_WARN( DtWarn )
         return publisher;
      }

      bool DtRadioTransmitterTranslator::performDisGlobalIdMapping(
         const DtObjectPublisher* publisher, const DtPortalReflectedRadioTransmitterObject& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performDisGlobalIdMapping( publisher, refObj,
            DtGlobalIdMapper::RadioTransmitterType, refObj.sr()->radioIndex(),
            beamId );
      }

      DtString DtRadioTransmitterTranslator::portalObjectName(
         const DtReflectedRadioTransmitter* refObj ) const
      {
         DtString newObjectName( refObj->globalId().string() );
         newObjectName += "-";
         newObjectName += refObj->radioId();
         newObjectName += "Xvrx";
         return newObjectName;
      }

      bool DtRadioTransmitterTranslator::performPortalGlobalIdMapping(
         const DtPortalRadioTransmitterObjectPublisher* publisher,
         const DtReflectedRadioTransmitter& refObj,
         DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
         int systemId /* = DtGlobalIdMapper::NoSystemId */,
         int beamId /* = DtGlobalIdMapper::NoBeamId */ )
      {
         return ParentClass::performPortalGlobalIdMapping( publisher,
            refObj, DtGlobalIdMapper::RadioTransmitterType,
            refObj.tsr()->radioId(), beamId );
      }

      void DtRadioTransmitterTranslator::deleteDisPublisher( DtBrokerObject* brokerObj )
      {
         DtRadioTransmitterPublisher* publisher =
            static_cast<DtRadioTransmitterPublisher*>( brokerObj->publisherPtr() );
         const DtPortalReflectedRadioTransmitterObject* refObj =
            static_cast<const DtPortalReflectedRadioTransmitterObject*>(
               brokerObj->reflectedObjPtr() );
         if ( publisher && refObj )
         {
            DtU32 radioIndex = refObj->sr()->radioIndex();
            disBroker()->globalIdMapper()->remove( refObj->sr()->entityIdentifier(),
               DtGlobalIdMapper::RadioTransmitterType, radioIndex );
            brokerObj->setPublisherPtr( 0 );
            DtDELETE( publisher );
         }
      }

      DtPortalRadioTransmitterObject* DtRadioTransmitterTranslator::translate(
         DtPortalRadioTransmitterObject* destination, const DtRadioTransmitterRepository& source,
         const DtReflectedRadioTransmitter& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         DtVariableLengthData antPatternData( (char*)
            source.antennaPattern().netRep(), source.antennaPattern().netSize() );
         destination->setAntennaPatternType( source.antennaPatternType() );
         destination->setAntennaPatternData( antPatternData );

         destination->setEncryptionKeyIdentifier( source.cryptoKeyId() );
         destination->setCryptographicMode( source.cryptoMode() );
         destination->setCryptoSystem( source.cryptoSystem() );
         destination->setDetailedModulationType(source.detailedModulationType());

         DtU64 freq = ((DtU64)source.frequency( DtUpperWord ) << 32) |
            source.frequency(DtLowerWord);
         destination->setFrequency( freq );

         DtU64 streamTag = source.streamTag( DtUpperWord );
         streamTag <<= 8 * sizeof(source.streamTag());
         streamTag += source.streamTag( DtLowerWord );
         destination->setStreamTag( streamTag );

         destination->setFrequencyBandwidth( source.frequencyBandwidth() );
         destination->setFrequencyHopInUse(source.frequencyHopInUse());
         destination->setRadioInputSource( source.inputSource() );

         DtVariableLengthData modParamData( (char*)
            source.modulationParamsAddr(), source.modulationParamsLength() );
         destination->setModulationParamsData( modParamData );

         destination->setRFModulationType( source.majorModulationType() );
         destination->setRFModulationSystemType( source.modulationSystemType() );
         destination->setTransmittedPower( source.power() );
         destination->setPseudoNoiseSpectrumInUse(source.pseudoNoiseSpectrumInUse());
         destination->setRadioIndex( source.radioId() );
         destination->setRadioSystemType( source.radioEntityType().string() );
         destination->setTimeHopInUse( source.timeHopInUse() );
         destination->setTransmitterOperationalStatus( source.transmitState() );
         destination->setWorldLocation( source.worldAntennaLoc() );

         destination->setSpreadSpectrumType( source.spreadSpectrumType() );

         return destination;
      }

      DtRadioTransmitterRepository* DtRadioTransmitterTranslator::translate(
         DtRadioTransmitterRepository* destination, const DtPortalRadioTransmitterObject& source,
         const DtPortalReflectedRadioTransmitterObject& refObj )
      {
         // Translate embedded system attributes.
         ParentClass::translate( destination, source, refObj );

         DtAntennaPatternRecord antPatternData;
         antPatternData.setFromNet( source.antennaPatternData().data(),
            source.antennaPatternData().size() );
         destination->setAntennaPatternType( (DtAntennaPatternType) source.antennaPatternType() );
         destination->setAntennaPattern( antPatternData );

         destination->setCryptoKeyId( source.encryptionKeyIdentifier() );
         destination->setCryptoMode( (DtCryptoMode)source.cryptographicMode() );
         destination->setCryptoSystem( (DtRadioCryptoSystem)source.cryptoSystem() );
         destination->setDetailedModulationType((DtDetailedModulationType)source.detailedModulationType());

         DtU64 freq = source.frequency();
         destination->setFrequency( (DtU32)(freq >> 32), (DtU32) freq );

         const size_t bitCount = sizeof(char) * sizeof(destination->streamTag());
         unsigned long upper = source.streamTag() >> bitCount;
         unsigned long lower = source.streamTag() & ((DtU64)-1 >> bitCount );
         destination->setStreamTag( upper, lower );

         destination->setFrequencyBandwidth( source.frequencyBandwidth() );
         destination->setFrequencyHopInUse(source.frequencyHopInUse());
         destination->setInputSource( (DtRadioInputSource)source.radioInputSource() );

         destination->setModulationParams( source.modulationParamsData().data(),
            source.modulationParamsData().size() );

         destination->setMajorModulationType( (DtRadioMajorModulation)source.rfModulationType() );
         destination->setModulationSystemType( (DtRadioSystem)source.rfModulationSystemType() );
         destination->setPower( source.transmittedPower() );
         destination->setPseudoNoiseSpectrumInUse(source.pseudoNoiseSpectrumInUse());
         destination->setRadioId(source.radioIndex());
         destination->setRadioEntityType( source.radioSystemType().string() );
         destination->setTimeHopInUse( source.timeHopInUse() );
         destination->setTransmitState( (DtRadioTransmitState)source.transmitterOperationalStatus() );
         destination->setWorldAntennaLoc( source.worldLocation() );

         destination->setSpreadSpectrumType( (DtSpreadSpectrumType)source.spreadSpectrumType() );

         return destination;
      }

   }
}
