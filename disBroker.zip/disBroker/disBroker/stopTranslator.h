/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file stopTranslator.h
//! \brief Contains the DtStopTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/disTranslator.h>
#include <vl/stopFreezeInteraction.h>
#include <portal/pStopInter.h>

namespace MAKVrExchange
{

   class DtPortalStopInteraction;

   namespace DtDisBroker
   {

      class DtDisBroker;

      //! \brief Provides Stop interaction translation between DIS and the
      //! VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtStopTranslator
         : public DtDisInteractionTranslator<DtPortalStopInteraction,DtStopFreezeInteraction>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Stop" );

         //! \brief CTOR.
         DtStopTranslator( DtBroker* broker );

         //! \brief Virtual DTOR.
         virtual ~DtStopTranslator();

         //! \brief Checks whether the portal interaction can be processed yet.
         virtual bool isPortalDiscoverable( const DtPortalStopInteraction& inter );

         //! \brief Translates the stop interaction into the portal.
         virtual DtPortalStopInteraction* translate( DtPortalStopInteraction* destination,
            const DtStopFreezeInteraction& source );

         //! \brief Translates the stop interaction from the portal.
         virtual DtStopFreezeInteraction* translate( DtStopFreezeInteraction* destination,
            const DtPortalStopInteraction& source );

      };

   }
}
