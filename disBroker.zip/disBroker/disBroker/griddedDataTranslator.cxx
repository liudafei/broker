/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file griddedDataTranslator.cxx
//! \brief Contains the DtGriddedDataObjectTranslator class definition.
//! \ingroup disBroker

#include <disBroker/griddedDataTranslator.h>
#include <disBroker/disBrokerInitializer.h>

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      DtGriddedDataObjectTranslator::DtGriddedDataObjectTranslator( DtBroker* disBroker )
         : ParentClass( disBroker, "Gridded Data", DtPortalGriddedDataObject::theKind )
      {
      }

      DtGriddedDataObjectTranslator::~DtGriddedDataObjectTranslator()
      {
      }

      bool DtGriddedDataObjectTranslator::isDisPublishable( DtBrokerObject* brokerObj,
         const DtPortalReflectedGriddedDataObject* refObj )
      {
         if ( disBroker()->disInitializer()->discoveryCriteria()->griddedDataNeedsGridId()
            && refObj->sr()->gridIdentifier() == DtEntityIdentifier() )
         {
            DtInfo << "DtGriddedDataObjectTranslator: " << brokerObj->objectName()
                   << ": Grid ID not present, object incomplete" << std::endl;
            brokerObj->setDropReason( "Missing Grid ID" );
            return false;
         }

         brokerObj->setDropReason( "" );
         return true;
      }

      DtString DtGriddedDataObjectTranslator::disObjectName(
         const DtPortalReflectedGriddedDataObject* refObj ) const
      {
         return refObj->sr()->gridIdentifier().string();
      }

      void DtGriddedDataObjectTranslator::updateDisBrokerObject( DtBrokerObject* brokerObj,
         const DtGriddedDataRepository& sr )
      {
         ParentClass::updateDisBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.gridIdentifier().string() );
      }

      template <>
      DtEntityIdentifier DtDisObjectTranslator<GRIDDED_DATA_TEMPLATE_ARGS>::mapIdentifier(
         const DtPortalReflectedGriddedDataObject* refObj,
         const DtString& identifier )
      {
         return mapObjectId( DtEntityIdentifier(identifier) );
      }

      DtString DtGriddedDataObjectTranslator::portalObjectName(
         const DtReflectedGriddedData* refObj ) const
      {
         return DtString(refObj->globalId().string()) + "Gvrx";
      }

      void DtGriddedDataObjectTranslator::updatePortalBrokerObject(
         DtBrokerObject* brokerObj, const DtPortalGriddedDataObject& sr )
      {
         ParentClass::updatePortalBrokerObject( brokerObj, sr );
         brokerObj->setObjectId( sr.gridIdentifier().string() );
      }

      DtPortalGriddedDataObject* DtGriddedDataObjectTranslator::translate(
         DtPortalGriddedDataObject* destination, const DtGriddedDataRepository& source,
         const DtReflectedGriddedData& refObj )
      {
         // Base class attributes for DtPortalGriddedDataObject
         destination->setGridIdentifier( *disBroker()->entityIdMapper()->convertDisEidToPortalEid( source.gridIdentifier() ) );
         destination->setFieldNumber( source.fieldNumber() );
         destination->setRecordNumber( source.recordNumber() );
         destination->setRecordTotal( source.recordTotal() );
         destination->setCoordinateSystem( source.coordSystem() );
         destination->setNumGridAxis( source.numGridAxes() );
         destination->setConstantGrid( source.constantGrid() );
         destination->setEnvironmentType( source.environmentType() );
         destination->setOrientation( source.orientation() );
         destination->setSampleTime( (((DtU64)source.sampleTime(0)) << 32) + source.sampleTime(1) );
         destination->setTotalValues( source.totalValues() );
         destination->setVectorDim( source.vectorDim() );

         DtAttributeValuePairList gridAxesAttributes;
         std::vector<DtU32> gridAxesType;
         gridAxesType.resize(source.numGridAxes());
         int index;
         for ( index = 0; index < source.numGridAxes(); ++index)
         {
            gridAxesType[index] = source.gridAxisRecordType(index);
            if(gridAxesType[index] == DtGridAxisFixed)
            {
               DtGridAxisRecordFixed record;
               source.getGridAxisRecord(index, record);
               char* buffer = new char[record.recordLength_RPR_20()];
               DtNetGridAxisRecordFixed_RPR_20* netRecord =
                  (DtNetGridAxisRecordFixed_RPR_20*)buffer;
               record.baseLoadNetRecord(*netRecord);

               DtVariableLengthData data( (const char *)netRecord,
                  record.recordLength_RPR_20() );
               gridAxesAttributes.push_back( DtAttributeValuePair( "", data ) );

               delete buffer;
            }
            else if(gridAxesType[index] == DtGridAxisVariable)
            {
               DtGridAxisRecordVariable record;
               source.getGridAxisRecord(index, record);
               char* buffer = new char[record.recordLength_RPR_20()];
               DtNetGridAxisRecordVariable_RPR_20* netRecord =
                  (DtNetGridAxisRecordVariable_RPR_20*)buffer;
               record.loadNetRecord(*netRecord);

               DtVariableLengthData data( (const char *)netRecord,
                  record.recordLength_RPR_20() );
               gridAxesAttributes.push_back( DtAttributeValuePair( "", data ) );

               delete buffer;
            }
         }
         destination->setGridAxisType( gridAxesType );
         destination->setGridAxisRecord( gridAxesAttributes );

         DtAttributeValuePairList gridDataAttributes;
         std::vector<DtU32> gridDataType;
         gridDataType.resize(source.vectorDim());
         for ( index = 0; index < source.vectorDim(); ++index)
         {
            gridDataType[index] = source.gridDataRecordType(index);
            if(gridDataType[index] == DtGridDataRecType0)
            {
               DtGridDataRecordType0 record;
               source.getGridDataRecord(index, record);
               char* buffer = new char[record.recordLength_RPR2_Rev3()];
               DtNetGridDataRecordType0_RPR2_Rev3* netRecord =
                  (DtNetGridDataRecordType0_RPR2_Rev3*)buffer;
               record.loadNetRecord_RPR2_Rev3(*netRecord);

               DtVariableLengthData data( (const char *)netRecord,
                  record.recordLength_RPR2_Rev3() );
               gridDataAttributes.push_back( DtAttributeValuePair( "", data ) );

               delete buffer;
            }
            else if(gridDataType[index] == DtGridDataRecType1)
            {
               DtGridDataRecordType1 record;
               source.getGridDataRecord(index, record);
               char* buffer = new char[record.recordLength_RPR2_Rev3()];
               DtNetGridDataRecordType1_RPR2_Rev3* netRecord =
                  (DtNetGridDataRecordType1_RPR2_Rev3*)buffer;
               record.loadNetRecord_RPR2_Rev3(*netRecord);

               DtVariableLengthData data( (const char *)netRecord,
                  record.recordLength_RPR2_Rev3() );
               gridDataAttributes.push_back( DtAttributeValuePair( "", data ) );

               delete buffer;
            }
            else if(gridDataType[index] == DtGridDataRecType2)
            {
               DtGridDataRecordType2 record;
               source.getGridDataRecord(index, record);
               char* buffer = new char[record.recordLength_RPR2_Rev3()];
               DtNetGridDataRecordType2_RPR2_Rev3* netRecord =
                  (DtNetGridDataRecordType2_RPR2_Rev3*)buffer;
               record.loadNetRecord_RPR2_Rev3(*netRecord);

               DtVariableLengthData data( (const char *)netRecord,
                  record.recordLength_RPR2_Rev3() );
               gridDataAttributes.push_back( DtAttributeValuePair( "", data ) );

               delete buffer;
            }
         }
         destination->setGridDataType( gridDataType );
         destination->setGridDataRecord( gridDataAttributes );

         return destination;
      }

      DtGriddedDataRepository* DtGriddedDataObjectTranslator::translate(
         DtGriddedDataRepository* destination, const DtPortalGriddedDataObject& source,
         const DtPortalReflectedGriddedDataObject& refObj )
      {
         // Base class attributes for DtPortalGriddedDataObject
         destination->setGridIdentifier( *disBroker()->entityIdMapper()->convertPortalEidToDisEid( source.gridIdentifier() ) );
         destination->setFieldNumber( source.fieldNumber() );
         destination->setRecordNumber( source.recordNumber() );
         destination->setRecordTotal( source.recordTotal() );
         destination->setCoordSystem( (DtEnvironmentDataCoordSystem)source.coordinateSystem() );
         destination->setNumGridAxes( source.numGridAxis() );
         destination->setConstantGrid( (DtEnvironmentGridType)source.constantGrid() );
         destination->setEnvironmentType( source.environmentType() );
         destination->setOrientation( source.orientation() );
         destination->setSampleTime( 0, source.sampleTime() / (2^32) );
         destination->setSampleTime( 1, source.sampleTime() % (2^32) );
         destination->setTotalValues( source.totalValues() );
         destination->setVectorDim( source.vectorDim() );

         std::vector<DtU32> gridDataType = source.gridDataType();
         DtAttributeValuePairList dataAttributes = source.gridDataRecord();
         DtAttributeValuePairList::iterator pos = dataAttributes.begin();
         int index;
         for (index = 0; pos != dataAttributes.end(); ++pos)
         {
            if(gridDataType[index] == DtGridDataRecType0)
            {
               DtNetGridDataRecordType0_RPR2_Rev3 *data =
                  (DtNetGridDataRecordType0_RPR2_Rev3*)pos->second.data();
               DtGridDataRecordType0 record;
               record.unloadNetRecord_RPR2_Rev3(*data);

               destination->setGridDataRecord( index++, record );
            }
            else if(gridDataType[index] == DtGridDataRecType1)
            {
               DtNetGridDataRecordType1_RPR2_Rev3 *data =
                  (DtNetGridDataRecordType1_RPR2_Rev3*)pos->second.data();
               DtGridDataRecordType1 record;
               record.unloadNetRecord_RPR2_Rev3(*data);

               destination->setGridDataRecord( index++, record );
            }
            else if(gridDataType[index] == DtGridDataRecType2)
            {
               DtNetGridDataRecordType2_RPR2_Rev3 *data =
                  (DtNetGridDataRecordType2_RPR2_Rev3*)pos->second.data();
               DtGridDataRecordType2 record;
               record.unloadNetRecord_RPR2_Rev3(*data);

               destination->setGridDataRecord( index++, record );
            }
         }

         std::vector<DtU32> gridAxisType = source.gridAxisType();
         DtAttributeValuePairList axisAttributes = source.gridAxisRecord();
         DtAttributeValuePairList::iterator axisPos = axisAttributes.begin();
         for (index = 0; axisPos != axisAttributes.end(); ++axisPos)
         {
            if(gridAxisType[index] == DtGridAxisFixed)
            {
               DtNetGridAxisRecordFixed_RPR_20 *data =
                  (DtNetGridAxisRecordFixed_RPR_20*)axisPos->second.data();
               DtGridAxisRecordFixed record;
               record.baseUnloadNetRecord(*data);

               destination->setGridAxisRecord( index++, record );
            }
            else if(gridAxisType[index] == DtGridAxisVariable)
            {
               DtNetGridAxisRecordVariable_RPR_20 *data =
                  (DtNetGridAxisRecordVariable_RPR_20*)axisPos->second.data();
               DtGridAxisRecordVariable record;
               record.unloadNetRecord(*data);

               destination->setGridAxisRecord( index++, record );
            }
         }

         return destination;
      }

   }
}
