/****************************************************************************
 * Copyright (c) 2016 VT MAK
 * All rights reserved.
 ****************************************************************************/

//! \file additionalPassiveActivitiesTranslator.h
//! \brief Contains the DtAdditionalPassiveActivitiesTranslator class declaration.
//! \ingroup disBroker

#pragma once

#include <disBroker/underwaterAcousticTranslator.h>
#include <vl/additionalPassiveActivitiesPublisher.h>
#include <vl/reflectedAdditionalPassiveActivitiesList.h>

class DtReflectedAdditionalPassiveActivities;
class DtAdditionalPassiveActivitiesRepository;

#define ADD_PASS_ACT_TEMPLATE_ARGS \
   DtPortalAdditionalPassiveActivitiesObject, DtPortalReflectedAdditionalPassiveActivitiesObject, \
   DtReflectedAdditionalPassiveActivities, DtReflectedAdditionalPassiveActivitiesList, \
   DtAdditionalPassiveActivitiesRepository, DtAdditionalPassiveActivitiesPublisher

namespace MAKVrExchange
{

   namespace DtDisBroker
   {

      //! \brief Provides Additional Passive Activities translation between DIS and the VR-Exchange Portal.
      //! \ingroup disBroker
      class DT_DLL_DISBROKER DtAdditionalPassiveActivitiesTranslator
         : public DtUnderwaterAcousticTranslator<ADD_PASS_ACT_TEMPLATE_ARGS>
      {
      public:

         //! Static translatorName method returns the translator name.
         Dt_DEF_TRANSLATOR_NAME( "Additional Passive Activities" );

         //! \brief CTOR.
         DtAdditionalPassiveActivitiesTranslator( DtBroker* disBroker );

         //! \brief Virtual DTOR.
         virtual ~DtAdditionalPassiveActivitiesTranslator();

      protected:

         //! \brief Returns whether the incoming portal object can be discovered.
         //! Overridden to perform checks for valid identifiers.
         virtual bool isDisPublishable( DtBrokerObject* brokerObj,
            const DtPortalReflectedAdditionalPassiveActivitiesObject* refObj );

         //! Instantiates the publisher for the given reflected object.
         //! This may be overridden to modify the constructor used to create
         //! the publisher or perform additional publisher initialization.
         //! Default implementation attempts to create the publisher using
         //! the given name (the value returned from ::disObjectName), then
         //! attempts to create the publisher again with no name if the first
         //! attempt fails.
         //! Called by ::createDisPublisher.
         virtual DtObjectPublisher* instantiateDisPublisher(
            const DtPortalReflectedAdditionalPassiveActivitiesObject* refObj,
            const DtEntityIdentifier& name );

         //! \brief Creates a new publisher and handles identifier mapping.
         //! Overridden to perform additional passive activities specific mapping.
         virtual void createDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Construct the portal object name.
         //! Overridden to construct an additional passive activities object name.
         virtual DtString portalObjectName( const DtReflectedAdditionalPassiveActivities* refObj ) const;

         //! Maps the publisher's global ID to the reflected object's identifier.
         //! Returns true if the mapping was successful, or false otherwise.
         //! This method can be overridden to perform mapping for different types
         //! of objects as well (emitters, etc.).
         virtual bool performPortalGlobalIdMapping(
            const DtPortalAdditionalPassiveActivitiesObjectPublisher* publisher,
            const DtReflectedAdditionalPassiveActivities& refObj,
            DtGlobalIdMapper::ObjectType type /* = DtGlobalIdMapper::EntityType */,
            int systemId /* = DtGlobalIdMapper::NoSystemId */,
            int beamId /* = DtGlobalIdMapper::NoBeamId */ );

         //! \brief Processes incoming portal updates.
         //! Overridden to properly cast publisher to get the state rep.
         virtual void receivePortalUpdate( const DtPortalReflectedAdditionalPassiveActivitiesObject& object );

         //! \brief Destroy the brokerObject's publisher.
         //! Overridden to correctly destroy the instantiated publisher and
         //! remove it from the manager if underwater acoustic PDUs aren't split.
         virtual void deleteDisPublisher( DtBrokerObject* brokerObject );

         //! \brief Translates an Additional Passive Activities object into the portal.
         virtual DtPortalAdditionalPassiveActivitiesObject* translate(
            DtPortalAdditionalPassiveActivitiesObject* destination,
            const DtAdditionalPassiveActivitiesRepository& source,
            const DtReflectedAdditionalPassiveActivities& refObj );

         //! \brief Translates an Additional Passive Activities object from the portal.
         virtual DtAdditionalPassiveActivitiesRepository* translate(
            DtAdditionalPassiveActivitiesRepository* destination,
            const DtPortalAdditionalPassiveActivitiesObject& source,
            const DtPortalReflectedAdditionalPassiveActivitiesObject& refObj );

      };

   }
}
